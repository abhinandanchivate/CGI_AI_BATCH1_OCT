
from pydantic import BaseModel, Field, EmailStr, field_validator , ConfigDict
class CustomerCreate(BaseModel):
    # Input rules: full_name 2–100 valid letters/separators, email format, phone 10 digits starting 6–9.  ==> pydantic spec i.e. CustomerCreate

    full_name: str = Field(min_length=2, max_length=100, description="Full name must be 2-100 characters long and contain only letters and spaces.")
    email: EmailStr
    phone: str = Field(pattern=r'^[6-9]\d{9}$', description="Phone number must be 10 digits long and start with a digit between 6 and 9.")

    @field_validator('full_name')
    def validate_full_name(cls, value:str):
        value = " ".join(value.split())  # Remove extra spaces
        if len(value)< 2 or not all (c.isalpha() or c.isspace() for c in value):
            raise ValueError("Full name must be 2-100 characters long and contain only letters and spaces.")
        return value

class CustomerUpdate(CustomerCreate):
    pass
class CustomerOut(CustomerCreate):
    # Output rules: full_name, email, phone.  ==> pydantic spec i.e. CustomerOut
    id: int
    model_config = ConfigDict(from_attributes=True)
    # model_config : used to configure the model's behavior.
    # ConfigDict: configuration helper ==> from_attributes= true ==> it will tell pydentic to read the values from object attreibutes not onlly from dicts.
    # from_attributes: 
    pass
class AccountCreate(BaseModel):
    pass
class AccountUpdate(BaseModel):
    pass
class AccountOut(BaseModel):
    pass
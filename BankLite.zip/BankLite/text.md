pip : package manager ===> install , update , uninstall the packages.

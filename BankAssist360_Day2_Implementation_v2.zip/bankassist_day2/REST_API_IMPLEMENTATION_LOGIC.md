# BankAssist360 Day 2 — REST API Logical Implementation Workbook

**Scope:** S006–S010 | Beginner-friendly | Python + FastAPI + SQLAlchemy + MySQL | Synthetic data only.

This is the missing **HOW TO IMPLEMENT** companion to `README.md`. Use both: this guide explains the decisions and coding sequence; the README shows setup and execution. All function names and routes below match the provided runnable source `app/main.py`.

> **Learning contract:** Database facts are authoritative. The LLM only drafts text. Each draft receives an audit and stays `PENDING` until an authorized reviewer decides. A review does not approve a refund or notify a customer. The offline path is deterministic, not GenAI.

## A. Understand one complete REST request before writing an endpoint

A REST endpoint is more than `@app.get` or `@app.post`. Every endpoint must answer:

1. **Who can invoke it?** No key, demo key, or reviewer key?
2. **What is input?** Path variable, header, JSON body, or dependency?
3. **How is the input validated?** Pydantic, authentication, existence, business state?
4. **Where does data come from?** MySQL, static catalog, or approved model provider?
5. **Which business rule runs?** Filter fields, guardrail, one-time review, etc.?
6. **Which side effects occur?** Read only; LLM call; insert audit; update review?
7. **What is the output contract?** JSON properties and HTTP status codes?
8. **How will we test it?** Happy path + authentication + missing record + malicious/invalid input?

### Request lifecycle

```mermaid
sequenceDiagram
    participant P as Postman
    participant U as Uvicorn
    participant F as FastAPI router
    participant D as Dependencies
    participant S as Service/business logic
    participant M as MySQL / LLM
    P->>U: HTTP method + URL + headers + JSON
    U->>F: Dispatch matching route
    F->>D: Resolve Header(), Depends(get_db), Pydantic
    D-->>F: Authorized context / validated inputs / Session
    F->>S: Call business function
    S->>M: Query or inference when needed
    M-->>S: Facts or draft
    S-->>F: Result or domain failure
    F-->>P: Serialized JSON + HTTP code
```

### Architecture responsibilities (important for learners)

| Layer / actual code | Role | Must **not** do |
|---|---|---|
| Router: `@app.get`, `@app.post` | Accept HTTP request and delegate | Invent transaction facts |
| Dependency: `demo_auth`, `reviewer_auth`, `get_db` | Authenticate, acquire DB session | Generate explanations |
| ORM: `Transaction`, `Audit` | Represent persisted tables | Make financial decisions |
| Schema: `TransactionOut`, `VariationIn`, `ReviewIn` | Validate / limit data | Expose memo or secrets |
| Business helpers: `fact_allowlist`, `validate_draft`, `create_explanation` | Apply banking teaching rules | Treat memo as instructions |
| Provider adapter: `generate_text`, `build_messages` | Use approved LLM or offline template | Claim offline text is GenAI |
| Reviewer endpoint: `review` | Apply state transition | Modify `Transaction.status` or approve refunds |

The small source package implements these layers mostly in **one file** (`app/main.py`) for ease of teaching; these are *logical layers*, not separate import modules in this version. Production projects should separate them.

## B. Implement common foundation FIRST (do this once)

### Foundation 1 — Environment configuration

**Why:** The same code must run against local MySQL and either offline or an approved LLM without hardcoding provider credentials.

**Open:** `app/main.py` → `class Settings(BaseSettings)` and `settings = Settings()`.

**Understand:** `BaseSettings` reads matching uppercase environment variables from `.env`. `provider_mode` accepts only `offline` or `llm`. `llm_api_key` stays server-side. The `.env` file must never be committed.

**Try:** Set `PROVIDER_MODE=offline` and check `/health`. To run a genuine LLM, configure all `LLM_*` values and restart the server.

### Foundation 2 — Database ORM and session

**Why:** Business data and audits must persist in MySQL instead of vanishing when Python stops.

**Open:** `engine = create_engine(...)`, `SessionLocal = sessionmaker(...)`, `class Transaction`, `class Audit`, and `get_db()`.

```python
engine = create_engine(settings.database_url, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)

def get_db():
    with SessionLocal() as db:
        yield db
```

**Logic:** engine configures connectivity → session factory creates per-request unit of work → FastAPI `Depends(get_db)` supplies session to route → context manager closes session after request. `db.get(Transaction, id)` retrieves by PK; `db.scalars(select(...)).all()` gets a list; `db.add` + `db.commit` persists.

**Checkpoint:** `Transaction` includes `memo` only for the adversarial test; `TransactionOut` does **not** include `memo`. `Audit` holds generated text and review status.

### Foundation 3 — Auth dependencies

**Why:** Trainees should retrieve and draft without acquiring review authority.

```python
def demo_auth(x_demo_key: str | None = Header(default=None)) -> None:
    if x_demo_key != settings.demo_api_key:
        raise HTTPException(status_code=401, detail="Invalid or missing demo key")
```

**Logic:** FastAPI converts `x_demo_key` to HTTP header `x-demo-key`. Reject before the route handler runs. `reviewer_auth` similarly reads `x-reviewer-key` and returns 403 on mismatch.

**Exercise:** Remove the key from a protected request; confirm endpoint business logic never executes.

### Foundation 4 — Database initialization

**Why:** A learner needs known rows before testing the endpoints.

**Open:** `lifespan()` → `Base.metadata.create_all(engine)` → `seed_synthetic_data()`.

**Logic:** At app startup, create missing lab tables and insert missing TXN101–TXN106. Do not treat automatic table creation as a production migration strategy. For a real deployment use migrations and controlled data loading.

---

# Endpoint 1 — GET `/health`

### 1. User story, inputs, outputs

**Who:** Trainer/operations user, no key. **What:** Check app's DB connectivity and model configuration. **Inputs:** none. **Expected result:** JSON stating database health, offline/LLM mode, and whether LLM configuration exists. **Side effects:** none.

### 2. Logical implementation steps

1. Define a GET route because health inspection is read-only.
2. Request `db: Session = Depends(get_db)` so FastAPI injects a session.
3. Run a cheap database query, `SELECT 1`, inside `try`.
4. If it succeeds, set `database=healthy`; if it fails, set `database=unavailable` (without exposing connection secrets).
5. Read `settings.provider_mode` and check whether all required LLM config fields are present. **Do not** call the LLM.
6. Return a JSON dictionary; FastAPI serializes it.

### 3. Code to implement (`app/main.py`)

```python
@app.get("/health")
def health(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        db_status = "healthy"
    except Exception:
        db_status = "unavailable"
    return {
        "status": "ok" if db_status == "healthy" else "degraded",
        "database": db_status,
        "provider_mode": settings.provider_mode,
        "llm_configured": bool(settings.llm_base_url and settings.llm_model and settings.llm_api_key),
    }
```

### 4. Walkthrough and checks

`@app.get` registers route; `Depends` injects session; `text('SELECT 1')` checks DB; booleans in `llm_configured` only mean settings are supplied, not that inference works.

**Postman:** GET `http://127.0.0.1:8000/health`, no body/header. **Expected offline:** `status=ok`, `database=healthy`, `provider_mode=offline`, `llm_configured=false`. Stop the MySQL container; `database=unavailable` should appear. Start MySQL again.

**Design warning:** A health response of 200 with `status=degraded` is suitable for this teaching contract, but production readiness checks may deliberately return 503.

---

# Endpoint 2 — GET `/model-selection`

### 1. User story

**Who:** Trainee. **What:** See which banking tasks require DB, rules, ML, GenAI, or an authorized workflow. **Input:** none. **Output:** static JSON catalog. **Side effects:** none. **This endpoint does not perform ML inference.**

### 2. Logical implementation steps

1. Write 5 example banking tasks on paper.
2. Identify source of truth for each task: lookup/decision/prediction/generation/financial action.
3. Represent each example as a JSON object: `task`, `choice`, `why`.
4. Register a GET endpoint; no database dependency is needed.
5. Return an object with an `examples` array.

### 3. Code

```python
@app.get("/model-selection")
def model_selection():
    return {"examples": [
        {"task": "Look up transaction status", "choice": "Database", "why": "Exact persisted record"},
        {"task": "Evaluate status equals FAILED", "choice": "Rules", "why": "Deterministic condition"},
        {"task": "Predict fraud risk", "choice": "Validated ML", "why": "Statistical prediction"},
        {"task": "Write explanation from facts", "choice": "Text LLM", "why": "Language generation"},
        {"task": "Approve a refund", "choice": "Authorized workflow", "why": "Controlled financial action"},
    ]}
```

### 4. Test and explanation

**Postman:** GET `http://127.0.0.1:8000/model-selection`. **Expected:** exactly 5 catalog entries. **Instructor asks:** Why not use an LLM to return `FAILED`? Because the DB already has that value. **Optional code change:** add another task, restart and observe output change; explain why it is still not an LLM request.

---

# Endpoint 3 — GET `/api/v1/transactions`

### 1. User story and contract

**Who:** Authenticated trainee. **Input:** `x-demo-key` header. **Output:** array of six verified transactions, with no memo. **Side effects:** none.

### 2. Logical implementation steps

1. Create an ORM entity with fields `transaction_id`, `amount`, `currency`, `direction`, `status`, `merchant`, `transaction_date`, plus internal `memo`.
2. Write a Pydantic response schema, `TransactionOut`, containing **only** the seven approved fields.
3. Add the authentication dependency to the GET route.
4. Inject a database session.
5. Build a SQLAlchemy `select(Transaction)` query and order by ID so training results are stable.
6. Run `db.scalars(query).all()` to receive ORM objects.
7. Return objects through FastAPI's `response_model=list[TransactionOut]`; Pydantic serializes only allowlisted fields.
8. Verify both success and missing-key paths.

### 3. Code

```python
class TransactionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    transaction_id: str
    amount: Decimal
    currency: str
    direction: str
    status: str
    merchant: str
    transaction_date: date

@app.get(
    "/api/v1/transactions",
    response_model=list[TransactionOut],
    dependencies=[Depends(demo_auth)],
)
def list_transactions(db: Session = Depends(get_db)):
    query = select(Transaction).order_by(Transaction.transaction_id)
    return db.scalars(query).all()
```

### 4. Trace the program

Postman sends GET + key → `demo_auth` checks string → `get_db` produces Session → `select` represents SQL query → MySQL returns rows → ORM converts rows to `Transaction` instances → `TransactionOut` filters response → FastAPI returns JSON. `memo` is present in DB but **never** in response schema.

**Successful test:** GET URL with header `x-demo-key: demo-training-key`; expect IDs TXN101–TXN106. **Negative tests:** no key → 401; search response for `memo` or `Ignore prior instructions` → absent. **Important:** Hiding a field in API output is not sufficient for LLM safety; the prompt builder also needs an independent allowlist.

---

# Endpoint 4 — POST `/api/v1/explanations/{transaction_id}`

### 1. Business contract

**Who:** Trainee. **Input:** path ID (`TXN104`), `x-demo-key`; no body. **Output:** internal draft + provider + flags + unique audit ID + `PENDING`. **Side effect:** new `Audit` row. **In `llm` mode only**, one external inference request.

### 2. Implement helpers in dependency order

**Helper A: choose approved facts.**

```python
def fact_allowlist(txn: Transaction) -> dict:
    return {
        "transaction_id": txn.transaction_id,
        "amount": f"{txn.amount:.2f}",
        "currency": txn.currency,
        "direction": txn.direction,
        "status": txn.status,
        "merchant": txn.merchant,
        "transaction_date": txn.transaction_date.isoformat(),
    }
```

**Why:** `memo` is excluded by construction; don't pass `txn.__dict__` or all ORM fields to an external model.

**Helper B: construct model messages.** `build_messages(facts)` returns system instructions forbidding invented outcomes and a user message containing JSON-serialized approved fields. This function performs **no inference**; it's just data preparation.

**Helper C: connect the provider.** `generate_text(facts, temperature)` does one of two things:

- `offline`: interpolate the fields into a deterministic reference template; label model `deterministic-template`.
- `llm`: verify `LLM_BASE_URL`, `LLM_MODEL`, `LLM_API_KEY`, build `/chat/completions` URL, send JSON `model`, `messages`, `temperature`, `max_tokens` with bearer authentication, parse `choices[0].message.content`. Return controlled 502 on provider failure and 503 on missing configuration; don't fall back silently.

**Helper D: validate response.** `validate_draft(draft, facts)` checks exact factual anchors and selected known unsafe expressions; it returns a list of flags. **Limitation:** string/regex tests can miss semantic hallucinations, so a clean flag list is not proof of safety.

**Helper E: orchestrate and persist.** `create_explanation(db, transaction_id, temperature)` retrieves the row, transforms fields, calls generation, validates, inserts `Audit`, commits and builds response. By extracting this helper, variability can reuse exactly the same logic.

### 3. Implementation of orchestration

```python
async def create_explanation(db: Session, transaction_id: str, temperature: float) -> dict:
    import json
    txn = db.get(Transaction, transaction_id)
    if txn is None:
        raise HTTPException(status_code=404, detail="Transaction not found")
    facts = fact_allowlist(txn)
    draft, model = await generate_text(facts, temperature)
    flags = validate_draft(draft, facts)
    audit = Audit(
        audit_id=str(uuid.uuid4()),
        transaction_id=transaction_id,
        provider=settings.provider_mode,
        model=model,
        draft=draft,
        flags=json.dumps(flags),
        review_status="PENDING",
    )
    db.add(audit)
    db.commit()
    return {
        "audit_id": audit.audit_id,
        "transaction_id": transaction_id,
        "provider": audit.provider,
        "model": model,
        "draft": draft,
        "flags": flags,
        "review": audit.review_status,
    }

@app.post("/api/v1/explanations/{transaction_id}", dependencies=[Depends(demo_auth)])
async def explain(transaction_id: str, db: Session = Depends(get_db)):
    return await create_explanation(db, transaction_id, temperature=0.2)
```

### 4. Trace each line at runtime

`{transaction_id}` captures path segment → dependency checks demo key → `db.get` hits MySQL → `fact_allowlist` strips memo → `generate_text` returns template or model output → `validate_draft` lists known issues → UUID creates unique audit ID → `db.add` stages the new row → `db.commit` persists it → JSON includes `review=PENDING`. `await` matters because HTTP inference uses asynchronous I/O. No transaction state is modified.

### 5. Workflow

```mermaid
flowchart TD
 A[POST explanation with ID] --> B{Demo key valid?}
 B -- No --> X[401]
 B -- Yes --> C[Load Transaction from MySQL]
 C --> D{Found?}
 D -- No --> Y[404]
 D -- Yes --> E[Create allowlisted facts, exclude memo]
 E --> F{Provider mode?}
 F -- offline --> G[Deterministic template]
 F -- llm --> H[POST approved chat completion]
 H --> I{Success?}
 I -- No --> Z[Controlled 502/503]
 I -- Yes --> J[Candidate draft]
 G --> J
 J --> K[Validator returns flags]
 K --> L[Persist unique Audit: PENDING]
 L --> M[Return JSON]
```

### 6. Test contract

POST `http://127.0.0.1:8000/api/v1/explanations/TXN104`; header `x-demo-key: demo-training-key`, no body. Expect `audit_id`, `draft`, `flags`, `provider=offline` initially, `review=PENDING`. Run TXN999 → 404. Run TXN103 → no malicious memo instruction in text. Configure LLM settings and restart for genuine inference. Save outputs for TXN101–TXN105.

**Business checkpoint:** Even if `flags=[]`, review must still be PENDING. The endpoint drafts text; it cannot authorize a refund.

---

# Endpoint 5 — POST `/api/v1/explanations/{transaction_id}/variability`

### 1. Business contract

**Who:** Trainee. **Inputs:** ID, demo key, optional JSON `{"temperature":0.7}`. **Output:** 3 generated results, 3 distinct audits, `unique_count`. **Side effect:** 3 new audit records. In offline mode all three strings should be identical.

### 2. Logical implementation steps

1. Define `VariationIn(BaseModel)` with `temperature: float = Field(default=0.7, ge=0, le=1.5)`.
2. Register POST under `/api/v1/explanations/{transaction_id}/variability`, before thinking about UI.
3. Add demo authentication and DB session.
4. Verify transaction exists **before** entering the 3-run loop.
5. Call shared `create_explanation()` three times; each runs generation, validation and commits a **new** audit.
6. Compute `{item["draft"] for item in results}`; its length counts exact distinct strings.
7. Return transaction, draw count, temperature, uniqueness and full results.

### 3. Code

```python
class VariationIn(BaseModel):
    temperature: float = Field(default=0.7, ge=0, le=1.5)

@app.post("/api/v1/explanations/{transaction_id}/variability",
          dependencies=[Depends(demo_auth)])
async def variability(transaction_id: str, body: VariationIn | None = None,
                      db: Session = Depends(get_db)):
    body = body or VariationIn()
    if db.get(Transaction, transaction_id) is None:
        raise HTTPException(status_code=404, detail="Transaction not found")
    results = []
    for _ in range(3):
        results.append(await create_explanation(db, transaction_id, body.temperature))
    return {"transaction_id": transaction_id, "runs": len(results),
            "temperature": body.temperature,
            "unique_count": len({item["draft"] for item in results}),
            "results": results}
```

### 4. Execution and expectations

Postman POST `.../explanations/TXN105/variability`, demo key, `Content-Type: application/json`, body `{"temperature":0.7}`. Check `runs=3`, 3 different UUIDs, `unique_count` between 1 and 3. In offline mode expect 1. Change temperature to 2.5 → 422 from Pydantic. In LLM mode compare **factual meaning**, not merely different wording. An unavailable provider partway through the loop may leave earlier audit records committed; this is a teaching implementation, not an all-or-nothing batch transaction.

---

# Endpoint 6 — GET `/api/v1/audits/{audit_id}`

### 1. Business contract

**Who:** Reviewer (reviewer key only). **Input:** `audit_id` path. **Output:** stored draft, model, validation flags, original allowlisted facts, review state. **Side effects:** none.

### 2. Logical implementation steps

1. Protect route with `Depends(reviewer_auth)`.
2. Create a DB Session with `Depends(get_db)`.
3. Retrieve audit by primary key: `db.get(Audit, audit_id)`.
4. Return 404 if absent.
5. Retrieve transaction referenced by `audit.transaction_id`.
6. Convert evidence through `fact_allowlist`, not raw ORM serialization.
7. Deserialize flag JSON using `json.loads(audit.flags)`.
8. Return review information and timestamp, never the untrusted memo.

### 3. Code

```python
@app.get("/api/v1/audits/{audit_id}", dependencies=[Depends(reviewer_auth)])
def get_audit(audit_id: str, db: Session = Depends(get_db)):
    import json
    audit = db.get(Audit, audit_id)
    if audit is None:
        raise HTTPException(status_code=404, detail="Audit not found")
    txn = db.get(Transaction, audit.transaction_id)
    return {
        "audit_id": audit.audit_id,
        "transaction_id": audit.transaction_id,
        "provider": audit.provider,
        "model": audit.model,
        "draft": audit.draft,
        "flags": json.loads(audit.flags),
        "review_status": audit.review_status,
        "review_reason": audit.review_reason,
        "evidence": fact_allowlist(txn),
        "created_at": audit.created_at.isoformat(),
    }
```

### 4. Test sequence

Create explanation and copy its actual `audit_id` → GET `/api/v1/audits/<id>` with `x-reviewer-key: reviewer-training-key` → confirm evidence matches TXN104 and `PENDING`. Missing reviewer key → 403; unknown audit ID → 404. Explain difference between **candidate text**, **validator flags**, **verified facts** and **reviewer decision**.

---

# Endpoint 7 — POST `/api/v1/reviews/{audit_id}`

### 1. Business contract

**Who:** Reviewer. **Input:** audit ID, reviewer key, JSON body with `decision` and `reason`. **Output:** one persisted review decision. **Side effect:** UPDATE `audits` only. **Never:** modify original transaction or approve payments/refunds.

### 2. Implement state machine before the API

```mermaid
stateDiagram-v2
    [*] --> PENDING: explanation created
    PENDING --> APPROVED_FOR_INTERNAL_USE: human review and no flags
    PENDING --> REJECTED: human review
    APPROVED_FOR_INTERNAL_USE --> [*]
    REJECTED --> [*]
```

**Rule 1:** Only two input values are accepted: `APPROVED_FOR_INTERNAL_USE` and `REJECTED` (Pydantic `Literal`).

**Rule 2:** Require a meaningful reason (min 5, max 1000 chars).

**Rule 3:** Only `PENDING` audits may be reviewed; second decision must return 409.

**Rule 4:** A flagged draft cannot be approved (but may be rejected). Reviewer must still independently verify an unflagged draft.

**Rule 5:** Use MySQL `SELECT ... FOR UPDATE` so simultaneous requests don't both act on PENDING. Keep the lock until commit.

### 3. Code

```python
class ReviewIn(BaseModel):
    decision: Literal["APPROVED_FOR_INTERNAL_USE", "REJECTED"]
    reason: str = Field(min_length=5, max_length=1000)

@app.post("/api/v1/reviews/{audit_id}", dependencies=[Depends(reviewer_auth)])
def review(audit_id: str, body: ReviewIn, db: Session = Depends(get_db)):
    import json
    audit = db.scalar(select(Audit).where(Audit.audit_id == audit_id).with_for_update())
    if audit is None:
        raise HTTPException(status_code=404, detail="Audit not found")
    if audit.review_status != "PENDING":
        raise HTTPException(status_code=409, detail="This audit has already been reviewed")
    if body.decision == "APPROVED_FOR_INTERNAL_USE" and json.loads(audit.flags):
        raise HTTPException(status_code=409, detail="Flagged draft cannot be approved")
    audit.review_status = body.decision
    audit.review_reason = body.reason
    db.commit()
    return {"audit_id": audit.audit_id, "review_status": audit.review_status,
            "review_reason": audit.review_reason}
```

### 4. Execution

- First POST explanation TXN104 to obtain a new audit ID.
- Inspect it through GET `/audits/{id}` and compare evidence.
- POST `/api/v1/reviews/{id}` with reviewer key and `Content-Type: application/json`.
- Body: `{"decision":"APPROVED_FOR_INTERNAL_USE","reason":"Checked each claim against synthetic source transaction."}` for a valid draft, or a REJECTED decision with a supported reason.
- GET audit again; expect persisted decision.
- POST second review for same ID → 409; invalid decision or too-short reason → 422; demo key instead of reviewer key → 403.

### 5. Important transaction nuance

`with_for_update()` locks the selected MySQL row **within a DB transaction**. The next `db.commit()` both persists the decision and releases that lock. In a real service, implement proper reviewer identity/roles, audit reviewer identity/time, explicit rollback on errors, concurrency integration tests and transactional error handling.

---

## C. Build order for learners: 18 actionable coding checkpoints

| # | Write / find in code | What is the logic? | Immediate verification |
|---:|---|---|---|
| 1 | `Settings` | Read DB/LLM/keys from environment | Start app, view `/health` |
| 2 | `create_engine` | Build DB pool | Query `SELECT 1` |
| 3 | `Transaction` | Define persisted source-of-truth fields | Query rows |
| 4 | `Audit` | Define draft+review persistence | Later inspect audit table |
| 5 | `SessionLocal` + `get_db` | Per-request session | Check Session injection |
| 6 | `seed_synthetic_data` | Six known records | Query transaction list |
| 7 | `demo_auth` | Restrict agent functions | No key → 401 |
| 8 | `reviewer_auth` | Separate reviewer capabilities | No reviewer key → 403 |
| 9 | `/health` | Operational introspection | DB on/off |
| 10 | `/model-selection` | Deterministic model-choice catalog | Five choices |
| 11 | `TransactionOut` + `/transactions` | Safe DB read & serialization | No memo |
| 12 | `fact_allowlist` | Exclude hostile memo at LLM boundary | Inspect facts |
| 13 | `build_messages` | Separate instructions from data | Inspect messages |
| 14 | `generate_text` | Offline template vs actual HTTP inference | Provider reflects mode |
| 15 | `validate_draft` | Known rule checks | Inject unsafe phrase |
| 16 | `create_explanation` + POST route | Compose services and persist audit | ID + PENDING |
| 17 | `/variability` | Repeat generation, audit each output | 3 audit IDs |
| 18 | `/audits` + `/reviews` | Inspect evidence and enforce one-time decision | 403, 409 and status update |

## D. End-to-end implementation exercises (write these assertions)

**Exercise D1 — HTTP validation:** For each protected endpoint, omit the appropriate header and record 401/403. For variability send `{"temperature":2.5}` and expect 422.

**Exercise D2 — Data minimization:** Assert `"memo" not in GET /transactions` and hostile TXN103 memo does not appear in serialized `build_messages(fact_allowlist(txn))`.

**Exercise D3 — Explanation correctness:** For each of TXN101–TXN105 inspect ID, amount, merchant, date, direction and status; every candidate must remain PENDING. Don't interpret `flags=[]` as semantic assurance.

**Exercise D4 — Hallucination:** Pass a manufactured draft with `Your refund is approved` to `validate_draft`; assert `UNSUPPORTED_REFUND_APPROVAL` appears. Pass an extra `INR 900.00`; assert `UNSUPPORTED_AMOUNT`.

**Exercise D5 — Variability:** In offline mode run 3 draws and verify 3 unique audit IDs, 1 unique string. In genuine LLM mode record actual uniqueness and compare meaning; difference is neither guaranteed nor evidence of better quality.

**Exercise D6 — Reviewer gate:** Approve/reject a clean pending draft, read audit again and confirm persistence, attempt second decision → 409. For flagged draft, attempt approval → 409.

## E. Common errors, exact explanations and fixes

| Problem | Why it happens | Debug first |
|---|---|---|
| `ModuleNotFoundError: pymysql` | Missing driver | `python -m pip install -r requirements.txt` in active venv |
| MySQL `Connection refused` | Docker stopped / wrong mapped port | `docker ps`, use host `127.0.0.1:3307` |
| `401 Invalid or missing demo key` | Wrong/missing `x-demo-key` | Postman Headers tab |
| `403 Reviewer access denied` | Wrong/missing `x-reviewer-key` | Reviewer-only header |
| `404 Transaction not found` | ID absent from seeded data | GET transaction list |
| `422` for variability/review | Pydantic body validation failed | Check JSON body, temperature and decision |
| `503 LLM mode is not fully configured` | Missing LLM endpoint/model/key | `.env` and server restart |
| `502 LLM inference failed` | Provider rejected/failed response | Check provider compatibility/configuration outside response logs |
| `409 This audit has already been reviewed` | One-time review state rule | Generate a new draft/audit |
| `409 Flagged draft cannot be approved` | Unsafe candidate | Reject it and correct upstream generator/checks |
| `unique_count=1` | Same strings across all runs | Valid result; offline mode always deterministic |

## F. What we deliberately do NOT claim

- The package is **not production banking code**. Demo keys, startup table creation, heuristic validator and simplistic auditing must be replaced.
- This guide is aligned to the actual `app/main.py` reference implementation; it is not a claim that a multi-file services architecture is already present.
- Real LLM invocation requires an approved OpenAI-compatible chat completions API. Offline output is deterministic.
- No code here infers refund, account balance, fraud, cause, payment settlement or a financial decision from an LLM.
- A passing guardrail test only proves the *specific test condition*, not general freedom from hallucinations.

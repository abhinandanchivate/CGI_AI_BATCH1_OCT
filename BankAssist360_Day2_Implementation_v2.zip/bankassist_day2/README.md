# BankAssist360 — Day 2: Implementation and Execution Lab

**START HERE FOR IMPLEMENTATION LOGIC:** [`REST_API_IMPLEMENTATION_LOGIC.md`](REST_API_IMPLEMENTATION_LOGIC.md) — detailed step-by-step coding design, Python functions, flowcharts, validation rules and exercises for every endpoint.


**Scope:** S006–S010. Six synthetic transactions, five initial internal drafts, deterministic offline mode, optional genuine OpenAI-compatible chat completions, injected-memo exclusion, audit and one-time reviewer decision. Not suitable for live banking or real customer information.

## 0. Prerequisites (why and expected output)

- Python 3.11–3.13, Docker Engine, Postman or Swagger, approved LLM chat-completions API for genuine GenAI.
- Python venv isolates dependencies; MySQL persists records and audits; FastAPI exposes HTTP endpoints.
- Never paste genuine customer data or production keys into this training app.

## 1. Start MySQL (10 minutes)

In a shell:

```bash
docker run -d --name bankassist360-mysql -e MYSQL_ROOT_PASSWORD=trainingRoot123 -e MYSQL_DATABASE=bankassist360 -e MYSQL_USER=bankassist -e MYSQL_PASSWORD=training123 -p 3307:3306 mysql:8.4
docker exec bankassist360-mysql mysqladmin ping -h 127.0.0.1 -u root -ptrainingRoot123
```

Expected: `mysqld is alive`. The `-p 3307:3306` syntax maps local port 3307 to the container's port 3306. All credentials are synthetic demo values. If already created use `docker start bankassist360-mysql`.

## 2. Start the application (10 minutes)

From the folder containing `requirements.txt`:

**Windows PowerShell**
```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python -m uvicorn app.main:app --reload
```

**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env
python -m uvicorn app.main:app --reload
```

Expected Swagger: http://127.0.0.1:8000/docs. Startup creates the schema and inserts six synthetic records, idempotently, for training only. In production use Alembic migrations and separate provisioning.

### File walkthrough

`app/main.py` contains the models (`Transaction`, `Audit`), settings, database session, authentication dependencies, allowlisted facts, trusted prompt construction, LLM adapter, heuristic validator, and seven endpoints. `scripts/run_5_cases.py` produces the output evidence. `tests/test_guardrails.py` checks that hostile memo text is excluded and catches known unsafe output patterns.

**Key boundary:** `fact_allowlist()` explicitly copies approved columns from `Transaction`. `memo` does not appear in this map, in the prompt builder, or in the public response model.

## 3. Endpoint #1: GET /health

**Purpose:** Verify service and DB health, show configured inference mode.

**Implementation path:** FastAPI route `health()` → `get_db()` → `SELECT 1` → response with status, db and mode. It does not perform a live LLM request.

**Postman**:
1. New HTTP Request → GET.
2. URL `http://127.0.0.1:8000/health`.
3. No headers needed. Click Send.
4. Verify `database: healthy`, `provider_mode: offline`, and `llm_configured: false`.
5. Stop the database temporarily and observe `database: unavailable` (the API itself must remain running). Restart DB.

Example:
```json
{"status":"ok","database":"healthy","provider_mode":"offline","llm_configured":false}
```

**Expected evidence:** JSON screenshot. **Interpretation:** DB connectivity success does not prove model reachability.

## 4. Endpoint #2: GET /model-selection

**Purpose:** Select technology appropriately for each banking action (S006/S008).

**Implementation path:** `model_selection()` returns a deterministic catalog of `task`, `choice`, `why` items. It is NOT model inference.

**Postman**:
1. Create GET `http://127.0.0.1:8000/model-selection`.
2. No authentication. Send.
3. Identify database lookup vs deterministic rules vs validated predictive ML vs text LLM vs authorized financial workflow.
4. Record a short justification for each mapping.

**Expected:** Five items. **Evidence:** completed model-selection note.

## 5. Endpoint #3: GET /api/v1/transactions

**Purpose:** Obtain six allowed records without exposing memos.

**Implementation path:** `demo_auth()` checks header → `get_db()` opens SQLAlchemy session → `select(Transaction).order_by(...)` → `TransactionOut` response-model filter. `memo` is omitted at schema layer.

**Postman**:
1. Create GET `http://127.0.0.1:8000/api/v1/transactions`.
2. Headers: `x-demo-key: demo-training-key`.
3. Send. Expect HTTP 200 and six rows TXN101–TXN106.
4. Verify amounts/status and presence of merchant/date/direction.
5. Search raw response for `memo` and `Ignore prior instructions`; neither should appear.
6. Remove key and retry. Expect HTTP 401.

**Evidence:** six redacted/allowlisted records and unauthenticated failure screenshot.

## 6. Endpoint #4: POST /api/v1/explanations/{transaction_id}

**Purpose:** Generate an evidence-grounded internal draft. In offline mode it is a fixed template; in LLM mode it performs real inference.

**Implementation path:**
1. `demo_auth()` rejects missing key.
2. `create_explanation()` retrieves transaction via `db.get(Transaction, transaction_id)`; returns 404 if missing.
3. `fact_allowlist()` constructs ID, amount, currency, direction, status, merchant, date; memo not included.
4. `build_messages()` packages trusted instructions plus allowlisted facts.
5. `generate_text()` uses deterministic template in offline mode or POST to the configured chat-completions endpoint in `llm` mode.
6. `validate_draft()` checks required fact strings, unsupported amount and selected unsafe claims. These heuristics cannot establish full semantic accuracy.
7. `Audit(...)` persists UUID, provider, model, draft, flags, `PENDING`.
8. API returns audit ID and internal draft. No financial action, publication or customer message is performed.

**Postman**:
1. Create POST `http://127.0.0.1:8000/api/v1/explanations/TXN104`.
2. Header: `x-demo-key: demo-training-key`.
3. Body: none. Send.
4. Confirm `provider: offline`, `review: PENDING`, `audit_id`, `flags`, `draft`.
5. Retry with TXN999. Expect 404.
6. Try TXN103. Verify hostile memo does not affect the draft.
7. For genuine GenAI: stop Uvicorn, edit `.env` to `PROVIDER_MODE=llm`, set `LLM_BASE_URL` to the provider API base path (e.g. an authorized URL ending `/v1`), `LLM_MODEL` and `LLM_API_KEY`. Restart. Verify `/health` reports `llm` mode and then retry. The example adapter adds `/chat/completions` automatically. It requires an *OpenAI-compatible* service; for providers using another API shape implement a dedicated adapter. Some providers reject `temperature` or other request parameters; adjust to their documentation.
8. Run `python scripts/run_5_cases.py` and check `evidence/results/TXN101.json` through `TXN105.json`.

**Expected:** five distinct audit IDs, all initially `PENDING`. Each draft carries its own validation flags. Be careful: a provider error should return controlled 502/503, **not** silent template fallback.

## 7. Endpoint #5: POST /api/v1/explanations/{transaction_id}/variability

**Purpose:** Compare independent generation draws (S009).

**Implementation path:** demo auth → existence check → loop three times over `create_explanation()` with same facts and configured temperature → each call generates/validates/persists its own audit → exact-string uniqueness count returned.

**Postman**:
1. Create POST `http://127.0.0.1:8000/api/v1/explanations/TXN105/variability`.
2. Headers: `x-demo-key: demo-training-key`, `Content-Type: application/json`.
3. Body → raw JSON: `{ "temperature": 0.7 }`.
4. Send. Confirm `runs: 3`, three distinct `audit_id` values and `unique_count` from 1 to 3.
5. In offline mode, expect the deterministic template to produce `unique_count: 1`.
6. In genuine LLM mode, wording may or may not vary; variation is not guaranteed. Compare semantic claims, not only the strings.
7. Send `{ "temperature": 2.5 }` and confirm HTTP 422 because this *teaching API* limits values to 0–1.5. Provider constraints may be narrower.

**Evidence:** three outputs, three audit IDs and a commentary on whether any variation changes the facts.

## 8. Endpoint #6: GET /api/v1/audits/{audit_id}

**Purpose:** Provide review evidence and traceability.

**Implementation path:** `reviewer_auth()` → query `Audit` → query its related `Transaction` → `fact_allowlist()` evidence → deserialize `flags` → return candidate, model, provider, review and facts.

**Postman**:
1. Copy a real `audit_id` from endpoint #4 or #5.
2. Create GET `http://127.0.0.1:8000/api/v1/audits/<ACTUAL_AUDIT_ID>`.
3. Header: `x-reviewer-key: reviewer-training-key`.
4. Send. Compare `draft` claims against `evidence` and `flags`.
5. Remove reviewer key. Expect HTTP 403.
6. Try an unknown audit UUID. Expect 404.

**Evidence:** reviewer notes noting supported/unsupported factual claims.

## 9. Endpoint #7: POST /api/v1/reviews/{audit_id}

**Purpose:** Accept one final internal review decision. Never update transaction status or approve refunds.

**Implementation path:** `reviewer_auth()` → `SELECT ... FOR UPDATE` audit row → verify `PENDING` → reject approval of draft with flags → persist decision and reason in DB → commit → return status. Row locking prevents concurrent reviewer decisions from silently overwriting each other in MySQL.

**Postman**:
1. Copy a `PENDING` audit ID.
2. Create POST `http://127.0.0.1:8000/api/v1/reviews/<ACTUAL_AUDIT_ID>`.
3. Headers: `x-reviewer-key: reviewer-training-key`, `Content-Type: application/json`.
4. For an acceptable draft, Body → raw JSON:
```json
{"decision":"APPROVED_FOR_INTERNAL_USE","reason":"Verified all required fields against the synthetic source transaction."}
```
5. For a bad draft, send a different *pending* audit ID and:
```json
{"decision":"REJECTED","reason":"Draft states refund approval without an authoritative source."}
```
6. Confirm returned status. GET its audit again to verify persistence.
7. Repeat POST for the same audit. Expect HTTP 409.
8. Use only demo key in place of reviewer key. Expect HTTP 403.

**Expected:** one-time decision, review reason stored, no external message or financial operation.

## 10. Automated negative tests and instructor checklist

```bash
python -m pytest -q
```

`test_memo_excluded_from_llm_payload` checks that an adversarial memo never reaches the prompt. `test_unsafe_refund_is_flagged` checks a known invented refund promise. `test_unsupported_amount_is_flagged` checks an additional invented currency amount. This is not an exhaustive safety or integration test suite.

**Exit package:** five draft JSON files, uniqueness experiment, prompt-exclusion test, amount/refund tests, audit evidence, reviewer decision, model-selection note and risk register.

## 11. Architecture and trust boundaries

```mermaid
flowchart TD
  A[Postman / Swagger trainee] --> B[FastAPI + demo auth]
  B --> C[(MySQL transactions)]
  C --> D[Allowlisted transaction facts]
  C --> X[Untrusted memo: excluded]
  D --> E[Trusted prompt construction]
  E --> F{PROVIDER_MODE}
  F -->|offline| G[Deterministic reference]
  F -->|llm| H[Approved chat-completion API]
  G --> I[Candidate internal draft]
  H --> I
  I --> J[Heuristic checks]
  J --> K[(Audit in MySQL: PENDING)]
  K --> L[Human semantic review]
  L --> M[Approved for INTERNAL use or Rejected]
```

**Explicit training limitations:** Demonstration credentials, table auto-creation, relaxed access design, no production-grade migration/identity/secret rotation/PII handling/retention, and incomplete claim detection. Always keep real customer data out of this lab.

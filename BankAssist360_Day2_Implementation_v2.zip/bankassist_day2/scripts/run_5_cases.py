"""Run five authenticated explanation calls and save separate evidence JSON files."""
import json
import os
from pathlib import Path
import httpx

base = os.getenv("API_URL", "http://127.0.0.1:8000")
key = os.getenv("DEMO_API_KEY", "demo-training-key")
evidence = Path("evidence/results")
evidence.mkdir(parents=True, exist_ok=True)
with httpx.Client(timeout=60) as client:
    for n in range(101, 106):
        transaction_id = f"TXN{n}"
        response = client.post(f"{base}/api/v1/explanations/{transaction_id}",
                               headers={"x-demo-key": key})
        response.raise_for_status()
        payload = response.json()
        (evidence / f"{transaction_id}.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print(transaction_id, payload["audit_id"], payload["flags"], payload["review"])

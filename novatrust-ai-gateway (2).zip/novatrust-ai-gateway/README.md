# NovaTrust Responsible AI Gateway

One banking demo for sessions **S011–S016**: bias mitigation, security, guardrails and prompt engineering.
All data is synthetic. LLM calls run on **Google Gemini** by default (`gemini-3.6-flash`);
Anthropic and OpenAI are optional alternatives, and **mock mode** runs everything with no API key.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                     # add GEMINI_API_KEY (or leave blank for mock mode)
uvicorn app.main:app --reload --port 8000
```

Open http://127.0.0.1:8000/docs and follow the lab guide, or run the scripted walkthrough:

```bash
python scripts/demo_runner.py                 # all sessions
python scripts/demo_runner.py --session S013 --pause
pytest -q                                     # smoke tests (mock mode)
```

## Layout

```
app/
  main.py                     FastAPI app, platform endpoints (/health, /audit/log)
  core/
    config.py                 env settings, provider auto-detect, canary secret
    llm.py                    one complete() for gemini | anthropic | openai | mock
    assistant.py              "Nova" chatbot pipeline with defense levels none|basic|full
    injection.py              L1 input screen, L2 spotlighting, L3 output check
    moderation.py             rules / LLM judge / OpenAI moderation
    pii.py                    Indian banking PII detection + redact/mask/pseudonymize/hash
    audit.py                  in-memory audit log
  data/
    synthetic.py              loan applications (biased labels + proxies), customer accounts
    knowledge_base.py         policy snippets + keyword retrieval (mini RAG)
  modules/
    s011_bias.py              fairness metrics, reweighing, resampling, threshold optimizer
    s012_security.py          chat with injection defense, anonymization, differential privacy
    s013_guardrails.py        moderation, Constitutional AI loop, red-team suite, RLHF preference capture
    s014_prompt_anatomy.py    prompt builder from named parts + context types
    s015_shots.py             zero / one / few-shot complaint triage + evaluation
    s016_cot.py               loan eligibility: direct vs CoT vs self-consistency, rule-engine ground truth
scripts/demo_runner.py        guided walkthrough against a running server
tests/test_endpoints.py       smoke tests
```

## Provider settings (.env)

| Variable | Meaning |
|---|---|
| `LLM_PROVIDER` | `gemini` (default), `anthropic`, `openai` or `mock`; blank = auto-detect from keys |
| `GEMINI_API_KEY` | Key from Google AI Studio (`GOOGLE_API_KEY` also works) |
| `GEMINI_MODEL` | Default `gemini-3.6-flash`; any current Gemini model id |
| `GEMINI_THINKING_LEVEL` | Optional `minimal`, `low`, `medium` or `high`; blank = model default |
| `ANTHROPIC_MODEL` / `OPENAI_MODEL` | Only if you use those providers |
| `DP_TOTAL_BUDGET` | Total epsilon an analyst session may spend (default 5.0) |

Mock mode is for running the lab offline. It returns clearly labelled `[MOCK]` answers; the S012/S013
mock deliberately behaves like a *naive* model so attacks are visible. Use a real provider for the
S014–S016 quality comparisons.

### Gemini notes

- Gemini 3.x ignores `temperature`, `top_p` and `top_k` (future models reject them), so the adapter
  never sends them. Self-consistency in S016 still samples several answers, but diversity comes from
  the model itself rather than a temperature setting.
- Thinking tokens count toward the output budget, so the adapter sends at least 2,048 output tokens.
- If Gemini's own safety filter blocks a request, the adapter returns a refusal string, which the
  gateway and the S013 red-team judge treat as a refusal.

### RLHF data capture (S013)

`/s013/rlhf/generate-pair` redacts PII before calling the LLM, stores the pair server-side and returns a
`pair_id`. `/s013/rlhf/feedback` accepts only `{pair_id, preferred, reason, labeler_id}`, so labels cannot be
attached to text the model never produced, and each labeler can label a pair once. Safety checks are stored
as flags on each record; they never block or rewrite the model's answers, because that would corrupt the
preference data.

"""Offline test of the Gemini adapter: the google-genai client is replaced by a fake."""
from types import SimpleNamespace

from app.core import config, llm


class _FakeModels:
    def __init__(self, reply):
        self.reply, self.calls = reply, []

    def generate_content(self, model, contents, config):
        self.calls.append({"model": model, "contents": contents, "config": config})
        return self.reply


def _patch(monkeypatch, reply):
    fake = _FakeModels(reply)
    import google.genai as genai
    monkeypatch.setattr(genai, "Client", lambda: SimpleNamespace(models=fake))
    monkeypatch.setattr(config, "LLM_PROVIDER", "gemini")
    return fake


def test_gemini_request_shape(monkeypatch):
    fake = _patch(monkeypatch, SimpleNamespace(text="Hello from Gemini"))
    monkeypatch.setattr(config, "GEMINI_THINKING_LEVEL", "low")
    out = llm.complete("SYS", "question", temperature=0.7, max_tokens=60,
                       history=[{"role": "user", "content": "hi"}, {"role": "assistant", "content": "hello"}])
    assert out["text"] == "Hello from Gemini" and out["provider"] == "gemini"
    call = fake.calls[0]
    assert [c.role for c in call["contents"]] == ["user", "model", "user"]
    cfg = call["config"]
    assert cfg.system_instruction == "SYS"
    assert cfg.temperature is None            # deprecated on Gemini 3.x, never sent
    assert cfg.max_output_tokens == 2048      # floor for thinking tokens
    assert str(cfg.thinking_config.thinking_level).endswith("LOW")


def test_gemini_safety_block_becomes_refusal(monkeypatch):
    blocked = SimpleNamespace(text=None, prompt_feedback=SimpleNamespace(block_reason="SAFETY"), candidates=[])
    _patch(monkeypatch, blocked)
    out = llm.complete("SYS", "bad request")
    assert out["text"].startswith("I can't help with that.") and "SAFETY" in out["text"]

"""
NovaTrust Responsible AI Gateway - one demo app for sessions S011-S016.
Run:  uvicorn app.main:app --reload      then open http://127.0.0.1:8000/docs
"""
from fastapi import FastAPI

from app.core import audit, config
from app.modules import s011_bias, s012_security, s013_guardrails, s014_prompt_anatomy, s015_shots, s016_cot

app = FastAPI(
    title="NovaTrust Responsible AI Gateway",
    version="1.0.0",
    description="Hands-on lab for S011-S016: bias mitigation, security, guardrails and prompt engineering "
                "in a retail-banking setting. All data is synthetic.",
)

for module in (s011_bias, s012_security, s013_guardrails, s014_prompt_anatomy, s015_shots, s016_cot):
    app.include_router(module.router)


@app.get("/", tags=["Platform"])
def root():
    return {"app": "NovaTrust Responsible AI Gateway", "docs": "/docs", "llm_provider": config.LLM_PROVIDER,
            "sessions": {"S011": "/s011", "S012": "/s012", "S013": "/s013", "S014": "/s014",
                         "S015": "/s015", "S016": "/s016"}}


@app.get("/health", tags=["Platform"])
def health():
    model = {"gemini": config.GEMINI_MODEL, "anthropic": config.ANTHROPIC_MODEL, "openai": config.OPENAI_MODEL}.get(config.LLM_PROVIDER, "mock-v1")
    return {"status": "ok", "llm_provider": config.LLM_PROVIDER, "model": model}


@app.get("/audit/log", tags=["Platform"])
def audit_log(limit: int = 50):
    """Every guardrail decision made by the gateway, newest first."""
    return {"events": audit.entries(limit)}


@app.delete("/audit/log", tags=["Platform"])
def audit_clear():
    audit.clear()
    return {"cleared": True}

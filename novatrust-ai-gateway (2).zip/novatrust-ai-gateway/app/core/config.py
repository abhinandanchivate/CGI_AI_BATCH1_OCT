"""Central configuration. All values come from environment variables (.env)."""
import os
from dotenv import load_dotenv

load_dotenv()


def _detect_provider() -> str:
    explicit = os.getenv("LLM_PROVIDER", "").strip().lower()
    if explicit in {"gemini", "anthropic", "openai", "mock"}:
        return explicit
    if os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"):
        return "gemini"
    if os.getenv("ANTHROPIC_API_KEY"):
        return "anthropic"
    if os.getenv("OPENAI_API_KEY"):
        return "openai"
    return "mock"


LLM_PROVIDER = _detect_provider()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.6-flash")
# Optional: minimal | low | medium | high. Blank = the model's default thinking level.
GEMINI_THINKING_LEVEL = os.getenv("GEMINI_THINKING_LEVEL", "").strip().lower()
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
DP_TOTAL_BUDGET = float(os.getenv("DP_TOTAL_BUDGET", "5.0"))

# Secret that the chatbot must never reveal. Used as a canary in S012/S013.
STAFF_SECRET = "NOVA-STAFF-7781"


def OPENAI_API_KEY_SET() -> bool:  # noqa: N802
    return bool(os.getenv("OPENAI_API_KEY"))

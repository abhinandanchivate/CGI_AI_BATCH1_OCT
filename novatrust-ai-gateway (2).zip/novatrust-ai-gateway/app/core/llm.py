"""
One function, `complete()`, hides which LLM provider is used.

Providers
---------
gemini    : Google Gemini via the google-genai SDK (GEMINI_API_KEY)  <- default
anthropic : Claude via the Anthropic SDK (ANTHROPIC_API_KEY)
openai    : OpenAI chat completions (OPENAI_API_KEY)
mock      : no network call. Each caller passes a `mock` function that returns a
            canned, clearly labelled answer so the lab runs without any API key.
"""
from __future__ import annotations

from typing import Callable, Optional

from app.core import config


class LLMResult(dict):
    """dict with keys: text, provider, model"""


def complete(
    system: str,
    user: str,
    *,
    history: Optional[list[dict]] = None,
    temperature: float = 0.0,
    max_tokens: int = 800,
    mock: Optional[Callable[[str, str], str]] = None,
) -> LLMResult:
    messages = list(history or []) + [{"role": "user", "content": user}]
    provider = config.LLM_PROVIDER

    if provider == "gemini":
        return _gemini(system, messages, max_tokens)

    if provider == "anthropic":
        import anthropic

        client = anthropic.Anthropic()
        resp = client.messages.create(
            model=config.ANTHROPIC_MODEL,
            system=system,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
        return LLMResult(text=text, provider="anthropic", model=config.ANTHROPIC_MODEL)

    if provider == "openai":
        from openai import OpenAI

        client = OpenAI()
        resp = client.chat.completions.create(
            model=config.OPENAI_MODEL,
            messages=[{"role": "system", "content": system}] + messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return LLMResult(text=resp.choices[0].message.content or "", provider="openai",
                         model=config.OPENAI_MODEL)

    # ---- mock ----
    text = mock(system, user) if mock else "[MOCK] No mock response defined for this call."
    return LLMResult(text=text, provider="mock", model="mock-v1")


def _gemini(system: str, messages: list[dict], max_tokens: int) -> LLMResult:
    """
    Gemini 3.x notes
    - temperature / top_p / top_k are deprecated and ignored (future models reject them),
      so they are NOT sent. Determinism comes from the prompt and output format instead.
    - Thinking tokens count toward the output budget, so a floor of 2,048 tokens is applied.
    - Gemini calls the assistant role "model".
    - If Gemini's own safety filter blocks the request, a refusal string is returned so the
      gateway and the red-team judge treat it like any other refusal.
    """
    from google import genai
    from google.genai import types

    client = genai.Client()  # reads GEMINI_API_KEY (or GOOGLE_API_KEY)
    contents = [
        types.Content(role="model" if m["role"] == "assistant" else "user",
                      parts=[types.Part(text=m["content"])])
        for m in messages
    ]
    cfg = {"system_instruction": system, "max_output_tokens": max(max_tokens, 2048)}
    if config.GEMINI_THINKING_LEVEL:
        cfg["thinking_config"] = types.ThinkingConfig(thinking_level=config.GEMINI_THINKING_LEVEL.upper())

    resp = client.models.generate_content(
        model=config.GEMINI_MODEL, contents=contents, config=types.GenerateContentConfig(**cfg))

    text = ""
    try:
        text = resp.text or ""
    except Exception:  # some SDK versions raise when no text part exists
        text = ""
    if not text:
        fb = getattr(resp, "prompt_feedback", None)
        reason = getattr(fb, "block_reason", None)
        if reason is None and getattr(resp, "candidates", None):
            reason = getattr(resp.candidates[0], "finish_reason", None)
        text = f"I can't help with that. [Gemini returned no text: {reason}]"
    return LLMResult(text=text, provider="gemini", model=config.GEMINI_MODEL)

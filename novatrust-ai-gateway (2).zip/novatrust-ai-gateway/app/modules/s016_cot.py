"""
S016 - Chain-of-Thought prompting
Task: personal-loan eligibility. It needs multi-step arithmetic (monthly rate -> EMI -> FOIR -> age at
maturity) and several rule checks, which is where step-by-step reasoning helps.
A deterministic rule engine gives the ground truth so we can score each prompting style.
"""
from __future__ import annotations

import re
from collections import Counter
from typing import Literal

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.core import llm
from app.data.knowledge_base import KB

router = APIRouter(prefix="/s016", tags=["S016 Chain-of-Thought"])

POLICY = next(d["text"] for d in KB if d["id"] == "KB-LOAN-01") + " " + next(d["text"] for d in KB if d["id"] == "KB-LOAN-02")


class LoanApplicant(BaseModel):
    name: str = "Applicant A"
    age: int = Field(34, ge=18, le=80)
    net_monthly_income: float = Field(65000, description="INR")
    existing_emis: float = Field(8000, description="INR per month")
    credit_score: int = Field(742, ge=300, le=900)
    loan_amount: float = Field(800000, description="INR")
    annual_rate_pct: float = 12.0
    tenure_months: int = 48


def emi(p: float, annual_rate: float, n: int) -> float:
    r = annual_rate / 12 / 100
    return p * r * (1 + r) ** n / ((1 + r) ** n - 1)


def rule_engine(a: LoanApplicant) -> dict:
    e = emi(a.loan_amount, a.annual_rate_pct, a.tenure_months)
    foir = (a.existing_emis + e) / a.net_monthly_income
    age_end = a.age + a.tenure_months / 12
    checks = {
        "age_at_maturity_<=_60": age_end <= 60 and a.age >= 21,
        "income_>=_25000": a.net_monthly_income >= 25000,
        "credit_score_>=_700": a.credit_score >= 700,
        "foir_<=_50pct": foir <= 0.50,
        "tenure_12_to_60": 12 <= a.tenure_months <= 60,
    }
    return {"emi": round(e, 2), "foir_pct": round(foir * 100, 2), "age_at_maturity": round(age_end, 2),
            "checks": checks, "decision": "ELIGIBLE" if all(checks.values()) else "NOT_ELIGIBLE"}


TEST_APPLICANTS = [
    LoanApplicant(name="A clear approve"),
    LoanApplicant(name="B low score", credit_score=688),
    LoanApplicant(name="C FOIR just over", net_monthly_income=48000, existing_emis=4300, loan_amount=600000, tenure_months=36),
    LoanApplicant(name="D FOIR just under", net_monthly_income=49000, existing_emis=4300, loan_amount=600000, tenure_months=36),
    LoanApplicant(name="E age at maturity", age=56, tenure_months=60, loan_amount=400000, existing_emis=0),
    LoanApplicant(name="F low income", net_monthly_income=24000, existing_emis=0, loan_amount=150000, tenure_months=24),
    LoanApplicant(name="G high rate long tenure", net_monthly_income=90000, existing_emis=15000, loan_amount=1200000,
                  annual_rate_pct=15.5, tenure_months=60),
    LoanApplicant(name="H boundary score 700", credit_score=700, net_monthly_income=70000, existing_emis=5000,
                  loan_amount=500000, tenure_months=24, age=58),
]

SYSTEM = "You are a NovaTrust Bank credit analyst. Apply the policy exactly."


def build_prompt(a: LoanApplicant, mode: str) -> str:
    facts = (f"Applicant: age {a.age}, net monthly income Rs {a.net_monthly_income:,.0f}, existing EMIs "
             f"Rs {a.existing_emis:,.0f}/month, credit score {a.credit_score}. Requested loan Rs {a.loan_amount:,.0f} "
             f"at {a.annual_rate_pct}% p.a. for {a.tenure_months} months.")
    if mode == "direct":
        return (f"POLICY: {POLICY}\n\n{facts}\n\nIs the applicant eligible? Answer immediately with no explanation, "
                "exactly in this format:\nEMI: <number>\nDECISION: ELIGIBLE or NOT_ELIGIBLE")
    return (f"POLICY: {POLICY}\n\n{facts}\n\nLet's think step by step:\n"
            "1. Compute the monthly interest rate r.\n2. Compute the EMI with the formula.\n"
            "3. Compute FOIR = (existing EMIs + new EMI) / income, as a percentage.\n"
            "4. Compute age at loan maturity.\n5. Check every policy rule and mark PASS/FAIL.\n"
            "6. The applicant is ELIGIBLE only if all rules pass.\n"
            "Show your working, then end with exactly:\nEMI: <number>\nDECISION: ELIGIBLE or NOT_ELIGIBLE")


def _mock_for(a: LoanApplicant):
    t = rule_engine(a)

    def mock(_s, prompt):
        tail = f"EMI: {t['emi']}\nDECISION: {t['decision']}"
        if "step by step" not in prompt:
            return tail
        lines = [f"1. r = {a.annual_rate_pct}/12/100 = {a.annual_rate_pct / 1200:.6f}",
                 f"2. EMI = {t['emi']:,.2f}",
                 f"3. FOIR = ({a.existing_emis:,.0f} + {t['emi']:,.0f}) / {a.net_monthly_income:,.0f} = {t['foir_pct']}%",
                 f"4. Age at maturity = {a.age} + {a.tenure_months}/12 = {t['age_at_maturity']}",
                 "5. " + "; ".join(f"{k}: {'PASS' if v else 'FAIL'}" for k, v in t["checks"].items())]
        return "[MOCK]\n" + "\n".join(lines) + "\n" + tail
    return mock


def parse(raw: str) -> dict:
    d = re.search(r"DECISION:\s*\**\s*(NOT_ELIGIBLE|NOT ELIGIBLE|ELIGIBLE)", raw, re.I)
    e = re.search(r"EMI:\s*\**\s*(?:Rs\.?|INR|₹)?\s*([\d,]+(?:\.\d+)?)", raw, re.I)
    dec = d.group(1).upper().replace(" ", "_") if d else None
    return {"decision": dec, "emi": float(e.group(1).replace(",", "")) if e else None}


def run_one(a: LoanApplicant, mode: str, samples: int = 3) -> dict:
    truth = rule_engine(a)
    if mode == "self_consistency":  # note: Gemini 3.x ignores temperature; samples still vary
        outs = [llm.complete(SYSTEM, build_prompt(a, "cot"), temperature=0.7, mock=_mock_for(a))["text"]
                for _ in range(samples)]
        parsed = [parse(o) for o in outs]
        votes = Counter(p["decision"] for p in parsed)
        decision = votes.most_common(1)[0][0]
        emis = [p["emi"] for p in parsed if p["emi"]]
        result = {"decision": decision, "emi": round(sorted(emis)[len(emis) // 2], 2) if emis else None,
                  "votes": dict(votes)}
        raw = outs[0]
    else:
        raw = llm.complete(SYSTEM, build_prompt(a, mode), mock=_mock_for(a), max_tokens=900)["text"]
        result = parse(raw)
    emi_err = abs(result["emi"] - truth["emi"]) / truth["emi"] * 100 if result.get("emi") else None
    return {"mode": mode, "model_answer": result, "ground_truth": truth,
            "decision_correct": result["decision"] == truth["decision"],
            "emi_error_pct": round(emi_err, 2) if emi_err is not None else None, "raw_output": raw}


class EligibilityRequest(BaseModel):
    applicant: LoanApplicant = LoanApplicant()
    mode: Literal["direct", "cot", "self_consistency"] = "cot"
    samples: int = Field(3, ge=3, le=7, description="Only for self_consistency")
    show_prompt: bool = True


@router.post("/loan-eligibility")
def loan_eligibility(req: EligibilityRequest):
    out = run_one(req.applicant, req.mode, req.samples)
    if req.show_prompt:
        out["prompt"] = build_prompt(req.applicant, "direct" if req.mode == "direct" else "cot")
    return out


@router.get("/test-applicants")
def test_applicants():
    return [dict(a.model_dump(), expected=rule_engine(a)) for a in TEST_APPLICANTS]


class EvalRequest(BaseModel):
    modes: list[Literal["direct", "cot", "self_consistency"]] = ["direct", "cot"]


@router.post("/evaluate")
def evaluate(req: EvalRequest):
    summary, rows = {}, []
    for mode in req.modes:
        res = [run_one(a, mode) for a in TEST_APPLICANTS]
        errs = [r["emi_error_pct"] for r in res if r["emi_error_pct"] is not None]
        summary[mode] = {"decision_accuracy": round(sum(r["decision_correct"] for r in res) / len(res), 3),
                         "mean_emi_error_pct": round(sum(errs) / len(errs), 2) if errs else None,
                         "unparseable": sum(r["model_answer"]["decision"] is None for r in res)}
        rows += [{"mode": mode, "applicant": a.name, "expected": r["ground_truth"]["decision"],
                  "got": r["model_answer"]["decision"], "correct": r["decision_correct"],
                  "emi_expected": r["ground_truth"]["emi"], "emi_got": r["model_answer"]["emi"]}
                 for a, r in zip(TEST_APPLICANTS, res)]
    return {"summary": summary, "rows": rows}

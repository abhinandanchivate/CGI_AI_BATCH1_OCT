"""S017 endpoints - Prompt Interventions & Prompt Tuning."""
import asyncio

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.core import prompting

router = APIRouter(prefix="/s017", tags=["S017 Prompt Interventions & Tuning"])


class InterventionRequest(BaseModel):
    question: str = Field(examples=["A train leaves at 9:40 and arrives at 13:15. "
                                    "How many minutes is the trip?"])
    techniques: list[str] = Field(default_factory=lambda: list(prompting.TECHNIQUES))


@router.get("/techniques")
def list_techniques():
    return {t: prompting.build(t, "<question>").__dict__ for t in prompting.TECHNIQUES}


@router.post("/interventions")
async def compare_interventions(req: InterventionRequest):
    """Run the same question through several prompting techniques side by side."""
    results = await asyncio.gather(*[prompting.run_technique(t, req.question)
                                     for t in req.techniques])
    return {"question": req.question, "results": results}


class Example(BaseModel):
    input: str
    expected: str


class TuneRequest(BaseModel):
    task: str = Field(examples=["Classify the sentiment of a product review as "
                                "positive, negative or mixed."])
    seed_prompt: str = Field(examples=["Sentiment of: {input}"])
    examples: list[Example] = Field(examples=[[
        {"input": "Battery is great but the screen cracked in a week.", "expected": "mixed"},
        {"input": "Absolutely love it, best purchase this year!", "expected": "positive"},
        {"input": "Stopped working after two days. Refund please.", "expected": "negative"},
        {"input": "Fast shipping, though the color is not what I expected.", "expected": "mixed"},
    ]])
    rounds: int = Field(2, ge=1, le=5)
    candidates: int = Field(3, ge=1, le=6)


@router.post("/evaluate")
async def evaluate(req: TuneRequest):
    """Score a single prompt template ({input} placeholder) on a dev set."""
    return await prompting.evaluate_prompt(req.seed_prompt, [e.model_dump() for e in req.examples])


@router.post("/tune")
async def tune(req: TuneRequest):
    """Discrete prompt tuning (APE/OPRO-style optimisation loop)."""
    return await prompting.tune(req.task, req.seed_prompt,
                                [e.model_dump() for e in req.examples],
                                req.rounds, req.candidates)

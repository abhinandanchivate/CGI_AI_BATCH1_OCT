"""S020 endpoints - Structured Output Prompting."""
import asyncio
from typing import Literal

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.core import agent, structured

router = APIRouter(prefix="/s020", tags=["S020 Structured Outputs"])
SAMPLE = ("Hi, this is Priya Nair. I've been charged twice for my Acme Cloud Pro plan this "
          "month and nobody answered my last email. Please refund the duplicate charge ASAP "
          "and confirm by email. Really frustrated.")


class ExtractRequest(BaseModel):
    text: str = Field(examples=[SAMPLE])
    methods: list[Literal["prompt_only", "json_mode", "schema_mode", "function_call"]] = \
        ["prompt_only", "json_mode", "schema_mode", "function_call"]


@router.get("/schema")
def schema():
    return structured.SupportTicket.model_json_schema()


@router.post("/extract")
async def extract(req: ExtractRequest):
    """Same extraction task, four structured-output techniques."""
    results = await asyncio.gather(*[structured.METHODS[m](req.text) for m in req.methods])
    return {m: r for m, r in zip(req.methods, results)}


class CustomSchemaRequest(BaseModel):
    text: str = Field(examples=["Meet Sam at Blue Tokai, Baner on Friday 6pm about the Q4 budget."])
    instruction: str = Field("Extract the event details.")
    json_schema: dict = Field(examples=[{
        "type": "object",
        "properties": {"person": {"type": "string"}, "place": {"type": "string"},
                       "day": {"type": "string"}, "time": {"type": "string"},
                       "topic": {"type": "string"}},
        "required": ["person", "place", "day", "time", "topic"]}])


@router.post("/custom")
async def custom(req: CustomSchemaRequest):
    """Bring your own JSON Schema."""
    return await structured.custom_schema(req.text, req.json_schema, req.instruction)


class AgentReportRequest(BaseModel):
    question: str = Field(examples=["Read acme.example/blog and summarise what's new."])
    agent: Literal["react", "function_calling"] = "function_calling"


@router.post("/agent-report")
async def agent_report(req: AgentReportRequest):
    """S019 agent run -> typed AgentReport (S020)."""
    runner = agent.run_react if req.agent == "react" else agent.run_function_calling
    result = await runner(req.question)
    return {"report": await structured.agent_report(req.question, result), "raw": result}

"""S022 endpoints - Transformer Architecture & Scaling Laws."""
import json

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.core import model_types, transformer_lab as lab
from app.core.llm import count_tokens, generate, no_thinking

router = APIRouter(prefix="/s022", tags=["S022 Transformers & Scaling Laws"])


class TokenRequest(BaseModel):
    text: str = Field(examples=["Transformers replaced recurrence with self-attention. "
                                "नमस्ते! 東京 🚀"])


@router.post("/tokens")
async def tokens(req: TokenRequest):
    """Real Gemini token count vs naive word split (shows why non-English costs more)."""
    n_tokens = await count_tokens(req.text)
    words = lab.toy_tokenize(req.text)
    return {"gemini_tokens": n_tokens, "naive_word_pieces": len(words),
            "characters": len(req.text),
            "chars_per_token": round(len(req.text) / max(n_tokens, 1), 2)}


class AttentionRequest(BaseModel):
    text: str = Field("The cat sat on the mat because it was tired")
    d_model: int = Field(16, ge=4, le=128)
    n_heads: int = Field(2, ge=1, le=16)
    causal: bool = True
    seed: int = 0


@router.post("/attention")
def attention(req: AttentionRequest):
    """Multi-head scaled dot-product self-attention, step by step (random weights)."""
    return lab.self_attention(req.text, req.d_model, req.n_heads, req.causal, req.seed)


class ParamRequest(BaseModel):
    n_layers: int = 12
    d_model: int = 768
    n_heads: int = 12
    vocab_size: int = 50257
    context_len: int = 1024
    ff_mult: int = 4
    tied_embeddings: bool = True


@router.post("/params")
def params(req: ParamRequest):
    """Parameter count, FLOPs/token and KV-cache size for a decoder-only transformer."""
    return lab.param_count(**req.model_dump())


class ScalingRequest(BaseModel):
    compute_budgets: list[float] = Field([1e19, 1e21, 1e23, 5.76e23],
                                         description="Training FLOPs (Chinchilla used 5.76e23)")


@router.post("/scaling")
def scaling(req: ScalingRequest):
    """Chinchilla compute-optimal allocation + predicted loss."""
    return lab.scaling_table(req.compute_budgets)


class ExplainRequest(BaseModel):
    topic: str = Field("scaling", description="attention | params | scaling | anything")
    question: str = Field("Why did Chinchilla beat larger models like Gopher?")
    reasoning: bool = Field(False, description="Use LRM mode (thinking) from S021")


@router.post("/explain")
async def explain(req: ExplainRequest):
    """Gemini explains the lab numbers, grounded in computed results."""
    context = {
        "attention": lambda: lab.self_attention("The cat sat on the mat because it was tired"),
        "params": lambda: lab.param_count(12, 768, 12, 50257, 1024),
        "scaling": lambda: lab.scaling_table([1e21, 5.76e23]),
    }.get(req.topic, lambda: {})()
    prompt = (f"Lab results (JSON):\n{json.dumps(context)[:6000]}\n\n"
              f"Student question: {req.question}\n"
              "Answer clearly in under 250 words, referencing the numbers above when useful.")
    system = "You are a patient deep-learning professor teaching transformers and scaling laws."
    if req.reasoning:
        cfg = model_types.modes()["lrm"]
        res = await generate(prompt, system=system, thinking_config=cfg["thinking"])
    else:
        res = await generate(prompt, system=system, **no_thinking())
    return res.public()

"""S019 endpoints - Prompts for Agents & ReAct."""
import asyncio
from typing import Literal

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.core import agent
from app.core.tools import TOOLS

router = APIRouter(prefix="/s019", tags=["S019 Agents & ReAct"])


class AgentRequest(BaseModel):
    question: str = Field(examples=[
        "Using the pricing page, how much more does a Pro plan cost than Starter over 12 months?"])
    agent: Literal["react", "function_calling", "both"] = "both"
    max_steps: int = Field(6, ge=1, le=12)
    guard: bool = Field(True, description="Scan tool outputs for injections (S018)")


@router.get("/tools")
def tools():
    return {name: {"description": t.description, "schema": t.json_schema}
            for name, t in TOOLS.items()}


@router.get("/react-prompt")
def react_prompt():
    """The full ReAct system prompt the text agent runs on."""
    return {"system_prompt": agent.REACT_SYSTEM.format(tools=agent.tool_catalog())}


@router.post("/run")
async def run(req: AgentRequest):
    jobs = {}
    if req.agent in ("react", "both"):
        jobs["react"] = agent.run_react(req.question, req.max_steps, req.guard)
    if req.agent in ("function_calling", "both"):
        jobs["function_calling"] = agent.run_function_calling(req.question, req.max_steps, req.guard)
    results = await asyncio.gather(*jobs.values())
    return dict(zip(jobs.keys(), results))

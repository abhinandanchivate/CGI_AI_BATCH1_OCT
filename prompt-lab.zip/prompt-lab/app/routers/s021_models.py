"""S021 endpoints - LLMs vs LRMs vs LMMs."""
from typing import Literal

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, Field

from app.core import model_types

router = APIRouter(prefix="/s021", tags=["S021 LLM vs LRM vs LMM"])
ModeName = Literal["llm", "lrm", "lrm_dynamic"]
MAX_IMAGE_BYTES = 15 * 1024 * 1024


class CompareRequest(BaseModel):
    question: str = Field(examples=["Alice has 3 brothers. Each brother has 2 sisters. "
                                    "How many sisters does Alice have?"])
    modes: list[ModeName] = ["llm", "lrm"]


@router.post("/compare")
async def compare(req: CompareRequest):
    """Same model, thinking off (LLM) vs on (LRM): answer, latency, thinking tokens."""
    return await model_types.compare(req.question, list(req.modes))


class BenchmarkRequest(BaseModel):
    modes: list[ModeName] = ["llm", "lrm"]


@router.post("/benchmark")
async def benchmark(req: BenchmarkRequest):
    """Accuracy / latency / token cost on a small trick-question benchmark."""
    return await model_types.benchmark(list(req.modes))


async def _read_image(image: UploadFile) -> bytes:
    if not (image.content_type or "").startswith("image/"):
        raise HTTPException(400, "Please upload an image file.")
    data = await image.read()
    if len(data) > MAX_IMAGE_BYTES:
        raise HTTPException(413, "Image too large for inline upload (max 15 MB).")
    return data


@router.post("/multimodal")
async def multimodal(image: UploadFile = File(...),
                     question: str = Form("What is in this image?")):
    """LMM: image + text in a single prompt."""
    return await model_types.multimodal(await _read_image(image), image.content_type, question)


@router.post("/multimodal/structured")
async def multimodal_structured(image: UploadFile = File(...)):
    """LMM + S020 schema: typed image report incl. visual prompt-injection flag (S018)."""
    return await model_types.multimodal_structured(await _read_image(image), image.content_type)

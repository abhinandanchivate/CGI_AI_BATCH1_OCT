"""Foundation layer: one async wrapper around the Google Gen AI SDK.

Every stage (S017-S022) talks to Gemini only through `generate()`, so features
added here (retries, rate limiting, token accounting, thought extraction) are
inherited by all later stages.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any

from google import genai
from google.genai import errors, types

from app.config import get_settings

_client: genai.Client | None = None
_semaphore: asyncio.Semaphore | None = None


def get_client() -> genai.Client:
    global _client
    if _client is None:
        _client = genai.Client(api_key=get_settings().gemini_api_key)
    return _client


def _sem() -> asyncio.Semaphore:
    global _semaphore
    if _semaphore is None:
        _semaphore = asyncio.Semaphore(get_settings().max_concurrency)
    return _semaphore


@dataclass
class LLMResult:
    text: str
    model: str
    latency_ms: float
    usage: dict[str, Any]
    thoughts: str | None = None
    response: Any = field(default=None, repr=False)  # raw SDK response

    def public(self) -> dict[str, Any]:
        out = {"text": self.text, "model": self.model,
               "latency_ms": self.latency_ms, "usage": self.usage}
        if self.thoughts:
            out["thought_summary"] = self.thoughts
        return out


def no_thinking(model: str | None = None) -> dict[str, Any]:
    """Disable 'thinking' on Flash models (fast, cheap, plain-LLM behaviour).
    Pro models cannot fully disable thinking, so we leave them alone."""
    model = model or get_settings().gemini_model
    if "flash" in model:
        return {"thinking_config": types.ThinkingConfig(thinking_budget=0)}
    return {}


def _usage(resp) -> dict[str, Any]:
    u = resp.usage_metadata
    if u is None:
        return {}
    return {
        "prompt_tokens": u.prompt_token_count,
        "output_tokens": u.candidates_token_count,
        "thinking_tokens": u.thoughts_token_count,
        "total_tokens": u.total_token_count,
    }


def _split_parts(resp) -> tuple[str, str | None]:
    answer, thoughts = [], []
    for cand in resp.candidates or []:
        if not cand.content or not cand.content.parts:
            continue
        for part in cand.content.parts:
            if part.text:
                (thoughts if part.thought else answer).append(part.text)
    return "".join(answer), ("\n".join(thoughts) or None)


async def generate(
    contents: Any,
    *,
    system: str | None = None,
    temperature: float | None = None,
    model: str | None = None,
    **config: Any,
) -> LLMResult:
    """Call Gemini. Extra kwargs go straight into GenerateContentConfig
    (e.g. response_schema, tools, thinking_config, stop_sequences)."""
    settings = get_settings()
    model = model or settings.gemini_model
    cfg = types.GenerateContentConfig(
        system_instruction=system, temperature=temperature, **config
    )
    async with _sem():
        for attempt in range(settings.max_retries + 1):
            try:
                start = time.perf_counter()
                resp = await get_client().aio.models.generate_content(
                    model=model, contents=contents, config=cfg
                )
                break
            except errors.APIError as exc:
                if exc.code in (429, 500, 503) and attempt < settings.max_retries:
                    await asyncio.sleep(2 ** attempt)
                    continue
                raise
    text, thoughts = _split_parts(resp)
    return LLMResult(
        text=text, model=model,
        latency_ms=round((time.perf_counter() - start) * 1000, 1),
        usage=_usage(resp), thoughts=thoughts, response=resp,
    )


async def count_tokens(contents: Any, model: str | None = None) -> int:
    resp = await get_client().aio.models.count_tokens(
        model=model or get_settings().gemini_model, contents=contents
    )
    return resp.total_tokens

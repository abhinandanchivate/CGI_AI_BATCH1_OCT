"""S022 - Transformer Architecture & Scaling Laws.

Hands-on, math-first pieces (pure NumPy, no API needed):
* scaled dot-product, multi-head, causal self-attention on a toy sentence
* parameter / FLOP / KV-cache estimator for a decoder-only transformer
* Kaplan (2020) and Chinchilla (2022) scaling-law calculators

Gemini is used for real tokenization (count_tokens) and to explain results, with
S021's LLM/LRM modes selectable, closing the loop on the whole course.
"""
from __future__ import annotations

import hashlib
import math
import re

import numpy as np


# ----------------------------------------------------------------- attention
def toy_tokenize(text: str) -> list[str]:
    return re.findall(r"\w+|[^\w\s]", text)[:32]


def sinusoidal_positions(seq_len: int, d_model: int) -> np.ndarray:
    pos = np.arange(seq_len)[:, None]
    i = np.arange(d_model)[None, :]
    angles = pos / np.power(10000, (2 * (i // 2)) / d_model)
    return np.where(i % 2 == 0, np.sin(angles), np.cos(angles))


def token_embeddings(tokens: list[str], d_model: int) -> np.ndarray:
    """Deterministic pseudo-embeddings (same token -> same vector)."""
    rows = []
    for tok in tokens:
        seed = int(hashlib.md5(tok.lower().encode()).hexdigest()[:8], 16)
        rows.append(np.random.default_rng(seed).normal(0, 1, d_model))
    return np.stack(rows)


def softmax(x: np.ndarray) -> np.ndarray:
    x = x - x.max(axis=-1, keepdims=True)
    e = np.exp(x)
    return e / e.sum(axis=-1, keepdims=True)


def self_attention(text: str, d_model: int = 16, n_heads: int = 2,
                   causal: bool = True, seed: int = 0) -> dict:
    if d_model % n_heads:
        raise ValueError("d_model must be divisible by n_heads")
    tokens = toy_tokenize(text)
    n, d_head = len(tokens), d_model // n_heads
    x = token_embeddings(tokens, d_model) + sinusoidal_positions(n, d_model)
    rng = np.random.default_rng(seed)
    heads, outputs = [], []
    for h in range(n_heads):
        wq, wk, wv = (rng.normal(0, 1 / math.sqrt(d_model), (d_model, d_head)) for _ in range(3))
        q, k, v = x @ wq, x @ wk, x @ wv
        scores = q @ k.T / math.sqrt(d_head)          # (n, n)
        if causal:
            scores = np.where(np.triu(np.ones((n, n)), 1) == 1, -np.inf, scores)
        weights = softmax(scores)
        outputs.append(weights @ v)                    # (n, d_head)
        top = [{"token": tokens[i], "attends_most_to": tokens[int(weights[i].argmax())],
                "weight": round(float(weights[i].max()), 3)} for i in range(n)]
        heads.append({"head": h, "weights": weights.round(3).tolist(), "top_links": top})
    concat = np.concatenate(outputs, axis=-1)
    w_o = rng.normal(0, 1 / math.sqrt(d_model), (d_model, d_model))
    return {"tokens": tokens, "d_model": d_model, "n_heads": n_heads, "d_head": d_head,
            "causal": causal, "output_shape": list((concat @ w_o).shape),
            "formula": "Attention(Q,K,V) = softmax(QK^T / sqrt(d_head) + mask) V",
            "heads": heads}


# ---------------------------------------------------------- param estimator
def param_count(n_layers: int, d_model: int, n_heads: int, vocab_size: int,
                context_len: int, ff_mult: int = 4, tied_embeddings: bool = True) -> dict:
    d, L, d_ff = d_model, n_layers, ff_mult * d_model
    embed = vocab_size * d
    pos = context_len * d                          # learned positions (GPT-2 style)
    attn = 4 * d * d + 4 * d                       # Wq, Wk, Wv, Wo + biases
    mlp = 2 * d * d_ff + d_ff + d                  # up + down projections + biases
    norms = 4 * d                                  # two LayerNorms (gain + bias)
    per_layer = attn + mlp + norms
    non_embedding = L * per_layer
    total = embed + pos + non_embedding + 2 * d + (0 if tied_embeddings else embed)
    return {
        "total_params": total, "total_human": _human(total),
        "non_embedding_params": non_embedding,
        "breakdown": {"token_embedding": embed, "position_embedding": pos,
                      "per_layer": {"attention": attn, "mlp": mlp, "layernorm": norms},
                      "all_layers": non_embedding},
        "head_dim": d // n_heads,
        "forward_flops_per_token": 2 * non_embedding + 2 * L * context_len * d,
        "training_flops_per_token_approx": 6 * total,
        "kv_cache_bytes_per_token_fp16": 2 * L * d * 2,
        "note": "GPT-2 small (12, 768, 12, 50257, 1024) gives ~124M as a sanity check.",
    }


def _human(n: float) -> str:
    for unit, div in (("T", 1e12), ("B", 1e9), ("M", 1e6), ("K", 1e3)):
        if abs(n) >= div:
            return f"{n / div:.2f}{unit}"
    return str(n)


# -------------------------------------------------------------- scaling laws
CHINCHILLA = {"E": 1.69, "A": 406.4, "B": 410.7, "alpha": 0.34, "beta": 0.28}


def chinchilla_loss(n_params: float, n_tokens: float) -> float:
    c = CHINCHILLA
    return c["E"] + c["A"] / n_params ** c["alpha"] + c["B"] / n_tokens ** c["beta"]


def kaplan_loss_from_params(n_params: float) -> float:
    return (8.8e13 / n_params) ** 0.076


def compute_optimal(compute_flops: float, tokens_per_param: float = 20.0) -> dict:
    """C = 6ND and D = k*N  =>  N = sqrt(C / (6k))."""
    n = math.sqrt(compute_flops / (6 * tokens_per_param))
    d = tokens_per_param * n
    return {"params": n, "tokens": d}


def scaling_table(budgets: list[float]) -> dict:
    rows = []
    for c in budgets:
        opt = compute_optimal(c)
        n, d = opt["params"], opt["tokens"]
        rows.append({
            "compute_flops": f"{c:.1e}",
            "optimal_params": _human(n), "optimal_tokens": _human(d),
            "loss_optimal": round(chinchilla_loss(n, d), 4),
            "loss_10x_bigger_model_fewer_tokens": round(chinchilla_loss(n * 10, d / 10), 4),
            "loss_10x_smaller_model_more_tokens": round(chinchilla_loss(n / 10, d * 10), 4),
            "kaplan_loss_same_params": round(kaplan_loss_from_params(n), 4),
        })
    return {"law": "L(N,D) = E + A/N^alpha + B/D^beta (Hoffmann et al. 2022)",
            "constants": CHINCHILLA, "rule_of_thumb": "~20 training tokens per parameter",
            "rows": rows,
            "takeaway": "For a fixed compute budget, both over-sized and under-sized "
                        "models reach a higher loss than the compute-optimal one."}

"""S017 - Prompt Interventions & Prompt Tuning.

Interventions: change the *prompt* (not the model) to change behaviour:
zero-shot, few-shot, chain-of-thought, role/persona, step-back, self-consistency.

Prompt tuning: real "soft" prompt tuning learns embedding vectors and needs model
weights. With an API-only model we do *discrete* prompt tuning instead
(APE / OPRO style): score a prompt on a labelled dev set, ask the LLM to
propose better prompts from the failures, keep the best, repeat.
"""
from __future__ import annotations

import asyncio
import re
from collections import Counter
from dataclasses import dataclass

from app.core.llm import generate, no_thinking

FINAL_RE = re.compile(r"final answer\s*[:\-]\s*(.+)", re.IGNORECASE)
ANSWER_SUFFIX = "\nEnd your response with a line of the form 'Final answer: <answer>'."

FEW_SHOT_EXAMPLES = [
    ("A shop sells pens at 3 for $2. How much do 12 pens cost?",
     "12 pens is 4 groups of 3, and 4 x $2 = $8.\nFinal answer: 8"),
    ("Tom is twice as old as Ann. Ann is 7. How old will Tom be in 3 years?",
     "Tom is 2 x 7 = 14 now, so in 3 years he is 17.\nFinal answer: 17"),
]

TECHNIQUES = ["zero_shot", "few_shot", "chain_of_thought", "role",
              "step_back", "self_consistency"]


@dataclass
class PromptSpec:
    system: str | None
    user: str
    temperature: float | None = 0.0


def build(technique: str, question: str) -> PromptSpec:
    """Return the prompt produced by an intervention technique."""
    match technique:
        case "zero_shot":
            return PromptSpec(None, question + ANSWER_SUFFIX)
        case "few_shot":
            shots = "\n\n".join(f"Q: {q}\nA: {a}" for q, a in FEW_SHOT_EXAMPLES)
            return PromptSpec(None, f"{shots}\n\nQ: {question}\nA:")
        case "chain_of_thought" | "self_consistency":
            return PromptSpec(None, f"{question}\nLet's think step by step." + ANSWER_SUFFIX)
        case "role":
            return PromptSpec(
                "You are a meticulous math olympiad coach. You check every "
                "arithmetic step twice and never guess.",
                question + ANSWER_SUFFIX,
            )
        case "step_back":
            return PromptSpec(
                None,
                f"{question}\nFirst, step back and state the general principle or "
                "formula this problem relies on. Then apply it." + ANSWER_SUFFIX,
            )
    raise ValueError(f"Unknown technique {technique!r}. Choose from {TECHNIQUES}")


def extract_final(text: str) -> str:
    text = text or ""
    matches = FINAL_RE.findall(text)
    if matches:
        answer = matches[-1]
    else:
        lines = [ln for ln in text.strip().splitlines() if ln.strip()]
        answer = lines[-1] if lines else ""
    return answer.strip().strip("*.$ ").strip()


async def run_technique(technique: str, question: str) -> dict:
    if technique == "self_consistency":
        return await self_consistency(question)
    spec = build(technique, question)
    res = await generate(spec.user, system=spec.system,
                         temperature=spec.temperature, **no_thinking())
    return {"technique": technique, "prompt": spec.user, "system": spec.system,
            "final_answer": extract_final(res.text), **res.public()}


async def self_consistency(question: str, samples: int = 5) -> dict:
    """Sample several diverse reasoning paths, then majority-vote the answers."""
    spec = build("self_consistency", question)
    results = await asyncio.gather(*[
        generate(spec.user, temperature=0.9, **no_thinking()) for _ in range(samples)
    ])
    answers = [extract_final(r.text) for r in results]
    winner, votes = Counter(answers).most_common(1)[0]
    return {"technique": "self_consistency", "prompt": spec.user,
            "final_answer": winner, "votes": dict(Counter(answers)),
            "agreement": round(votes / samples, 2),
            "latency_ms": max(r.latency_ms for r in results)}


# ---------------------------------------------------------------- prompt tuning
def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s.lower()).strip()


def fill(template: str, value: str) -> str:
    return template.replace("{input}", value)


async def evaluate_prompt(template: str, examples: list[dict]) -> dict:
    outputs = await asyncio.gather(*[
        generate(fill(template, ex["input"]), temperature=0.0, **no_thinking())
        for ex in examples
    ])
    failures, correct = [], 0
    for ex, out in zip(examples, outputs):
        if _norm(ex["expected"]) in _norm(out.text):
            correct += 1
        else:
            failures.append({"input": ex["input"], "expected": ex["expected"],
                             "got": out.text[:300]})
    return {"score": round(correct / len(examples), 3), "failures": failures}


META_PROMPT = """You are an expert prompt engineer.
Task the prompt must solve: {task}

Current prompt template (the placeholder {{input}} is replaced with each example):
<<<
{prompt}
>>>
Score on the dev set: {score}

Examples it got wrong:
{failures}

Write {n} improved prompt templates. Each MUST contain the literal placeholder {{input}}.
Make them meaningfully different (e.g. add format constraints, examples, reasoning, role).
Separate templates with a line containing only ===PROMPT===. Output nothing else."""


async def propose(task: str, prompt: str, score: float,
                  failures: list[dict], n: int) -> list[str]:
    failure_txt = "\n".join(
        f"- input: {f['input']!r} | expected: {f['expected']!r} | got: {f['got']!r}"
        for f in failures[:5]) or "(none - try to make it more robust)"
    res = await generate(
        META_PROMPT.format(task=task, prompt=prompt, score=score,
                           failures=failure_txt, n=n),
        temperature=1.0,
    )
    cands = [c.strip().strip("<>").strip() for c in res.text.split("===PROMPT===")]
    return [c for c in cands if "{input}" in c][:n]


async def tune(task: str, seed_prompt: str, examples: list[dict],
               rounds: int = 2, candidates: int = 3) -> dict:
    best = {"prompt": seed_prompt, **await evaluate_prompt(seed_prompt, examples)}
    history = [{"round": 0, "prompt": seed_prompt, "score": best["score"]}]
    for r in range(1, rounds + 1):
        if best["score"] == 1.0:
            break
        for cand in await propose(task, best["prompt"], best["score"],
                                  best["failures"], candidates):
            ev = await evaluate_prompt(cand, examples)
            history.append({"round": r, "prompt": cand, "score": ev["score"]})
            if ev["score"] > best["score"]:
                best = {"prompt": cand, **ev}
    return {"best_prompt": best["prompt"], "best_score": best["score"],
            "seed_score": history[0]["score"], "remaining_failures": best["failures"],
            "history": history}

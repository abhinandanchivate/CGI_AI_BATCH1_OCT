"""Prompt Engineering Lab: one FastAPI app that grows stage by stage (S017 -> S022).

Enable stages incrementally with ENABLED_STAGES in .env, e.g. "S017,S018".
"""
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from google.genai import errors

from app.config import get_settings
from app.routers import (s017_prompting, s018_security, s019_agents,
                         s020_structured, s021_models, s022_transformers)

STAGES = {
    "S017": ("Prompt Interventions & Prompt Tuning", s017_prompting.router),
    "S018": ("Adversarial Prompting & Prompt Security", s018_security.router),
    "S019": ("Prompts for Agents & ReAct-style Prompting", s019_agents.router),
    "S020": ("Structured Output Prompting", s020_structured.router),
    "S021": ("LLMs vs LRMs vs LMMs", s021_models.router),
    "S022": ("Transformers Architecture & Scaling Laws", s022_transformers.router),
}

settings = get_settings()
app = FastAPI(title="Prompt Engineering Lab (Gemini)", version="1.0.0",
              description="Incremental FastAPI project covering sessions S017-S022.")

for code in settings.stages:
    if code in STAGES:
        app.include_router(STAGES[code][1])


@app.exception_handler(errors.APIError)
async def gemini_error(_: Request, exc: errors.APIError):
    return JSONResponse(status_code=502, content={
        "error": "Gemini API error", "code": exc.code, "message": str(exc)[:500]})


@app.exception_handler(ValueError)
async def value_error(_: Request, exc: ValueError):
    return JSONResponse(status_code=400, content={"error": str(exc)})


@app.get("/")
def index():
    return {
        "model": settings.gemini_model,
        "docs": "/docs",
        "stages": {code: {"title": title, "enabled": code in settings.stages,
                          "prefix": f"/{code.lower()}"}
                   for code, (title, _) in STAGES.items()},
    }

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    gemini_api_key: str
    gemini_model: str = "gemini-2.5-flash"
    gemini_pro_model: str = "gemini-2.5-pro"
    enabled_stages: str = "S017,S018,S019,S020,S021,S022"
    max_concurrency: int = 4  # protects you from free-tier rate limits
    max_retries: int = 3
    secret_canary: str = "ACME-ESC-7F3A9"  # S018: the "secret" attackers try to steal

    @property
    def stages(self) -> list[str]:
        return [s.strip().upper() for s in self.enabled_stages.split(",") if s.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()

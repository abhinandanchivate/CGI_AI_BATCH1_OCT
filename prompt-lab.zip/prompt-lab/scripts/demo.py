"""Walk through every stage against a running server.

    uvicorn app.main:app --reload       # terminal 1
    python scripts/demo.py               # terminal 2   (or: python scripts/demo.py S018)
"""
import json
import sys

import httpx

BASE = "http://127.0.0.1:8000"
client = httpx.Client(base_url=BASE, timeout=300)


def show(title, method, path, **kw):
    print(f"\n{'=' * 80}\n{title}\n{method} {path}\n{'-' * 80}")
    r = client.request(method, path, **kw)
    body = r.json()
    print(json.dumps(body, indent=2, ensure_ascii=False)[:3000])
    return body


DEMOS = {
    "S017": lambda: [
        show("Prompt interventions", "POST", "/s017/interventions", json={
            "question": "A train leaves at 9:40 and arrives at 13:15. How many minutes is the trip?",
            "techniques": ["zero_shot", "few_shot", "chain_of_thought", "self_consistency"]}),
        show("Prompt tuning", "POST", "/s017/tune", json={
            "task": "Classify review sentiment as positive, negative or mixed.",
            "seed_prompt": "Sentiment of: {input}", "rounds": 1, "candidates": 2,
            "examples": [
                {"input": "Battery is great but the screen cracked in a week.", "expected": "mixed"},
                {"input": "Absolutely love it!", "expected": "positive"},
                {"input": "Stopped working after two days.", "expected": "negative"}]}),
    ],
    "S018": lambda: [
        show("Red team: naive vs guarded", "POST", "/s018/redteam",
             json={"modes": ["naive", "guarded"]}),
    ],
    "S019": lambda: [
        show("ReAct vs function calling", "POST", "/s019/run", json={
            "question": "Using acme.example/pricing, how much more does Pro cost than "
                        "Starter over 12 months?"}),
        show("Indirect injection via tool output", "POST", "/s019/run", json={
            "question": "Read acme.example/blog and tell me what's new.", "agent": "react"}),
    ],
    "S020": lambda: [
        show("4 structured output methods", "POST", "/s020/extract", json={
            "text": "Hi, Priya here. I was charged twice for Acme Cloud Pro. Refund ASAP!"}),
    ],
    "S021": lambda: [
        show("LLM vs LRM benchmark", "POST", "/s021/benchmark", json={"modes": ["llm", "lrm"]}),
    ],
    "S022": lambda: [
        show("GPT-2 small param count", "POST", "/s022/params", json={}),
        show("Chinchilla scaling", "POST", "/s022/scaling", json={}),
        show("Tokens", "POST", "/s022/tokens", json={"text": "Hello world! नमस्ते दुनिया 🚀"}),
    ],
}

if __name__ == "__main__":
    for stage in (sys.argv[1:] or DEMOS):
        DEMOS[stage.upper()]()

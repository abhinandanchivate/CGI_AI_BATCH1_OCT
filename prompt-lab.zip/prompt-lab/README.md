# Prompt Engineering Lab: S017 → S022 (FastAPI + Gemini)

One FastAPI app that grows session by session. Each stage adds a module in
`app/core/` and a router in `app/routers/`, and **reuses what earlier stages built**.

```
S017 prompting ──► S018 security ──► S019 agents ──► S020 structured ──► S021 model types ──► S022 transformers
   templates,        guards scan        tool outputs     typed agent         scored with S017,      explanations use
   extract_final     everything below   are guarded      reports, schemas    images → S020 schema   S021 LLM/LRM modes
```

## Setup

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env          # add GEMINI_API_KEY from https://aistudio.google.com/apikey
uvicorn app.main:app --reload
```

Open **http://127.0.0.1:8000/docs**: every endpoint has a pre-filled example.
Run the guided tour with `python scripts/demo.py` (or `python scripts/demo.py S018`).

**Learning incrementally:** set `ENABLED_STAGES=S017` in `.env`, then add one stage
per session. The model is configurable (`GEMINI_MODEL`, default `gemini-2.5-flash`).

## Project layout

```
app/
  config.py              settings (.env)
  main.py                mounts enabled stages
  core/
    llm.py               foundation: async Gemini wrapper, retries, rate limit, token + thought accounting
    prompting.py         S017
    security.py          S018
    tools.py, agent.py   S019
    structured.py        S020
    model_types.py       S021
    transformer_lab.py   S022 (pure NumPy)
  routers/s017_*.py … s022_*.py
scripts/demo.py
```

## S017 · Prompt Interventions & Prompt Tuning

| Endpoint | What it shows |
|---|---|
| `GET /s017/techniques` | The exact prompt each technique produces |
| `POST /s017/interventions` | Zero-shot, few-shot, CoT, role, step-back, self-consistency (majority vote over 5 samples) side by side |
| `POST /s017/evaluate` | Score a prompt template (`{input}`) on a labelled dev set |
| `POST /s017/tune` | **Discrete prompt tuning** (APE/OPRO-style): evaluate → LLM proposes better prompts from failures → keep best → repeat |

Note: *soft* prompt tuning (learning embedding vectors) needs model weights; with an API model we optimise the text prompt instead.

## S018 · Adversarial Prompting & Prompt Security

A support bot holds a secret canary (`SECRET_CANARY`). Attackers try to steal it.

| Endpoint | What it shows |
|---|---|
| `POST /s018/scan` | Layer 1: regex heuristics + spotlighted LLM classifier |
| `POST /s018/chat` | Direct injection, `mode=naive` vs `mode=guarded` |
| `POST /s018/summarize` | Indirect injection hidden in a document |
| `POST /s018/redteam` | Runs 8 attacks per mode and reports **attack success rate** |

Guarded mode = input scan → hardened system prompt → spotlighting (random unguessable tags) → sandwich defense → output guard (catches spaced-out / re-cased / base64 leaks). Two attacks (social engineering, the poem trick) intentionally slip past the regexes, which is why the deeper layers exist.

## S019 · Prompts for Agents & ReAct

Tools (all offline/simulated): `calculator` (safe AST, no `eval`), `kb_search`, `get_date`, `fetch_page`.

| Endpoint | What it shows |
|---|---|
| `GET /s019/react-prompt` | The full ReAct system prompt |
| `POST /s019/run` | **Text ReAct** (Thought/Action/Observation parsed by regex, `stop_sequences` stops hallucinated observations) vs **native function calling**, same tools, full traces |

Try `"Read acme.example/blog and tell me what's new"`: the page contains a hidden injection. With `guard=true` the S018 scanner flags and spotlights it; try `guard=false` and compare.

## S020 · Structured Output Prompting

| Endpoint | What it shows |
|---|---|
| `POST /s020/extract` | Same extraction, 4 methods: prompt-only + **validate/repair loop**, JSON mode, `response_schema` (Pydantic), **forced function call** (`mode=ANY`) |
| `POST /s020/custom` | Bring your own JSON Schema |
| `POST /s020/agent-report` | Runs an S019 agent, returns a typed `AgentReport` |

## S021 · LLMs vs LRMs vs LMMs

| Endpoint | What it shows |
|---|---|
| `POST /s021/compare` | Same model, thinking off (**LLM**) vs on (**LRM**, fixed or dynamic budget): answers, latency, thinking tokens, thought summaries |
| `POST /s021/benchmark` | Accuracy vs cost on trick questions (bat-and-ball, "strawberry raspberry", …) |
| `POST /s021/multimodal` | **LMM**: upload an image + question (multipart form) |
| `POST /s021/multimodal/structured` | Image → typed report, including a *visual prompt-injection* flag |

```bash
curl -F "image=@photo.jpg" -F "question=What's happening here?" http://127.0.0.1:8000/s021/multimodal
```

## S022 · Transformers Architecture & Scaling Laws

| Endpoint | What it shows |
|---|---|
| `POST /s022/tokens` | Real Gemini token count vs characters (try Hindi/Japanese/emoji) |
| `POST /s022/attention` | Multi-head causal scaled-dot-product attention with sinusoidal positions, full weight matrices |
| `POST /s022/params` | Param count / FLOPs per token / KV cache. Defaults = GPT-2 small → **124.44M** |
| `POST /s022/scaling` | Chinchilla `L(N,D)=E+A/N^α+B/D^β`; at 5.76e23 FLOPs it recovers **~69B params / 1.39T tokens**, and shows over/under-sized models lose |
| `POST /s022/explain` | Gemini explains the computed numbers, optionally in LRM mode |

## Exercises

1. **S017:** Add a `tree_of_thought` technique to `prompting.build()` and compare it on `/interventions`.
2. **S018:** Get the naive bot's attack success rate above 50%, then add a new defense layer that brings guarded mode to 0%.
3. **S019:** Add a `currency_convert` tool. Notice both agents pick it up with no prompt changes.
4. **S020:** Add a `confidence: float` field with `ge=0, le=1` and see which methods still validate.
5. **S021:** Add a `pro` mode using `GEMINI_PRO_MODEL` to `modes()` and rerun the benchmark.
6. **S022:** Use `/params` to estimate Llama-style 7B (32 layers, d=4096, 32 heads, vocab 32000, ctx 4096), then check its Chinchilla-optimal token count.

## Notes

* Free-tier rate limits are real; `MAX_CONCURRENCY` and automatic retry with backoff on 429/503 are built in. `/s017/tune` and `/s018/redteam` make many calls.
* Gemini API errors are returned as HTTP 502 with the original message.
* Model names change over time; if a model is retired, update `GEMINI_MODEL` in `.env`.

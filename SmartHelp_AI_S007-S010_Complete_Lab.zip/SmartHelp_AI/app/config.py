from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "mysql+pymysql://smarthelp:smarthelp123@127.0.0.1:3307/smarthelp"
    gemini_api_key: str = ""
    gemini_model: str = "gemini-2.5-flash"
    enable_unsafe_demo: bool = True
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()

from google import genai
from google.genai import types
from app.config import settings

class LLMUnavailable(Exception):
    pass

def generate(prompt: str, temperature: float = 0.2) -> str:
    if not settings.gemini_api_key or settings.gemini_api_key == "YOUR_GEMINI_API_KEY":
        raise LLMUnavailable("Set GEMINI_API_KEY in .env")
    try:
        client = genai.Client(api_key=settings.gemini_api_key)
        response = client.models.generate_content(
            model=settings.gemini_model,
            contents=prompt,
            config=types.GenerateContentConfig(temperature=temperature, max_output_tokens=300),
        )
        if not response.text:
            raise LLMUnavailable("No text received from model; it may have been blocked")
        return response.text.strip()
    except LLMUnavailable:
        raise
    except Exception as exc:
        raise LLMUnavailable(f"Gemini request failed: {type(exc).__name__}") from exc

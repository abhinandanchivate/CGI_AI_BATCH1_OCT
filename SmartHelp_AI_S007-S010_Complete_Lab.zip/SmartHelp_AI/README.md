# SmartHelp AI — FastAPI + MySQL + Gemini classroom demo

Start here: **GUIDED_LAB.md** (complete beginner walkthrough and sample requests).

Quick start: `docker compose up -d` → create and activate venv → `pip install -r requirements.txt` → copy `.env.example` to `.env` and set `GEMINI_API_KEY` → `python -m uvicorn app.main:app --reload` → open http://127.0.0.1:8000/docs.

Test: `python -m pytest -q`.

Never commit `.env` or use actual customer data. This is an educational prototype, not a production customer service system.

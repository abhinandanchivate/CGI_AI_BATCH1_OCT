from app.main import SEED_POLICIES
from app.config import Settings

def test_four_policies():
    assert set(SEED_POLICIES) == {"warranty", "returns", "delivery", "refund"}

def test_default_model():
    assert Settings(_env_file=None).gemini_model

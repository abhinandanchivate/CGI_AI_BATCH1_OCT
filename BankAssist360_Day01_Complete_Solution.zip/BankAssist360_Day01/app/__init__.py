"""BankAssist Day 1 package."""

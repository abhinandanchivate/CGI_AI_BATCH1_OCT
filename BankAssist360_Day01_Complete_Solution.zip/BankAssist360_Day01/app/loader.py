"""Day 1: deterministic and read-only ingestion of synthetic banking data."""
from __future__ import annotations
import csv
import json
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import date
from decimal import Decimal, InvalidOperation
from pathlib import Path

CURRENCIES = {'INR', 'USD', 'EUR'}
CUSTOMER_FIELDS = {'customer_id', 'masked_name', 'segment', 'status'}
TXN_FIELDS = {'txn_id', 'customer_id', 'date', 'amount', 'currency', 'description'}

class DataQualityError(Exception):
    """Fatal source error: fail closed, do not pretend an empty input is healthy."""

@dataclass(frozen=True)
class Customer:
    customer_id: str
    masked_name: str
    segment: str
    status: str

@dataclass(frozen=True)
class Transaction:
    txn_id: str
    customer_id: str
    date: str
    amount: str
    currency: str
    description: str

def mask(value: object) -> str:
    """Never emit the complete source value in errors or diagnostics."""
    text = str(value or '')
    return '***' if len(text) < 5 else text[:2] + '***' + text[-2:]

def read_rows(path: Path, required_fields: set[str]) -> list[tuple[int, dict[str, str]]]:
    try:
        with path.open('r', encoding='utf-8-sig', newline='') as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None:
                raise DataQualityError(f'CSV has no header: {path.name}')
            missing = required_fields - set(reader.fieldnames)
            if missing:
                raise DataQualityError(f'Missing required columns in {path.name}: {sorted(missing)}')
            return [(line, row) for line, row in enumerate(reader, start=2)]
    except (FileNotFoundError, IsADirectoryError, PermissionError, UnicodeError, csv.Error) as exc:
        raise DataQualityError(f'Unable to read {path.name}: {type(exc).__name__}') from exc

def issue(dataset: str, row: int, field: str, rule: str, value: object = '') -> dict:
    return {'dataset': dataset, 'row': row, 'field': field, 'rule': rule, 'value_masked': mask(value)}

def validate_customer(row: dict, number: int) -> list[dict]:
    errors = [issue('customers', number, k, 'required', row.get(k)) for k in sorted(CUSTOMER_FIELDS) if not (row.get(k) or '').strip()]
    if row.get('status') and row['status'] not in ('ACTIVE', 'INACTIVE'):
        errors.append(issue('customers', number, 'status', 'allowed_status', row['status']))
    return errors

def validate_transaction(row: dict, number: int, customer_ids: set[str]) -> list[dict]:
    errors = [issue('transactions', number, k, 'required', row.get(k)) for k in sorted(TXN_FIELDS) if not (row.get(k) or '').strip()]
    raw_amount = (row.get('amount') or '').strip()
    if raw_amount:
        try:
            amount = Decimal(raw_amount)
            if not amount.is_finite() or amount == 0:
                errors.append(issue('transactions', number, 'amount', 'nonzero_finite_amount', raw_amount))
        except InvalidOperation:
            errors.append(issue('transactions', number, 'amount', 'amount_decimal', raw_amount))
    if row.get('date'):
        try:
            parsed = date.fromisoformat(row['date'])
            if parsed.isoformat() != row['date']:
                raise ValueError('not canonical ISO')
        except ValueError:
            errors.append(issue('transactions', number, 'date', 'iso_date', row['date']))
    if row.get('currency') and row['currency'] not in CURRENCIES:
        errors.append(issue('transactions', number, 'currency', 'known_currency', row['currency']))
    if row.get('customer_id') and row['customer_id'] not in customer_ids:
        errors.append(issue('transactions', number, 'customer_id', 'known_customer', row['customer_id']))
    return errors

def load_customers(path: Path) -> tuple[dict[str, Customer], list[dict], int]:
    rows = read_rows(path, CUSTOMER_FIELDS)
    records: dict[str, Customer] = {}
    errors: list[dict] = []
    seen: set[str] = set()
    for n, row in rows:
        current = validate_customer(row, n)
        key = (row.get('customer_id') or '').strip()
        if key and key in seen:
            current.append(issue('customers', n, 'customer_id', 'duplicate_customer_id', key))
        seen.add(key)
        if current:
            errors.extend(current)
        else:
            records[key] = Customer(**{k: row[k] for k in Customer.__dataclass_fields__})
    return records, errors, len(rows)

def load_transactions(path: Path, customers: dict[str, Customer]) -> tuple[list[Transaction], list[dict], int, dict]:
    rows = read_rows(path, TXN_FIELDS)
    records: list[Transaction] = []
    errors: list[dict] = []
    seen_ids: set[str] = set()
    seen_composite: set[tuple[str, str]] = set()
    amount_totals: dict[str, Decimal] = {}
    for n, row in rows:
        current = validate_transaction(row, n, set(customers))
        txn_id, txn_date = (row.get('txn_id') or '').strip(), (row.get('date') or '').strip()
        if txn_id and txn_id in seen_ids:
            current.append(issue('transactions', n, 'txn_id', 'duplicate_transaction_id', txn_id))
        composite = (txn_id, txn_date)
        if txn_id and txn_date and composite in seen_composite:
            current.append(issue('transactions', n, 'txn_id,date', 'duplicate_composite_key', txn_id))
        seen_ids.add(txn_id)
        seen_composite.add(composite)
        if current:
            errors.extend(current)
        else:
            records.append(Transaction(**{k: row[k] for k in Transaction.__dataclass_fields__}))
            currency = row['currency']
            amount_totals[currency] = amount_totals.get(currency, Decimal('0')) + Decimal(row['amount'])
    return records, errors, len(rows), {key: str(value) for key, value in sorted(amount_totals.items())}

def build_report(data_dir: Path) -> tuple[dict, dict, list]:
    customers, ce, ct = load_customers(data_dir / 'customers.csv')
    transactions, te, tt, sums = load_transactions(data_dir / 'transactions.csv', customers)
    errors = ce + te
    bad_customer_rows = len({e['row'] for e in ce})
    bad_txn_rows = len({e['row'] for e in te})
    report = {
        'map_id': 'SOL-B01', 'dataset_kind': 'synthetic_only', 'status': 'PASS' if not errors else 'QUALITY_ISSUES',
        'source_rows': {'customers': ct, 'transactions': tt},
        'valid_rows': {'customers': len(customers), 'transactions': len(transactions)},
        'invalid_rows': {'customers': bad_customer_rows, 'transactions': bad_txn_rows},
        'control_totals': {'customers_reconciled': ct == len(customers) + bad_customer_rows,
                           'transactions_reconciled': tt == len(transactions) + bad_txn_rows,
                           'valid_transaction_amount_by_currency': sums},
        'errors_by_rule': dict(sorted(Counter(e['rule'] for e in errors).items())),
        'errors': errors,
        'limitations': ['Amount totals cover validated rows only; rejected monetary values are not summed.',
                        'Not authorised to make account changes or other consequential banking decisions.']}
    return report, customers, transactions

def save_outputs(data_dir: Path, output_dir: Path) -> dict:
    report, customers, transactions = build_report(data_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / 'data_quality_report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    (output_dir / 'validated_customers.json').write_text(json.dumps([asdict(v) for v in customers.values()], indent=2), encoding='utf-8')
    (output_dir / 'validated_transactions.json').write_text(json.dumps([asdict(v) for v in transactions], indent=2), encoding='utf-8')
    return report

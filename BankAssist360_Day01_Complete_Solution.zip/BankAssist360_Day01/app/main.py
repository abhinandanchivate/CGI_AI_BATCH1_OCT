"""Day 1 BankAssist 360 read-only API: no AI models, no account modification."""
import os
from pathlib import Path
from fastapi import FastAPI, HTTPException
from app.loader import DataQualityError, build_report

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = Path(os.environ.get('BANKASSIST_DATA_DIR', str(ROOT / 'data')))
app = FastAPI(title='BankAssist 360 — Day 1', version='0.1.0')

def get_quality():
    try:
        return build_report(DATA_DIR)[0]
    except DataQualityError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

@app.get('/health')
def health():
    report = get_quality()
    return {'status': 'healthy' if report['status'] == 'PASS' else 'degraded',
            'source_rows': report['source_rows'], 'valid_rows': report['valid_rows'],
            'invalid_rows': report['invalid_rows'], 'reconciled': all(
                value for key, value in report['control_totals'].items() if key.endswith('_reconciled'))}

@app.get('/data-quality')
def data_quality():
    return get_quality()

import csv
from pathlib import Path
from fastapi.testclient import TestClient
from app.loader import DataQualityError, build_report, load_customers, load_transactions
from app.main import app

BASE = Path(__file__).resolve().parents[1]

def test_control_totals_and_no_silent_drop():
    report, customers, txns = build_report(BASE / 'data')
    assert report['source_rows'] == {'customers': 5, 'transactions': 11}
    assert report['valid_rows'] == {'customers': 5, 'transactions': 5}
    assert report['invalid_rows'] == {'customers': 0, 'transactions': 6}
    assert report['control_totals']['transactions_reconciled']
    assert len(customers) == 5 and len(txns) == 5

def test_all_expected_rules_detected():
    report, _, _ = build_report(BASE / 'data')
    for rule in ['known_customer', 'amount_decimal', 'required', 'iso_date', 'duplicate_transaction_id', 'known_currency']:
        assert report['errors_by_rule'][rule] >= 1
    assert all('row' in item and 'value_masked' in item for item in report['errors'])

def test_api():
    client = TestClient(app)
    res = client.get('/health')
    assert res.status_code == 200 and res.json()['status'] == 'degraded'
    assert res.json()['reconciled'] is True
    res = client.get('/data-quality')
    assert res.status_code == 200 and res.json()['source_rows']['transactions'] == 11

def test_missing_file_fails_closed(tmp_path):
    try:
        build_report(tmp_path)
    except DataQualityError:
        pass
    else:
        assert False, 'Missing file must fail closed'

def test_duplicate_customers_rejected(tmp_path):
    (tmp_path / 'customers.csv').write_text('customer_id,masked_name,segment,status\nC1,A***,RETAIL,ACTIVE\nC1,B***,RETAIL,ACTIVE\n', encoding='utf-8')
    customers, errors, total = load_customers(tmp_path / 'customers.csv')
    assert total == 2 and len(customers) == 1 and len(errors) == 1

# Day 1 — 5W1H scope card (S001 / SOL-B01)

| Question | Decision |
|---|---|
| Who | Bank service-desk staff / trainer / learners; no public customer access |
| What | Read synthetic, masked customer and transaction CSVs; validate records; report data quality |
| Where | Local Python 3.11+ development environment, read-only FastAPI demo |
| When | On local CLI execution or on API request; reports reflect current local CSV contents |
| Why | Ensure data integrity before any later language-model or retrieval component |
| How | `csv` + Python conditional validation + dataclasses + set/dict lookup + FastAPI |

## Data dictionary and masking
Customers: `customer_id` (synthetic identifier), `masked_name` (already masked), `segment`, `status`.
Transactions: `txn_id` (synthetic identifier), `customer_id` (synthetic identifier), `date` (ISO YYYY-MM-DD), `amount` (signed decimal string), `currency`, `description`.

## Human decision boundary
Read-only reporting only. No refunds, reversals, fee waivers, account changes, or complaint outcomes. No model calls on Day 1. Synthetic teaching data only.

## Assumptions
Signed positive/negative amounts are accepted (credits/debits); zero is rejected. Currency allow-list is INR, USD, EUR. Rows with any validation violation are excluded from validated records and documented in the quality report. Monetary control totals are for valid rows only. Local API is training-only and has no authentication; **do not expose it publicly**.

# Validation rules — Day 1

| Rule | Meaning | Why |
|---|---|---|
| required | Every declared field must have a value | Missing identifiers break downstream joins |
| allowed_status | Customer status is ACTIVE or INACTIVE | Avoid unknown state |
| duplicate_customer_id | Customer ID must be unique | Prevent silent key overwrites |
| amount_decimal | Transaction amount parses as Decimal | Avoid invalid monetary data |
| nonzero_finite_amount | No zero, Infinity or NaN | Avoid meaningless amounts |
| iso_date | Date is canonical YYYY-MM-DD | Consistent downstream filters |
| known_currency | ISO-like approved training list INR/USD/EUR | Avoid misinterpreted amounts |
| known_customer | Transaction customer_id references a valid customer | Enforce referential integrity |
| duplicate_transaction_id | Transaction ID must be unique | Avoid double-counting |
| duplicate_composite_key | `(txn_id,date)` tuple must be unique | Demonstrate compound-key checks |

Every error is captured with `dataset`, `row`, `field`, `rule`, and `value_masked`. Fatal missing/unreadable files raise `DataQualityError` and /health returns HTTP 503. `source_rows = valid_rows + invalid_rows` is checked per file.

# BankAssist 360 — Day 1 runnable solution (SOL-B01)

**Scope:** Python for AI (S001, S003, S004, S005). No LLM, RAG, cloud or later-day implementation. Synthetic data only.

## Windows quick start (PowerShell)
```powershell
cd BankAssist360_Day01
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run_day01.py
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```
Visit `http://127.0.0.1:8000/docs`, `http://127.0.0.1:8000/health` and `http://127.0.0.1:8000/data-quality`.

## Outputs
`outputs/data_quality_report.json` — masked rule-level errors, counts, valid-currency totals.
`outputs/validated_customers.json` and `outputs/validated_transactions.json` — valid synthetic rows.

## Teaching demo
The transaction CSV includes **deliberately invalid records** (bad amount, missing customer, invalid date, duplicate ID, unsupported currency). This is an expected **degraded** quality status, not application failure. Fix those rows and rerun to see `healthy`. Missing source file is a **503**, never false success.

## Day 1 workflow
CSV → read/required-column check → row validation (if/elif, loops) → typed dataclasses → referential / duplicate checks → JSON quality report → FastAPI /health + /data-quality.

## Day 2 carry-forward
Use only validated transaction outputs for the subsequent transaction-explanation prototype. No generated AI explanation is included here.

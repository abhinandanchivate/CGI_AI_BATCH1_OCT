"""Run from project root: python run_day01.py"""
from pathlib import Path
from app.loader import save_outputs
if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    report = save_outputs(root / 'data', root / 'outputs')
    print('Status:', report['status'])
    print('Source rows:', report['source_rows'])
    print('Valid rows:', report['valid_rows'])
    print('Invalid rows:', report['invalid_rows'])
    print('Outputs saved to:', root / 'outputs')

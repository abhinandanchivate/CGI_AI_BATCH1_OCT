Run this command in **Command Prompt, PowerShell, or Terminal** to create and start a MySQL container:

```bash
docker run --name mysql-banklite -e MYSQL_ROOT_PASSWORD=RootPass123 -e MYSQL_DATABASE=banklite -e MYSQL_USER=bank_app -e MYSQL_PASSWORD=BankPass123 -p 3306:3306 -v banklite_mysql_data:/var/lib/mysql -d mysql:8.4
```

| Part                                    | Purpose                                 |
| --------------------------------------- | --------------------------------------- |
| `--name mysql-banklite`                 | Container name                          |
| `MYSQL_ROOT_PASSWORD`                   | Sets the MySQL administrator password   |
| `MYSQL_DATABASE=banklite`               | Creates the `banklite` database         |
| `MYSQL_USER` / `MYSQL_PASSWORD`         | Creates the application's database user |
| `-p 3306:3306`                          | Maps your computer’s port 3306 to MySQL |
| `-v banklite_mysql_data:/var/lib/mysql` | Keeps database data in a Docker volume  |
| `-d`                                    | Runs the container in the background    |
| `mysql:8.4`                             | MySQL image and version                 |

**Check the container:**

```bash
docker ps
docker logs mysql-banklite
```

Wait until the logs show **“ready for connections.”**

**Connect to MySQL from the command line:**

```bash
docker exec -it mysql-banklite mysql -u bank_app -p banklite
```

Enter `BankPass123` when prompted. Then try:

```sql
SHOW DATABASES;
SELECT DATABASE();
SHOW TABLES;
```

**For your FastAPI application running on your computer, use:**

```env
DATABASE_URL=mysql+pymysql://bank_app:BankPass123@localhost:3306/banklite
```

**Stop or restart the existing container:**

```bash
docker stop mysql-banklite
docker start mysql-banklite
```

Use these example passwords for local training only.

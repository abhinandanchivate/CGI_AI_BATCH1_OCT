from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from app.config import settings

engine = create_engine(settings.database_url)
# create_engine : used to create a new SQLAlchemy engine 
# what is an engine in SQLAlchemy? An engine is an interface to the database, which provides a source of database connectivity and behavior.\
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
# SessionLocal : why in uppercase : because it is a class that is used to create new session objects for interacting with the database.
#sessionmaker: used to create and configure the new session object 
# autocommit : False : used to disable the autocommit feature.
# autoflush : False : used to disable the autoflush feature.--> will prevent the session from automatically flushing changes to the database before executing a query.
# bind:engine : used to bind the session to the engine , so that the session can use the engine to connect to the database.

class Base(DeclarativeBase):
    pass
    # DeclarativeBase : used to create a new base class for the declarative model classes.
    # pass : in a class --> it is a keyword that acts as a placeholder for the future code.  ==> python does not allow an empty block --> if u don't want to write anything then we should use the pass keyword.. {}--> pass

def get_db():
    db = SessionLocal()
    try:
        yield db
        return db
        # yeild: used to give a value , pauses and continue later.
    finally:
        db.close()

from app.database import Base
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import String, Integer, Float, ForeignKey,Numeric
from decimal import Decimal
class Customer(Base):
    __tablename__ = "customers"
    id:Mapped[int] = mapped_column(primary_key=True)
    full_name:Mapped[str] = mapped_column(String(100),nullable=False)
    email:Mapped[str] = mapped_column(String(100),nullable=False, unique=True, index=True)
    phone:Mapped[str] = mapped_column(String(10),nullable=False, unique=True)



class Account(Base):
    __tablename__ = "accounts"
    id:Mapped[int] = mapped_column(primary_key=True)
    account_number:Mapped[str] = mapped_column(String(12),nullable=False, unique=True, index=True)
    account_type:Mapped[str] = mapped_column(String(50),nullable=False)
    balance:Mapped[Decimal] = mapped_column(Numeric(14,2),nullable=False, default=Decimal("0.00"))
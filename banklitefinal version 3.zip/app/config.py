from pydantic_settings import BaseSettings, SettingsConfigDict

# pydantic-settings : used to manage envs 
class Settings(BaseSettings):
    database_url: str
    app_name: str = "BankLite Training API"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

#  SettingsConfigDict : used to configures how the settings are loaded , including the envs.
settings = Settings()

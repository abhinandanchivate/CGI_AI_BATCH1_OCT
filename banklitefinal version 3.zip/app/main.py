from fastapi import FastAPI
from app.config import settings
from app.database import Base, engine
from app.routers.customers import router as customer_router

def create_app(create_tables: bool = True) -> FastAPI:
    app = FastAPI(title=settings.app_name)
    if create_tables:
       
        Base.metadata.create_all(bind=engine) # only in training ==> production 
    app.include_router(customer_router,prefix="/api/v1")

    @app.get("/health", status_code=200, tags=["health"])
    def health_check():
        return {"status": "ok"}
    return app

app = create_app()
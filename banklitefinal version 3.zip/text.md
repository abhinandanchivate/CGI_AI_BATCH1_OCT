pip : package manager ===> install , update , uninstall the packages.

python3 -m uvicorn app.main:app --reload

python3:
-m : module uviconrn: web server that serves the banklite app
app.main:: it finds main.py in app folder.
app: it uses the variable called app deinfed inside the main.py
--reload : will help u to reload the app if any changes are done in your app code.

Traceback (most recent call last):
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/compiler.py", line 7220, in visit\*create_table
processed = self.process(
create_column, first_pk=column.primary_key and not first_pk
)
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/compiler.py", line 972, in process
return obj.\_compiler_dispatch(self, \*\*kwargs)

```^^^^^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/visitors.py", line 128, in \_compiler_dispatch
return meth(self, **kw) # type: ignore[no-any-return] # noqa: E501
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/compiler.py", line 7303, in visit_create_column
text = self.get_column_specification(column, first_pk=first_pk)
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/dialects/mysql/base.py", line 2040, in get_column_specification
return self.dialect.\_dispatch_for_vendor(
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^
self.\_mysql_get_column_specification,
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
...<2 lines>...
**kw,
^^^^^
)
^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/dialects/mysql/base.py", line 3159, in \_dispatch_for_vendor
return mysql_callable(\*arg, **kw)
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/dialects/mysql/base.py", line 2057, in \_mysql_get_column_specification
self.dialect.type_compiler_instance.process(
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^
column.type, type_expression=column
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
),
^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/compiler.py", line 1017, in process
return type*._compiler_dispatch(self, **kw)
~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/visitors.py", line 128, in \_compiler_dispatch
return meth(self, **kw) # type: ignore[no-any-return] # noqa: E501
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/compiler.py", line 7958, in visit_string
return self.visit_VARCHAR(type_, \*\*kw)
~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/dialects/mysql/base.py", line 2607, in visit_VARCHAR
raise exc.CompileError(
"VARCHAR requires a length on dialect %s" % self.dialect.name
)
sqlalchemy.exc.CompileError: VARCHAR requires a length on dialect mysql

The above exception was the direct cause of the following exception:

Traceback (most recent call last):
File "/Library/Frameworks/Python.framework/Versions/3.14/lib/python3.14/multiprocessing/process.py", line 320, in \_bootstrap
self.run()
~~~~~~~~^^
File "/Library/Frameworks/Python.framework/Versions/3.14/lib/python3.14/multiprocessing/process.py", line 108, in run
self.\_target(\*self.\_args, **self.\_kwargs)
~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/uvicorn/\_subprocess.py", line 80, in subprocess_started
target(sockets=sockets)
~~~~~~^^^^^^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/uvicorn/server.py", line 86, in run
return asyncio_run(self.serve(sockets=sockets), loop_factory=self.config.get_loop_factory())
File "/Library/Frameworks/Python.framework/Versions/3.14/lib/python3.14/asyncio/runners.py", line 204, in run
return runner.run(main)
~~~~~~~~~~^^^^^^
File "/Library/Frameworks/Python.framework/Versions/3.14/lib/python3.14/asyncio/runners.py", line 127, in run
return self.\_loop.run_until_complete(task)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^
File "uvloop/loop.pyx", line 1515, in uvloop.loop.Loop.run_until_complete
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/uvicorn/server.py", line 90, in serve
await self.\_serve(sockets)
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/uvicorn/server.py", line 97, in \_serve
config.load()
~~~~~~~~~~~^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/uvicorn/config.py", line 511, in load
self.loaded_app = self.load_app()
~~~~~~~~~~~~~^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/uvicorn/config.py", line 434, in load_app
return import_from_string(self.app)
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/uvicorn/importer.py", line 19, in import_from_string
module = importlib.import_module(module_str)
File "/Library/Frameworks/Python.framework/Versions/3.14/lib/python3.14/importlib/**init**.py", line 88, in import_module
return \_bootstrap.\_gcd_import(name[level:], package, level)
~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
File "<frozen importlib._bootstrap>", line 1398, in \_gcd_import
File "<frozen importlib._bootstrap>", line 1371, in \_find_and_load
File "<frozen importlib._bootstrap>", line 1342, in \_find_and_load_unlocked
File "<frozen importlib._bootstrap>", line 938, in \_load_unlocked
File "<frozen importlib._bootstrap_external>", line 762, in exec_module
File "<frozen importlib._bootstrap>", line 491, in \_call_with_frames_removed
File "/Users/abhinandanchivate/Downloads/BankLite/app/main.py", line 18, in <module>
app = create_app()
File "/Users/abhinandanchivate/Downloads/BankLite/app/main.py", line 10, in create_app
Base.metadata.create_all(bind=engine) # only in training ==> production
~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/schema.py", line 6698, in create_all
bind.\_run_ddl_visitor(
~~~~~~~~~~~~~~~~~~~~~^
ddl.SchemaGenerator, self, checkfirst=checkfirst, tables=tables
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
)
^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/engine/base.py", line 3238, in \_run_ddl_visitor
conn.\_run_ddl_visitor(visitorcallable, element, **kwargs)
~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/engine/base.py", line 2439, in \_run_ddl_visitor
).traverse_single(element)
~~~~~~~~~~~~~~~^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/visitors.py", line 650, in traverse_single
return meth(obj, \*\*kw)
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/ddl.py", line 1472, in visit_metadata
self.traverse_single(
~~~~~~~~~~~~~~~~~~~~^
table,
^^^^^^
...<2 lines>...
\_is_metadata_operation=True,
^^^^^^^^^^^^^^^^^^^^^^^^^^^^
)
^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/visitors.py", line 650, in traverse_single
return meth(obj, **kw)
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/ddl.py", line 1515, in visit_table
table_create_ddl.\_invoke_with(self.connection)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/ddl.py", line 337, in \_invoke_with
return bind.execute(self)
~~~~~~~~~~~~^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/engine/base.py", line 1451, in execute
return meth(
self,
distilled_parameters,
execution_options or NO_OPTIONS,
)
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/ddl.py", line 203, in \_execute_on_connection
return connection.\_execute_ddl(
~~~~~~~~~~~~~~~~~~~~~~~^
self, distilled_params, execution_options
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
)
^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/engine/base.py", line 1557, in \_execute_ddl
compiled = ddl.compile(
dialect=dialect, schema_translate_map=schema_translate_map
)
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/elements.py", line 318, in compile
return self.\_compiler(dialect, **kw)
~~~~~~~~~~~~~~^^^^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/ddl.py", line 87, in \_compiler
return dialect.ddl_compiler(dialect, self, \*\*kw)
~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/compiler.py", line 936, in **init**
self.string = self.process(self.statement, **compile_kwargs)
~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/compiler.py", line 972, in process
return obj.\_compiler_dispatch(self, **kwargs)
~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/visitors.py", line 128, in \_compiler_dispatch
return meth(self, \*\*kw) # type: ignore[no-any-return] # noqa: E501
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/sqlalchemy/sql/compiler.py", line 7230, in visit_create_table
raise exc.CompileError(
...<2 lines>...
) from ce
sqlalchemy.exc.CompileError: (in table 'customers', column 'full_name'): VARCHAR requires a length on dialect mysql

solN : we fix it by providing the size .


File "<frozen importlib._bootstrap_external>", line 762, in exec_module
  File "<frozen importlib._bootstrap>", line 491, in _call_with_frames_removed
  File "/Users/abhinandanchivate/Downloads/BankLite/app/main.py", line 18, in <module>
    app = create_app()
  File "/Users/abhinandanchivate/Downloads/BankLite/app/main.py", line 11, in create_app
    app.include_router(Customer.router,prefix="/api/v1")
                       ^^^^^^^^^^^^^^^
AttributeError: type object 'Customer' has no attribute 'router'
```

solN : wrong import in Main.py and we imported router from routers/customers and fixed it.

result = context.run(func, \*args)
File "/Users/abhinandanchivate/Downloads/BankLite/.venv/lib/python3.14/site-packages/fastapi/telemetry/\_api.py", line 244, in \_run_sync_endpoint
return function(\*\*arguments)
File "/Users/abhinandanchivate/Downloads/BankLite/app/routers/customers.py", line 38, in get_all_customers
customers = db.scalar(select(Customer)).all()
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AttributeError: 'Customer' object has no attribute 'all'

soln:

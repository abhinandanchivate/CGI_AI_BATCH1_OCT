# BankAssist 360 — Day 3: Responsible GenAI + Prompt Engineering (S011–S016)

A training-oriented implementation of Python, FastAPI, SQLAlchemy, MySQL and optional Gemini. **Not production ready and not an authorized banking decision system.** No real customer data should be used. Gemini integration was not live-tested against your account.

## Quick start

1. Install Python 3.11–3.13 and Docker Desktop.
2. Start MySQL: `docker compose up -d`.
3. Create virtual environment: `python -m venv .venv` (Mac/Linux `python3 -m venv .venv`).
4. Activate: Windows PowerShell `.venv\Scripts\Activate.ps1`; Mac/Linux `source .venv/bin/activate`.
5. `pip install -r requirements.txt`.
6. Copy `.env.example` to `.env` and set unique MySQL credentials, a long random `DEMO_API_TOKEN`, and optionally `GEMINI_API_KEY`.
7. To enable Gemini, set `AI_ENABLED=true` in `.env`; verify model availability in your API account.
8. `python -m uvicorn app.main:app --reload`.
9. Visit `http://127.0.0.1:8000/docs`. Use `x-demo-token` header for protected routes.
10. Test: `python -m pytest -q` (uses a separate SQLite test DB; do not use production data).

**Important:** `compose.yaml` contains classroom example passwords. Change them AND the URL in `.env` before use. The sample database is bound to loopback; don't publish it.

## Example curl (Mac/Linux)

```bash
curl -X POST http://127.0.0.1:8000/api/v1/ask \
  -H 'content-type: application/json' -H 'x-demo-token: REPLACE_WITH_YOUR_TOKEN' \
  -d '{"question":"My debit card is lost. What should I do?","style":"few_shot","context_type":"policy"}'
```

When `AI_ENABLED=false`, the `/ask` route returns `status=unavailable` rather than inventing an LLM response.

## API routes

| Method | Path | Topic |
|---|---|---|
| GET | `/health` | Key presence and mode (never exposes key) |
| POST | `/api/v1/ask` | S012–S016 safe prompt-building + generation + output checks |
| POST | `/api/v1/privacy/anonymize` | S012 elementary PII masking |
| POST | `/api/v1/fairness/evaluate` | S011 descriptive group fairness metrics |
| POST | `/api/v1/fairness/postprocess?score=0.51` | S011 uncertain-score human review |
| POST | `/api/v1/security/redteam` | S013 prompt-injection demonstration |

## Design constraints

- RLHF and Constitutional AI are **explained and demonstrated as principles**, not trained or claimed as implemented algorithms.
- Differential privacy requires formal epsilon/delta accounting and a vetted mechanism; **not implemented**. See `docs/SECURITY_STANDARDS.md`.
- Model safety configuration + regex rules are defense-in-depth *examples*, never guarantees.
- Prompt styles do not require or expose hidden model chain-of-thought; `structured_steps` requests short user-facing explanation.
- Raw text isn't written to MySQL audit events, but LLM requests go to the configured Gemini provider. Masking is incomplete; don't use private data.
- There is no real-bank integration, human approval workflow, training pipeline, demographic attribute collection, or production authentication/rate limiting.

## References

- FastAPI: https://fastapi.tiangolo.com/
- Google Gen AI Python SDK: https://googleapis.github.io/python-genai/
- OWASP LLM Prompt Injection: https://cheatsheetseries.owasp.org/cheatsheets/LLM_Prompt_Injection_Prevention_Cheat_Sheet.html
- NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

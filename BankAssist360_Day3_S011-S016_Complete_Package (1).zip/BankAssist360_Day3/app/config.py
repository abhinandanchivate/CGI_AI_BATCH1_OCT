from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_name: str = "BankAssist 360 - Day 3"
    database_url: str = "sqlite:///./bankassist.db"
    gemini_api_key: str = ""
    gemini_model: str = "gemini-flash-latest"
    demo_api_token: str = "replace-this-with-a-long-random-secret"
    ai_enabled: bool = False


@lru_cache

def get_settings() -> Settings:
    return Settings()

import hmac
import logging
from contextlib import asynccontextmanager
from uuid import uuid4
from fastapi import Depends, FastAPI, Header, HTTPException
from sqlalchemy.orm import Session
from app.config import Settings, get_settings
from app.database import Base, engine, get_db
from app.guards import anonymize, fairness_metrics, inspect_input, inspect_output, postprocess_decision
from app.llm import GeminiService, GeminiUnavailable
from app.models import AuditEvent
from app.prompts import build_prompt
from app.schemas import AskRequest, AskResponse, FairnessRequest, PrivacyRequest, RedTeamRequest

log = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Only for classroom use. Production databases must use Alembic migrations.
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(title="BankAssist 360 | Responsible GenAI Lab", lifespan=lifespan)


def authenticate(x_demo_token: str | None = Header(default=None), settings: Settings = Depends(get_settings)):
    if not x_demo_token or not hmac.compare_digest(x_demo_token, settings.demo_api_token):
        raise HTTPException(status_code=401, detail="Invalid lab token")


def audit(db: Session, category: str, action: str, detail: str) -> None:
    # Never persist a raw customer question or API key in audit records.
    db.add(AuditEvent(category=category, action=action, detail=detail[:400]))
    db.commit()


@app.get("/health")
def health(settings: Settings = Depends(get_settings)):
    return {"status": "ok", "model": settings.gemini_model,
            "gemini_api_key_configured": bool(settings.gemini_api_key),
            "ai_enabled": settings.ai_enabled}


@app.post("/api/v1/ask", response_model=AskResponse, dependencies=[Depends(authenticate)])
def ask(payload: AskRequest, db: Session = Depends(get_db), settings: Settings = Depends(get_settings)):
    request_id = str(uuid4())
    reasons = inspect_input(payload.question) + inspect_input(payload.context)
    if reasons:
        audit(db, "prompt", "blocked", ",".join(sorted(set(reasons))))
        return AskResponse(answer="Request requires review.", status="blocked", reasons=sorted(set(reasons)),
                           prompt_style=payload.style, request_id=request_id)
    safe_question = anonymize(payload.question)
    safe_context = anonymize(payload.context)
    prompt = build_prompt(safe_question, safe_context, payload.context_type, payload.style)
    try:
        answer = GeminiService(settings).generate(prompt, payload.temperature)
    except GeminiUnavailable:
        audit(db, "llm", "unavailable", "provider_disabled_or_failed")
        return AskResponse(answer="AI service unavailable. No answer was generated.", status="unavailable",
                           reasons=["provider_unavailable"], prompt_style=payload.style, request_id=request_id)
    output_reasons = inspect_output(answer)
    if output_reasons:
        audit(db, "output", "blocked", ",".join(output_reasons))
        return AskResponse(answer="Response withheld for privacy review.", status="review",
                           reasons=output_reasons, prompt_style=payload.style, request_id=request_id)
    # A model's policy claims are not verified facts: route results to human review.
    audit(db, "llm", "review", "generated_not_factually_verified")
    return AskResponse(answer=answer, status="review", reasons=["verify_against_approved_policy"],
                       prompt_style=payload.style, request_id=request_id)


@app.post("/api/v1/privacy/anonymize", dependencies=[Depends(authenticate)])
def privacy(payload: PrivacyRequest):
    return {"anonymized": anonymize(payload.text), "warning": "Regex masking is incomplete; do not send real customer PII."}


@app.post("/api/v1/fairness/evaluate", dependencies=[Depends(authenticate)])
def fairness(payload: FairnessRequest):
    return fairness_metrics([record.model_dump() for record in payload.records])


@app.post("/api/v1/fairness/postprocess", dependencies=[Depends(authenticate)])
def postprocess(score: float):
    if score < 0 or score > 1:
        raise HTTPException(status_code=422, detail="score must be between 0 and 1")
    return postprocess_decision(score)


@app.post("/api/v1/security/redteam", dependencies=[Depends(authenticate)])
def redteam(payload: RedTeamRequest):
    return {"detected": bool(inspect_input(payload.attack)), "indicators": inspect_input(payload.attack),
            "warning": "A string match is not proof of injection safety. Test with human review."}

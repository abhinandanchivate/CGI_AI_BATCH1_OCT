from typing import Literal
from pydantic import BaseModel, Field


PromptStyle = Literal["zero_shot", "one_shot", "few_shot", "structured_steps"]


class AskRequest(BaseModel):
    question: str = Field(min_length=5, max_length=1500)
    style: PromptStyle = "zero_shot"
    context_type: Literal["policy", "transaction", "general"] = "policy"
    context: str = Field(default="", max_length=2000)
    temperature: float = Field(default=0.2, ge=0, le=1)


class AskResponse(BaseModel):
    answer: str
    status: Literal["answered", "blocked", "unavailable", "review"]
    reasons: list[str] = Field(default_factory=list)
    prompt_style: PromptStyle
    request_id: str


class FairnessRecord(BaseModel):
    group: Literal["A", "B"]
    true_label: bool
    approved: bool


class FairnessRequest(BaseModel):
    records: list[FairnessRecord] = Field(min_length=2, max_length=500)


class PrivacyRequest(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


class RedTeamRequest(BaseModel):
    attack: str = Field(min_length=3, max_length=1500)

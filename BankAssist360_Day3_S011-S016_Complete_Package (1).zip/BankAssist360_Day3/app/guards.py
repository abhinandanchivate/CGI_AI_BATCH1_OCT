import re
from collections import Counter

# Demonstration indicators, NOT comprehensive prompt-injection detection.
INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(all\s+)?(previous|prior)\s+instructions", re.I),
    re.compile(r"(reveal|print|show)\s+(the\s+)?(system prompt|secret|api key)", re.I),
    re.compile(r"you\s+are\s+now\s+(a|an)\s+", re.I),
]
HARMFUL_PATTERNS = [re.compile(r"how to (steal|forge) (a |an )?(card|identity)", re.I)]
EMAIL = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
PHONE = re.compile(r"(?<!\d)[6-9]\d{9}(?!\d)")
ACCOUNT = re.compile(r"\b\d{12,18}\b")


def anonymize(text: str) -> str:
    text = EMAIL.sub("[EMAIL]", text)
    text = PHONE.sub("[PHONE]", text)
    return ACCOUNT.sub("[ACCOUNT]", text)


def inspect_input(text: str) -> list[str]:
    reasons = ["possible_prompt_injection"] if any(p.search(text) for p in INJECTION_PATTERNS) else []
    if any(p.search(text) for p in HARMFUL_PATTERNS):
        reasons.append("restricted_request")
    return reasons


def inspect_output(text: str) -> list[str]:
    reasons = []
    if EMAIL.search(text) or PHONE.search(text) or ACCOUNT.search(text):
        reasons.append("possible_sensitive_data")
    return reasons


def fairness_metrics(records: list[dict]) -> dict:
    """Training-only descriptive group statistics; not a fairness certification."""
    result = {}
    for group in ("A", "B"):
        rows = [r for r in records if r["group"] == group]
        approved = sum(r["approved"] for r in rows)
        positives = [r for r in rows if r["true_label"]]
        true_positives = sum(r["approved"] for r in positives)
        result[group] = {
            "count": len(rows),
            "approval_rate": approved / len(rows) if rows else None,
            "true_positive_rate": true_positives / len(positives) if positives else None,
        }
    a, b = result["A"]["approval_rate"], result["B"]["approval_rate"]
    gap = abs(a - b) if a is not None and b is not None else None
    return {"groups": result, "approval_rate_gap": gap, "review_required": gap is None or gap > 0.1,
            "note": "Illustrative rates only; assess sample size, lawful attributes, confounding and errors."}


def balance_counts(labels: list[str]) -> dict:
    """Report imbalance rather than fabricating synthetic minority applicants."""
    counts = Counter(labels)
    return {"counts": dict(counts), "recommendation": "Review representativeness and sampling before training."}


def postprocess_decision(score: float, cutoff: float = 0.5) -> dict:
    """Illustrative post-processing: route uncertain predictions to human review."""
    if abs(score - cutoff) <= 0.1:
        return {"decision": "human_review", "reason": "near_decision_threshold"}
    return {"decision": "candidate_yes" if score > cutoff else "candidate_no", "reason": "not_an_authorized_credit_decision"}

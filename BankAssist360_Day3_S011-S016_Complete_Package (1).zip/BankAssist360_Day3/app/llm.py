from app.config import Settings


class GeminiUnavailable(Exception):
    pass


class GeminiService:
    def __init__(self, settings: Settings):
        self.settings = settings

    def generate(self, prompt: str, temperature: float) -> str:
        if not self.settings.ai_enabled or not self.settings.gemini_api_key:
            raise GeminiUnavailable("Gemini is disabled or its API key is not configured")
        try:
            from google import genai
            from google.genai import types
            with genai.Client(api_key=self.settings.gemini_api_key) as client:
                response = client.models.generate_content(
                    model=self.settings.gemini_model,
                    contents=prompt,
                    config=types.GenerateContentConfig(
                        temperature=temperature,
                        max_output_tokens=400,
                        # Model moderation is one layer, not a complete safety boundary.
                        safety_settings=[
                            types.SafetySetting(category="HARM_CATEGORY_HARASSMENT", threshold="BLOCK_MEDIUM_AND_ABOVE"),
                            types.SafetySetting(category="HARM_CATEGORY_HATE_SPEECH", threshold="BLOCK_MEDIUM_AND_ABOVE"),
                            types.SafetySetting(category="HARM_CATEGORY_DANGEROUS_CONTENT", threshold="BLOCK_MEDIUM_AND_ABOVE"),
                        ],
                    ),
                )
            if not response.text:
                raise GeminiUnavailable("Model returned no text; possibly blocked by safety filters")
            return response.text.strip()
        except GeminiUnavailable:
            raise
        except Exception as exc:
            raise GeminiUnavailable("Gemini request failed; inspect server-side diagnostics") from exc

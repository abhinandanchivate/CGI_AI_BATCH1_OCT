# Architecture and end-to-end workflows

## Application architecture

```mermaid
flowchart TD
    A[Student / Swagger / curl] --> B[FastAPI auth and Pydantic input validation]
    B --> C[Prompt-injection and prohibited-request indicators]
    C -->|suspicious| D[Block and minimal MySQL audit]
    C -->|passes| E[PII masking]
    E --> F[Approved policy + untrusted-context wrapper]
    F --> G[Zero/one/few-shot or structured steps]
    G --> H[Gemini SDK optional]
    H --> I[Output privacy scan]
    I -->|possibly sensitive| J[Withhold + minimal MySQL audit]
    I -->|passes| K[Review-required answer]
    K --> L[Human policy verification before action]
```

## S011 Fairness workflow

```mermaid
flowchart LR
  A[Illustrative labeled records] --> B[Check coverage and imbalance]
  B --> C[Per-group approval rate and TPR]
  C --> D[Compare observed gaps]
  D --> E[Investigate samples and confounders]
  E --> F[Human validation before any remediation]
```

## S012–S013 guardrails and red-team

```mermaid
flowchart LR
 A[Attack phrase] --> B[Input checks]
 B --> C{Indicator detected?}
 C -->|yes| D[Block + audit category]
 C -->|no| E[Still potentially unsafe]
 E --> F[Constrained prompt + model safety + output review]
```

## S014–S016 prompting workflow

```mermaid
flowchart TD
 A[Role] --> B[Task: answer support question]
 B --> C[Rules and scope]
 C --> D[Approved policy context]
 D --> E[Untrusted external context]
 E --> F{Prompt style}
 F --> G[Zero shot]
 F --> H[One shot example]
 F --> I[Few shot examples]
 F --> J[Structured visible steps]
 G --> K[Gemini generation]
 H --> K
 I --> K
 J --> K
```

## Data-flow / trust boundaries

- **Browser -> API:** user content untrusted. Authenticate all lab endpoints except health.
- **API -> Gemini:** a third-party processing boundary. Anonymization attempts are not sufficient for PII compliance.
- **API -> MySQL:** event categories and short diagnostic strings only; avoid raw input/outputs/secrets.
- **Policy fixture:** a hard-coded illustrative policy; real projects require access-controlled versioned authoritative retrieval and deterministic evidence validation.
- **Human:** final review required for policy claims and every consequential banking decision.

# Standards mapping and implementation limits

| Topic | Present demo | Needed for real bank deployment |
|---|---|---|
| S011 Balanced datasets | `balance_counts` for illustrative counts | lawful sampling, label quality and representation audit; don't fabricate applicants |
| S011 Fairness metrics | group rates + TPR + sample sizes | subgroup error and equal opportunity analysis, confidence intervals, monitoring |
| S011 Post-processing | uncertain scores to human review | policy/ethics/legal sign-off; never auto-discriminate using protected attributes |
| S012 Injection | direct phrase indicators + untrusted-data framing | threat modeling, trusted retrieval, classifier, tool isolation, least privilege, attack testing |
| S012 Anonymization | pattern masking | DLP/tokenization, proper consent, cryptographic controls, retention policy |
| S012 Differential privacy | conceptual only | vetted DP library, formal privacy accountant, threat model, epsilon/delta budget and utility tests |
| S013 RLHF | concept only | preference data, reward/preference model, training evaluation & alignment governance |
| S013 Constitutional AI | policy-based prompt principle only | constitutional critique/revision/training with robust independent tests |
| S013 Red teaming | sample payload endpoint and tests | adversarial corpus, human assessment, replay and incident process |
| S013 Moderation API | Gemini provider safety settings | actual moderation service/API, audited thresholds, escalation strategy |
| S014 Prompt anatomy | role, policy, context, task, output rules | approved templating/versioning; defend against instruction-data confusion |
| S015 Shots | zero, one, few | curated unbiased examples and tests |
| S016 CoT | concise structured visible steps | do not request/reveal private chain-of-thought; evaluate answers rather than internal traces |

Additional controls: OIDC/JWT and role authorization; real secret manager; production DB migrations with Alembic; pool sizing and timeouts; HTTPS; egress policies; rate limits; monitoring; no customer logs; tenant isolation; complete prompt-injection and output validation; disaster recovery; model-version pinning; security and legal review; data-subject rights.

## Differential privacy: instructor explanation

A DP algorithm bounds what an attacker can learn about whether a *single individual* was included in data. Parameters `epsilon` and `delta` express the privacy bound. Adding arbitrary random noise is **not** a proof of differential privacy; a proper sensitivity calculation, approved mechanism, composition accounting and repeated-query budget are required. No DP claims should be made about this lab.

## Guardrail honesty

An LLM can disobey its instructions. String patterns are bypassable. No deterministic check in this demonstration establishes that an answer is factually supported; responses are always marked `review`. The sample has no bank authorization to approve loans, access accounts, or submit disputes.

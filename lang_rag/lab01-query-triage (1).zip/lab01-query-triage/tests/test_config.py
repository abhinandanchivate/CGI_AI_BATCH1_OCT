from bankassist.config import SETTINGS, get_llm, model_kwargs


def test_gemini_gets_thinking_level_not_temperature():
    kwargs = model_kwargs("google_genai:gemini-3.8-flash")
    assert "temperature" not in kwargs
    assert kwargs.get("thinking_level") == SETTINGS.thinking_level


def test_other_providers_get_temperature_zero():
    assert model_kwargs("openai:gpt-4o-mini") == {"temperature": 0}


def test_default_model_is_gemini_and_sends_no_temperature():
    llm = get_llm()
    assert type(llm).__name__ == "ChatGoogleGenerativeAI"
    assert llm.temperature is None

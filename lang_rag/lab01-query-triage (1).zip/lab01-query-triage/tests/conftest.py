"""Offline test setup: fake keys so model objects can be built, tracing off, fake embeddings."""

import os

os.environ.setdefault("GOOGLE_API_KEY", "test-key-not-used")
os.environ["LANGSMITH_TRACING"] = "false"

import pytest
from langchain_core.embeddings import DeterministicFakeEmbedding

try:  # data_access exists from Lab 3 onwards
    from bankassist import data_access
except ImportError:  # pragma: no cover - Labs 1 and 2
    data_access = None


@pytest.fixture
def fake_embeddings():
    return DeterministicFakeEmbedding(size=64)


@pytest.fixture(autouse=True)
def fresh_customer_data():
    """Reset in-memory customer data so tests that block cards do not leak state."""
    if data_access:
        data_access._customers.cache_clear()
    yield
    if data_access:
        data_access._customers.cache_clear()

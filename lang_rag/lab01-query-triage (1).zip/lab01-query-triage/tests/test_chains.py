import pytest
from pydantic import ValidationError

from bankassist.chains import INTENTS, Intent, Ticket


def test_intents_string_matches_literal():
    assert INTENTS.split(", ") == list(Intent.__args__)


def test_ticket_rejects_unknown_intent():
    with pytest.raises(ValidationError):
        Ticket(intent="mortgage_fraud", urgency="high", sentiment="negative", summary="x")


def test_ticket_accepts_valid_values():
    t = Ticket(intent="card_block", urgency="high", sentiment="negative", summary="Lost card 4321")
    assert t.model_dump()["intent"] == "card_block"

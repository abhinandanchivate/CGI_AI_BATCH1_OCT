# Build prompt: BankAssist 360, Lab 1 (lab01-query-triage)

Paste everything below into an AI coding assistant (Gemini, Claude, Copilot Chat) from the project
root. Review every file it returns, then run `make install && make test`.

---

You are a senior Python engineer building one lab of the BankAssist 360 course: a retail-banking
assistant for the fictional Apex National Bank (India, amounts in INR), built with LangChain v1,
LangGraph v1, LangSmith and Google Gemini.

GOAL (Lab 1: Query Triage with Model I/O and LCEL)
Sessions: S028 Model I/O · S029 Chains, Prompt Templates, Sequential Flows
Turn a raw customer message into a structured ticket and a drafted reply, with every step traced in LangSmith.

STARTING POINT:
Create a new project from scratch.

PROJECT STRUCTURE (create exactly this; '<- new in this lab' marks what you write now):

    lab01-query-triage/
      pyproject.toml          dependencies, ruff, pytest
      Makefile
      README.md
      .env.example
      .github/workflows/ci.yml
      .pre-commit-config.yaml
      src/bankassist/
        __init__.py            package marker and version   <- new in this lab
        config.py              settings, paths, logging, Gemini model factories   <- new in this lab
        cli.py                 --step runner   <- new in this lab
        chains.py              triage chain and Ticket schema   <- new in this lab
        lab.py                 this lab's runnable steps   <- new in this lab
        assignments/           your part 12 and 13 work
      data/
        eval/routing_set.jsonl   <- new in this lab
      tests/
        conftest.py   <- new in this lab
        test_config.py   <- new in this lab
        test_chains.py   <- new in this lab
      indexes/                generated at run time (git-ignored)
      docs/Lab01.pptx
      docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant

DEPENDENCIES (pyproject.toml [project].dependencies):
    langchain>=1.0,<2, langchain-core>=1.0,<2, langchain-google-genai>=4.4, langsmith>=0.4,
    pydantic>=2.6, python-dotenv>=1.0

AI TOOLS (use exactly these; declare their names in lab.py as AI_TOOLS, in this order):
    - Gemini 3.8 Flash: Triage, reply drafting and the language and PII checks
    - LangChain LCEL: Pipelines built with the pipe operator (prompt, model, parser), RunnableParallel, batch
      and stream
    - Pydantic structured output: The Ticket schema via with_structured_output
    - LangSmith tracing: Runs, tags and metadata; @traceable on plain functions
    Model IDs come from .env: LLM_MODEL=google_genai:gemini-3.8-flash

CODING STANDARDS:
- Python 3.11+, src layout: package `bankassist` under `src/`,
  installable with `pip install -e ".[dev]"`.
- `pyproject.toml` is the single source of dependencies (setuptools build, `dev` extra with pytest, ruff,
  pre-commit), ruff (line length 120; rules E, F, W, I, B, UP, SIM, RUF; `bankassist` is first-party) and
  pytest settings (`testpaths = ["tests"]`, `pythonpath = ["src", "."]`).
- Configuration only through `.env`, loaded once in `config.py`; never hard-code keys. Ship `.env.example`.
- Models: `init_chat_model("google_genai:<model>")`. Gemini 3+ deprecates temperature, top_p and top_k:
  never pass them for Gemini; pass `thinking_level` from `THINKING_LEVEL` instead. Embeddings:
  `GoogleGenerativeAIEmbeddings(model="gemini-embedding-2")`. Default models: main `gemini-3.8-flash`,
  fast `gemini-3.5-flash-lite`, judge `gemini-4-argon`.
- No import-time side effects: models, indexes and graphs are created by `build_*` / `get_*` functions,
  cached with `functools.lru_cache` where reuse matters. Pass dependencies (retriever, models, embeddings)
  as arguments so tests can inject fakes.
- Type hints and a docstring on every module and public function; Pydantic models for every structured LLM output.
- Library modules log with `get_logger(__name__)`; only `lab.py` prints results.
- Security: customer identity comes from `RunnableConfig["configurable"]["customer_id"]`, never from model
  arguments; money-moving actions need human approval; mask PII before it reaches a model or a trace.
- Tests run offline: `tests/conftest.py` sets a fake `GOOGLE_API_KEY`, `LANGSMITH_TRACING=false` and provides a
  `DeterministicFakeEmbedding` fixture. No test may call a real API.
- `lab.py` exposes `main()` that calls `bankassist.cli.run_steps(title, {number: step_function}, tools=AI_TOOLS)`;
  each step function's first docstring line is its description, and `AI_TOOLS` (a module-level tuple) names the
  lab's AI tools, shown by `--help`. `python -m bankassist.lab --step N` runs one step.

FILES TO WRITE:

src/bankassist/__init__.py: BankAssist 360: a retail-banking assistant built with LangChain, LangGraph,
  LangSmith and Gemini.
  Public API (implement exactly these names and signatures):
    (package marker: `__version__ = "1.0.0"`)

src/bankassist/config.py: Central configuration for BankAssist 360.
  Public API (implement exactly these names and signatures):
    constant PROJECT_ROOT = Path(__file__).resolve().parents[2]
    constant DATA_DIR = PROJECT_ROOT / 'data'
    constant POLICY_DIR = DATA_DIR / 'policies'
    constant PDF_DIR = DATA_DIR / 'pdfs'
    constant EVAL_DIR = DATA_DIR / 'eval'
    constant INDEX_DIR = PROJECT_ROOT / 'indexes'
    class Settings()
        # Runtime settings read from environment variables, with safe defaults.
        field llm_model: str
        field fast_llm_model: str
        field judge_model: str
        field embed_provider: str
        field embed_model: str
        field thinking_level: str
        field log_level: str
        field langsmith_project: str
    constant SETTINGS = Settings()
    def get_logger(name: str) -> logging.Logger
        # Return a module logger with one consistent format for the whole project.
    def model_kwargs(model: str) -> dict
        # Provider-specific settings for repeatable, cost-aware answers.
    @lru_cache(maxsize=8)
    def get_llm(model: str | None=None)
        # Build (once per model) and return a chat model.
    def get_fast_llm()
        # Cheaper model for routing, grading and query rewriting (Lab 10 model tiering).
    def get_judge_llm()
        # Stronger model used only as an evaluation judge (Lab 10).
    @lru_cache(maxsize=1)
    def get_embeddings()
        # Build (once) and return the embedding model for ``EMBED_PROVIDER``.

src/bankassist/cli.py: Tiny CLI helper so every lab can run all steps or one step: ``python -m bankassist.lab
  --step 3``.
  Public API (implement exactly these names and signatures):
    def run_steps(title: str, steps: dict[int, Callable[[], None]], tools: Sequence[str]=()) -> None
        # Run every step in order, or only ``--step N``. ``tools`` lists the AI tools this lab uses (shown in --help).

src/bankassist/chains.py: Reusable LCEL chains: query triage (Lab 1) used again by the Lab 4 workflow.
  Public API (implement exactly these names and signatures):
    constant INTENTS = ', '.join(Intent.__args__)
    class Ticket(BaseModel)
        # Structured triage result for one customer message.
        field intent: Intent
        field urgency: Literal['low', 'medium', 'high']
        field sentiment: Literal['positive', 'neutral', 'negative']
        field summary: str
    constant TRIAGE_PROMPT
    constant REPLY_PROMPT
    def build_triage_chain() -> Runnable
        # prompt -> model with structured output -> Ticket.
    def build_reply_chain() -> Runnable
        # reply prompt -> model -> plain string.
    def triage(message: str) -> Ticket
        # Convenience wrapper used by the workflow and tests.

IMPLEMENTATION RULES (the tests and the lab guide depend on these):
    - config.py: load `.env` from the project root (`Path(__file__).resolve().parents[2]`); `Settings` is a
      frozen dataclass read from env vars; `model_kwargs(model)` returns `{'thinking_level': ...}` for
      `google_genai:` models and `{'temperature': 0}` otherwise; `get_llm`, `get_embeddings` are `lru_cache`d.
    - chains.py: `Intent` is a `Literal` of the 8 intents; `INTENTS` is built from `Intent.__args__` so the
      list exists once; `Ticket` has `intent`, `urgency` (low|medium|high), `sentiment`
      (positive|neutral|negative), `summary`.
    - TRIAGE_PROMPT defines each intent and says urgency is high when money or a card is lost or fraud is
      suspected. REPLY_PROMPT: max 80 words, polite, never promises a refund.
    - `build_triage_chain()` = TRIAGE_PROMPT | llm.with_structured_output(Ticket), run name `triage`;
      `build_reply_chain()` = REPLY_PROMPT | llm | StrOutputParser(), run name `draft_reply`.
    - lab.py: step 4 is a sequential pipeline using `RunnablePassthrough.assign` twice (ticket, then
      draft_reply) named `triage_pipeline`; step 5 uses `RunnableParallel(ticket=..., language=...,
      has_pii=...)`; step 7 wraps a function with `@traceable(name='triage_api', tags=['lab1'],
      metadata={'prompt_version': 'v1'})`.

src/bankassist/lab.py: this lab's runnable steps, registered in run_steps() with these numbers:
    --step 1: Call the model with message roles and read token usage
    --step 3: Prompt template + structured output with Pydantic
    --step 4: Sequential flow: ticket, then drafted reply
    --step 5: Run triage, language detection and a PII check in parallel
    --step 6: Batch a backlog, then stream one reply
    --step 7: Trace a plain Python function with tags and metadata

DATA (provided by the course; copy it, do not invent it):
    data/eval/routing_set.jsonl   <- new in this lab

TESTS (offline, pytest). Write these new test functions:
  tests/test_config.py
    test_gemini_gets_thinking_level_not_temperature
        # checks: gemini gets thinking level not temperature
    test_other_providers_get_temperature_zero
        # checks: other providers get temperature zero
    test_default_model_is_gemini_and_sends_no_temperature
        # checks: default model is gemini and sends no temperature
  tests/test_chains.py
    test_intents_string_matches_literal
        # checks: intents string matches literal
    test_ticket_rejects_unknown_intent
        # checks: ticket rejects unknown intent
    test_ticket_accepts_valid_values
        # checks: ticket accepts valid values
  tests/conftest.py: fake GOOGLE_API_KEY, LANGSMITH_TRACING=false, fake_embeddings fixture

ALSO WRITE OR UPDATE: README.md (setup, steps table, expected outputs, structure),
.env.example (only the keys this lab needs), Makefile (install, test, lint, run STEP=N), .gitignore,
.pre-commit-config.yaml (ruff, private-key detection), .github/workflows/ci.yml
(ruff + pytest on Python 3.11 and 3.12).

EXPECTED BEHAVIOUR WHEN RUN WITH REAL KEYS:
    - Ticket: transaction_dispute, high, negative
    - Draft reply under 80 words, no refund promise
    - LangSmith run triage_pipeline with child runs

ACCEPTANCE CHECKS (all must pass before you finish):
    1. `ruff check .` reports no issues.
    2. `pytest` passes offline with no API keys and no network calls.
    3. `python -m bankassist.lab --help` lists steps 1, 3, 4, 5, 6, 7.
    4. No module creates a model, index or graph at import time.
    5. Gemini models are never given a temperature.

OUTPUT FORMAT: return every new or changed file in full, each preceded by a line
`=== path/to/file ===`.
No placeholders, no 'rest unchanged' comments. After the files, list any assumption you made.

"""Tiny CLI helper so every lab can run all steps or one step: ``python -m bankassist.lab --step 3``."""

from __future__ import annotations

import argparse
from collections.abc import Callable, Sequence


def run_steps(title: str, steps: dict[int, Callable[[], None]], tools: Sequence[str] = ()) -> None:
    """Run every step in order, or only ``--step N``. ``tools`` lists the AI tools this lab uses (shown in --help)."""
    epilog = f"AI tools in this lab: {', '.join(tools)}" if tools else None
    parser = argparse.ArgumentParser(description=title, epilog=epilog)
    parser.add_argument("--step", type=int, choices=sorted(steps), help="run only this step")
    args = parser.parse_args()
    if tools:
        print(f"{title}\nAI tools: {', '.join(tools)}")
    for number, fn in steps.items():
        if args.step is None or args.step == number:
            print(f"\n=== Step {number}: {(fn.__doc__ or fn.__name__).strip().splitlines()[0]} ===")
            fn()

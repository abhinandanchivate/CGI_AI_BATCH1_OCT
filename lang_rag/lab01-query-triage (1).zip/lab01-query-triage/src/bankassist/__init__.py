"""BankAssist 360: a retail-banking assistant built with LangChain, LangGraph, LangSmith and Gemini.

Each lab project ships this package as a snapshot: everything built up to that lab,
plus ``bankassist.lab`` with the lab's runnable steps.
"""

__version__ = "1.0.0"

"""Your solutions for the assignment (part 12) and modification tasks (part 13)."""

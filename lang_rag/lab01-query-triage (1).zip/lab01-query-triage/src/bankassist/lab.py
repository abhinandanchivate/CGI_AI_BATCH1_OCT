"""Lab 1: Query triage with Model I/O, prompt templates and LCEL chains.

Sessions: S028 Model I/O and Integration, S029 Chains, Prompt Templates, Sequential Flows.
Run:      python -m bankassist.lab            (all steps)
          python -m bankassist.lab --step 4   (one step)
"""

from __future__ import annotations

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable, RunnableParallel, RunnablePassthrough
from langsmith import traceable

from bankassist.chains import INTENTS, build_reply_chain, build_triage_chain
from bankassist.cli import run_steps
from bankassist.config import get_llm

SAMPLE_MESSAGE = "My debit card was charged twice at Big Bazaar on 28 Oct for 2,450. Please fix this ASAP!"
BATCH_MESSAGES = [
    "What is the ATM fee at other banks?",
    "I lost my credit card",
    "What is the home loan rate?",
    "Your branch staff ignored me for an hour",
    "Good morning!",
]


def build_pipeline() -> Runnable:
    """Sequential flow: triage -> reply, keeping both results."""
    triage_chain = build_triage_chain()
    reply_chain = build_reply_chain()
    return (
        RunnablePassthrough.assign(ticket=triage_chain)
        | RunnablePassthrough.assign(draft_reply=lambda x: reply_chain.invoke(x["ticket"].model_dump()))
    ).with_config(run_name="triage_pipeline")


def step1_messages() -> None:
    """Call the model with message roles and read token usage."""
    resp = get_llm().invoke([
        SystemMessage("You are BankAssist, a polite assistant for Apex National Bank. Never give investment advice."),
        HumanMessage("What documents do I need for KYC?"),
    ])
    print(resp.content)
    print("Token usage:", resp.usage_metadata)
    print("Note: this answer is general knowledge, not the bank's policy. RAG fixes this in Lab 5.")


def step2_3_structured() -> None:
    """Prompt template + structured output with Pydantic."""
    ticket = build_triage_chain().invoke({"intents": INTENTS, "message": SAMPLE_MESSAGE})
    print(ticket.model_dump_json(indent=2))


def step4_sequential() -> None:
    """Sequential flow: ticket, then drafted reply."""
    result = build_pipeline().invoke({"intents": INTENTS, "message": SAMPLE_MESSAGE})
    print(result["ticket"].model_dump_json(indent=2))
    print("\nDraft reply:\n", result["draft_reply"])


def step5_parallel() -> None:
    """Run triage, language detection and a PII check in parallel."""
    llm = get_llm()
    lang_prompt = ChatPromptTemplate.from_template("Return only the ISO 639-1 language code of: {message}")
    pii_prompt = ChatPromptTemplate.from_template(
        "Answer yes or no only: does this text contain a full card number, Aadhaar or PAN? {message}")
    lang = lang_prompt | llm | StrOutputParser()
    pii = pii_prompt | llm | StrOutputParser()
    parallel = RunnableParallel(ticket=build_triage_chain(), language=lang, has_pii=pii)
    print(parallel.invoke({"intents": INTENTS, "message": "Mera card kho gaya hai, please block karo"}))


def step6_batch_stream() -> None:
    """Batch a backlog, then stream one reply."""
    tickets = build_triage_chain().batch(
        [{"intents": INTENTS, "message": m} for m in BATCH_MESSAGES], config={"max_concurrency": 3})
    for msg, t in zip(BATCH_MESSAGES, tickets, strict=True):
        print(f"{t.intent:20} {t.urgency:6} | {msg}")
    print("\nStreaming reply for the lost-card ticket:")
    for chunk in build_reply_chain().stream(tickets[1].model_dump()):
        print(chunk, end="", flush=True)
    print()


@traceable(name="triage_api", tags=["lab1"], metadata={"prompt_version": "v1"})
def triage_api(message: str, channel: str) -> dict:
    """Function-level tracing with tags and metadata for filtering in LangSmith."""
    return build_pipeline().invoke({"intents": INTENTS, "message": message},
                                   config={"metadata": {"channel": channel}, "tags": ["lab1"]})


def step7_traced() -> None:
    """Trace a plain Python function with tags and metadata."""
    out = triage_api("Please block my card ending 4321", channel="whatsapp")
    print(out["ticket"].intent, "->", out["draft_reply"][:120], "...")
    print("Open LangSmith, project 'bankassist360', filter by tag 'lab1'.")


AI_TOOLS = (  # what each does: README.md, 'AI tools used'
    "Gemini 3.8 Flash",
    "LangChain LCEL",
    "Pydantic structured output",
    "LangSmith tracing",
)


def main() -> None:
    run_steps("Lab 1: Model I/O, prompts and LCEL", {
        1: step1_messages, 3: step2_3_structured, 4: step4_sequential,
        5: step5_parallel, 6: step6_batch_stream, 7: step7_traced,
    }, tools=AI_TOOLS)


if __name__ == "__main__":
    main()

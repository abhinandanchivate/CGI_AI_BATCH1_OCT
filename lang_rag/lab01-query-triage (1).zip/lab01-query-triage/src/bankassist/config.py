"""Central configuration for BankAssist 360.

Every lab imports models, embeddings, paths and loggers from here, so the provider,
model names and folders can be changed in one place (the ``.env`` file).

Importing this module loads ``.env``. That also switches LangSmith tracing on
when ``LANGSMITH_TRACING=true`` is set.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[2]  # src/bankassist/config.py -> project root
load_dotenv(PROJECT_ROOT / ".env")

DATA_DIR = PROJECT_ROOT / "data"
POLICY_DIR = DATA_DIR / "policies"
PDF_DIR = DATA_DIR / "pdfs"
EVAL_DIR = DATA_DIR / "eval"
INDEX_DIR = PROJECT_ROOT / "indexes"


@dataclass(frozen=True)
class Settings:
    """Runtime settings read from environment variables, with safe defaults.

    Defaults use Google Gemini (model IDs current as of November 2026). Any provider
    supported by ``init_chat_model`` works by changing the ``provider:model`` strings.
    """

    llm_model: str = os.getenv("LLM_MODEL", "google_genai:gemini-3.8-flash")
    fast_llm_model: str = os.getenv("FAST_LLM_MODEL", "google_genai:gemini-3.5-flash-lite")
    judge_model: str = os.getenv("JUDGE_MODEL", "google_genai:gemini-4-argon")
    embed_provider: str = os.getenv("EMBED_PROVIDER", "google_genai")
    embed_model: str = os.getenv("EMBED_MODEL", "gemini-embedding-2")
    thinking_level: str = os.getenv("THINKING_LEVEL", "low")  # minimal | low | medium | high
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    langsmith_project: str = os.getenv("LANGSMITH_PROJECT", "bankassist360")


SETTINGS = Settings()


def get_logger(name: str) -> logging.Logger:
    """Return a module logger with one consistent format for the whole project."""
    if not logging.getLogger().handlers:
        logging.basicConfig(
            level=SETTINGS.log_level,
            format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
            datefmt="%H:%M:%S",
        )
    return logging.getLogger(name)


def model_kwargs(model: str) -> dict:
    """Provider-specific settings for repeatable, cost-aware answers.

    Gemini 3+ models deprecate ``temperature``/``top_p``/``top_k``; reasoning depth is set
    with ``thinking_level`` instead. Other providers get ``temperature=0``.
    """
    if model.startswith("google_genai:"):
        return {"thinking_level": SETTINGS.thinking_level} if SETTINGS.thinking_level else {}
    return {"temperature": 0}


@lru_cache(maxsize=8)
def get_llm(model: str | None = None):
    """Build (once per model) and return a chat model.

    Args:
        model: ``provider:model`` string; defaults to ``LLM_MODEL``.
    """
    from langchain.chat_models import init_chat_model

    name = model or SETTINGS.llm_model
    return init_chat_model(name, **model_kwargs(name))


def get_fast_llm():
    """Cheaper model for routing, grading and query rewriting (Lab 10 model tiering)."""
    return get_llm(model=SETTINGS.fast_llm_model)


def get_judge_llm():
    """Stronger model used only as an evaluation judge (Lab 10)."""
    return get_llm(model=SETTINGS.judge_model)


@lru_cache(maxsize=1)
def get_embeddings():
    """Build (once) and return the embedding model for ``EMBED_PROVIDER``."""
    if SETTINGS.embed_provider == "google_genai":
        from langchain_google_genai import GoogleGenerativeAIEmbeddings

        return GoogleGenerativeAIEmbeddings(model=SETTINGS.embed_model)
    if SETTINGS.embed_provider == "openai":
        from langchain_openai import OpenAIEmbeddings

        return OpenAIEmbeddings(model=SETTINGS.embed_model)
    raise ValueError(f"Unsupported EMBED_PROVIDER: {SETTINGS.embed_provider}")

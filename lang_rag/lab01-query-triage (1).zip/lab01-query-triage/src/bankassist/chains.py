"""Reusable LCEL chains: query triage (Lab 1) used again by the Lab 4 workflow."""

from __future__ import annotations

from typing import Literal

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable
from pydantic import BaseModel, Field

from bankassist.config import get_llm

Intent = Literal[
    "balance_enquiry", "transaction_dispute", "card_block", "loan_enquiry",
    "fee_query", "kyc", "complaint", "other",
]
INTENTS = ", ".join(Intent.__args__)  # single source of truth for the prompt


class Ticket(BaseModel):
    """Structured triage result for one customer message."""

    intent: Intent
    urgency: Literal["low", "medium", "high"]
    sentiment: Literal["positive", "neutral", "negative"]
    summary: str = Field(description="One sentence, include amounts and dates")


TRIAGE_PROMPT = ChatPromptTemplate.from_messages([
    ("system",
     "You triage customer messages for Apex National Bank.\n"
     "Allowed intents: {intents}.\n"
     "card_block = lost, stolen or block a card. transaction_dispute = wrong, duplicate or unknown debit.\n"
     "fee_query = any charge, fee or charge code. kyc = documents, PAN, re-KYC.\n"
     "Urgency is high if money is lost, a card is lost, or fraud is suspected."),
    ("human", "Customer message:\n{message}"),
])

REPLY_PROMPT = ChatPromptTemplate.from_template(
    "Write a short, polite first reply (max 80 words) to this customer.\n"
    "Intent: {intent}. Urgency: {urgency}. Sentiment: {sentiment}.\n"
    "Summary: {summary}\n"
    "Do not promise refunds; say the team will investigate."
)


def build_triage_chain() -> Runnable:
    """prompt -> model with structured output -> Ticket."""
    return (TRIAGE_PROMPT | get_llm().with_structured_output(Ticket)).with_config(run_name="triage")


def build_reply_chain() -> Runnable:
    """reply prompt -> model -> plain string."""
    return (REPLY_PROMPT | get_llm() | StrOutputParser()).with_config(run_name="draft_reply")


def triage(message: str) -> Ticket:
    """Convenience wrapper used by the workflow and tests."""
    return build_triage_chain().invoke({"intents": INTENTS, "message": message})

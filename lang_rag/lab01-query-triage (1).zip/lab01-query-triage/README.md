# BankAssist 360, Lab 1: Query Triage with Model I/O and LCEL

S028 Model I/O · S029 Chains, Prompt Templates, Sequential Flows

Turn a raw customer message into a structured ticket and a drafted reply, with every step traced in LangSmith.

This project is standalone: it contains everything built in earlier labs (nothing (first lab)), so you can
start here without finishing the previous lab. Code from earlier labs is identical to their projects.

## How to run this lab

You need Python 3.11 or 3.12 and these keys in `.env`: `GOOGLE_API_KEY` and `LANGSMITH_API_KEY`. Tests need no keys.

macOS or Linux:

```bash
python3 -m venv .venv && source .venv/bin/activate
make install                 # pip install -e ".[dev]" + pre-commit hooks
cp .env.example .env         # then add your keys
make test                    # offline: expect 6 passed
make run                     # every step in order
make run STEP=7              # one step
```

Windows (PowerShell, no make needed):

```powershell
py -3.11 -m venv .venv; .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
Copy-Item .env.example .env  # then add your keys
pytest                       # offline: expect 6 passed
python -m bankassist.lab     # every step in order
python -m bankassist.lab --step 7  # one step
```

`python -m bankassist.lab --help` lists the steps. Step numbers match the implementation steps in the lab
guide; guide steps without their own command are code you read in `src/bankassist/`, and their effect shows
in the next step that runs.

What to expect when you run it:

- Steps 4, 5 and 7 are best inspected in LangSmith (project `bankassist360`): keep `LANGSMITH_TRACING=true`.
- Step 6 sends a batch of five messages with `max_concurrency=3`, then streams one reply token by token.
- Nothing is written to disk.

Start again from a clean state with `make clean` (deletes `indexes/`).

## Steps in this lab

| Command | What it does |
| --- | --- |
| `--step 1` | Call the model with message roles and read token usage |
| `--step 3` | Prompt template + structured output with Pydantic |
| `--step 4` | Sequential flow: ticket, then drafted reply |
| `--step 5` | Run triage, language detection and a PII check in parallel |
| `--step 6` | Batch a backlog, then stream one reply |
| `--step 7` | Trace a plain Python function with tags and metadata |

The full walkthrough, code explanations, knowledge check, assignment and modification tasks are in
the BankAssist 360 lab guide (Lab 1). Slides: `docs/Lab01.pptx`. To rebuild this project with an AI
coding assistant, use the prompt in `docs/BUILD_PROMPT.md`.

## AI tools used

| Tool | Role in this lab |
| --- | --- |
| Gemini 3.8 Flash | Triage, reply drafting and the language and PII checks |
| LangChain LCEL | Pipelines built with the pipe operator (prompt, model, parser), RunnableParallel, batch and stream |
| Pydantic structured output | The Ticket schema via with_structured_output |
| LangSmith tracing | Runs, tags and metadata; @traceable on plain functions |

Model names are the defaults in `.env.example`; change them there, never in code. `python -m bankassist.lab --help`
lists the same tools.

## Expected outputs

- Ticket: transaction_dispute, high, negative
- Draft reply under 80 words, no refund promise
- LangSmith run triage_pipeline with child runs

## Concepts covered

- **Chat model interface:** Messages in, AIMessage out, any provider
- **Prompt template:** Reusable prompt with named variables
- **Structured output:** Model fills a validated Pydantic schema
- **LCEL and Runnables:** invoke, batch, stream; | chains steps
- **Sequential vs parallel:** assign adds keys; RunnableParallel fans out
- **Tracing:** @traceable, tags and metadata in LangSmith

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `ModuleNotFoundError: bankassist` | The virtual environment is not active or the project is not installed. | Activate `.venv`, then `make install` (or `python -m pip install -e ".[dev]"`). |
| `make: command not found` (Windows) | make is not installed. | Run the commands directly: `pytest`, `python -m bankassist.lab --step N`. |
| `Activate.ps1 cannot be loaded` (Windows) | PowerShell blocks local scripts by default. | Run `Set-ExecutionPolicy -Scope Process RemoteSigned`, then activate again. |
| 400 or 404 from Gemini naming the model | The model ID in `.env` is retired or mistyped. | Check the IDs against the Gemini API changelog and update `LLM_MODEL`, `FAST_LLM_MODEL`, `JUDGE_MODEL`. |
| 429 or `RESOURCE_EXHAUSTED` | Free-tier rate limit. | Wait a minute, lower concurrency (Lab 1 step 6, Lab 10 `run_experiment`), or use a paid key. |
| No traces in LangSmith | Tracing is off, the key is wrong, or you are looking at another project. | Set `LANGSMITH_TRACING=true` and `LANGSMITH_API_KEY`; open project `bankassist360`. |
| Chroma or FAISS dimension error | Indexes were built with another embedding model. | `make clean`, then rerun the step. |
| Lab 7 or later: first query is slow | The cross-encoder is downloading. | Wait once; it is cached afterwards. |
| Lab 10 `/approve` returns 409 | Nothing is waiting for approval on that session. | Send a card-block request to `/chat` first with the same `session_id`. |

## Project structure

```text
lab01-query-triage/
  pyproject.toml          dependencies, ruff, pytest
  Makefile
  README.md
  .env.example
  .github/workflows/ci.yml
  .pre-commit-config.yaml
  src/bankassist/
    __init__.py            package marker and version   <- new in this lab
    config.py              settings, paths, logging, Gemini model factories   <- new in this lab
    cli.py                 --step runner   <- new in this lab
    chains.py              triage chain and Ticket schema   <- new in this lab
    lab.py                 this lab's runnable steps   <- new in this lab
    assignments/           your part 12 and 13 work
  data/
    eval/routing_set.jsonl   <- new in this lab
  tests/
    conftest.py   <- new in this lab
    test_config.py   <- new in this lab
    test_chains.py   <- new in this lab
  indexes/                generated at run time (git-ignored)
  docs/Lab01.pptx
  docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant
```

## Standards used

- `src/` layout, installable package, one source of truth for dependencies (`pyproject.toml`)
- Configuration only through `.env` (see `.env.example`); no keys in code
- No import-time side effects: models, indexes and graphs are built by `build_*` / `get_*` functions
- Type hints, docstrings, Pydantic schemas for every structured model output
- `ruff` lint, `pytest` offline tests, pre-commit hooks and a GitHub Actions workflow
- Gemini 3+ models: no `temperature`; `thinking_level` instead (set in `.env`)

## Next

Continue with [Lab 2](../lab02-conversational-memory/).

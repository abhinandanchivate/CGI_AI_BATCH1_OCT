# BankAssist 360: ten lab projects

A retail-banking AI assistant built in ten labs with LangChain, LangGraph, LangSmith, RAG and Google Gemini.
Each folder below is a **standalone, installable project**: it contains everything built up to that lab, its own
tests, data, README, CI workflow and slides. Learners can start any lab without finishing the previous one.

| Project | Lab | Sessions | New in this project |
| --- | --- | --- | --- |
| `lab01-query-triage` | 1 | S028, S029 | `config.py`, `cli.py`, `chains.py` |
| `lab02-conversational-memory` | 2 | S030 | `memory.py` |
| `lab03-banking-agent` | 3 | S031 | `data_access.py`, `tools.py`, `agent.py` |
| `lab04-langgraph-workflow` | 4 | S032 | `workflow.py` |
| `lab05-policy-rag` | 5 | S033, S034 | `guardrails.py`, `prompts.py`, `retrievers.py`, `rag.py` |
| `lab06-chunking-matching` | 6 | S035, S036 | `retrievers.py` grows: exact match, hit rate |
| `lab07-hybrid-rerank` | 7 | S040, S041 | `retrievers.py`, `rag.py` grow: fusion, re-rank |
| `lab08-domain-multimodal` | 8 | S037, S042 | `multimodal.py`; glossary and domain prompt |
| `lab09-agentic-rag` | 9 | S039, S043 | `agentic_rag.py` |
| `lab10-evaluation-release` | 10 | S038, S044, S045 | `evaluation.py`, `api.py` (capstone) |

## Start a lab

```bash
cd lab01-query-triage
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
make install                                          # pip install -e ".[dev]" + pre-commit hooks
cp .env.example .env                                  # add GOOGLE_API_KEY and LANGSMITH_API_KEY
make test                                             # offline, no keys needed
make run                                              # or: python -m bankassist.lab --step 3
```

One shared virtual environment also works: install `lab10-evaluation-release` (its dependencies cover every lab),
then `pip install -e .` inside whichever lab you are working on.

## Standards in every project

- `src/` layout and one package name (`bankassist`), so imports read the same in every lab
- `pyproject.toml` as the single source of dependencies, ruff and pytest settings
- `.env.example` with only the keys that lab needs; Gemini 3+ uses `thinking_level`, never `temperature`
- Offline `pytest` suite (fake keys, fake embeddings, stubbed model nodes), `ruff`, pre-commit hooks
- GitHub Actions workflow (`.github/workflows/ci.yml`) running lint and tests on Python 3.11 and 3.12
- No import-time side effects; customer identity from config; human approval before card blocks

## How to run the labs

Each lab is its own project. Pick one, then:

```bash
cd lab05-policy-rag
python3 -m venv .venv && source .venv/bin/activate   # Windows: py -3.11 -m venv .venv; .venv\Scripts\Activate.ps1
make install                                         # or: python -m pip install -e ".[dev]"
cp .env.example .env                                 # add GOOGLE_API_KEY and LANGSMITH_API_KEY
make test                                            # offline, no keys used
make run                                             # every step; make run STEP=4 for one
```

| Lab | Project | Steps | Offline tests | Extra keys | First-run notes |
| --- | --- | --- | --- | --- | --- |
| 1 | `lab01-query-triage` | 1, 3, 4, 5, 6, 7 | 6 | – | None |
| 2 | `lab02-conversational-memory` | 1, 2, 3, 4, 5 | 7 | – | None |
| 3 | `lab03-banking-agent` | 2, 3, 4, 5 | 18 | – | None |
| 4 | `lab04-langgraph-workflow` | 4, 5, 6 | 26 | – | None |
| 5 | `lab05-policy-rag` | 1, 2, 4, 5, 6 | 38 | – | Saves FAISS and Chroma indexes |
| 6 | `lab06-chunking-matching` | 1, 6, 7 | 42 | – | Embedding-heavy step 1 |
| 7 | `lab07-hybrid-rerank` | 1, 5, 6 | 45 | – | Downloads the cross-encoder (~90 MB) |
| 8 | `lab08-domain-multimodal` | 1, 2, 4, 6 | 49 | – | Builds `policies_v2`, captions the chart |
| 9 | `lab09-agentic-rag` | 1, 5 | 50 | TAVILY_API_KEY | Live search needs Tavily |
| 10 | `lab10-evaluation-release` | 1, 5, 6, 8 | 54 | TAVILY_API_KEY | Several minutes for step 5; `make api`, `make gate` |

Each project's README has the full run guide for Windows and macOS/Linux, the AI tools the lab uses, what to
expect, and troubleshooting. `python -m bankassist.lab --help` also lists the lab's AI tools.
One shared environment installed from `lab10-evaluation-release` also works for every lab.

### Offline rehearsal (instructors)

`_instructor/course-source/tools/smoke.py` runs every step of a lab with stand-ins for the chat model,
embeddings, re-ranker and LangSmith, so you can check a lab end to end without keys:

```bash
cd lab05-policy-rag && pip install -e ".[dev]"
python ../_instructor/course-source/tools/smoke.py . 5     # SMOKE_SHOW=1 prints each step's output
```

## Build prompts

Each project has `docs/BUILD_PROMPT.md`: a ready-to-paste prompt that lets an AI coding assistant generate that
project (structure, signatures, rules, tests and acceptance checks), generated from the reference code.

## For instructors

`_instructor/course-source/` holds the single source the ten projects are generated from (shared modules with
`# region labN` blocks, per-lab step files, tests, data). After changing it, regenerate every project:

```bash
cd _instructor/course-source
python build_projects.py ../../       # rebuilds lab01-... to lab10-... (needs Node.js for README text and build prompts)
```

Gemini model IDs were checked against the Gemini API changelog on 3 November 2026. Check them before each course
run; only `.env.example` files need to change.

# Build prompt: BankAssist 360, Lab 3 (lab03-banking-agent)

Paste everything below into an AI coding assistant (Gemini, Claude, Copilot Chat) from the project
root. Review every file it returns, then run `make install && make test`.

---

You are a senior Python engineer building one lab of the BankAssist 360 course: a retail-banking
assistant for the fictional Apex National Bank (India, amounts in INR), built with LangChain v1,
LangGraph v1, LangSmith and Google Gemini.

GOAL (Lab 3: Banking Agent with Tools)
Sessions: S031 Tool / Agent Integration
An agent that decides which banking tool to call, with the customer's identity injected securely rather than
chosen by the model.

STARTING POINT:
Copy the project `lab02-conversational-memory` to `lab03-banking-agent`, delete its `src/bankassist/lab.py`,
and keep these files unchanged unless this prompt says the file grows:
    src/bankassist/: config.py, cli.py, chains.py, memory.py

PROJECT STRUCTURE (create exactly this; '<- new in this lab' marks what you write now):

    lab03-banking-agent/
      pyproject.toml          dependencies, ruff, pytest
      Makefile
      README.md
      .env.example
      .github/workflows/ci.yml
      .pre-commit-config.yaml
      src/bankassist/
        __init__.py            package marker and version
        config.py              settings, paths, logging, Gemini model factories
        cli.py                 --step runner
        chains.py              triage chain and Ticket schema
        memory.py              trimming, summaries, checkpointer, store
        data_access.py         synthetic core-banking data   <- new in this lab
        tools.py               banking tools (identity from config)   <- new in this lab
        agent.py               create_agent banking agent   <- new in this lab
        lab.py                 this lab's runnable steps   <- new in this lab
        assignments/           your part 12 and 13 work
      scripts/
        generate_sample_data.py   <- new in this lab
      data/
        eval/routing_set.jsonl
        customers.json   <- new in this lab
        transactions.csv   <- new in this lab
      tests/
        conftest.py
        test_config.py
        test_chains.py
        test_memory.py
        test_tools.py   <- new in this lab
      indexes/                generated at run time (git-ignored)
      docs/Lab03.pptx
      docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant

DEPENDENCIES (pyproject.toml [project].dependencies):
    langchain>=1.0,<2, langchain-core>=1.0,<2, langchain-google-genai>=4.4, langsmith>=0.4,
    pydantic>=2.6, python-dotenv>=1.0, langgraph>=1.0,<2, pandas>=2.0

AI TOOLS (use exactly these; declare their names in lab.py as AI_TOOLS, in this order):
    - Gemini 3.8 Flash: The tool-calling agent model
    - LangChain create_agent: The ReAct agent loop
    - LangChain @tool: Balance, transactions, EMI and card-block tools with the customer injected from config
    - LangGraph runtime: Runs the agent graph, its checkpointer and streaming
    - LangSmith tracing: Every tool call and result
    Model IDs come from .env: LLM_MODEL=google_genai:gemini-3.8-flash

CODING STANDARDS:
- Python 3.11+, src layout: package `bankassist` under `src/`,
  installable with `pip install -e ".[dev]"`.
- `pyproject.toml` is the single source of dependencies (setuptools build, `dev` extra with pytest, ruff,
  pre-commit), ruff (line length 120; rules E, F, W, I, B, UP, SIM, RUF; `bankassist` is first-party) and
  pytest settings (`testpaths = ["tests"]`, `pythonpath = ["src", "."]`).
- Configuration only through `.env`, loaded once in `config.py`; never hard-code keys. Ship `.env.example`.
- Models: `init_chat_model("google_genai:<model>")`. Gemini 3+ deprecates temperature, top_p and top_k:
  never pass them for Gemini; pass `thinking_level` from `THINKING_LEVEL` instead. Embeddings:
  `GoogleGenerativeAIEmbeddings(model="gemini-embedding-2")`. Default models: main `gemini-3.8-flash`,
  fast `gemini-3.5-flash-lite`, judge `gemini-4-argon`.
- No import-time side effects: models, indexes and graphs are created by `build_*` / `get_*` functions,
  cached with `functools.lru_cache` where reuse matters. Pass dependencies (retriever, models, embeddings)
  as arguments so tests can inject fakes.
- Type hints and a docstring on every module and public function; Pydantic models for every structured LLM output.
- Library modules log with `get_logger(__name__)`; only `lab.py` prints results.
- Security: customer identity comes from `RunnableConfig["configurable"]["customer_id"]`, never from model
  arguments; money-moving actions need human approval; mask PII before it reaches a model or a trace.
- Tests run offline: `tests/conftest.py` sets a fake `GOOGLE_API_KEY`, `LANGSMITH_TRACING=false` and provides a
  `DeterministicFakeEmbedding` fixture. No test may call a real API.
- `lab.py` exposes `main()` that calls `bankassist.cli.run_steps(title, {number: step_function}, tools=AI_TOOLS)`;
  each step function's first docstring line is its description, and `AI_TOOLS` (a module-level tuple) names the
  lab's AI tools, shown by `--help`. `python -m bankassist.lab --step N` runs one step.

FILES TO WRITE:

src/bankassist/data_access.py: Data access layer for the synthetic core-banking data.
  Public API (implement exactly these names and signatures):
    def get_customer(customer_id: str) -> dict | None
        # Return a copy of the customer record, or None if the ID is unknown.
    def get_transactions(customer_id: str, limit: int=5) -> list[dict]
        # Return the customer's most recent transactions, newest first.
    def set_card_status(customer_id: str, card_last4: str, status: str) -> bool
        # Update a card's status in the in-memory store. Returns True if a card was updated.

src/bankassist/tools.py: Banking tools for the Lab 3 agent and the Lab 4 workflow.
  Public API (implement exactly these names and signatures):
    constant MAX_TXN_LIMIT = 20
    def emi_amount(principal_inr: float, annual_rate_pct: float, tenure_years: int) -> float
        # Standard EMI formula: P * r * (1+r)^n / ((1+r)^n - 1). Pure function, unit tested.
    @tool
    def get_account_balance(config: RunnableConfig) -> str
        # Get the current balance of the logged-in customer's accounts.
    @tool
    def get_recent_transactions(limit: int, config: RunnableConfig) -> list[dict]
        # Get the logged-in customer's most recent transactions, newest first. limit: 1-20.
    @tool
    def calculate_emi(principal_inr: float, annual_rate_pct: float, tenure_years: int) -> str
        # Calculate the monthly EMI for a loan. Use for any EMI or loan instalment question.
    @tool
    def raise_card_block_request(card_last4: str, reason: str, config: RunnableConfig) -> str
        # Raise a request to block the customer's card. Does NOT block immediately.
    constant BANKING_TOOLS

src/bankassist/agent.py: Banking agent (Lab 3): create_agent with the banking tools.
  Public API (implement exactly these names and signatures):
    constant SYSTEM_PROMPT
    constant DEFAULT_CONFIG
    def build_banking_agent(with_memory: bool=True)
        # ReAct agent on LangGraph. Memory is optional so it can be nested in the Lab 4 workflow.
    def ask(agent, question: str, config: dict | None=None) -> str
        # Send one question and return the final answer text.

IMPLEMENTATION RULES (the tests and the lab guide depend on these):
    - `emi_amount`: P*r*(1+r)^n / ((1+r)^n - 1) with r = annual/12/100, n = years*12; if r == 0 return P/n;
      raise ValueError for non-positive principal or tenure. 25 lakh at 8.5% for 20 years = INR 21,696.
    - Tools read the customer from `config['configurable']['customer_id']` via a `config: RunnableConfig`
      parameter, so the model-facing schema has no customer_id. Tools return `'ERROR: ...'` strings instead of
      raising.
    - `get_recent_transactions` clamps limit to 1..20 (MAX_TXN_LIMIT), newest first.
      `raise_card_block_request` checks the card belongs to the customer and returns `Request BLK-XXXXXX ...
      status pending_verification`; it never blocks the card.
    - data_access.py loads customers.json and transactions.csv lazily with `lru_cache`, returns deep copies
      from `get_customer`, and `set_card_status` mutates the cached record.
    - agent.py: `build_banking_agent(with_memory=True)` = `create_agent(model, tools=BANKING_TOOLS,
      system_prompt=SYSTEM_PROMPT, checkpointer=InMemorySaver() if with_memory else None)`; DEFAULT_CONFIG has
      thread_id C1001-s3, customer_id C1001 and recursion_limit 12.

src/bankassist/lab.py: this lab's runnable steps, registered in run_steps() with these numbers:
    --step 2: See raw tool calling before using an agent
    --step 3: Build the agent and answer account questions
    --step 4: Stream each step of the ReAct loop
    --step 5: Test cross-customer access, bad input, injection and out-of-scope requests

DATA (provided by the course; copy it, do not invent it):
    data/eval/routing_set.jsonl
    data/customers.json   <- new in this lab
    data/transactions.csv   <- new in this lab

TESTS (offline, pytest). Write these new test functions:
  tests/test_tools.py
    test_emi_matches_lab_guide
        # checks: emi matches lab guide
    test_emi_zero_rate_is_simple_division
        # checks: emi zero rate is simple division
    test_emi_rejects_invalid_input
        # checks: emi rejects invalid input
    test_calculate_emi_tool_formats_inr
        # checks: calculate emi tool formats inr
    test_customer_identity_is_hidden_from_the_model
        # checks: The model-facing schema must not expose config or customer_id.
    test_balance_uses_injected_customer
        # checks: balance uses injected customer
    test_recent_transactions_newest_first_and_capped
        # checks: recent transactions newest first and capped
    test_block_request_for_unknown_card_returns_error
        # checks: block request for unknown card returns error
    test_block_request_does_not_block_immediately
        # checks: block request does not block immediately

ALSO WRITE OR UPDATE: README.md (setup, steps table, expected outputs, structure),
.env.example (only the keys this lab needs), Makefile (install, test, lint, run STEP=N, data), .gitignore,
.pre-commit-config.yaml (ruff, private-key detection), .github/workflows/ci.yml
(ruff + pytest on Python 3.11 and 3.12).

EXPECTED BEHAVIOUR WHEN RUN WITH REAL KEYS:
    - Balance: XXXX4521, INR 84,250.75
    - EMI for 25 lakh, 8.5%, 20 years: INR 21,696
    - Two identical INR 2,450 debits on 28 Oct
    - Block request: pending_verification

ACCEPTANCE CHECKS (all must pass before you finish):
    1. `ruff check .` reports no issues.
    2. `pytest` passes offline with no API keys and no network calls.
    3. `python -m bankassist.lab --help` lists steps 2, 3, 4, 5.
    4. No module creates a model, index or graph at import time.
    5. Gemini models are never given a temperature.

OUTPUT FORMAT: return every new or changed file in full, each preceded by a line
`=== path/to/file ===`.
No placeholders, no 'rest unchanged' comments. After the files, list any assumption you made.

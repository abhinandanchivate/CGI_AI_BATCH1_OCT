# BankAssist 360, Lab 3: Banking Agent with Tools

S031 Tool / Agent Integration

An agent that decides which banking tool to call, with the customer's identity injected securely rather than chosen by the model.

This project is standalone: it contains everything built in earlier labs (`chains.py`, `memory.py`), so you can
start here without finishing the previous lab. Code from earlier labs is identical to their projects.

## How to run this lab

You need Python 3.11 or 3.12 and these keys in `.env`: `GOOGLE_API_KEY` and `LANGSMITH_API_KEY`. Tests need no keys.

macOS or Linux:

```bash
python3 -m venv .venv && source .venv/bin/activate
make install                 # pip install -e ".[dev]" + pre-commit hooks
cp .env.example .env         # then add your keys
make test                    # offline: expect 18 passed
make run                     # every step in order
make run STEP=5              # one step
```

Windows (PowerShell, no make needed):

```powershell
py -3.11 -m venv .venv; .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
Copy-Item .env.example .env  # then add your keys
pytest                       # offline: expect 18 passed
python -m bankassist.lab     # every step in order
python -m bankassist.lab --step 5  # one step
```

`python -m bankassist.lab --help` lists the steps. Step numbers match the implementation steps in the lab
guide; guide steps without their own command are code you read in `src/bankassist/`, and their effect shows
in the next step that runs.

What to expect when you run it:

- Uses `data/customers.json` and `data/transactions.csv`; `make data` regenerates them identically.
- The agent always acts for customer C1001 (from the run config), whatever the message says.
- Card status changes live in memory only; rerunning resets them.

Start again from a clean state with `make clean` (deletes `indexes/`); `make data` regenerates the sample data.

## Steps in this lab

| Command | What it does |
| --- | --- |
| `--step 2` | See raw tool calling before using an agent |
| `--step 3` | Build the agent and answer account questions |
| `--step 4` | Stream each step of the ReAct loop |
| `--step 5` | Test cross-customer access, bad input, injection and out-of-scope requests |

The full walkthrough, code explanations, knowledge check, assignment and modification tasks are in
the BankAssist 360 lab guide (Lab 3). Slides: `docs/Lab03.pptx`. To rebuild this project with an AI
coding assistant, use the prompt in `docs/BUILD_PROMPT.md`.

## AI tools used

| Tool | Role in this lab |
| --- | --- |
| Gemini 3.8 Flash | The tool-calling agent model |
| LangChain create_agent | The ReAct agent loop |
| LangChain @tool | Balance, transactions, EMI and card-block tools with the customer injected from config |
| LangGraph runtime | Runs the agent graph, its checkpointer and streaming |
| LangSmith tracing | Every tool call and result |

Model names are the defaults in `.env.example`; change them there, never in code. `python -m bankassist.lab --help`
lists the same tools.

## Expected outputs

- Balance: XXXX4521, INR 84,250.75
- EMI for 25 lakh, 8.5%, 20 years: INR 21,696
- Two identical INR 2,450 debits on 28 Oct
- Block request: pending_verification

## Concepts covered

- **Tool:** Function + name, description, JSON schema
- **Tool calling:** Model proposes; your code executes
- **Injected arguments:** RunnableConfig hidden from the model
- **ReAct loop:** Reason, act, observe, repeat
- **create_agent:** LangGraph agent with tools and memory
- **Least privilege:** No tool, no capability

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `ModuleNotFoundError: bankassist` | The virtual environment is not active or the project is not installed. | Activate `.venv`, then `make install` (or `python -m pip install -e ".[dev]"`). |
| `make: command not found` (Windows) | make is not installed. | Run the commands directly: `pytest`, `python -m bankassist.lab --step N`. |
| `Activate.ps1 cannot be loaded` (Windows) | PowerShell blocks local scripts by default. | Run `Set-ExecutionPolicy -Scope Process RemoteSigned`, then activate again. |
| 400 or 404 from Gemini naming the model | The model ID in `.env` is retired or mistyped. | Check the IDs against the Gemini API changelog and update `LLM_MODEL`, `FAST_LLM_MODEL`, `JUDGE_MODEL`. |
| 429 or `RESOURCE_EXHAUSTED` | Free-tier rate limit. | Wait a minute, lower concurrency (Lab 1 step 6, Lab 10 `run_experiment`), or use a paid key. |
| No traces in LangSmith | Tracing is off, the key is wrong, or you are looking at another project. | Set `LANGSMITH_TRACING=true` and `LANGSMITH_API_KEY`; open project `bankassist360`. |
| Chroma or FAISS dimension error | Indexes were built with another embedding model. | `make clean`, then rerun the step. |
| Lab 7 or later: first query is slow | The cross-encoder is downloading. | Wait once; it is cached afterwards. |
| Lab 10 `/approve` returns 409 | Nothing is waiting for approval on that session. | Send a card-block request to `/chat` first with the same `session_id`. |

## Project structure

```text
lab03-banking-agent/
  pyproject.toml          dependencies, ruff, pytest
  Makefile
  README.md
  .env.example
  .github/workflows/ci.yml
  .pre-commit-config.yaml
  src/bankassist/
    __init__.py            package marker and version
    config.py              settings, paths, logging, Gemini model factories
    cli.py                 --step runner
    chains.py              triage chain and Ticket schema
    memory.py              trimming, summaries, checkpointer, store
    data_access.py         synthetic core-banking data   <- new in this lab
    tools.py               banking tools (identity from config)   <- new in this lab
    agent.py               create_agent banking agent   <- new in this lab
    lab.py                 this lab's runnable steps   <- new in this lab
    assignments/           your part 12 and 13 work
  scripts/
    generate_sample_data.py   <- new in this lab
  data/
    eval/routing_set.jsonl
    customers.json   <- new in this lab
    transactions.csv   <- new in this lab
  tests/
    conftest.py
    test_config.py
    test_chains.py
    test_memory.py
    test_tools.py   <- new in this lab
  indexes/                generated at run time (git-ignored)
  docs/Lab03.pptx
  docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant
```

## Standards used

- `src/` layout, installable package, one source of truth for dependencies (`pyproject.toml`)
- Configuration only through `.env` (see `.env.example`); no keys in code
- No import-time side effects: models, indexes and graphs are built by `build_*` / `get_*` functions
- Type hints, docstrings, Pydantic schemas for every structured model output
- `ruff` lint, `pytest` offline tests, pre-commit hooks and a GitHub Actions workflow
- Gemini 3+ models: no `temperature`; `thinking_level` instead (set in `.env`)

## Next

Continue with [Lab 4](../lab04-langgraph-workflow/).

# BankAssist 360, Lab 4: Smart Banking Helpdesk with LangGraph

S032 Hands-on Workflow Creation

Combine triage, memory and the agent into one graph that routes by intent and pauses for a human before any card is blocked.

This project is standalone: it contains everything built in earlier labs (`chains.py`, `memory.py`, `data_access.py`, `tools.py`, `agent.py`), so you can
start here without finishing the previous lab. Code from earlier labs is identical to their projects.

## How to run this lab

You need Python 3.11 or 3.12 and these keys in `.env`: `GOOGLE_API_KEY` and `LANGSMITH_API_KEY`. Tests need no keys.

macOS or Linux:

```bash
python3 -m venv .venv && source .venv/bin/activate
make install                 # pip install -e ".[dev]" + pre-commit hooks
cp .env.example .env         # then add your keys
make test                    # offline: expect 26 passed
make run                     # every step in order
make run STEP=6              # one step
```

Windows (PowerShell, no make needed):

```powershell
py -3.11 -m venv .venv; .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
Copy-Item .env.example .env  # then add your keys
pytest                       # offline: expect 26 passed
python -m bankassist.lab     # every step in order
python -m bankassist.lab --step 6  # one step
```

`python -m bankassist.lab --help` lists the steps. Step numbers match the implementation steps in the lab
guide; guide steps without their own command are code you read in `src/bankassist/`, and their effect shows
in the next step that runs.

What to expect when you run it:

- Step 5 pauses at the human-approval interrupt and resumes with `approve` in the same run.
- Step 6 classifies the 20 questions in `data/eval/routing_set.jsonl` (20 model calls).
- Card 4321 is blocked in memory only; rerunning resets it.

Start again from a clean state with `make clean` (deletes `indexes/`); `make data` regenerates the sample data.

## Steps in this lab

| Command | What it does |
| --- | --- |
| `--step 4` | Compile the graph and print its Mermaid diagram |
| `--step 5` | Run, pause at the interrupt, inspect state, then resume with approve |
| `--step 6` | Measure routing accuracy on the labelled routing set |

The full walkthrough, code explanations, knowledge check, assignment and modification tasks are in
the BankAssist 360 lab guide (Lab 4). Slides: `docs/Lab04.pptx`. To rebuild this project with an AI
coding assistant, use the prompt in `docs/BUILD_PROMPT.md`.

## AI tools used

| Tool | Role in this lab |
| --- | --- |
| Gemini 3.8 Flash | Intent triage and block-request extraction |
| LangGraph StateGraph | The intent-routing graph over BankState |
| LangGraph interrupt (human-in-the-loop) | interrupt and Command(resume=...) before any card block |
| LangSmith tracing | Graph runs and routing-accuracy review |

Model names are the defaults in `.env.example`; change them there, never in code. `python -m bankassist.lab --help`
lists the same tools.

## Expected outputs

- Routing accuracy 95% or higher
- Run pauses with an interrupt payload
- Approve blocks; reject keeps card active
- Mermaid diagram of the graph

## Concepts covered

- **StateGraph:** Nodes sharing one typed state
- **Reducers:** messages append; other keys overwrite
- **Conditional edges:** Python router picks the next node
- **Agent as a node:** Lab 3 agent inside the workflow
- **interrupt / Command:** Pause for a human, then resume
- **Durable execution:** Resume later, even in another process

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `ModuleNotFoundError: bankassist` | The virtual environment is not active or the project is not installed. | Activate `.venv`, then `make install` (or `python -m pip install -e ".[dev]"`). |
| `make: command not found` (Windows) | make is not installed. | Run the commands directly: `pytest`, `python -m bankassist.lab --step N`. |
| `Activate.ps1 cannot be loaded` (Windows) | PowerShell blocks local scripts by default. | Run `Set-ExecutionPolicy -Scope Process RemoteSigned`, then activate again. |
| 400 or 404 from Gemini naming the model | The model ID in `.env` is retired or mistyped. | Check the IDs against the Gemini API changelog and update `LLM_MODEL`, `FAST_LLM_MODEL`, `JUDGE_MODEL`. |
| 429 or `RESOURCE_EXHAUSTED` | Free-tier rate limit. | Wait a minute, lower concurrency (Lab 1 step 6, Lab 10 `run_experiment`), or use a paid key. |
| No traces in LangSmith | Tracing is off, the key is wrong, or you are looking at another project. | Set `LANGSMITH_TRACING=true` and `LANGSMITH_API_KEY`; open project `bankassist360`. |
| Chroma or FAISS dimension error | Indexes were built with another embedding model. | `make clean`, then rerun the step. |
| Lab 7 or later: first query is slow | The cross-encoder is downloading. | Wait once; it is cached afterwards. |
| Lab 10 `/approve` returns 409 | Nothing is waiting for approval on that session. | Send a card-block request to `/chat` first with the same `session_id`. |

## Project structure

```text
lab04-langgraph-workflow/
  pyproject.toml          dependencies, ruff, pytest
  Makefile
  README.md
  .env.example
  .github/workflows/ci.yml
  .pre-commit-config.yaml
  src/bankassist/
    __init__.py            package marker and version
    config.py              settings, paths, logging, Gemini model factories
    cli.py                 --step runner
    chains.py              triage chain and Ticket schema
    memory.py              trimming, summaries, checkpointer, store
    data_access.py         synthetic core-banking data
    tools.py               banking tools (identity from config)
    agent.py               create_agent banking agent
    workflow.py            LangGraph routing + human approval   <- new in this lab
    lab.py                 this lab's runnable steps   <- new in this lab
    assignments/           your part 12 and 13 work
  scripts/
    generate_sample_data.py
  data/
    eval/routing_set.jsonl
    customers.json
    transactions.csv
  tests/
    conftest.py
    test_config.py
    test_chains.py
    test_memory.py
    test_tools.py
    test_workflow.py   <- new in this lab
  indexes/                generated at run time (git-ignored)
  docs/Lab04.pptx
  docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant
```

## Standards used

- `src/` layout, installable package, one source of truth for dependencies (`pyproject.toml`)
- Configuration only through `.env` (see `.env.example`); no keys in code
- No import-time side effects: models, indexes and graphs are built by `build_*` / `get_*` functions
- Type hints, docstrings, Pydantic schemas for every structured model output
- `ruff` lint, `pytest` offline tests, pre-commit hooks and a GitHub Actions workflow
- Gemini 3+ models: no `temperature`; `thinking_level` instead (set in `.env`)

## Next

Continue with [Lab 5](../lab05-policy-rag/).

"""Banking workflow (Lab 4): intent routing and human approval with LangGraph.

``build_workflow_builder`` returns the uncompiled graph so callers choose the checkpointer.
``policy_qa`` is a stub here; Lab 5 passes RAG and Lab 9 passes Agentic RAG.
"""

from __future__ import annotations

from collections.abc import Callable

from langchain_core.messages import AIMessage
from langchain_core.runnables import RunnableConfig
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.types import interrupt
from pydantic import BaseModel

from bankassist.agent import build_banking_agent
from bankassist.chains import INTENTS, build_triage_chain
from bankassist.config import get_llm
from bankassist.data_access import set_card_status

HELPLINE = "1800-XXX-XXXX"
ROUTES: dict[str, str] = {
    "card_block": "prepare_block",
    "balance_enquiry": "banking_agent",
    "transaction_dispute": "banking_agent",
    "loan_enquiry": "banking_agent",
    "fee_query": "policy_qa",
    "kyc": "policy_qa",
    "complaint": "create_complaint",
}
END_NODES = ["execute_block", "block_rejected", "banking_agent", "policy_qa", "create_complaint", "general_reply"]


class BankState(MessagesState):
    ticket: dict
    block_request: dict
    decision: str


class BlockReq(BaseModel):
    card_last4: str
    reason: str


# ------------------------------------------------------------------ nodes
def classify(state: BankState) -> dict:
    ticket = build_triage_chain().invoke({"intents": INTENTS, "message": state["messages"][-1].content})
    return {"ticket": ticket.model_dump()}


def prepare_block(state: BankState, config: RunnableConfig) -> dict:
    req = get_llm().with_structured_output(BlockReq).invoke(
        f"Extract the card's last 4 digits and the reason: {state['messages'][-1].content}")
    return {"block_request": {**req.model_dump(), "customer_id": config["configurable"]["customer_id"]}}


def human_approval(state: BankState) -> dict:
    decision = interrupt({"action": "block_card", **state["block_request"]})
    return {"decision": str(decision).strip().lower()}


def execute_block(state: BankState) -> dict:
    req = state["block_request"]
    if set_card_status(req["customer_id"], req["card_last4"], "blocked"):
        return {"messages": [AIMessage(f"Your card ending {req['card_last4']} has been blocked.")]}
    return {"messages": [AIMessage(f"No card ending {req['card_last4']} was found. Please call {HELPLINE}.")]}


def block_rejected(state: BankState) -> dict:
    return {"messages": [AIMessage(f"We could not verify the request. Please call {HELPLINE} "
                                   "or visit your branch to block the card.")]}


def make_banking_agent_node() -> Callable:
    agent = build_banking_agent(with_memory=False)  # parent graph's checkpointer stores state

    def banking_agent(state: BankState, config: RunnableConfig) -> dict:
        out = agent.invoke({"messages": state["messages"]}, config)
        return {"messages": [out["messages"][-1]]}

    return banking_agent


def policy_qa_stub(state: BankState) -> dict:
    return {"messages": [AIMessage("[Policy answer will come from RAG in Lab 5]")]}


def create_complaint(state: BankState) -> dict:
    return {"messages": [AIMessage(f"Complaint registered: {state['ticket']['summary']} "
                                   "Reference CMP-1023. We will respond within 48 hours.")]}


def general_reply(state: BankState) -> dict:
    return {"messages": [get_llm().invoke(state["messages"])]}


# ------------------------------------------------------------------ routing
def route_by_intent(state: BankState) -> str:
    return ROUTES.get(state["ticket"]["intent"], "general_reply")


def route_after_approval(state: BankState) -> str:
    return "execute_block" if state["decision"] == "approve" else "block_rejected"


def build_workflow_builder(policy_qa: Callable = policy_qa_stub) -> StateGraph:
    """Return the uncompiled graph so callers choose the checkpointer (memory, SQLite, Postgres)."""
    g = StateGraph(BankState)
    for name, fn in [("classify", classify), ("prepare_block", prepare_block),
                     ("human_approval", human_approval), ("execute_block", execute_block),
                     ("block_rejected", block_rejected), ("banking_agent", make_banking_agent_node()),
                     ("policy_qa", policy_qa), ("create_complaint", create_complaint),
                     ("general_reply", general_reply)]:
        g.add_node(name, fn)
    g.add_edge(START, "classify")
    g.add_conditional_edges("classify", route_by_intent)
    g.add_edge("prepare_block", "human_approval")
    g.add_conditional_edges("human_approval", route_after_approval)
    for node in END_NODES:
        g.add_edge(node, END)
    return g

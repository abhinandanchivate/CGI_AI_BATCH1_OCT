# Build prompt: BankAssist 360, Lab 4 (lab04-langgraph-workflow)

Paste everything below into an AI coding assistant (Gemini, Claude, Copilot Chat) from the project
root. Review every file it returns, then run `make install && make test`.

---

You are a senior Python engineer building one lab of the BankAssist 360 course: a retail-banking
assistant for the fictional Apex National Bank (India, amounts in INR), built with LangChain v1,
LangGraph v1, LangSmith and Google Gemini.

GOAL (Lab 4: Smart Banking Helpdesk with LangGraph)
Sessions: S032 Hands-on Workflow Creation
Combine triage, memory and the agent into one graph that routes by intent and pauses for a human before any
card is blocked.

STARTING POINT:
Copy the project `lab03-banking-agent` to `lab04-langgraph-workflow`, delete its `src/bankassist/lab.py`,
and keep these files unchanged unless this prompt says the file grows:
    src/bankassist/: config.py, cli.py, chains.py, memory.py, data_access.py, tools.py, agent.py

PROJECT STRUCTURE (create exactly this; '<- new in this lab' marks what you write now):

    lab04-langgraph-workflow/
      pyproject.toml          dependencies, ruff, pytest
      Makefile
      README.md
      .env.example
      .github/workflows/ci.yml
      .pre-commit-config.yaml
      src/bankassist/
        __init__.py            package marker and version
        config.py              settings, paths, logging, Gemini model factories
        cli.py                 --step runner
        chains.py              triage chain and Ticket schema
        memory.py              trimming, summaries, checkpointer, store
        data_access.py         synthetic core-banking data
        tools.py               banking tools (identity from config)
        agent.py               create_agent banking agent
        workflow.py            LangGraph routing + human approval   <- new in this lab
        lab.py                 this lab's runnable steps   <- new in this lab
        assignments/           your part 12 and 13 work
      scripts/
        generate_sample_data.py
      data/
        eval/routing_set.jsonl
        customers.json
        transactions.csv
      tests/
        conftest.py
        test_config.py
        test_chains.py
        test_memory.py
        test_tools.py
        test_workflow.py   <- new in this lab
      indexes/                generated at run time (git-ignored)
      docs/Lab04.pptx
      docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant

DEPENDENCIES (pyproject.toml [project].dependencies):
    langchain>=1.0,<2, langchain-core>=1.0,<2, langchain-google-genai>=4.4, langsmith>=0.4,
    pydantic>=2.6, python-dotenv>=1.0, langgraph>=1.0,<2, pandas>=2.0

AI TOOLS (use exactly these; declare their names in lab.py as AI_TOOLS, in this order):
    - Gemini 3.8 Flash: Intent triage and block-request extraction
    - LangGraph StateGraph: The intent-routing graph over BankState
    - LangGraph interrupt (human-in-the-loop): interrupt and Command(resume=...) before any card block
    - LangSmith tracing: Graph runs and routing-accuracy review
    Model IDs come from .env: LLM_MODEL=google_genai:gemini-3.8-flash

CODING STANDARDS:
- Python 3.11+, src layout: package `bankassist` under `src/`,
  installable with `pip install -e ".[dev]"`.
- `pyproject.toml` is the single source of dependencies (setuptools build, `dev` extra with pytest, ruff,
  pre-commit), ruff (line length 120; rules E, F, W, I, B, UP, SIM, RUF; `bankassist` is first-party) and
  pytest settings (`testpaths = ["tests"]`, `pythonpath = ["src", "."]`).
- Configuration only through `.env`, loaded once in `config.py`; never hard-code keys. Ship `.env.example`.
- Models: `init_chat_model("google_genai:<model>")`. Gemini 3+ deprecates temperature, top_p and top_k:
  never pass them for Gemini; pass `thinking_level` from `THINKING_LEVEL` instead. Embeddings:
  `GoogleGenerativeAIEmbeddings(model="gemini-embedding-2")`. Default models: main `gemini-3.8-flash`,
  fast `gemini-3.5-flash-lite`, judge `gemini-4-argon`.
- No import-time side effects: models, indexes and graphs are created by `build_*` / `get_*` functions,
  cached with `functools.lru_cache` where reuse matters. Pass dependencies (retriever, models, embeddings)
  as arguments so tests can inject fakes.
- Type hints and a docstring on every module and public function; Pydantic models for every structured LLM output.
- Library modules log with `get_logger(__name__)`; only `lab.py` prints results.
- Security: customer identity comes from `RunnableConfig["configurable"]["customer_id"]`, never from model
  arguments; money-moving actions need human approval; mask PII before it reaches a model or a trace.
- Tests run offline: `tests/conftest.py` sets a fake `GOOGLE_API_KEY`, `LANGSMITH_TRACING=false` and provides a
  `DeterministicFakeEmbedding` fixture. No test may call a real API.
- `lab.py` exposes `main()` that calls `bankassist.cli.run_steps(title, {number: step_function}, tools=AI_TOOLS)`;
  each step function's first docstring line is its description, and `AI_TOOLS` (a module-level tuple) names the
  lab's AI tools, shown by `--help`. `python -m bankassist.lab --step N` runs one step.

FILES TO WRITE:

src/bankassist/workflow.py: Banking workflow (Lab 4): intent routing and human approval with LangGraph.
  Public API (implement exactly these names and signatures):
    constant HELPLINE = '1800-XXX-XXXX'
    constant ROUTES
    constant END_NODES
    class BankState(MessagesState)
        field ticket: dict
        field block_request: dict
        field decision: str
    class BlockReq(BaseModel)
        field card_last4: str
        field reason: str
    def classify(state: BankState) -> dict
    def prepare_block(state: BankState, config: RunnableConfig) -> dict
    def human_approval(state: BankState) -> dict
    def execute_block(state: BankState) -> dict
    def block_rejected(state: BankState) -> dict
    def make_banking_agent_node() -> Callable
    def policy_qa_stub(state: BankState) -> dict
    def create_complaint(state: BankState) -> dict
    def general_reply(state: BankState) -> dict
    def route_by_intent(state: BankState) -> str
    def route_after_approval(state: BankState) -> str
    def build_workflow_builder(policy_qa: Callable=policy_qa_stub) -> StateGraph
        # Return the uncompiled graph so callers choose the checkpointer (memory, SQLite, Postgres).

IMPLEMENTATION RULES (the tests and the lab guide depend on these):
    - `BankState(MessagesState)` adds `ticket: dict`, `block_request: dict`, `decision: str`.
    - ROUTES maps card_block -> prepare_block; balance_enquiry, transaction_dispute, loan_enquiry ->
      banking_agent; fee_query, kyc -> policy_qa; complaint -> create_complaint; anything else ->
      general_reply.
    - `human_approval` calls `interrupt({'action': 'block_card', **block_request})` and stores the lower-cased
      decision; `route_after_approval` goes to execute_block only for exactly 'approve', else block_rejected.
    - `prepare_block` extracts card_last4 and reason with structured output (`BlockReq`) and adds customer_id
      from config. `execute_block` calls `set_card_status(..., 'blocked')`.
    - `build_workflow_builder(policy_qa=policy_qa_stub)` returns the UNCOMPILED StateGraph; the banking agent
      node uses `build_banking_agent(with_memory=False)` because the parent graph owns the checkpointer.

src/bankassist/lab.py: this lab's runnable steps, registered in run_steps() with these numbers:
    --step 4: Compile the graph and print its Mermaid diagram
    --step 5: Run, pause at the interrupt, inspect state, then resume with approve
    --step 6: Measure routing accuracy on the labelled routing set

DATA (provided by the course; copy it, do not invent it):
    data/eval/routing_set.jsonl
    data/customers.json
    data/transactions.csv

TESTS (offline, pytest). Write these new test functions:
  tests/test_workflow.py
    test_route_by_intent
        # checks: route by intent
    test_only_explicit_approve_executes
        # checks: only explicit approve executes
    test_card_block_requires_human_decision
        # checks: card block requires human decision

ALSO WRITE OR UPDATE: README.md (setup, steps table, expected outputs, structure),
.env.example (only the keys this lab needs), Makefile (install, test, lint, run STEP=N, data), .gitignore,
.pre-commit-config.yaml (ruff, private-key detection), .github/workflows/ci.yml
(ruff + pytest on Python 3.11 and 3.12).

EXPECTED BEHAVIOUR WHEN RUN WITH REAL KEYS:
    - Routing accuracy 95% or higher
    - Run pauses with an interrupt payload
    - Approve blocks; reject keeps card active
    - Mermaid diagram of the graph

ACCEPTANCE CHECKS (all must pass before you finish):
    1. `ruff check .` reports no issues.
    2. `pytest` passes offline with no API keys and no network calls.
    3. `python -m bankassist.lab --help` lists steps 4, 5, 6.
    4. No module creates a model, index or graph at import time.
    5. Gemini models are never given a temperature.

OUTPUT FORMAT: return every new or changed file in full, each preceded by a line
`=== path/to/file ===`.
No placeholders, no 'rest unchanged' comments. After the files, list any assumption you made.

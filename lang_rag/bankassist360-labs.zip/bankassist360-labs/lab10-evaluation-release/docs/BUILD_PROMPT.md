# Build prompt: BankAssist 360, Lab 10 (lab10-evaluation-release)

Paste everything below into an AI coding assistant (Gemini, Claude, Copilot Chat) from the project
root. Review every file it returns, then run `make install && make test`.

---

You are a senior Python engineer building one lab of the BankAssist 360 course: a retail-banking
assistant for the fictional Apex National Bank (India, amounts in INR), built with LangChain v1,
LangGraph v1, LangSmith and Google Gemini.

GOAL (Lab 10: RAG Evaluation, Optimisation and Release Gate)
Sessions: S044 RAG Evaluation · S038 Optimizing RAG · S045 Best Practices
Measure every RAG version on one dataset, cut cost and latency, and block any release that misses its targets.

STARTING POINT:
Copy the project `lab09-agentic-rag` to `lab10-evaluation-release`, delete its `src/bankassist/lab.py`,
and keep these files unchanged unless this prompt says the file grows:
    src/bankassist/: config.py, cli.py, chains.py, memory.py, data_access.py, tools.py, agent.py,
    workflow.py, guardrails.py, prompts.py, retrievers.py, rag.py, multimodal.py, agentic_rag.py

PROJECT STRUCTURE (create exactly this; '<- new in this lab' marks what you write now):

    lab10-evaluation-release/
      pyproject.toml          dependencies, ruff, pytest
      Makefile
      README.md
      .env.example
      .github/workflows/ci.yml
      .pre-commit-config.yaml
      src/bankassist/
        __init__.py            package marker and version
        config.py              settings, paths, logging, Gemini model factories
        cli.py                 --step runner
        chains.py              triage chain and Ticket schema
        memory.py              trimming, summaries, checkpointer, store
        data_access.py         synthetic core-banking data
        tools.py               banking tools (identity from config)
        agent.py               create_agent banking agent
        workflow.py            LangGraph routing + human approval
        guardrails.py          PII masking, injection guard
        prompts.py             RAG and domain prompts
        retrievers.py          loading, chunking, vector stores, matching, hybrid, glossary
        rag.py                 RAG chains returning answer + evidence
        multimodal.py          PDF tables/images, filtered retrieval
        agentic_rag.py         corrective RAG graph with live search
        evaluation.py          dataset, evaluators, experiments, gate   <- new in this lab
        api.py                 capstone FastAPI service   <- new in this lab
        lab.py                 this lab's runnable steps   <- new in this lab
        assignments/           your part 12 and 13 work
      scripts/
        generate_sample_data.py
        generate_pdfs.py
        release_gate.py   <- new in this lab
      data/
        eval/routing_set.jsonl
        customers.json
        transactions.csv
        policies
        eval/chunk_eval.jsonl
        eval/hard_set.jsonl
        pdfs
        eval/golden_set.jsonl   <- new in this lab
      tests/
        conftest.py
        test_config.py
        test_chains.py
        test_memory.py
        test_tools.py
        test_workflow.py
        test_guardrails.py
        test_loaders.py
        test_matching.py
        test_hybrid.py
        test_glossary.py
        test_multimodal.py
        test_agentic_rag.py
        test_evaluation.py   <- new in this lab
      indexes/                generated at run time (git-ignored)
      docs/Lab10.pptx
      docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant
      docs/MODEL_CARD.md      capstone model card template (stretch goal)

DEPENDENCIES (pyproject.toml [project].dependencies):
    langchain>=1.0,<2, langchain-core>=1.0,<2, langchain-google-genai>=4.4, langsmith>=0.4,
    pydantic>=2.6, python-dotenv>=1.0, langgraph>=1.0,<2, pandas>=2.0, langchain-community>=0.4,
    langchain-chroma>=1.0, langchain-text-splitters>=1.0, faiss-cpu>=1.8, chromadb>=0.5,
    rank_bm25>=0.2, langchain-experimental>=0.4, sentence-transformers>=3.0, pymupdf>=1.24,
    pdfplumber>=0.11, reportlab>=4.0, matplotlib>=3.8, langchain-tavily>=0.2, fastapi>=0.110,
    uvicorn>=0.29, langgraph-checkpoint-sqlite>=2.0

AI TOOLS (use exactly these; declare their names in lab.py as AI_TOOLS, in this order):
    - LangSmith datasets + evaluators: Golden dataset, client.evaluate experiments and user feedback
    - Gemini 4 Argon (judge): Faithfulness and correctness judging
    - Gemini 3.8 Flash + Flash-Lite: The RAG versions under test, with model tiering
    - LLM cache (SQLite): SQLiteCache for repeated prompts
    - FastAPI + LangGraph: The capstone API with a SqliteSaver checkpointer
    Model IDs come from .env: LLM_MODEL=google_genai:gemini-3.8-flash; FAST_LLM_MODEL=google_genai:gemini-3.5-flash-lite; JUDGE_MODEL=google_genai:gemini-4-argon

CODING STANDARDS:
- Python 3.11+, src layout: package `bankassist` under `src/`,
  installable with `pip install -e ".[dev]"`.
- `pyproject.toml` is the single source of dependencies (setuptools build, `dev` extra with pytest, ruff,
  pre-commit), ruff (line length 120; rules E, F, W, I, B, UP, SIM, RUF; `bankassist` is first-party) and
  pytest settings (`testpaths = ["tests"]`, `pythonpath = ["src", "."]`).
- Configuration only through `.env`, loaded once in `config.py`; never hard-code keys. Ship `.env.example`.
- Models: `init_chat_model("google_genai:<model>")`. Gemini 3+ deprecates temperature, top_p and top_k:
  never pass them for Gemini; pass `thinking_level` from `THINKING_LEVEL` instead. Embeddings:
  `GoogleGenerativeAIEmbeddings(model="gemini-embedding-2")`. Default models: main `gemini-3.8-flash`,
  fast `gemini-3.5-flash-lite`, judge `gemini-4-argon`.
- No import-time side effects: models, indexes and graphs are created by `build_*` / `get_*` functions,
  cached with `functools.lru_cache` where reuse matters. Pass dependencies (retriever, models, embeddings)
  as arguments so tests can inject fakes.
- Type hints and a docstring on every module and public function; Pydantic models for every structured LLM output.
- Library modules log with `get_logger(__name__)`; only `lab.py` prints results.
- Security: customer identity comes from `RunnableConfig["configurable"]["customer_id"]`, never from model
  arguments; money-moving actions need human approval; mask PII before it reaches a model or a trace.
- Tests run offline: `tests/conftest.py` sets a fake `GOOGLE_API_KEY`, `LANGSMITH_TRACING=false` and provides a
  `DeterministicFakeEmbedding` fixture. No test may call a real API.
- `lab.py` exposes `main()` that calls `bankassist.cli.run_steps(title, {number: step_function}, tools=AI_TOOLS)`;
  each step function's first docstring line is its description, and `AI_TOOLS` (a module-level tuple) names the
  lab's AI tools, shown by `--help`. `python -m bankassist.lab --step N` runs one step.

FILES TO WRITE:

src/bankassist/evaluation.py: RAG evaluation (Lab 10): dataset, evaluators, experiments, optimisation and the
  release gate.
  Public API (implement exactly these names and signatures):
    constant DATASET = 'bankassist-golden-v1'
    constant TOP_K = 5
    constant TARGETS
    def load_golden() -> list[dict]
    def ensure_dataset(client=None) -> str
        # Create the LangSmith dataset once (idempotent).
    def pack(answer: str, docs: list[Document]) -> dict
        # Normalise every RAG version's output for the evaluators.
    def make_targets() -> dict[str, Callable[[dict], dict]]
        # Build one target per RAG version (imports are lazy: each version builds indexes).
    def retrieval_precision(outputs: dict, reference_outputs: dict) -> dict
        # Share of the top-k retrieved sections that are relevant. None for out-of-scope questions.
    def retrieval_recall(outputs: dict, reference_outputs: dict) -> dict
        # Share of relevant sections that appear in the top-k. None for out-of-scope questions.
    class Verdict(BaseModel)
        field reasoning: str
        field score: float
    def faithfulness(outputs: dict) -> dict
        # Supported claims / total claims, judged only against the retrieved context.
    def correctness(inputs: dict, outputs: dict, reference_outputs: dict) -> dict
        # Does the answer contain the reference's key facts (or refuse when out of scope)?
    constant EVALUATORS = [retrieval_precision, retrieval_recall, faithfulness, correctness]
    def run_experiment(name: str, target: Callable[[dict], dict], client=None)
    def summarise(results) -> dict[str, float]
        # Average each feedback metric from an ExperimentResults object.
    def failed_targets(scores: dict[str, float], targets: dict[str, float]=TARGETS) -> dict[str, float]
        # Metrics below target (a missing metric counts as failed).
    def enable_optimisations() -> None
        # Persistent LLM cache: identical prompts (repeated FAQs, re-runs) cost nothing.

src/bankassist/api.py: Capstone: BankAssist 360 as an HTTP API.
  Public API (implement exactly these names and signatures):
    constant STATE = {}
    class ChatIn(BaseModel)
        field customer_id: str
        field session_id: str
        field message: str
    class ApprovalIn(BaseModel)
        field customer_id: str
        field session_id: str
        field decision: Literal['approve', 'reject']
        field reviewer: str
    @api.get('/health')
    def health() -> dict
    @api.post('/chat')
    def chat(req: ChatIn) -> dict
    @api.post('/approve')
    def approve(req: ApprovalIn) -> dict

IMPLEMENTATION RULES (the tests and the lab guide depend on these):
    - DATASET = 'bankassist-golden-v1', TOP_K = 5, TARGETS = faithfulness 0.90, retrieval_recall 0.85,
      retrieval_precision 0.60, correctness 0.85.
    - `ensure_dataset` is idempotent (`client.has_dataset`), examples are {inputs: {question}, outputs:
      {answer, relevant_sources}}. `pack` returns answer, retrieved_ids (unique source_ref in order) and
      contexts.
    - Retrieval evaluators return score None when relevant_sources is empty (out of scope). Judges use
      `Verdict(reasoning, score in 0..1)` with reasoning before the score, on the JUDGE_MODEL.
    - `run_experiment` = client.evaluate(target, data=dataset, evaluators=EVALUATORS, experiment_prefix=name,
      max_concurrency=4); `summarise` averages `feedback.*` columns; `failed_targets` treats a missing metric
      as 0.
    - `enable_optimisations` sets a SQLiteCache at indexes/llm_cache.db. scripts/release_gate.py exits 1 when
      any target fails.
    - api.py: FastAPI lifespan compiles `build_workflow_builder(policy_qa=make_policy_qa_node())` with a
      SqliteSaver at indexes/threads.db; /health; /chat masks PII and returns pending_approval on interrupt;
      /approve returns 409 when nothing is waiting, else resumes with Command(resume=decision).

src/bankassist/lab.py: this lab's runnable steps, registered in run_steps() with these numbers:
    --step 1: Create the LangSmith dataset
    --step 5: Run all three RAG versions as experiments and print the comparison table
    --step 6: Re-run the agentic version with caching and model tiering
    --step 8: Capture a run ID and attach user feedback to it

DATA (provided by the course; copy it, do not invent it):
    data/eval/routing_set.jsonl
    data/customers.json
    data/transactions.csv
    data/policies
    data/eval/chunk_eval.jsonl
    data/eval/hard_set.jsonl
    data/pdfs
    data/eval/golden_set.jsonl   <- new in this lab

TESTS (offline, pytest). Write these new test functions:
  tests/test_evaluation.py
    test_precision_and_recall
        # checks: precision and recall
    test_out_of_scope_questions_are_skipped
        # checks: out of scope questions are skipped
    test_pack_deduplicates_sections_in_order
        # checks: pack deduplicates sections in order
    test_gate_fails_on_missing_or_low_metric
        # checks: gate fails on missing or low metric

ALSO WRITE OR UPDATE: README.md (setup, steps table, expected outputs, structure),
.env.example (only the keys this lab needs), Makefile (install, test, lint, run STEP=N, data, api, gate), .gitignore,
.pre-commit-config.yaml (ruff, private-key detection), .github/workflows/ci.yml
(ruff + pytest on Python 3.11 and 3.12).

EXPECTED BEHAVIOUR WHEN RUN WITH REAL KEYS:
    - Three experiments with per-example scores
    - Comparison table filled from real runs
    - release_gate.py exits 1 on a miss

ACCEPTANCE CHECKS (all must pass before you finish):
    1. `ruff check .` reports no issues.
    2. `pytest` passes offline with no API keys and no network calls.
    3. `python -m bankassist.lab --help` lists steps 1, 5, 6, 8.
    4. No module creates a model, index or graph at import time.
    5. Gemini models are never given a temperature.

OUTPUT FORMAT: return every new or changed file in full, each preceded by a line
`=== path/to/file ===`.
No placeholders, no 'rest unchanged' comments. After the files, list any assumption you made.

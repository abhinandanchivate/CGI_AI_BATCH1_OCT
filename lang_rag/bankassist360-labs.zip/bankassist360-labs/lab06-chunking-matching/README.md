# BankAssist 360, Lab 6: Chunking Strategies and Exact vs Semantic Matching

S035 Chunking Strategies · S036 Semantic Search vs Exact Matching

Measure which chunking strategy retrieves policy clauses best, and prove why embeddings miss charge codes that keyword search finds.

This project is standalone: it contains everything built in earlier labs (`chains.py`, `memory.py`, `data_access.py`, `tools.py`, `agent.py`, `workflow.py`, `guardrails.py`, `prompts.py`, `retrievers.py`, `rag.py`), so you can
start here without finishing the previous lab. Code from earlier labs is identical to their projects.

## How to run this lab

You need Python 3.11 or 3.12 and these keys in `.env`: `GOOGLE_API_KEY` and `LANGSMITH_API_KEY`. Tests need no keys.

macOS or Linux:

```bash
python3 -m venv .venv && source .venv/bin/activate
make install                 # pip install -e ".[dev]" + pre-commit hooks
cp .env.example .env         # then add your keys
make test                    # offline: expect 42 passed
make run                     # every step in order
make run STEP=7              # one step
```

Windows (PowerShell, no make needed):

```powershell
py -3.11 -m venv .venv; .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
Copy-Item .env.example .env  # then add your keys
pytest                       # offline: expect 42 passed
python -m bankassist.lab     # every step in order
python -m bankassist.lab --step 7  # one step
```

`python -m bankassist.lab --help` lists the steps. Step numbers match the implementation steps in the lab
guide; guide steps without their own command are code you read in `src/bankassist/`, and their effect shows
in the next step that runs.

What to expect when you run it:

- Step 1 builds five temporary FAISS indexes and the semantic chunker embeds every sentence: the most embedding-heavy step of the course. Expect a minute or two.
- Step 7 makes no API calls at all (exact code lookup).

Start again from a clean state with `make clean` (deletes `indexes/`); `make data` regenerates the sample data.

## Steps in this lab

| Command | What it does |
| --- | --- |
| `--step 1` | Score five chunking strategies on the same labelled questions |
| `--step 6` | Compare BM25 (exact tokens) with vector search (meaning) |
| `--step 7` | Direct exact-code lookup, no ranking needed |

The full walkthrough, code explanations, knowledge check, assignment and modification tasks are in
the BankAssist 360 lab guide (Lab 6). Slides: `docs/Lab06.pptx`. To rebuild this project with an AI
coding assistant, use the prompt in `docs/BUILD_PROMPT.md`.

## AI tools used

| Tool | Role in this lab |
| --- | --- |
| Gemini Embedding 2 | Embeddings for one temporary index per chunking strategy |
| LangChain text splitters | Fixed, recursive and markdown-header chunkers |
| SemanticChunker | Embedding-based breakpoints (langchain-experimental) |
| FAISS | The vector side of each comparison |
| BM25 | Keyword retrieval with BM25Retriever (rank_bm25) |
| LangSmith | Retriever traces for each query |

Model names are the defaults in `.env.example`; change them there, never in code. `python -m bankassist.lab --help`
lists the same tools.

## Expected outputs

- Results table: chunks, avg size, hit@4
- Markdown-header chunking usually wins
- Vector wins paraphrases; BM25 wins codes

## Concepts covered

- **Chunking trade-off:** Small = precise; large = context
- **Structure-aware chunking:** Split on headings; tables stay whole
- **Semantic chunking:** Split where meaning shifts
- **Hit rate at k:** Gold phrase found in top k
- **BM25:** Exact terms weighted by rarity
- **Exact matching:** Regex lookup for codes

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `ModuleNotFoundError: bankassist` | The virtual environment is not active or the project is not installed. | Activate `.venv`, then `make install` (or `python -m pip install -e ".[dev]"`). |
| `make: command not found` (Windows) | make is not installed. | Run the commands directly: `pytest`, `python -m bankassist.lab --step N`. |
| `Activate.ps1 cannot be loaded` (Windows) | PowerShell blocks local scripts by default. | Run `Set-ExecutionPolicy -Scope Process RemoteSigned`, then activate again. |
| 400 or 404 from Gemini naming the model | The model ID in `.env` is retired or mistyped. | Check the IDs against the Gemini API changelog and update `LLM_MODEL`, `FAST_LLM_MODEL`, `JUDGE_MODEL`. |
| 429 or `RESOURCE_EXHAUSTED` | Free-tier rate limit. | Wait a minute, lower concurrency (Lab 1 step 6, Lab 10 `run_experiment`), or use a paid key. |
| No traces in LangSmith | Tracing is off, the key is wrong, or you are looking at another project. | Set `LANGSMITH_TRACING=true` and `LANGSMITH_API_KEY`; open project `bankassist360`. |
| Chroma or FAISS dimension error | Indexes were built with another embedding model. | `make clean`, then rerun the step. |
| Lab 7 or later: first query is slow | The cross-encoder is downloading. | Wait once; it is cached afterwards. |
| Lab 10 `/approve` returns 409 | Nothing is waiting for approval on that session. | Send a card-block request to `/chat` first with the same `session_id`. |

## Project structure

```text
lab06-chunking-matching/
  pyproject.toml          dependencies, ruff, pytest
  Makefile
  README.md
  .env.example
  .github/workflows/ci.yml
  .pre-commit-config.yaml
  src/bankassist/
    __init__.py            package marker and version
    config.py              settings, paths, logging, Gemini model factories
    cli.py                 --step runner
    chains.py              triage chain and Ticket schema
    memory.py              trimming, summaries, checkpointer, store
    data_access.py         synthetic core-banking data
    tools.py               banking tools (identity from config)
    agent.py               create_agent banking agent
    workflow.py            LangGraph routing + human approval
    guardrails.py          PII masking, injection guard
    prompts.py             RAG and domain prompts
    retrievers.py          loading, chunking, vector stores, matching, hybrid, glossary
    rag.py                 RAG chains returning answer + evidence
    lab.py                 this lab's runnable steps   <- new in this lab
    assignments/           your part 12 and 13 work
  scripts/
    generate_sample_data.py
  data/
    eval/routing_set.jsonl
    customers.json
    transactions.csv
    policies
    eval/chunk_eval.jsonl   <- new in this lab
  tests/
    conftest.py
    test_config.py
    test_chains.py
    test_memory.py
    test_tools.py
    test_workflow.py
    test_guardrails.py
    test_loaders.py
    test_matching.py   <- new in this lab
  indexes/                generated at run time (git-ignored)
  docs/Lab06.pptx
  docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant
```

## Standards used

- `src/` layout, installable package, one source of truth for dependencies (`pyproject.toml`)
- Configuration only through `.env` (see `.env.example`); no keys in code
- No import-time side effects: models, indexes and graphs are built by `build_*` / `get_*` functions
- Type hints, docstrings, Pydantic schemas for every structured model output
- `ruff` lint, `pytest` offline tests, pre-commit hooks and a GitHub Actions workflow
- Gemini 3+ models: no `temperature`; `thinking_level` instead (set in `.env`)

## Next

Continue with [Lab 7](../lab07-hybrid-rerank/).

# Build prompt: BankAssist 360, Lab 6 (lab06-chunking-matching)

Paste everything below into an AI coding assistant (Gemini, Claude, Copilot Chat) from the project
root. Review every file it returns, then run `make install && make test`.

---

You are a senior Python engineer building one lab of the BankAssist 360 course: a retail-banking
assistant for the fictional Apex National Bank (India, amounts in INR), built with LangChain v1,
LangGraph v1, LangSmith and Google Gemini.

GOAL (Lab 6: Chunking Strategies and Exact vs Semantic Matching)
Sessions: S035 Chunking Strategies · S036 Semantic Search vs Exact Matching
Measure which chunking strategy retrieves policy clauses best, and prove why embeddings miss charge codes that
keyword search finds.

STARTING POINT:
Copy the project `lab05-policy-rag` to `lab06-chunking-matching`, delete its `src/bankassist/lab.py`,
and keep these files unchanged unless this prompt says the file grows:
    src/bankassist/: config.py, cli.py, chains.py, memory.py, data_access.py, tools.py, agent.py,
    workflow.py, guardrails.py, prompts.py, retrievers.py, rag.py

PROJECT STRUCTURE (create exactly this; '<- new in this lab' marks what you write now):

    lab06-chunking-matching/
      pyproject.toml          dependencies, ruff, pytest
      Makefile
      README.md
      .env.example
      .github/workflows/ci.yml
      .pre-commit-config.yaml
      src/bankassist/
        __init__.py            package marker and version
        config.py              settings, paths, logging, Gemini model factories
        cli.py                 --step runner
        chains.py              triage chain and Ticket schema
        memory.py              trimming, summaries, checkpointer, store
        data_access.py         synthetic core-banking data
        tools.py               banking tools (identity from config)
        agent.py               create_agent banking agent
        workflow.py            LangGraph routing + human approval
        guardrails.py          PII masking, injection guard
        prompts.py             RAG and domain prompts
        retrievers.py          loading, chunking, vector stores, matching, hybrid, glossary
        rag.py                 RAG chains returning answer + evidence
        lab.py                 this lab's runnable steps   <- new in this lab
        assignments/           your part 12 and 13 work
      scripts/
        generate_sample_data.py
      data/
        eval/routing_set.jsonl
        customers.json
        transactions.csv
        policies
        eval/chunk_eval.jsonl   <- new in this lab
      tests/
        conftest.py
        test_config.py
        test_chains.py
        test_memory.py
        test_tools.py
        test_workflow.py
        test_guardrails.py
        test_loaders.py
        test_matching.py   <- new in this lab
      indexes/                generated at run time (git-ignored)
      docs/Lab06.pptx
      docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant

DEPENDENCIES (pyproject.toml [project].dependencies):
    langchain>=1.0,<2, langchain-core>=1.0,<2, langchain-google-genai>=4.4, langsmith>=0.4,
    pydantic>=2.6, python-dotenv>=1.0, langgraph>=1.0,<2, pandas>=2.0, langchain-community>=0.4,
    langchain-chroma>=1.0, langchain-text-splitters>=1.0, faiss-cpu>=1.8, chromadb>=0.5,
    rank_bm25>=0.2, langchain-experimental>=0.4

AI TOOLS (use exactly these; declare their names in lab.py as AI_TOOLS, in this order):
    - Gemini Embedding 2: Embeddings for one temporary index per chunking strategy
    - LangChain text splitters: Fixed, recursive and markdown-header chunkers
    - SemanticChunker: Embedding-based breakpoints (langchain-experimental)
    - FAISS: The vector side of each comparison
    - BM25: Keyword retrieval with BM25Retriever (rank_bm25)
    - LangSmith: Retriever traces for each query
    Model IDs come from .env: EMBED_MODEL=gemini-embedding-2

CODING STANDARDS:
- Python 3.11+, src layout: package `bankassist` under `src/`,
  installable with `pip install -e ".[dev]"`.
- `pyproject.toml` is the single source of dependencies (setuptools build, `dev` extra with pytest, ruff,
  pre-commit), ruff (line length 120; rules E, F, W, I, B, UP, SIM, RUF; `bankassist` is first-party) and
  pytest settings (`testpaths = ["tests"]`, `pythonpath = ["src", "."]`).
- Configuration only through `.env`, loaded once in `config.py`; never hard-code keys. Ship `.env.example`.
- Models: `init_chat_model("google_genai:<model>")`. Gemini 3+ deprecates temperature, top_p and top_k:
  never pass them for Gemini; pass `thinking_level` from `THINKING_LEVEL` instead. Embeddings:
  `GoogleGenerativeAIEmbeddings(model="gemini-embedding-2")`. Default models: main `gemini-3.8-flash`,
  fast `gemini-3.5-flash-lite`, judge `gemini-4-argon`.
- No import-time side effects: models, indexes and graphs are created by `build_*` / `get_*` functions,
  cached with `functools.lru_cache` where reuse matters. Pass dependencies (retriever, models, embeddings)
  as arguments so tests can inject fakes.
- Type hints and a docstring on every module and public function; Pydantic models for every structured LLM output.
- Library modules log with `get_logger(__name__)`; only `lab.py` prints results.
- Security: customer identity comes from `RunnableConfig["configurable"]["customer_id"]`, never from model
  arguments; money-moving actions need human approval; mask PII before it reaches a model or a trace.
- Tests run offline: `tests/conftest.py` sets a fake `GOOGLE_API_KEY`, `LANGSMITH_TRACING=false` and provides a
  `DeterministicFakeEmbedding` fixture. No test may call a real API.
- `lab.py` exposes `main()` that calls `bankassist.cli.run_steps(title, {number: step_function}, tools=AI_TOOLS)`;
  each step function's first docstring line is its description, and `AI_TOOLS` (a module-level tuple) names the
  lab's AI tools, shown by `--help`. `python -m bankassist.lab --step N` runs one step.

FILES TO WRITE:

src/bankassist/retrievers.py GROWS: add these to the existing module, change nothing else:
    constant CODE_PATTERN = re.compile('\\b(?:CHG|POL|OPS)-[A-Z]+-\\d{2,4}\\b')
    def exact_code_lookup(query: str, chunks: list[Document]) -> list[Document]
        # Return chunks that contain any charge or document code found in the query.
    def load_eval(name: str) -> list[dict]
        # Read a JSONL evaluation set from data/eval/.
    def hit_rate(retrieve: Callable[[str], list[Document]], rows: list[dict], k: int) -> float
        # Share of questions where any top-k chunk contains the gold phrase (case-insensitive).

IMPLEMENTATION RULES (the tests and the lab guide depend on these):
    - CODE_PATTERN = r'\b(?:CHG|POL|OPS)-[A-Z]+-\d{2,4}\b', matched against the UPPER-CASED query.
    - `hit_rate(retrieve, rows, k)`: share of rows where any of the top-k chunks contains `gold_text` (case-
      insensitive). `load_eval(name)` reads JSONL from data/eval/.
    - lab.py compares five chunkers (fixed 500, recursive 800/100, recursive 400/50, markdown-header,
      semantic) with a temporary FAISS index each, then BM25 vs vector, then exact code lookup.

src/bankassist/lab.py: this lab's runnable steps, registered in run_steps() with these numbers:
    --step 1: Score five chunking strategies on the same labelled questions
    --step 6: Compare BM25 (exact tokens) with vector search (meaning)
    --step 7: Direct exact-code lookup, no ranking needed

DATA (provided by the course; copy it, do not invent it):
    data/eval/routing_set.jsonl
    data/customers.json
    data/transactions.csv
    data/policies
    data/eval/chunk_eval.jsonl   <- new in this lab

TESTS (offline, pytest). Write these new test functions:
  tests/test_matching.py
    test_exact_code_lookup_is_case_insensitive
        # checks: exact code lookup is case insensitive
    test_exact_code_lookup_ignores_plain_questions
        # checks: exact code lookup ignores plain questions
    test_hit_rate_counts_gold_phrases
        # checks: hit rate counts gold phrases
    test_eval_sets_load
        # checks: eval sets load

ALSO WRITE OR UPDATE: README.md (setup, steps table, expected outputs, structure),
.env.example (only the keys this lab needs), Makefile (install, test, lint, run STEP=N, data), .gitignore,
.pre-commit-config.yaml (ruff, private-key detection), .github/workflows/ci.yml
(ruff + pytest on Python 3.11 and 3.12).

EXPECTED BEHAVIOUR WHEN RUN WITH REAL KEYS:
    - Results table: chunks, avg size, hit@4
    - Markdown-header chunking usually wins
    - Vector wins paraphrases; BM25 wins codes

ACCEPTANCE CHECKS (all must pass before you finish):
    1. `ruff check .` reports no issues.
    2. `pytest` passes offline with no API keys and no network calls.
    3. `python -m bankassist.lab --help` lists steps 1, 6, 7.
    4. No module creates a model, index or graph at import time.
    5. Gemini models are never given a temperature.

OUTPUT FORMAT: return every new or changed file in full, each preceded by a line
`=== path/to/file ===`.
No placeholders, no 'rest unchanged' comments. After the files, list any assumption you made.

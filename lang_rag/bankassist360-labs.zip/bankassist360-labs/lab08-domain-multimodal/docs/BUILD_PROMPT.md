# Build prompt: BankAssist 360, Lab 8 (lab08-domain-multimodal)

Paste everything below into an AI coding assistant (Gemini, Claude, Copilot Chat) from the project
root. Review every file it returns, then run `make install && make test`.

---

You are a senior Python engineer building one lab of the BankAssist 360 course: a retail-banking
assistant for the fictional Apex National Bank (India, amounts in INR), built with LangChain v1,
LangGraph v1, LangSmith and Google Gemini.

GOAL (Lab 8: Domain-Specific and Multimodal RAG)
Sessions: S037 RAG for Domain-Specific Applications · S042 Multi-modal RAG
Adapt RAG to banking rules and extend it to PDFs whose answers live in tables and charts.

STARTING POINT:
Copy the project `lab07-hybrid-rerank` to `lab08-domain-multimodal`, delete its `src/bankassist/lab.py`,
and keep these files unchanged unless this prompt says the file grows:
    src/bankassist/: config.py, cli.py, chains.py, memory.py, data_access.py, tools.py, agent.py,
    workflow.py, guardrails.py, prompts.py, retrievers.py, rag.py

PROJECT STRUCTURE (create exactly this; '<- new in this lab' marks what you write now):

    lab08-domain-multimodal/
      pyproject.toml          dependencies, ruff, pytest
      Makefile
      README.md
      .env.example
      .github/workflows/ci.yml
      .pre-commit-config.yaml
      src/bankassist/
        __init__.py            package marker and version
        config.py              settings, paths, logging, Gemini model factories
        cli.py                 --step runner
        chains.py              triage chain and Ticket schema
        memory.py              trimming, summaries, checkpointer, store
        data_access.py         synthetic core-banking data
        tools.py               banking tools (identity from config)
        agent.py               create_agent banking agent
        workflow.py            LangGraph routing + human approval
        guardrails.py          PII masking, injection guard
        prompts.py             RAG and domain prompts
        retrievers.py          loading, chunking, vector stores, matching, hybrid, glossary
        rag.py                 RAG chains returning answer + evidence
        multimodal.py          PDF tables/images, filtered retrieval   <- new in this lab
        lab.py                 this lab's runnable steps   <- new in this lab
        assignments/           your part 12 and 13 work
      scripts/
        generate_sample_data.py
        generate_pdfs.py   <- new in this lab
      data/
        eval/routing_set.jsonl
        customers.json
        transactions.csv
        policies
        eval/chunk_eval.jsonl
        eval/hard_set.jsonl
        pdfs   <- new in this lab
      tests/
        conftest.py
        test_config.py
        test_chains.py
        test_memory.py
        test_tools.py
        test_workflow.py
        test_guardrails.py
        test_loaders.py
        test_matching.py
        test_hybrid.py
        test_glossary.py   <- new in this lab
        test_multimodal.py   <- new in this lab
      indexes/                generated at run time (git-ignored)
      docs/Lab08.pptx
      docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant

DEPENDENCIES (pyproject.toml [project].dependencies):
    langchain>=1.0,<2, langchain-core>=1.0,<2, langchain-google-genai>=4.4, langsmith>=0.4,
    pydantic>=2.6, python-dotenv>=1.0, langgraph>=1.0,<2, pandas>=2.0, langchain-community>=0.4,
    langchain-chroma>=1.0, langchain-text-splitters>=1.0, faiss-cpu>=1.8, chromadb>=0.5,
    rank_bm25>=0.2, langchain-experimental>=0.4, sentence-transformers>=3.0, pymupdf>=1.24,
    pdfplumber>=0.11, reportlab>=4.0, matplotlib>=3.8

AI TOOLS (use exactly these; declare their names in lab.py as AI_TOOLS, in this order):
    - Gemini 3.8 Flash (vision): Table summaries, chart captions and multimodal answers
    - Gemini Embedding 2: Embeddings for the policies_v2 collection
    - Chroma metadata filters: Current-version and audience filters before generation
    - PyMuPDF + pdfplumber: PDF text, image and table extraction
    - LangSmith: Multimodal traces
    Model IDs come from .env: LLM_MODEL=google_genai:gemini-3.8-flash; EMBED_MODEL=gemini-embedding-2

CODING STANDARDS:
- Python 3.11+, src layout: package `bankassist` under `src/`,
  installable with `pip install -e ".[dev]"`.
- `pyproject.toml` is the single source of dependencies (setuptools build, `dev` extra with pytest, ruff,
  pre-commit), ruff (line length 120; rules E, F, W, I, B, UP, SIM, RUF; `bankassist` is first-party) and
  pytest settings (`testpaths = ["tests"]`, `pythonpath = ["src", "."]`).
- Configuration only through `.env`, loaded once in `config.py`; never hard-code keys. Ship `.env.example`.
- Models: `init_chat_model("google_genai:<model>")`. Gemini 3+ deprecates temperature, top_p and top_k:
  never pass them for Gemini; pass `thinking_level` from `THINKING_LEVEL` instead. Embeddings:
  `GoogleGenerativeAIEmbeddings(model="gemini-embedding-2")`. Default models: main `gemini-3.8-flash`,
  fast `gemini-3.5-flash-lite`, judge `gemini-4-argon`.
- No import-time side effects: models, indexes and graphs are created by `build_*` / `get_*` functions,
  cached with `functools.lru_cache` where reuse matters. Pass dependencies (retriever, models, embeddings)
  as arguments so tests can inject fakes.
- Type hints and a docstring on every module and public function; Pydantic models for every structured LLM output.
- Library modules log with `get_logger(__name__)`; only `lab.py` prints results.
- Security: customer identity comes from `RunnableConfig["configurable"]["customer_id"]`, never from model
  arguments; money-moving actions need human approval; mask PII before it reaches a model or a trace.
- Tests run offline: `tests/conftest.py` sets a fake `GOOGLE_API_KEY`, `LANGSMITH_TRACING=false` and provides a
  `DeterministicFakeEmbedding` fixture. No test may call a real API.
- `lab.py` exposes `main()` that calls `bankassist.cli.run_steps(title, {number: step_function}, tools=AI_TOOLS)`;
  each step function's first docstring line is its description, and `AI_TOOLS` (a module-level tuple) names the
  lab's AI tools, shown by `--help`. `python -m bankassist.lab --step N` runs one step.

FILES TO WRITE:

src/bankassist/multimodal.py: Domain-specific and multimodal RAG (Lab 8): PDF extraction, captions, filtered
  retrieval.
  Public API (implement exactly these names and signatures):
    constant IMAGE_DIR = INDEX_DIR / 'images'
    constant COLLECTION = 'policies_v2'
    constant ROLE_AUDIENCES = {'customer': ['public'], 'staff': ['public', 'staff']}
    def table_to_markdown(rows: list[list[str | None]]) -> str
        # Convert pdfplumber rows to a markdown table so headers stay attached to values.
    def extract_pdf(path: Path) -> list[dict]
        # Return text, table and image items with page numbers.
    def image_message(path: str, ext: str, text: str) -> HumanMessage
    def pdf_to_documents(path: Path, doc_id: str) -> list[Document]
        # Multi-vector pattern: embed a summary or caption, keep the raw table or image for answering.
    @lru_cache(maxsize=1)
    def build_domain_index()
        # All policies (incl. superseded and staff-only, filtered at query time) + the rate card PDF.
    def retriever_for(role: str, k: int=5) -> Runnable
        # Filters run BEFORE the LLM sees anything: current versions only, audience by role.
    def multimodal_answer(question: str, role: str='customer') -> str
        # Retrieve, swap in raw tables and images, answer with a vision-capable model.

src/bankassist/prompts.py GROWS: add these to the existing module, change nothing else:
    constant BANK_PROMPT

src/bankassist/retrievers.py GROWS: add these to the existing module, change nothing else:
    constant GLOSSARY
    def expand_query(query: str) -> str
        # Append glossary meanings for banking acronyms (keeps the original words for BM25).

IMPLEMENTATION RULES (the tests and the lab guide depend on these):
    - GLOSSARY maps MAB, LTV, NACH, FD, EMI, KYC, ROI, OVD to their meanings; `expand_query` APPENDS `' | ABBR
      (meaning); ...'` and keeps the original text; set `DEFAULT_QUERY_TRANSFORM = expand_query`.
    - BANK_PROMPT rules: cite [doc_id, section or page]; INR with Indian grouping; rate/fee disclaimer; never
      share internal content; helpline 1800-XXX-XXXX for disputes; refuse with NOT_FOUND; inputs role,
      context, question.
    - multimodal.py: `extract_pdf` returns text (PyMuPDF), images (saved under indexes/images, path kept) and
      tables (pdfplumber -> markdown). `pdf_to_documents` embeds an LLM summary or caption and keeps the raw
      table or image path in metadata (multi-vector).
    - `build_domain_index` (lru_cache) indexes ALL chunks, including superseded and staff-only, plus the rate
      card into Chroma collection 'policies_v2'; filtering happens at query time.
    - `retriever_for(role)` filters `{'$and': [{'is_current': True}, {'audience': {'$in': audiences}}]}` with
      ROLE_AUDIENCES customer -> [public], staff -> [public, staff]. `multimodal_answer` swaps in raw tables
      and attaches images as base64 `image_url` content blocks.

src/bankassist/lab.py: this lab's runnable steps, registered in run_steps() with these numbers:
    --step 1: Expand banking acronyms
    --step 2: Show that superseded and staff-only content never reaches a customer
    --step 4: Extract text, tables and images from the rate card PDF
    --step 6: Answer table, chart and role-restricted questions

DATA (provided by the course; copy it, do not invent it):
    data/eval/routing_set.jsonl
    data/customers.json
    data/transactions.csv
    data/policies
    data/eval/chunk_eval.jsonl
    data/eval/hard_set.jsonl
    data/pdfs   <- new in this lab

TESTS (offline, pytest). Write these new test functions:
  tests/test_glossary.py
    test_expand_query_keeps_original_words
        # checks: expand query keeps original words
    test_glossary_is_the_default_query_transform
        # checks: glossary is the default query transform
  tests/test_multimodal.py
    test_table_to_markdown_keeps_header
        # checks: table to markdown keeps header
    test_rate_card_has_text_table_and_image
        # checks: rate card has text table and image

ALSO WRITE OR UPDATE: README.md (setup, steps table, expected outputs, structure),
.env.example (only the keys this lab needs), Makefile (install, test, lint, run STEP=N, data), .gitignore,
.pre-commit-config.yaml (ruff, private-key detection), .github/workflows/ci.yml
(ruff + pytest on Python 3.11 and 3.12).

EXPECTED BEHAVIOUR WHEN RUN WITH REAL KEYS:
    - Acronyms match their expanded forms
    - Only 2026 home-loan policy cited
    - Customer refused internal steps; staff sees them
    - Table and chart answers cite the page

ACCEPTANCE CHECKS (all must pass before you finish):
    1. `ruff check .` reports no issues.
    2. `pytest` passes offline with no API keys and no network calls.
    3. `python -m bankassist.lab --help` lists steps 1, 2, 4, 6.
    4. No module creates a model, index or graph at import time.
    5. Gemini models are never given a temperature.

OUTPUT FORMAT: return every new or changed file in full, each preceded by a line
`=== path/to/file ===`.
No placeholders, no 'rest unchanged' comments. After the files, list any assumption you made.

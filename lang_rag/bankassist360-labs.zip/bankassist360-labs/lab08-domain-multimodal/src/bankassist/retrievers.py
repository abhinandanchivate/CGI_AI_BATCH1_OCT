"""Retrieval building blocks.

Lab 5: load_policies, split_recursive / split_markdown, build_chunks, format_docs, FAISS and Chroma
Lab 6: exact_code_lookup, load_eval, hit_rate
Lab 7: rrf, CrossEncoderReranker, AdvancedRetriever, get_advanced_retriever
Lab 8: GLOSSARY, expand_query (plugged into the advanced retriever)

Functions that need embeddings accept an ``embeddings`` argument, so tests can pass a fake.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from collections.abc import Callable, Iterable
from functools import lru_cache
from pathlib import Path

from langchain_core.documents import Document
from langchain_core.runnables import Runnable, RunnableLambda
from langchain_text_splitters import MarkdownHeaderTextSplitter, RecursiveCharacterTextSplitter
from pydantic import BaseModel, Field

from bankassist.config import EVAL_DIR, INDEX_DIR, POLICY_DIR, get_embeddings, get_fast_llm, get_logger

log = get_logger(__name__)

FAISS_DIR = INDEX_DIR / "faiss_policies"
CHROMA_DIR = INDEX_DIR / "chroma_policies"

_HEADER_FIELDS = {
    "doc_id": re.compile(r"Document ID:\s*([\w-]+)"),
    "effective": re.compile(r"Effective:\s*([\w-]+)"),
    "audience": re.compile(r"Audience:\s*(\w+)"),
}
_SECTION_IN_TEXT = re.compile(r"^##\s*(\d+)\.", re.MULTILINE)  # first section heading in a chunk


# ---------------------------------------------------------------- loading (Lab 5)
def load_policies(folder: Path = POLICY_DIR) -> list[Document]:
    """Load every markdown policy with document-level metadata."""
    docs: list[Document] = []
    for path in sorted(Path(folder).glob("*.md")):
        text = path.read_text(encoding="utf-8")
        meta = {"source": path.name, "title": text.splitlines()[0].lstrip("# ").strip(),
                "category": path.stem.split("_")[0]}
        for key, pattern in _HEADER_FIELDS.items():
            match = pattern.search(text)
            meta[key] = match.group(1) if match else "unknown"
        if meta["doc_id"] == "unknown":
            meta["doc_id"] = path.stem
        meta["is_current"] = "superseded" not in text.splitlines()[1].lower()
        docs.append(Document(page_content=text, metadata=meta))
    log.info("Loaded %d policy documents from %s", len(docs), folder)
    return docs


# ---------------------------------------------------------------- chunking (Lab 5)
def _assign_ids(chunks: list[Document]) -> list[Document]:
    """Give every chunk a stable ``chunk_id`` and a ``source_ref`` (doc_id#section)."""
    counters: dict[str, int] = defaultdict(int)
    last_section: dict[str, str] = {}
    for c in chunks:
        section = c.metadata.get("section", "")
        match = re.match(r"(\d+)", section) or _SECTION_IN_TEXT.search(c.page_content)
        # A chunk that starts mid-section inherits the previous chunk's section in the same document.
        sec_no = match.group(1) if match else last_section.get(c.metadata["doc_id"], "0")
        last_section[c.metadata["doc_id"]] = sec_no
        ref = f"{c.metadata['doc_id']}#{sec_no}"
        c.metadata["source_ref"] = ref
        c.metadata["chunk_id"] = f"{ref}-{counters[ref]:02d}"
        counters[ref] += 1
    return chunks


def split_recursive(docs: list[Document], chunk_size: int = 800, overlap: int = 100) -> list[Document]:
    """Baseline: recursive character splitting that prefers headings and paragraphs."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, chunk_overlap=overlap,
        separators=["\n## ", "\n\n", "\n", ". ", " "])
    return _assign_ids(splitter.split_documents(docs))


def split_markdown(docs: list[Document], max_size: int = 1000, overlap: int = 100) -> list[Document]:
    """Structure-aware: split on '#'/'##' headings, then by size. Keeps tables with their section."""
    header_splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=[("#", "doc_title"), ("##", "section")], strip_headers=False)
    sizer = RecursiveCharacterTextSplitter(chunk_size=max_size, chunk_overlap=overlap)
    chunks: list[Document] = []
    for doc in docs:
        for sec in header_splitter.split_text(doc.page_content):
            sec.metadata = {**doc.metadata, **sec.metadata}
            chunks.extend(sizer.split_documents([sec]))
    return _assign_ids(chunks)


def build_chunks(strategy: str = "markdown", folder: Path = POLICY_DIR) -> list[Document]:
    """Load and chunk policies (markdown-header chunking is the Lab 6 winner)."""
    docs = load_policies(folder)
    if strategy == "markdown":
        return split_markdown(docs)
    if strategy == "recursive":
        return split_recursive(docs)
    raise ValueError(f"unknown chunking strategy: {strategy}")


def format_docs(docs: Iterable[Document]) -> str:
    """Render chunks for a prompt, each tagged with its citation reference."""
    return "\n\n".join(
        f"[{d.metadata.get('source_ref', d.metadata.get('doc_id', 'unknown'))}] {d.page_content}"
        for d in docs)


# ---------------------------------------------------------------- vector stores (Lab 5)
def build_faiss(chunks: list[Document], embeddings=None, save_dir: Path | None = FAISS_DIR):
    """Embed chunks into a FAISS index and optionally save it."""
    from langchain_community.vectorstores import FAISS

    store = FAISS.from_documents(chunks, embeddings or get_embeddings())
    if save_dir:
        store.save_local(str(save_dir))
        log.info("Saved FAISS index (%d chunks) to %s", len(chunks), save_dir)
    return store


def load_faiss(embeddings=None, load_dir: Path = FAISS_DIR):
    """Reload a FAISS index we created ourselves (pickle => only trust your own files)."""
    from langchain_community.vectorstores import FAISS

    return FAISS.load_local(str(load_dir), embeddings or get_embeddings(),
                            allow_dangerous_deserialization=True)


def build_chroma(chunks: list[Document], embeddings=None, collection: str = "policies",
                 persist_dir: Path | None = CHROMA_DIR):
    """Embed chunks into a persistent Chroma collection. Stable IDs make re-runs idempotent."""
    from langchain_chroma import Chroma

    kwargs = {"persist_directory": str(persist_dir)} if persist_dir else {}
    store = Chroma(collection_name=collection, embedding_function=embeddings or get_embeddings(), **kwargs)
    ids = [c.metadata["chunk_id"] for c in chunks]
    existing = set(store.get(ids=ids)["ids"]) if ids else set()
    if existing:
        store.delete(ids=list(existing))  # replace changed chunks instead of duplicating
    store.add_documents(chunks, ids=ids)
    log.info("Chroma collection '%s' now holds %d chunks", collection, len(chunks))
    return store


# ---------------------------------------------------------------- exact matching and evaluation (Lab 6)
CODE_PATTERN = re.compile(r"\b(?:CHG|POL|OPS)-[A-Z]+-\d{2,4}\b")


def exact_code_lookup(query: str, chunks: list[Document]) -> list[Document]:
    """Return chunks that contain any charge or document code found in the query."""
    codes = set(CODE_PATTERN.findall(query.upper()))
    if not codes:
        return []
    return [c for c in chunks if any(code in c.page_content for code in codes)]


def load_eval(name: str) -> list[dict]:
    """Read a JSONL evaluation set from data/eval/."""
    return [json.loads(line) for line in (EVAL_DIR / name).read_text().splitlines() if line]


def hit_rate(retrieve: Callable[[str], list[Document]], rows: list[dict], k: int) -> float:
    """Share of questions where any top-k chunk contains the gold phrase (case-insensitive)."""
    hits = sum(any(r["gold_text"].lower() in d.page_content.lower() for d in retrieve(r["question"])[:k])
               for r in rows)
    return hits / len(rows)


# ---------------------------------------------------------------- fusion and advanced retriever (Lab 7)
def rrf(result_lists: Iterable[list[Document]], k: int = 60, top_n: int = 20) -> list[Document]:
    """Reciprocal Rank Fusion: score = sum over lists of 1 / (k + rank)."""
    scores: dict[str, float] = defaultdict(float)
    by_id: dict[str, Document] = {}
    for results in result_lists:
        for rank, doc in enumerate(results):
            cid = doc.metadata["chunk_id"]
            scores[cid] += 1 / (k + rank + 1)
            by_id.setdefault(cid, doc)
    ranked = sorted(scores.items(), key=lambda item: -item[1])[:top_n]
    return [by_id[cid] for cid, _ in ranked]


class Queries(BaseModel):
    """Structured output for multi-query generation."""

    queries: list[str] = Field(description="Up to 3 alternative search queries", max_length=3)


MULTI_QUERY_PROMPT = (
    "Rewrite the customer question into up to 3 search queries for Indian retail banking "
    "policy documents. Use formal banking terms (for example 'cheque return' for 'bounce'), "
    "keep any codes exactly, and split multi-part questions. Question: {q}"
)
DEFAULT_QUERY_TRANSFORM: Callable[[str], str] | None = None  # Lab 8 sets this to expand_query


class CrossEncoderReranker:
    """Lazy wrapper around a sentence-transformers cross-encoder."""

    def __init__(self, model_name: str = "cross-encoder/ms-marco-MiniLM-L-6-v2") -> None:
        self.model_name = model_name
        self._model = None

    def rerank(self, query: str, docs: list[Document], top_n: int = 5) -> list[Document]:
        if not docs:
            return []
        if self._model is None:
            from sentence_transformers import CrossEncoder  # heavy import, done once

            self._model = CrossEncoder(self.model_name)
        scores = self._model.predict([(query, d.page_content) for d in docs])
        ranked = sorted(zip(docs, scores, strict=True), key=lambda pair: -pair[1])[:top_n]
        for doc, score in ranked:
            doc.metadata["rerank_score"] = float(score)
        return [doc for doc, _ in ranked]


class AdvancedRetriever:
    """Multi-query expansion -> BM25 + vector + exact lookup -> RRF -> cross-encoder re-rank."""

    def __init__(self, chunks: list[Document], embeddings=None, k: int = 10,
                 use_multi_query: bool = True, use_rerank: bool = True,
                 query_generator: Callable[[str], list[str]] | None = None,
                 query_transform: Callable[[str], str] | None = None,
                 reranker: CrossEncoderReranker | None = None) -> None:
        from langchain_community.retrievers import BM25Retriever
        from langchain_community.vectorstores import FAISS

        self.chunks = chunks
        self.bm25 = BM25Retriever.from_documents(chunks, k=k)
        self.vector = FAISS.from_documents(chunks, embeddings or get_embeddings()).as_retriever(
            search_kwargs={"k": k})
        self.use_multi_query = use_multi_query
        self.use_rerank = use_rerank
        self._query_generator = query_generator
        self._query_transform = query_transform
        self.reranker = reranker or CrossEncoderReranker()

    def hybrid_search(self, query: str) -> list[Document]:
        lists = [self.bm25.invoke(query), self.vector.invoke(query)]
        exact = exact_code_lookup(query, self.chunks)
        if exact:
            lists.append(exact)
        return rrf(lists)

    def generate_queries(self, query: str) -> list[str]:
        if self._query_generator:
            return self._query_generator(query)
        out = get_fast_llm().with_structured_output(Queries).invoke(MULTI_QUERY_PROMPT.format(q=query))
        return out.queries

    def retrieve(self, query: str, top_n: int = 5) -> list[Document]:
        if self._query_transform:
            query = self._query_transform(query)
        variants = [query] + (self.generate_queries(query) if self.use_multi_query else [])
        candidates = rrf([self.hybrid_search(v) for v in variants])
        if self.use_rerank:
            return self.reranker.rerank(query, candidates, top_n=top_n)
        return candidates[:top_n]

    def as_runnable(self, name: str = "advanced_retriever") -> Runnable:
        """Expose as a traced runnable so it can be piped into LCEL chains."""
        return RunnableLambda(self.retrieve).with_config(run_name=name)


@lru_cache(maxsize=1)
def get_advanced_retriever() -> Runnable:
    """Default advanced retriever over current, public policies (built once per process)."""
    chunks = [c for c in build_chunks() if c.metadata["is_current"] and c.metadata["audience"] == "public"]
    return AdvancedRetriever(chunks, query_transform=DEFAULT_QUERY_TRANSFORM).as_runnable()


# ---------------------------------------------------------------- domain glossary (Lab 8)
GLOSSARY: dict[str, str] = {
    "MAB": "monthly average balance",
    "LTV": "loan to value ratio",
    "NACH": "national automated clearing house mandate",
    "FD": "fixed deposit",
    "EMI": "equated monthly instalment",
    "KYC": "know your customer",
    "ROI": "rate of interest",
    "OVD": "officially valid document",
}


def expand_query(query: str) -> str:
    """Append glossary meanings for banking acronyms (keeps the original words for BM25)."""
    found = [f"{abbr} ({meaning})" for abbr, meaning in GLOSSARY.items()
             if re.search(rf"\b{abbr}\b", query, re.IGNORECASE)]
    return query + (" | " + "; ".join(found) if found else "")


DEFAULT_QUERY_TRANSFORM = expand_query

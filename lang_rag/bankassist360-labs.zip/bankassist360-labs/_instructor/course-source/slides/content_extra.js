// Extra per-lab slide content (condensed from the lab guide).
// concepts: [term, meaning] x6 · walk: [command or action, expected result] x6
// quiz: {q, o: [A,B,C,D], a: index, why} x4 · assign: {title, brief, reqs[3], accept[3]} · mods: [title, change] x3
module.exports = {
  1: {
    concepts: [["Chat model interface", "Messages in, AIMessage out, any provider"], ["Prompt template", "Reusable prompt with named variables"], ["Structured output", "Model fills a validated Pydantic schema"], ["LCEL and Runnables", "invoke, batch, stream; | chains steps"], ["Sequential vs parallel", "assign adds keys; RunnableParallel fans out"], ["Tracing", "@traceable, tags and metadata in LangSmith"]],
    walk: [["pytest", "All tests pass: setup is correct"], ["--step 1", "KYC answer + token usage dict"], ["--step 3", "Ticket: transaction_dispute, high, negative"], ["LangSmith: triage run", "Prompt, Gemini call (Ticket tool), parser"], ["--step 5", "Three branches overlap on the timeline"], ["--step 7", "Filter tag lab1; metadata channel = whatsapp"]],
    quiz: [
      { q: "What does prompt | model.with_structured_output(Ticket) create?", o: ["Two calls you make one by one", "A sequence passing each output forward", "Two parallel branches", "An agent"], a: 1, why: "The pipe builds a RunnableSequence." },
      { q: "Why are intent and urgency typed as Literal?", o: ["Faster generation", "Bad values fail validation", "Gemini requires it", "Fewer tokens"], a: 1, why: "Validation catches unexpected values before routing." },
      { q: "RunnablePassthrough.assign(ticket=chain) returns…", o: ["Only the ticket", "Input dict plus a ticket key", "A JSON string", "Nothing"], a: 1, why: "assign keeps earlier keys." },
      { q: "Best call to triage 5,000 queued emails?", o: ["invoke in a loop", "stream", "batch with max_concurrency", "bind_tools"], a: 2, why: "Concurrent, rate-limit aware." },
    ],
    assign: { title: "Inbox triage report", brief: "Nightly report that triages messages and flags those needing a human.", reqs: ["Batch-triage routing_set.jsonl (max_concurrency=5)", "Add language and needs_human fields", "Write triage_report.csv; one parent trace, tag a01"], accept: ["Routing accuracy ≥ 90%", "20 of 20 valid tickets", "needs_human rule matches exactly"] },
    mods: [["Add a product field", "Ticket gets product: savings, card, loan, deposit, other"], ["Reply in the customer's language", "Pass the parallel language result into the reply prompt"], ["Version the prompt", "PROMPT_VERSION env as trace metadata; compare v1 and v2"]],
  },
  2: {
    concepts: [["Statelessness", "Memory means re-sending context"], ["MessagesPlaceholder", "Prompt slot for past messages"], ["Token budget", "trim_messages keeps the newest that fit"], ["Summarisation", "Fold old turns into a summary"], ["Checkpointer + thread_id", "Saves graph state per conversation"], ["Long-term store", "Cross-session facts by customer_id"]],
    walk: [["--step 1", "Model does not know your name"], ["--step 3", "Same session: Priya. Other session: unknown"], ["--step 4", "81 messages -> N after trimming"], ["--step 5", "Turn 3 answers senior-citizen FD rates"], ["LangSmith: last turn", "System message holds summary + profile"], ["pytest tests/test_memory.py", "Isolation and summarisation pass offline"]],
    quiz: [
      { q: "Why does the model forget your name between calls?", o: ["Responses are cached", "Each request has only what you send", "Thinking level is low", "Rate limits"], a: 1, why: "Models are stateless." },
      { q: "Which value keys short-term memory?", o: ["customer_id", "thread_id", "run_id", "model name"], a: 1, why: "One thread_id = one conversation." },
      { q: "trim_messages(start_on='human') prevents…", o: ["Dropping the system message", "History starting with an orphan AI/tool message", "Exceeding the budget", "Summaries"], a: 1, why: "Some providers reject orphaned turns." },
      { q: "Where should 'prefers Hindi' live?", o: ["Trimmed history", "Thread checkpointer only", "Long-term store by customer", "Hard-coded prompt"], a: 2, why: "It must survive across sessions." },
    ],
    assign: { title: "Persistent, preference-aware chat", brief: "Customers return days later and expect to be remembered.", reqs: ["CLI chat with --customer and --session on SqliteSaver", "detect_preferences node writes to the store", "Restart continues the same conversation"], accept: ["Continues after restart", "Preference reused in a new session", "Turn 15 input under 1,500 tokens"] },
    mods: [["Shrink the budget", "TOKEN_BUDGET = 300; explain what was dropped"], ["Summarise by tokens", "Trigger when tokens > 800, not message count"], ["Forget me", "Delete the profile on request; confirm empty profile"]],
  },
  3: {
    concepts: [["Tool", "Function + name, description, JSON schema"], ["Tool calling", "Model proposes; your code executes"], ["Injected arguments", "RunnableConfig hidden from the model"], ["ReAct loop", "Reason, act, observe, repeat"], ["create_agent", "LangGraph agent with tools and memory"], ["Least privilege", "No tool, no capability"]],
    walk: [["Print tool schema", "get_account_balance shows no parameters"], ["pytest tests/test_tools.py", "EMI check INR 21,696 passes"], ["--step 2", "One calculate_emi call, nothing executed"], ["--step 3", "Five answers incl. duplicate INR 2,450 debits"], ["LangSmith: 'charged twice'", "Model -> tool -> model -> answer"], ["--step 5", "No data for C1002; transfer declined"]],
    quiz: [
      { q: "Who executes a tool call?", o: ["Gemini's servers", "Your agent runtime", "LangSmith", "The vector DB"], a: 1, why: "The model only proposes the call." },
      { q: "Why read customer_id from RunnableConfig?", o: ["Speed", "The model can't choose whose data", "Gemini requires it", "Caching"], a: 1, why: "Identity comes from the session." },
      { q: "What normally ends the ReAct loop?", o: ["Three iterations", "A reply with no tool calls", "A tool ERROR", "User types stop"], a: 1, why: "recursion_limit is the safety net." },
      { q: "Best place to say when to use calculate_emi?", o: ["System prompt only", "The tool's docstring", "Variable name", "Trace metadata"], a: 1, why: "The docstring is the tool description." },
    ],
    assign: { title: "Fixed-deposit advisor tools", brief: "Quote FD maturity with the right rate for each customer.", reqs: ["Pure fd_maturity_amount with quarterly compounding", "get_fd_quote tool adds senior rate from profile", "Unit tests in tests/test_fd.py"], accept: ["Maturity within INR 1 of formula", "C1003 gets senior rate; C1001 does not", "One get_fd_quote call per question"] },
    mods: [["Date filter", "since_date on get_recent_transactions"], ["Structured final answer", "response_format with answer and tools_used"], ["Approval inside the agent", "HumanInTheLoopMiddleware on raise_card_block_request"]],
  },
  4: {
    concepts: [["StateGraph", "Nodes sharing one typed state"], ["Reducers", "messages append; other keys overwrite"], ["Conditional edges", "Python router picks the next node"], ["Agent as a node", "Lab 3 agent inside the workflow"], ["interrupt / Command", "Pause for a human, then resume"], ["Durable execution", "Resume later, even in another process"]],
    walk: [["Read ROUTES", "Routing is a data table"], ["pytest tests/test_workflow.py", "Approve and reject paths pass offline"], ["--step 4", "Mermaid diagram matches the flow"], ["--step 5", "Interrupt payload, then card blocked"], ["LangSmith: thread C1001-s4", "Two traces; approved_by metadata"], ["--step 6", "Routing accuracy ≥ 95%"]],
    quiz: [
      { q: "A node returns {'ticket': {...}}. What changes?", o: ["Whole state replaced", "Only the ticket key", "Ticket appended to messages", "Error"], a: 1, why: "Keys update individually." },
      { q: "Why does interrupt need a checkpointer?", o: ["Speed", "Paused state must be saved", "LangSmith", "Routing"], a: 1, why: "Nothing to resume from otherwise." },
      { q: "How do you continue a paused run?", o: ["Same input again", "Command(resume=...) with same config", "New thread_id", "Call the node"], a: 1, why: "thread_id finds the checkpoint." },
      { q: "'yes please' goes to block_rejected. Why good?", o: ["Fails safe", "It's a bug", "Faster", "LLM decides"], a: 0, why: "Only exact approval moves money-related actions." },
    ],
    assign: { title: "Dispute handling with automatic credit", brief: "Credit small clear duplicates automatically; review the rest.", reqs: ["find_disputed_txn with structured output", "assess: ≤ INR 5,000 duplicate -> auto_credit", "Larger disputes -> interrupt for review"], accept: ["Big Bazaar duplicate auto-credited", "> INR 5,000 always pauses", "Routing still ≥ 95%"] },
    mods: [["New gated intent", "card_unblock reuses the approval node"], ["Reviewer comments", "Resume with a dict; store the note"], ["Resume in another process", "SqliteSaver; start in one run, resume in the next"]],
  },
  5: {
    concepts: [["RAG pipeline", "Index offline; retrieve and generate online"], ["Metadata", "doc_id, effective, audience for cite and filter"], ["Chunk size and overlap", "Precision vs context"], ["Embeddings", "gemini-embedding-2 vectors"], ["FAISS vs Chroma", "In-memory index vs persistent database"], ["Grounded prompt", "Cite every fact; refuse if missing"]],
    walk: [["Read a policy header", "Becomes doc_id, effective, audience"], ["--step 2", "7 documents, 13 chunks, IDs like POL-CC-2026#1-00"], ["--step 4", "Top hit POL-SAV-2026#1; files in indexes/"], ["--step 5", "Filtered hits all from POL-HL-2026"], ["--step 6", "INR 10,000 [POL-SAV-2026#1]; car loan refused"], ["Plug into Lab 4", "ATM fee answered from the fee schedule"]],
    quiz: [
      { q: "Why RAG instead of fine-tuning for policies?", o: ["Fewer tokens", "Current text at query time, with citations", "Faster model", "No embeddings"], a: 1, why: "Auditable and always current." },
      { q: "What is chunk_overlap for?", o: ["More chunks", "Keep boundary-crossing sentences intact", "Dedupe", "Speed"], a: 1, why: "Facts straddling a split survive." },
      { q: "FAISS returns 0.42 and 0.91. Which is closer?", o: ["0.91", "0.42", "Equal", "Depends on k"], a: 1, why: "L2 distance: lower is closer." },
      { q: "Why pass stable ids to Chroma?", o: ["Required", "Re-index updates, no duplicates", "Faster search", "Encryption"], a: 1, why: "Idempotent indexing." },
    ],
    assign: { title: "Incremental policy re-indexing", brief: "Re-embed only what changed each quarter.", reqs: ["Hash manifest in indexes/manifest.json", "Delete and re-add chunks of changed docs", "Log unchanged, updated, added, removed"], accept: ["No-change run embeds 0 chunks", "Edited fee shows INR 25 in answers", "No duplicate chunks"] },
    mods: [["Tune k", "Compare k = 2, 4, 8 on tokens and answers"], ["MMR search", "search_type='mmr', fetch_k=12"], ["Check citations", "Every [ref] must be a retrieved source_ref"]],
  },
  6: {
    concepts: [["Chunking trade-off", "Small = precise; large = context"], ["Structure-aware chunking", "Split on headings; tables stay whole"], ["Semantic chunking", "Split where meaning shifts"], ["Hit rate at k", "Gold phrase found in top k"], ["BM25", "Exact terms weighted by rarity"], ["Exact matching", "Regex lookup for codes"]],
    walk: [["Read chunk_eval.jsonl", "Gold phrases copied verbatim"], ["--step 1", "Counts 19, 14, 29, 35 + semantic"], ["LangSmith: chunk_eval runs", "Semantic costs most to index"], ["Compare CHG-ATM-07 chunks", "Fixed chunk loses the table header"], ["--step 6", "Vector wins 'bounces'; BM25 wins codes"], ["--step 7", "chg-atm-07 -> POL-FEE-2026#2, POL-SAV-2026#4"]],
    quiz: [
      { q: "Which keeps a fee table with its header?", o: ["Fixed 500", "Semantic", "Markdown header + recursive", "None"], a: 2, why: "Splits on headings." },
      { q: "BM25 scores a chunk high when…", o: ["Rare query terms appear in it", "It is long", "Embedding is close", "It is recent"], a: 0, why: "TF weighted by IDF." },
      { q: "'cheque bounces' vs policy 'cheque return': which finds it?", o: ["BM25", "Vector search", "Exact lookup", "None"], a: 1, why: "Embeddings match meaning." },
      { q: "Why score with a gold phrase, not chunk ID?", o: ["Faster", "Boundaries differ by strategy", "Fewer tokens", "Required"], a: 1, why: "Fair across strategies." },
    ],
    assign: { title: "Chunking study with contextual headers", brief: "Evidence for two common improvements.", reqs: ["A: markdown chunks; B: + title/section headers", "C: parent-document retrieval", "hit@1, hit@4, avg chars on two eval sets"], accept: ["Reproducible numbers", "Recommendation follows the data", "Header test passes"] },
    mods: [["Smaller sections", "split_markdown(max_size=400); explain changes"], ["Exact lookup for forms", "'Form 60' becomes a code"], ["Report hit@1 too", "Print hit@1 and hit@4 per strategy"]],
  },
  7: {
    concepts: [["Failure-mode analysis", "Label misses before fixing"], ["Hybrid search", "BM25 + vector together"], ["Reciprocal Rank Fusion", "Fuse by 1 / (k + rank)"], ["Multi-query", "Rephrasings widen recall"], ["Cross-encoder", "Reads question + chunk together"], ["Ablation", "Measure each stage's gain"]],
    walk: [["Label hard_set.jsonl", "Vague, code, mixed, multi-part"], ["--step 1", "MISS lines from vector-only search"], ["pytest -k 'rrf or hybrid'", "Fusion tests pass offline"], ["--step 5", "Five hit@5 lines; full pipeline highest"], ["--step 6", "INR 23 beyond 5 free, two citations"], ["LangSmith: advanced_retriever", "Read the generated query variants"]],
    quiz: [
      { q: "Why not add BM25 and vector scores?", o: ["Different scales", "BM25 negative", "Vector always 1", "Too slow"], a: 0, why: "Fuse ranks instead." },
      { q: "RRF k=60: X is 1st in one list only; Y is 3rd in both. Higher?", o: ["X", "Y", "Tie", "Depends"], a: 1, why: "1/61 ≈ 0.016 vs 2/63 ≈ 0.032." },
      { q: "Why re-rank only the top 20?", o: ["Less accurate", "One model pass per pair is slow", "Needs GPU", "BM25 only"], a: 1, why: "Accuracy costs compute." },
      { q: "Multi-query mainly improves…", o: ["Precision", "Recall", "Latency", "Cost"], a: 1, why: "Re-ranking restores precision." },
    ],
    assign: { title: "Adaptive retrieval", brief: "Use only the stages each query needs.", reqs: ["Rule-based classify_query (no LLM)", "Codes -> exact + BM25; short -> multi-query", "Route recorded as trace metadata"], accept: ["hit@5 within 2 points of full", "Latency ≥ 30% lower", "Classifier tests pass"] },
    mods: [["Refuse on low relevance", "Empty result below a rerank threshold"], ["Change fusion constant", "rrf(k=10); explain the change"], ["Try HyDE", "Search with a hypothetical answer"]],
  },
  8: {
    concepts: [["Glossary expansion", "Append acronym meanings"], ["Versioning", "is_current excludes superseded rules"], ["Retrieval access control", "audience filter by role"], ["Domain prompt", "INR format, disclaimers, helpline"], ["Multimodal PDFs", "Text, tables, images extracted separately"], ["Multi-vector", "Embed summary; answer from original"]],
    walk: [["Open loan_rate_card.pdf", "Slab table + bar chart"], ["--step 1", "MAB | MAB (monthly average balance)"], ["--step 4", "text, image, table items for page 1"], ["--step 2", "Customer list excludes OPS-CB, POL-HL-2025"], ["--step 6", "Lowest fee: above INR 2 crore, 0.25%"], ["LangSmith: chart question", "Image block sent to Gemini"]],
    quiz: [
      { q: "Why filter staff-only content at retrieval?", o: ["Cheaper", "The model never sees it", "Faster", "Chroma requires it"], a: 1, why: "A filter is a guarantee." },
      { q: "Multi-vector: what is embedded / answered from?", o: ["Raw / raw", "Summary / original", "Raw / summary", "Neither"], a: 1, why: "Summaries search well; originals keep detail." },
      { q: "Why convert tables to markdown?", o: ["Smaller", "Values stay with headers", "Chroma needs it", "For images"], a: 1, why: "Flattened tables lose columns." },
      { q: "Why append, not replace, acronym meanings?", o: ["BM25 + embeddings both match", "Shorter", "Fewer tokens", "Faster"], a: 0, why: "Both retrievers benefit." },
    ],
    assign: { title: "Point-in-time answers + annual report", brief: "Answer what applied on a past date, and chart questions.", reqs: ["effective_int and family metadata", "as_of filter keeps latest version per family", "Index annual_report_extract.pdf"], accept: ["June 2025 fee cites POL-HL-2025", "FY24 margin = 3.4% from chart", "Role filter still works"] },
    mods: [["Grow the glossary", "Add EBLR, GST, NRI with tests"], ["Answer in customer's language", "Use the Lab 2 profile in the prompt"], ["OCR fallback", "pytesseract when a page has no text"]],
  },
  9: {
    concepts: [["Agentic RAG", "Decide whether, where, how to retrieve"], ["Query routing", "policy, live or direct"], ["Corrective RAG", "Grade chunks; rewrite on failure"], ["Grounding check", "Every claim supported by context"], ["Bounded loops", "MAX_REWRITES, MAX_GENERATIONS"], ["Model tiering", "Flash-Lite decides; Flash answers"]],
    walk: [["Read build_agentic_rag", "Nodes, routers and counters"], ["pytest tests/test_agentic_rag.py", "All nodes present"], ["--step 1", "Agent cites rbi.org.in (with Tavily key)"], ["--step 5: prepayment", "policy, 0 rewrites, grounded, POL-HL-2026#5"], ["--step 5: yacht loan", "2 rewrites, then not-found + helpline"], ["MAX_REWRITES = 0", "Straight to not_found; restore"]],
    quiz: [
      { q: "What does the graph guarantee that retriever-as-tool doesn't?", o: ["Grading and grounding always run", "Web search", "No LLM", "Speed"], a: 0, why: "They are fixed edges." },
      { q: "Why keep question and query separate?", o: ["Answer the original question after rewrites", "Save tokens", "LangGraph requires it", "Caching"], a: 0, why: "Rewrites are for search only." },
      { q: "What stops endless rewrites?", o: ["after_grade checks the counter", "The model", "Tavily limits", "Checkpointer"], a: 0, why: "Recursion limit is the backstop." },
      { q: "Why Flash-Lite for routing and grading?", o: ["Cheap yes/no decisions", "More accurate", "Flash can't do JSON", "Streaming"], a: 0, why: "Tiering cuts cost." },
    ],
    assign: { title: "Decomposing multi-part questions", brief: "Answer every part of a compound question.", reqs: ["decompose node: up to 3 sub-questions", "Retrieve + grade each; merge by chunk_id", "Single-part questions unchanged"], accept: ["NRI KYC question: 3 parts cited", "No decomposition on single-part", "Within loop limits"] },
    mods: [["Cache live search", "15-minute TTL per query"], ["Escalate, not just refuse", "not_found adds a reference like ESC-1001"], ["Expose the path", "path list in state, appended by each node"]],
  },
  10: {
    concepts: [["Golden dataset", "Questions, references, relevant sources"], ["Code evaluators", "Precision and recall, free and exact"], ["LLM-as-judge", "gemini-4-argon scores with a rubric"], ["Faithfulness", "Supported claims / total claims"], ["Experiments", "Versions compared side by side"], ["Release gate", "Exit 1 when a target is missed"]],
    walk: [["--step 1", "Dataset with 30 examples (idempotent)"], ["--step 5", "Table: 3 versions x 4 metrics"], ["LangSmith Compare", "Open lowest faithfulness; read judge note"], ["Judge 5 by hand", "Tighten rubric if > 1 disagreement"], ["--step 6 twice", "Second run faster: LLM cache"], ["python -m scripts.release_gate", "PASSED/0 or FAILED/1"]],
    quiz: [
      { q: "Precision@5 = 0.4, recall@5 = 1.0 means…", o: ["All relevant found, much noise", "Relevant missed", "Perfect", "Answer wrong"], a: 0, why: "Noise wastes tokens." },
      { q: "Faithfulness 0.6 with recall 1.0: likely cause?", o: ["Retriever", "Generator added claims", "Dataset", "Cache"], a: 1, why: "Right sections were present." },
      { q: "Why None for out-of-scope retrieval metrics?", o: ["Undefined: no relevant sections", "Bug", "Saves time", "Required"], a: 0, why: "Correctness checks the refusal." },
      { q: "Why a stronger judge model?", o: ["Less self-preference, better judgement", "Cheaper", "Faster", "Required"], a: 0, why: "Judges follow rubrics better." },
    ],
    assign: { title: "Evaluation in CI", brief: "Test every change; gate every release.", reqs: ["GitHub Actions: lint + pytest on PRs", "release_gate on main with secrets", "citation_accuracy + p95 latency summary"], accept: ["PR job needs no keys", "Broken branch blocked", "Citation accuracy ≥ 0.95"] },
    mods: [["Change k for metrics", "TOP_K = 3; explain the trade-off"], ["Document-level metrics", "doc_recall beside section recall"], ["Judge variance", "num_repetitions=3; flag spread > 0.2"]],
  },
};

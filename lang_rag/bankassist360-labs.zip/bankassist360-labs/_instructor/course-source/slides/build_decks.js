// Build one PowerPoint deck per lab from content.js.
// Usage (from the slides/ folder):  node src/build_decks.js
const path = require("path");
const pptxgen = require("pptxgenjs");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");
const LABS = require("./content.js");
const EXTRA = require("./content_extra.js");
const RUN = require("./run_notes.json");
const TOOLS = require("./ai_tools.json");

const THEME = {
  name: "BankAssist 360",
  headFontFace: "Cambria",
  bodyFontFace: "Calibri",
  colors: {
    dk1: "1B262C", lt1: "FFFFFF", dk2: "0B3C49", lt2: "E8F1F2",
    accent1: "E89B2E", accent2: "1F7A8C", accent3: "5B6B73", accent4: "C9DCE0",
    accent5: "C2502E", accent6: "3E8E5E", hlink: "1F7A8C", folHlink: "5B6B73",
  },
};
const OUT_DIR = path.resolve(__dirname, "..");
const SLUGS = { 1: "lab01-query-triage", 2: "lab02-conversational-memory", 3: "lab03-banking-agent",
  4: "lab04-langgraph-workflow", 5: "lab05-policy-rag", 6: "lab06-chunking-matching", 7: "lab07-hybrid-rerank",
  8: "lab08-domain-multimodal", 9: "lab09-agentic-rag", 10: "lab10-evaluation-release" };
const MODULES_FROM = { config: 1, cli: 1, chains: 1, memory: 2, data_access: 3, tools: 3, agent: 3, workflow: 4,
  guardrails: 5, prompts: 5, retrievers: 5, rag: 5, multimodal: 8, agentic_rag: 9, evaluation: 10, api: 10 };
const MODULE_ROLE = { config: "Settings, paths, Gemini model factories", cli: "--step runner",
  chains: "Triage chain and Ticket schema", memory: "Trimming, summaries, checkpointer, store",
  data_access: "Synthetic core-banking data", tools: "Banking tools; identity from config",
  agent: "create_agent banking agent", workflow: "LangGraph routing + human approval",
  guardrails: "PII masking, injection guard", prompts: "RAG and domain prompts",
  retrievers: "Loading, chunking, vector stores", rag: "RAG chains returning answer + evidence",
  multimodal: "PDF tables and images, filtered retrieval", agentic_rag: "Corrective RAG graph, live search",
  evaluation: "Dataset, evaluators, experiments, gate", api: "Capstone FastAPI service" };
const GROWS = { 6: ["retrievers", "exact_code_lookup, hit_rate"], 7: ["retrievers", "rrf, AdvancedRetriever, build_advanced_rag"],
  8: ["retrievers", "GLOSSARY, expand_query, BANK_PROMPT"] };
const W = 10, M = 0.5;

function buildDeck(lab, next) {
  const X = EXTRA[lab.n];
  const pres = new pptxgen();
  pres.layout = "LAYOUT_16x9";
  pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
  pres.author = "BankAssist 360 course team";
  pres.title = `Lab ${lab.n}: ${lab.title}`;
  const C = pres.SchemeColor;
  const footer = `BankAssist 360 · Lab ${lab.n}`;

  // ---------------------------------------------------------------- layouts
  const darkObjects = [
    { placeholder: { options: { name: "kicker", type: "body", x: 0.6, y: 1.25, w: 8.8, h: 0.45, fontSize: 16, bold: true, color: C.accent1, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: 0.6, y: 1.75, w: 8.8, h: 1.5, fontSize: 40, bold: true, color: C.background1, align: "left", valign: "top", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "body", type: "body", x: 0.6, y: 3.4, w: 8.8, h: 0.9, fontSize: 16, color: C.background2, valign: "top", margin: 0 }, text: "" } },
    { text: { text: "BankAssist 360 · GenAI case study · Runs on Google Gemini · Apex National Bank (fictional)", options: { x: 0.6, y: 4.95, w: 8.8, h: 0.3, fontSize: 11, color: C.accent4, margin: 0 } } },
  ];
  pres.defineSlideMaster({ title: "DARK", background: { color: THEME.colors.dk2 }, objects: darkObjects });
  pres.defineSlideMaster({
    title: "CONTENT",
    background: { color: THEME.colors.lt1 },
    margin: [0.5, 0.5, 0.6, 0.5],
    objects: [
      { placeholder: { options: { name: "title", type: "title", x: M, y: 0.3, w: 9, h: 0.7, fontSize: 30, bold: true, color: C.text2, align: "left", valign: "middle", margin: 0 }, text: "" } },
      { text: { text: footer, options: { x: M, y: 5.2, w: 5, h: 0.3, fontSize: 10, color: C.accent3, margin: 0 } } },
    ],
    slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.3, fontSize: 10, color: THEME.colors.accent3, align: "right" },
  });

  const numCircle = (slide, n, x, y, d = 0.42, fill = C.accent1) => {
    slide.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: fill }, line: { color: fill }, objectName: `num-${n}` });
    slide.addText(String(n), { x, y, w: d, h: d, fontSize: 14, bold: true, color: C.background1, align: "center", valign: "middle", margin: 0, isTextBox: true });
  };
  const content = (title, section) => {
    const s = pres.addSlide({ masterName: "CONTENT", sectionTitle: section });
    s.addText(title, { placeholder: "title" });
    return s;
  };

  // ---------------------------------------------------------------- 1. title
  pres.addSection({ title: "Introduction" });
  let s = pres.addSlide({ masterName: "DARK", sectionTitle: "Introduction" });
  s.addText(`LAB ${String(lab.n).padStart(2, "0")}`, { placeholder: "kicker" });
  s.addText(lab.title, { placeholder: "title" });
  s.addText(lab.sessions, { placeholder: "body" });
  s.addNotes(`Lab ${lab.n} covers ${lab.sessions}. ${lab.lead} Allow about 2.5 to 3 hours including exercises.`);

  // ---------------------------------------------------------------- 2. outcomes
  s = content("What you will build", "Introduction");
  s.addText(lab.lead, { x: M, y: 1.3, w: 4.2, h: 1.85, fontSize: 20, italic: true, color: C.text2, valign: "top", margin: 0, isTextBox: true });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y: 3.75, w: 4.2, h: 0.75, rectRadius: 0.08, fill: { color: C.background2 }, line: { color: C.background2 }, objectName: "run-command" });
  s.addText("Run this lab (its own project)", { x: M, y: 3.35, w: 4.2, h: 0.32, fontSize: 12, bold: true, color: C.accent2, margin: 0, isTextBox: true });
  s.addText(`cd ${SLUGS[lab.n]}\n${lab.run}`, { x: M + 0.15, y: 3.75, w: 4.0, h: 0.75, fontSize: 11, fontFace: "Courier New", color: C.text1, valign: "middle", margin: 0, isTextBox: true });
  lab.outcomes.forEach((o, i) => {
    const y = 1.3 + i * 0.85;
    numCircle(s, i + 1, 5.2, y);
    s.addText(o, { x: 5.8, y: y - 0.06, w: 3.7, h: 0.55, fontSize: 16, color: C.text1, valign: "middle", margin: 0, isTextBox: true });
  });
  s.addNotes(`Learning outcomes. ${lab.outcomes.join("; ")}. Run everything from the project root: ${lab.run}`);

  // ---------------------------------------------------------------- 3. scenario
  s = content("Business scenario", "Introduction");
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y: 1.3, w: 5.5, h: 3.5, rectRadius: 0.1, fill: { color: C.background2 }, line: { color: C.background2 }, objectName: "problem-card" });
  s.addText("The problem", { x: M + 0.3, y: 1.55, w: 4.9, h: 0.4, fontSize: 14, bold: true, color: C.accent2, margin: 0, isTextBox: true });
  s.addText(lab.scenario, { x: M + 0.3, y: 2.0, w: 4.9, h: 2.6, fontSize: 18, color: C.text2, valign: "top", margin: 0, isTextBox: true });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 6.4, y: 1.3, w: 3.1, h: 3.5, rectRadius: 0.1, fill: { color: C.background1 }, line: { color: C.accent4, width: 1.25 }, objectName: "persona-card" });
  s.addShape(pres.shapes.OVAL, { x: 6.7, y: 1.6, w: 0.95, h: 0.95, fill: { color: C.text2 }, line: { color: C.text2 }, objectName: "persona-avatar" });
  s.addText(lab.persona.initials, { x: 6.7, y: 1.6, w: 0.95, h: 0.95, fontSize: 22, bold: true, color: C.background1, align: "center", valign: "middle", margin: 0, isTextBox: true });
  s.addText(lab.persona.name, { x: 6.7, y: 2.75, w: 2.6, h: 0.6, fontSize: 15, bold: true, color: C.text2, valign: "top", margin: 0, isTextBox: true });
  s.addText(lab.persona.need, { x: 6.7, y: 3.4, w: 2.6, h: 1.25, fontSize: 14, color: C.accent3, valign: "top", margin: 0, isTextBox: true });
  s.addNotes(`Set the scene: ${lab.scenario} Persona: ${lab.persona.name}, who needs: ${lab.persona.need}.`);

  // ---------------------------------------------------------------- 3b. concepts
  s = content("Concepts covered", "Introduction");
  X.concepts.forEach(([term, meaning], i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const x = M + col * 3.075, y = 1.3 + row * 1.75;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 2.85, h: 1.5, rectRadius: 0.08, fill: { color: C.background2 }, line: { color: C.background2 }, objectName: `concept-${i + 1}` });
    numCircle(s, i + 1, x + 0.2, y + 0.2, 0.36, C.accent2);
    s.addText(term, { x: x + 0.7, y: y + 0.15, w: 2.0, h: 0.5, fontSize: 15, bold: true, color: C.text2, valign: "middle", margin: 0, isTextBox: true });
    s.addText(meaning, { x: x + 0.2, y: y + 0.72, w: 2.5, h: 0.65, fontSize: 13, color: C.text1, valign: "top", margin: 0, isTextBox: true });
  });
  s.addNotes(`Concepts in this lab: ${X.concepts.map(([t, m]) => `${t}: ${m}`).join("; ")}. The lab guide maps each concept to the step that uses it.`);

  // ---------------------------------------------------------------- 3c. project structure
  s = content("Project structure", "Introduction");
  const mods = Object.keys(MODULES_FROM).filter((m) => MODULES_FROM[m] <= lab.n);
  const fresh = mods.filter((m) => MODULES_FROM[m] === lab.n);
  const grows = GROWS[lab.n] ? GROWS[lab.n][0] : null;
  const treeLines = [`${SLUGS[lab.n]}/`, "  src/bankassist/",
    ...mods.map((m) => `    ${(m + ".py").padEnd(16)}${MODULES_FROM[m] === lab.n ? "+ new" : m === grows ? "+ grows" : ""}`),
    `    ${"lab.py".padEnd(16)}+ new`, "  tests/  data/  docs/", "  pyproject.toml  Makefile"];
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y: 1.2, w: 4.2, h: 3.75, rectRadius: 0.08, fill: { color: C.text2 }, line: { color: C.text2 }, objectName: "project-tree" });
  s.addText(treeLines.join("\n"), { x: M + 0.2, y: 1.3, w: 3.9, h: 3.55, fontSize: treeLines.length > 18 ? 9 : 10.5, fontFace: "Courier New", color: C.background1, valign: "top", margin: 0, isTextBox: true });
  s.addText("New in this lab", { x: 5.0, y: 1.2, w: 4.5, h: 0.35, fontSize: 16, bold: true, color: C.text2, margin: 0, isTextBox: true });
  const newItems = [...fresh.map((m) => [`${m}.py`, MODULE_ROLE[m]]), ...(grows ? [[`${grows}.py`, `grows: ${GROWS[lab.n][1]}`]] : []), ["lab.py", "This lab's runnable steps"]];
  newItems.slice(0, 4).forEach(([f, d], i) => {
    const y = 1.65 + i * 0.6;
    s.addText([{ text: f, options: { bold: true, fontFace: "Courier New", color: C.accent2, breakLine: true } }, { text: d, options: { color: C.text1 } }],
      { x: 5.0, y, w: 4.5, h: 0.55, fontSize: 12, valign: "top", margin: 0, isTextBox: true });
  });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.0, y: 4.1, w: 4.5, h: 0.85, rectRadius: 0.08, fill: { color: C.background2 }, line: { color: C.background2 }, objectName: "setup-box" });
  s.addText(`make install  ·  cp .env.example .env\nmake test  ·  make run STEP=${RUN[lab.n].steps[0][0]}`, { x: 5.15, y: 4.1, w: 4.2, h: 0.85, fontSize: 12, fontFace: "Courier New", color: C.text1, valign: "middle", margin: 0, isTextBox: true });
  s.addNotes(`Each lab is a standalone project (${SLUGS[lab.n]}) containing everything built so far, so learners can start at any lab. New in this lab: ${newItems.map(([f, d]) => `${f}: ${d}`).join("; ")}. Setup: make install, copy .env.example to .env and add GOOGLE_API_KEY and LANGSMITH_API_KEY, make test (offline), make run.`);

  // ---------------------------------------------------------------- 3d. run this lab
  s = content("Run this lab", "Introduction");
  const run = RUN[lab.n];
  const cmd = [
    "# macOS / Linux",
    `cd ${SLUGS[lab.n]}`,
    "python3 -m venv .venv",
    "source .venv/bin/activate",
    "make install",
    "cp .env.example .env",
    "make test",
    `make run STEP=${run.steps[0][0]}`,
    "",
    "# Windows (PowerShell)",
    `cd ${SLUGS[lab.n]}`,
    "py -3.11 -m venv .venv",
    ".venv\\Scripts\\Activate.ps1",
    'python -m pip install -e ".[dev]"',
    "Copy-Item .env.example .env",
    "pytest",
    `python -m bankassist.lab --step ${run.steps[0][0]}`,
  ];
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y: 1.2, w: 4.3, h: 3.75, rectRadius: 0.08, fill: { color: C.text2 }, line: { color: C.text2 }, objectName: "run-commands" });
  s.addText(cmd.map((l, i) => ({ text: l, options: { color: l.startsWith("#") ? C.accent1 : C.background1, bold: l.startsWith("#"), breakLine: i < cmd.length - 1 } })),
    { x: M + 0.2, y: 1.3, w: 4.0, h: 3.55, fontSize: 10.5, fontFace: "Courier New", valign: "top", margin: 0, isTextBox: true });
  s.addText("Steps", { x: 5.1, y: 1.2, w: 4.4, h: 0.32, fontSize: 15, bold: true, color: C.text2, margin: 0, isTextBox: true });
  s.addText(run.steps.map(([k, d], i) => ({ text: "", options: {} }) && [
      { text: `--step ${k}  `, options: { fontFace: "Courier New", bold: true, color: C.accent2 } },
      { text: d, options: { color: C.text1, breakLine: i < run.steps.length - 1 } }]).flat(),
    { x: 5.1, y: 1.55, w: 4.4, h: 1.55, fontSize: 11, valign: "top", fit: "shrink", paraSpaceAfter: 2, margin: 0, isTextBox: true });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 5.1, y: 3.15, w: 4.4, h: 0.38, rectRadius: 0.06, fill: { color: C.background2 }, line: { color: C.background2 }, objectName: "tests-badge" });
  s.addText(`Offline check: make test  →  ${run.tests} passed` + (run.optional ? "   ·   + Tavily key (optional)" : ""),
    { x: 5.2, y: 3.15, w: 4.2, h: 0.38, fontSize: 11, color: C.text1, valign: "middle", margin: 0, isTextBox: true });
  s.addText("Before you run", { x: 5.1, y: 3.62, w: 4.4, h: 0.3, fontSize: 13, bold: true, color: C.text2, margin: 0, isTextBox: true });
  s.addText(run.notes.slice(0, 2).map((n, i) => ({ text: n.replace(/`/g, ""), options: { bullet: true, breakLine: i < 1 } })),
    { x: 5.1, y: 3.92, w: 4.4, h: 1.05, fontSize: 10, color: C.text1, valign: "top", fit: "shrink", paraSpaceAfter: 3, margin: 0, isTextBox: true });
  s.addNotes(`Run ${SLUGS[lab.n]}: create a virtual environment, make install, copy .env.example to .env and add GOOGLE_API_KEY and LANGSMITH_API_KEY${run.optional ? ` (optional ${run.optional})` : ""}, then make test (expect ${run.tests} passed, no keys used) and make run STEP=N. Steps: ${run.steps.map(([k, d]) => `--step ${k}: ${d}`).join("; ")}. Before running: ${run.notes.map((n) => n.replace(/`/g, "")).join(" ")} Reset with make clean.`);

  // ---------------------------------------------------------------- 3e. AI tools in this lab
  s = content("AI tools in this lab", "Introduction");
  const tools = TOOLS[lab.n];
  const toolRowH = Math.min(0.62, 3.75 / tools.length);
  tools.forEach(([name, role], i) => {
    const y = 1.25 + i * toolRowH;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y, w: 3.3, h: 0.44, rectRadius: 0.22, fill: { color: C.background2 }, line: { color: C.accent1, width: 0.75 }, objectName: `tool-chip-${i + 1}` });
    s.addText(name, { x: M, y, w: 3.3, h: 0.44, fontSize: 12, bold: true, color: C.text2, align: "center", valign: "middle", margin: 0, isTextBox: true });
    s.addText(role, { x: M + 3.55, y, w: 9.5 - M - 3.55, h: 0.44, fontSize: 12.5, color: C.text1, valign: "middle", fit: "shrink", margin: 0, isTextBox: true });
  });
  s.addText([{ text: "Models are set in .env, never in code.", options: { bold: true, color: C.text2 } }, { text: "   ", options: { color: C.text1 } }, { text: "python -m bankassist.lab --help", options: { fontFace: "Courier New", color: C.accent2 } }, { text: " lists these tools.", options: { color: C.text1 } }],
    { x: M, y: 4.9, w: 10 - 2 * M, h: 0.3, fontSize: 10.5, valign: "middle", margin: 0, isTextBox: true });
  s.addNotes(`AI tools in ${SLUGS[lab.n]}: ${tools.map(([n, r]) => `${n}: ${r}`).join("; ")}. Model names are the .env defaults (LLM_MODEL, FAST_LLM_MODEL, JUDGE_MODEL, EMBED_MODEL); check them against the Gemini API changelog before each run. python -m bankassist.lab --help lists the same tools.`);

  // ---------------------------------------------------------------- 4. flow (snake layout)
  pres.addSection({ title: "Design" });
  s = content("Architecture flow", "Design");
  const steps = lab.flow, cols = Math.ceil(steps.length / 2), gap = 0.4;
  const bw = (W - 2 * M - (cols - 1) * gap) / cols, bh = 1.0, rows = [1.45, 3.3];
  const pos = steps.map((_, i) => {
    const row = i < cols ? 0 : 1;
    const col = row === 0 ? i : cols - 1 - (i - cols);
    return { x: M + col * (bw + gap), y: rows[row], row };
  });
  const arrow = (opts) => s.addShape(pres.shapes.LINE, { ...opts, line: { color: THEME.colors.accent3, width: 1.5, endArrowType: "triangle" } });
  steps.forEach((label, i) => {
    const p = pos[i];
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: p.x, y: p.y, w: bw, h: bh, rectRadius: 0.08, fill: { color: C.background2 }, line: { color: C.accent4, width: 1 }, objectName: `flow-${i + 1}` });
    numCircle(s, i + 1, p.x + 0.12, p.y + 0.12, 0.34);
    s.addText(label, { x: p.x + 0.52, y: p.y + 0.08, w: bw - 0.62, h: bh - 0.16, fontSize: 13, bold: true, color: C.text2, valign: "middle", margin: 0, isTextBox: true });
    if (i === steps.length - 1) return;
    const q = pos[i + 1];
    if (p.row === q.row && p.row === 0) arrow({ x: p.x + bw, y: p.y + bh / 2, w: gap, h: 0 });
    else if (p.row === q.row) arrow({ x: q.x + bw, y: p.y + bh / 2, w: gap, h: 0, flipH: true });
    else arrow({ x: p.x + bw / 2, y: p.y + bh, w: 0, h: rows[1] - rows[0] - bh });
  });
  s.addText("Read left to right on the top row, then right to left on the bottom row. The full diagram is in the lab guide.", { x: M, y: 4.62, w: 9, h: 0.4, fontSize: 12, color: C.accent3, margin: 0, isTextBox: true });
  s.addNotes(`Walk the flow in order: ${steps.map((t, i) => `${i + 1}. ${t}`).join("; ")}.`);

  // ---------------------------------------------------------------- 5. inputs and outputs
  s = content("Inputs and expected outputs", "Design");
  [["IN", "Inputs", lab.inputs, C.accent2, M], ["OUT", "Expected outputs", lab.outputs, C.accent1, 5.2]].forEach(([tag, head, items, color, x]) => {
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 1.3, w: 4.3, h: 3.5, rectRadius: 0.1, fill: { color: C.background1 }, line: { color: C.accent4, width: 1.25 }, objectName: `${tag.toLowerCase()}-card` });
    s.addShape(pres.shapes.OVAL, { x: x + 0.3, y: 1.55, w: 0.6, h: 0.6, fill: { color }, line: { color } });
    s.addText(tag, { x: x + 0.3, y: 1.55, w: 0.6, h: 0.6, fontSize: 12, bold: true, color: C.background1, align: "center", valign: "middle", margin: 0, isTextBox: true });
    s.addText(head, { x: x + 1.05, y: 1.55, w: 3.0, h: 0.6, fontSize: 18, bold: true, color: C.text2, valign: "middle", margin: 0, isTextBox: true });
    s.addText(items.map((t, i) => ({ text: t, options: { bullet: true, breakLine: i < items.length - 1 } })),
      { x: x + 0.3, y: 2.35, w: 3.75, h: 2.3, fontSize: 14, color: C.text1, valign: "top", paraSpaceAfter: 6, margin: 0, isTextBox: true });
  });
  s.addNotes(`Inputs: ${lab.inputs.join("; ")}. Expected outputs: ${lab.outputs.join("; ")}.`);

  // ---------------------------------------------------------------- 6. steps
  pres.addSection({ title: "Build" });
  s = content("Implementation steps", "Build");
  const perCol = Math.ceil(lab.steps.length / 2), rowH = Math.min(0.9, 3.6 / perCol);
  lab.steps.forEach((st, i) => {
    const col = i < perCol ? 0 : 1, row = col === 0 ? i : i - perCol;
    const x = M + col * 4.7, y = 1.3 + row * rowH;
    numCircle(s, i + 1, x, y + 0.04, 0.42, C.text2);
    s.addText(st.t, { x: x + 0.6, y, w: 3.8, h: 0.34, fontSize: 15, bold: true, color: C.text2, margin: 0, isTextBox: true });
    s.addText(`Why: ${st.why}`, { x: x + 0.6, y: y + 0.34, w: 3.8, h: 0.32, fontSize: 13, color: C.accent3, margin: 0, isTextBox: true });
  });
  s.addNotes(`Each step in the lab guide has the code, why we do it, and a code explanation. ${lab.steps.map((st, i) => `Step ${i + 1}, ${st.t}: ${st.why}.`).join(" ")}`);

  // ---------------------------------------------------------------- 6b. walkthrough
  s = content("Hands-on walkthrough", "Build");
  s.addText([{ text: "--step N means  ", options: { color: C.accent3 } }, { text: `${lab.run} --step N`, options: { fontFace: "Courier New", color: C.text1 } }],
    { x: M, y: 4.98, w: 8.4, h: 0.22, fontSize: 11, margin: 0, isTextBox: true });
  s.addText("Do this", { x: 1.0, y: 1.15, w: 3.6, h: 0.3, fontSize: 12, bold: true, color: C.accent2, margin: 0, isTextBox: true });
  s.addText("Expect this", { x: 4.85, y: 1.15, w: 4.6, h: 0.3, fontSize: 12, bold: true, color: C.accent2, margin: 0, isTextBox: true });
  X.walk.forEach(([action, expect], i) => {
    const y = 1.55 + i * 0.58;
    const isCmd = /^(--|pytest|python|MAX_)/.test(action);
    numCircle(s, i + 1, M, y + 0.04, 0.36, C.text2);
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 1.0, y, w: 3.6, h: 0.44, rectRadius: 0.06, fill: { color: C.background2 }, line: { color: C.background2 }, objectName: `walk-${i + 1}` });
    s.addText(action, { x: 1.12, y, w: 3.4, h: 0.44, fontSize: isCmd ? 12 : 13, fontFace: isCmd ? "Courier New" : undefined, bold: !isCmd, color: C.text1, valign: "middle", margin: 0, isTextBox: true });
    s.addShape(pres.shapes.LINE, { x: 4.62, y: y + 0.22, w: 0.18, h: 0, line: { color: THEME.colors.accent3, width: 1.25, endArrowType: "triangle" } });
    s.addText(expect, { x: 4.85, y, w: 4.65, h: 0.44, fontSize: 14, color: C.text1, valign: "middle", margin: 0, isTextBox: true });
  });
  s.addNotes(`Walkthrough (full version with 10 to 12 actions is in the lab guide): ${X.walk.map(([a, e], i) => `${i + 1}. ${a}: expect ${e}`).join(". ")}.`);

  // ---------------------------------------------------------------- 7. key code
  s = content("Key code", "Build");
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y: 1.25, w: 5.9, h: 3.7, rectRadius: 0.08, fill: { color: C.text2 }, line: { color: C.text2 }, objectName: "code-panel" });
  s.addText(lab.code.file, { x: M + 0.2, y: 1.35, w: 5.5, h: 0.32, fontSize: 11, bold: true, color: C.accent1, margin: 0, isTextBox: true });
  s.addText(lab.code.lines.join("\n"), { x: M + 0.2, y: 1.72, w: 5.55, h: 3.1, fontSize: 11, fontFace: "Courier New", color: C.background1, valign: "top", margin: 0, isTextBox: true });
  s.addText("Why it works", { x: 6.75, y: 1.25, w: 2.75, h: 0.4, fontSize: 16, bold: true, color: C.text2, margin: 0, isTextBox: true });
  lab.code.notes.forEach((n, i) => {
    const y = 1.85 + i * 1.0;
    numCircle(s, i + 1, 6.75, y, 0.36);
    s.addText(n, { x: 7.25, y: y - 0.05, w: 2.25, h: 0.9, fontSize: 14, color: C.text1, valign: "top", margin: 0, isTextBox: true });
  });
  s.addNotes(`Code from ${lab.code.file}. ${lab.code.notes.join(". ")}. The complete, tested version is in this lab's project.`);

  // ---------------------------------------------------------------- 8. LangSmith
  pres.addSection({ title: "Verify" });
  s = content("LangSmith checkpoint", "Verify");
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y: 1.3, w: 4.4, h: 3.5, rectRadius: 0.1, fill: { color: C.background2 }, line: { color: C.background2 }, objectName: "trace-tree" });
  s.addText("Trace tree", { x: M + 0.3, y: 1.5, w: 3.8, h: 0.35, fontSize: 14, bold: true, color: C.accent2, margin: 0, isTextBox: true });
  s.addShape(pres.shapes.OVAL, { x: M + 0.3, y: 2.03, w: 0.18, h: 0.18, fill: { color: C.text2 }, line: { color: C.text2 } });
  s.addText(`lab${lab.n} run`, { x: M + 0.6, y: 1.95, w: 3.4, h: 0.34, fontSize: 13, bold: true, color: C.text2, margin: 0, isTextBox: true });
  lab.flow.slice(0, 6).forEach((t, i) => {
    const y = 2.4 + i * 0.38;
    s.addShape(pres.shapes.LINE, { x: M + 0.39, y: y + 0.13, w: 0.35, h: 0, line: { color: THEME.colors.accent3, width: 1 } });
    s.addShape(pres.shapes.OVAL, { x: M + 0.78, y: y + 0.06, w: 0.14, h: 0.14, fill: { color: C.accent2 }, line: { color: C.accent2 } });
    s.addText(t, { x: M + 1.02, y: y - 0.03, w: 3.2, h: 0.32, fontSize: 12, color: C.text1, margin: 0, isTextBox: true });
  });
  s.addShape(pres.shapes.LINE, { x: M + 0.39, y: 2.21, w: 0, h: 0.38 * Math.min(lab.flow.length, 6) - 0.05, line: { color: THEME.colors.accent3, width: 1 } });
  s.addText("What to check", { x: 5.3, y: 1.3, w: 4.2, h: 0.4, fontSize: 16, bold: true, color: C.text2, margin: 0, isTextBox: true });
  lab.langsmith.forEach((t, i) => {
    const y = 1.9 + i * 0.95;
    numCircle(s, i + 1, 5.3, y, 0.4, C.accent6);
    s.addText(t, { x: 5.85, y: y - 0.05, w: 3.65, h: 0.8, fontSize: 15, color: C.text1, valign: "top", margin: 0, isTextBox: true });
  });
  s.addNotes(`Open smith.langchain.com, project bankassist360. ${lab.langsmith.join(". ")}.`);

  // ---------------------------------------------------------------- 9. errors
  s = content("Common errors and fixes", "Verify");
  const head = ["Error", "Cause", "Fix"].map((t) => ({ text: t, options: { bold: true, color: C.background1, fill: { color: C.text2 } } }));
  s.addTable([head, ...lab.errors.map((r) => r.map((t, j) => ({ text: t, options: { color: j === 0 ? C.accent5 : C.text1, bold: j === 0 } })))], {
    x: M, y: 1.35, w: 9, colW: [3.0, 2.8, 3.2], fontSize: 14, fontFace: "Calibri", valign: "middle",
    border: { type: "solid", pt: 0.75, color: THEME.colors.accent4 }, rowH: [0.5, ...lab.errors.map(() => (lab.errors.length > 3 ? 0.6 : 0.75))], margin: 0.1,
  });
  s.addText("Check the trace first: most errors are visible in the failing run's inputs.", { x: M, y: 4.6, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.accent3, margin: 0, isTextBox: true });
  s.addNotes(lab.errors.map((r) => `${r[0]}: caused by ${r[1]}; fix: ${r[2]}.`).join(" "));

  // ---------------------------------------------------------------- 9b. knowledge check
  s = content("Knowledge check", "Verify");
  X.quiz.forEach((qz, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = M + col * 4.6, y = 1.2 + row * 1.9;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w: 4.4, h: 1.75, rectRadius: 0.08, fill: { color: C.background1 }, line: { color: C.accent4, width: 1.25 }, objectName: `quiz-${i + 1}` });
    s.addText(`Q${i + 1}`, { x: x + 0.2, y: y + 0.12, w: 0.5, h: 0.3, fontSize: 13, bold: true, color: C.accent1, margin: 0, isTextBox: true });
    s.addText(qz.q, { x: x + 0.7, y: y + 0.1, w: 3.55, h: 0.55, fontSize: 13, bold: true, color: C.text2, valign: "top", margin: 0, isTextBox: true });
    s.addText(qz.o.map((o, j) => ({ text: `${"ABCD"[j]}. ${o}`, options: { breakLine: j < 3 } })),
      { x: x + 0.7, y: y + 0.68, w: 3.55, h: 1.0, fontSize: 12, color: C.text1, valign: "top", margin: 0, isTextBox: true });
  });
  s.addNotes(`Answer key: ${X.quiz.map((qz, i) => `Q${i + 1}: ${"ABCD"[qz.a]}. ${qz.why}`).join(" ")} Two short-answer questions and full explanations are in the lab guide.`);

  // ---------------------------------------------------------------- 10. practise and assess
  s = content("Practise and assess", "Verify");
  s.addText("Extension exercises", { x: M, y: 1.25, w: 4.3, h: 0.4, fontSize: 16, bold: true, color: C.text2, margin: 0, isTextBox: true });
  lab.exercises.forEach((t, i) => {
    const y = 1.8 + i * 1.5;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y, w: 4.3, h: 1.3, rectRadius: 0.08, fill: { color: C.background2 }, line: { color: C.background2 }, objectName: `exercise-${i + 1}` });
    s.addText(t, { x: M + 0.25, y: y + 0.15, w: 3.8, h: 1.0, fontSize: 15, color: C.text2, valign: "middle", margin: 0, isTextBox: true });
  });
  s.addText("Assessment checklist", { x: 5.2, y: 1.25, w: 4.3, h: 0.4, fontSize: 16, bold: true, color: C.text2, margin: 0, isTextBox: true });
  lab.checklist.forEach((t, i) => {
    const y = 1.85 + i * 0.75;
    s.addShape(pres.shapes.RECTANGLE, { x: 5.2, y: y + 0.05, w: 0.3, h: 0.3, fill: { color: C.background1 }, line: { color: C.accent6, width: 1.5 }, objectName: `check-${i + 1}` });
    s.addText(t, { x: 5.7, y: y - 0.02, w: 3.8, h: 0.5, fontSize: 15, color: C.text1, valign: "middle", margin: 0, isTextBox: true });
  });
  s.addNotes(`Exercises: ${lab.exercises.join("; ")}. The instructor checks: ${lab.checklist.join("; ")}.`);

  // ---------------------------------------------------------------- 10b. assignment
  s = content("Assignment task", "Verify");
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y: 1.25, w: 5.4, h: 3.65, rectRadius: 0.1, fill: { color: C.background2 }, line: { color: C.background2 }, objectName: "assignment-card" });
  s.addText(X.assign.title, { x: M + 0.3, y: 1.4, w: 4.8, h: 0.45, fontSize: 20, bold: true, color: C.text2, margin: 0, isTextBox: true });
  s.addText(X.assign.brief, { x: M + 0.3, y: 1.9, w: 4.8, h: 0.6, fontSize: 15, italic: true, color: C.accent3, valign: "top", margin: 0, isTextBox: true });
  s.addText("Requirements", { x: M + 0.3, y: 2.55, w: 4.8, h: 0.3, fontSize: 13, bold: true, color: C.accent2, margin: 0, isTextBox: true });
  s.addText(X.assign.reqs.map((t, i) => ({ text: t, options: { bullet: true, breakLine: i < X.assign.reqs.length - 1 } })),
    { x: M + 0.3, y: 2.9, w: 4.8, h: 1.9, fontSize: 14, color: C.text1, valign: "top", paraSpaceAfter: 6, margin: 0, isTextBox: true });
  s.addText("Acceptance criteria", { x: 6.25, y: 1.25, w: 3.25, h: 0.4, fontSize: 16, bold: true, color: C.text2, margin: 0, isTextBox: true });
  X.assign.accept.forEach((t, i) => {
    const y = 1.85 + i * 0.95;
    s.addShape(pres.shapes.RECTANGLE, { x: 6.25, y: y + 0.05, w: 0.3, h: 0.3, fill: { color: C.background1 }, line: { color: C.accent6, width: 1.5 }, objectName: `accept-${i + 1}` });
    s.addText(t, { x: 6.7, y: y - 0.02, w: 2.8, h: 0.8, fontSize: 15, color: C.text1, valign: "top", margin: 0, isTextBox: true });
  });
  s.addNotes(`Assignment: ${X.assign.title}. ${X.assign.brief} Requirements: ${X.assign.reqs.join("; ")}. Acceptance: ${X.assign.accept.join("; ")}. Full brief, deliverables and pass marks are in the lab guide, part 12.`);

  // ---------------------------------------------------------------- 10c. modification tasks
  s = content("Modification tasks", "Verify");
  X.mods.forEach(([t, d], i) => {
    const x = M + i * 3.075;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 1.3, w: 2.85, h: 3.4, rectRadius: 0.1, fill: { color: C.background1 }, line: { color: C.accent4, width: 1.25 }, objectName: `mod-${i + 1}` });
    numCircle(s, i + 1, x + 0.25, 1.55, 0.5, C.accent1);
    s.addText(t, { x: x + 0.25, y: 2.25, w: 2.35, h: 0.8, fontSize: 16, bold: true, color: C.text2, valign: "top", margin: 0, isTextBox: true });
    s.addText(d, { x: x + 0.25, y: 3.1, w: 2.35, h: 1.45, fontSize: 14, color: C.text1, valign: "top", margin: 0, isTextBox: true });
  });
  s.addText("Each task changes the lab's own files; the guide (part 13) gives the file, expected result and a hint.", { x: M, y: 4.8, w: 9, h: 0.35, fontSize: 12, italic: true, color: C.accent3, margin: 0, isTextBox: true });
  s.addNotes(`Modification tasks: ${X.mods.map(([t, d], i) => `${i + 1}. ${t}: ${d}`).join(". ")}.`);

  // ---------------------------------------------------------------- 10d. build prompt
  s = content("Build it with an AI assistant", "Verify");
  const newMods = Object.keys(MODULES_FROM).filter((m) => MODULES_FROM[m] === lab.n);
  const alsoGrows = { 7: ["rag.py (grows)"], 8: ["prompts.py (grows)"] }[lab.n] || [];
  const files = [...newMods.map((m) => `${m}.py`), ...(GROWS[lab.n] ? [`${GROWS[lab.n][0]}.py (grows)`] : []), ...alsoGrows, "lab.py"];
  const outline = [
    "You are a senior Python engineer building",
    `Lab ${lab.n} of BankAssist 360 ...`,
    "",
    lab.n === 1 ? "STARTING POINT: new project" : `STARTING POINT: copy ${SLUGS[lab.n - 1]}`,
    "PROJECT STRUCTURE: exact tree, new files marked",
    "DEPENDENCIES · CODING STANDARDS",
    `FILES TO WRITE: ${files.join(", ")}`,
    "IMPLEMENTATION RULES · STEPS · DATA · TESTS",
    "ACCEPTANCE CHECKS: ruff, pytest offline, --help",
    "",
    `${SLUGS[lab.n]}/   (new or growing)`,
    ...files.map((f) => `  src/bankassist/${f}`),
  ];
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y: 1.25, w: 5.4, h: 3.65, rectRadius: 0.08, fill: { color: C.text2 }, line: { color: C.text2 }, objectName: "prompt-outline" });
  s.addText("docs/BUILD_PROMPT.md", { x: M + 0.2, y: 1.35, w: 5.0, h: 0.32, fontSize: 11, bold: true, color: C.accent1, margin: 0, isTextBox: true });
  s.addText(outline.join("\n"), { x: M + 0.2, y: 1.72, w: 5.05, h: 3.1, fontSize: 10.5, fontFace: "Courier New", color: C.background1, valign: "top", fit: "shrink", margin: 0, isTextBox: true });
  s.addText("How to use it", { x: 6.25, y: 1.25, w: 3.25, h: 0.4, fontSize: 16, bold: true, color: C.text2, margin: 0, isTextBox: true });
  ["Paste the prompt into Gemini, Claude or Copilot Chat", "Create the files exactly as returned", "Run make install && make test", "Compare with the reference project"].forEach((t, i) => {
    const y = 1.8 + i * 0.78;
    numCircle(s, i + 1, 6.25, y, 0.38, C.accent2);
    s.addText(t, { x: 6.75, y: y - 0.04, w: 2.75, h: 0.65, fontSize: 14, color: C.text1, valign: "top", margin: 0, isTextBox: true });
  });
  s.addNotes(`The build prompt for ${SLUGS[lab.n]} is in the project's docs/BUILD_PROMPT.md and in part 14 of the lab guide. It is generated from the reference code, so the structure and signatures match exactly. Files to write: ${files.join(", ")}. Learners must still review every generated file against the code explanations.`);

  // ---------------------------------------------------------------- 11. next
  pres.addSection({ title: "Next" });
  s = pres.addSlide({ masterName: "DARK", sectionTitle: "Next" });
  s.addText(next ? "NEXT LAB" : "CAPSTONE", { placeholder: "kicker" });
  s.addText(next ? `Lab ${next.n}: ${next.title}` : "BankAssist 360 as an API", { placeholder: "title" });
  s.addText(next ? `${next.sessions} · project ${SLUGS[next.n]}` : "uvicorn bankassist.api:api --reload · /chat and /approve · make gate in CI", { placeholder: "body" });
  s.addNotes(next ? `Preview Lab ${next.n}: ${next.lead}` : "Teams join all labs into one service and present a 5-minute demo with a 1-page design note.");

  return pres;
}

(async () => {
  for (let i = 0; i < LABS.length; i++) {
    const lab = LABS[i];
    const file = path.join(OUT_DIR, `Lab${String(lab.n).padStart(2, "0")}_${lab.title.replace(/[^A-Za-z0-9]+/g, "_").replace(/_+$/, "")}.pptx`);
    await buildDeck(lab, LABS[i + 1]).writeFile({ fileName: file });
    await applyTheme(file, THEME);
    console.log("wrote", path.basename(file));
  }
})().catch((e) => { console.error(e); process.exit(1); });

"""Lab 2: Conversational memory and context handling.

Session: S030 Memory and Context Handling.
Run:     python -m bankassist.lab [--step N]
"""

from __future__ import annotations

from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langgraph.store.memory import InMemoryStore

from bankassist.cli import run_steps
from bankassist.config import get_llm
from bankassist.memory import SYSTEM_TEXT, TOKEN_BUDGET, build_memory_graph, trimmer


def step1_stateless() -> None:
    """Prove the model is stateless."""
    llm = get_llm()
    llm.invoke("My name is Priya.")
    print(llm.invoke("What is my name?").content)


def step2_placeholder() -> None:
    """Pass history with MessagesPlaceholder."""
    prompt = ChatPromptTemplate.from_messages([("system", SYSTEM_TEXT), MessagesPlaceholder("history"),
                                               ("human", "{question}")])
    history = [HumanMessage("My name is Priya."), AIMessage("Hello Priya!")]
    print((prompt | get_llm()).invoke({"history": history, "question": "What is my name?"}).content)


def step3_sessions() -> None:
    """Isolate sessions with RunnableWithMessageHistory."""
    sessions: dict[str, InMemoryChatMessageHistory] = {}

    def get_history(session_id: str) -> InMemoryChatMessageHistory:
        return sessions.setdefault(session_id, InMemoryChatMessageHistory())

    prompt = ChatPromptTemplate.from_messages([("system", SYSTEM_TEXT), MessagesPlaceholder("history"),
                                               ("human", "{question}")])
    chat = RunnableWithMessageHistory(prompt | get_llm(), get_history,
                                      input_messages_key="question", history_messages_key="history")
    chat.invoke({"question": "Hi, I'm Priya"}, config={"configurable": {"session_id": "C1001-s1"}})
    same = chat.invoke({"question": "What is my name?"}, config={"configurable": {"session_id": "C1001-s1"}})
    other = chat.invoke({"question": "What is my name?"}, config={"configurable": {"session_id": "C1002-s1"}})
    print("Same session :", same.content)
    print("Other session:", other.content)


def step4_trim() -> None:
    """Trim a long history to the token budget."""
    long_history = [SystemMessage(SYSTEM_TEXT)]
    for i in range(40):
        long_history += [HumanMessage(f"Question {i} about fixed deposits " * 5), AIMessage(f"Answer {i} " * 10)]
    trimmed = trimmer.invoke(long_history)
    print(f"{len(long_history)} messages -> {len(trimmed)} after trimming to ~{TOKEN_BUDGET} tokens")


def step5_6_graph_memory() -> None:
    """Thread memory with a checkpointer + long-term profile store + summarisation."""
    store = InMemoryStore()
    store.put(("C1001", "profile"), "prefs", {"language": "English", "senior_citizen": False})
    graph = build_memory_graph(store=store)
    cfg = {"configurable": {"thread_id": "C1001-s1", "customer_id": "C1001"}}
    for q in ["Hi, I'm Priya", "What is the FD rate?", "And for senior citizens?"]:
        out = graph.invoke({"messages": [{"role": "user", "content": q}]}, cfg)
        print(f"> {q}\n{out['messages'][-1].content}\n")
    for i in range(6):  # push past the summary trigger
        graph.invoke({"messages": [{"role": "user", "content": f"Tell me one more banking fact ({i})"}]}, cfg)
    state = graph.get_state(cfg).values
    print(f"After 9 turns: {len(state['messages'])} messages kept, summary = {state.get('summary', '')[:150]}...")


AI_TOOLS = (  # what each does: README.md, 'AI tools used'
    "Gemini 3.8 Flash",
    "LangChain message history",
    "LangGraph checkpointer + store",
    "LangSmith tracing",
)


def main() -> None:
    run_steps("Lab 2: Memory and context", {
        1: step1_stateless, 2: step2_placeholder, 3: step3_sessions, 4: step4_trim, 5: step5_6_graph_memory,
    }, tools=AI_TOOLS)


if __name__ == "__main__":
    main()

"""Lab 7: Hybrid search, multi-query retrieval and re-ranking.

Sessions: S040 Challenges in RAG Implementation, S041 Hybrid Search and Multi-Query RAG.
Run:      python -m bankassist.lab [--step N]
"""

from __future__ import annotations

from bankassist.cli import run_steps
from bankassist.rag import build_advanced_rag
from bankassist.retrievers import AdvancedRetriever, build_chunks, hit_rate, load_eval


def current_public_chunks():
    return [c for c in build_chunks() if c.metadata["is_current"] and c.metadata["audience"] == "public"]


def step1_failure_log() -> None:
    """Run the hard set through vector-only search and list the misses."""
    retriever = AdvancedRetriever(current_public_chunks(), use_multi_query=False, use_rerank=False)
    for row in load_eval("hard_set.jsonl"):
        docs = retriever.vector.invoke(row["question"])[:5]
        if not any(row["gold_text"].lower() in d.page_content.lower() for d in docs):
            print(f"MISS: {row['question']!r} (expected text: {row['gold_text']!r})")
    print("Label each miss with a failure mode from the table in the lab guide.")


def step5_compare_configs() -> None:
    """Measure hit@5 for five retriever configurations on the hard set."""
    chunks = current_public_chunks()
    rows = load_eval("hard_set.jsonl")
    full = AdvancedRetriever(chunks)
    no_rerank = AdvancedRetriever(chunks, use_rerank=False)
    configs = {
        "vector": full.vector.invoke,
        "bm25": full.bm25.invoke,
        "hybrid": full.hybrid_search,
        "hybrid+mq": no_rerank.retrieve,
        "hybrid+mq+rerank": full.retrieve,
    }
    for name, fn in configs.items():
        print(f"{name:18} hit@5 = {hit_rate(fn, rows, k=5):.0%}")


def step6_rag_v2() -> None:
    """Answer a mixed code-and-paraphrase question with the advanced pipeline."""
    out = build_advanced_rag().invoke("Why was I charged CHG-ATM-07 and how many free ATM withdrawals do I get?")
    print(out["answer"])
    print("sources:", [d.metadata["chunk_id"] for d in out["docs"]])


AI_TOOLS = (  # what each does: README.md, 'AI tools used'
    "Gemini 3.8 Flash",
    "Gemini 3.5 Flash-Lite",
    "Gemini Embedding 2",
    "BM25 + FAISS",
    "Cross-encoder (MiniLM)",
    "LangSmith",
)


def main() -> None:
    run_steps("Lab 7: Hybrid search and re-ranking", {1: step1_failure_log, 5: step5_compare_configs,
                                                      6: step6_rag_v2}, tools=AI_TOOLS)


if __name__ == "__main__":
    main()

"""Lab 8: Domain-specific and multimodal RAG.

Sessions: S037 RAG for Domain-Specific Applications, S042 Multi-modal RAG.
Run:      python -m bankassist.lab [--step N]
"""

from __future__ import annotations

from pathlib import Path

from bankassist.cli import run_steps
from bankassist.config import PDF_DIR, PROJECT_ROOT
from bankassist.multimodal import extract_pdf, multimodal_answer, retriever_for
from bankassist.retrievers import expand_query


def step1_glossary() -> None:
    """Expand banking acronyms."""
    for q in ["What is the MAB for Classic?", "Max LTV for 50 lakh?", "Senior citizen FD rate"]:
        print(f"{q!r} -> {expand_query(q)!r}")


def step2_filters() -> None:
    """Show that superseded and staff-only content never reaches a customer."""
    for role in ["customer", "staff"]:
        docs = retriever_for(role).invoke("internal steps to hotlist a card and home loan processing fee")
        print(role, "->", sorted({d.metadata["doc_id"] for d in docs}))


def step4_extract() -> None:
    """Extract text, tables and images from the rate card PDF."""
    for item in extract_pdf(PDF_DIR / "loan_rate_card.pdf"):
        if item["type"] == "image":
            preview = Path(item["path"]).relative_to(PROJECT_ROOT).as_posix()  # indexes/images/...png
        else:
            preview = item["content"][:80].replace("\n", " ")
        print(item["type"], item["page"], preview)


def step6_answers() -> None:
    """Answer table, chart and role-restricted questions."""
    for q, role in [("What is the MAB for Classic?", "customer"),
                    ("Which loan slab has the lowest processing fee?", "customer"),
                    ("Which tenure has the highest rate in the chart?", "customer"),
                    ("What are the internal steps to hotlist a card?", "customer"),
                    ("What are the internal steps to hotlist a card?", "staff")]:
        print(f"> [{role}] {q}\n{multimodal_answer(q, role)}\n")


AI_TOOLS = (  # what each does: README.md, 'AI tools used'
    "Gemini 3.8 Flash (vision)",
    "Gemini Embedding 2",
    "Chroma metadata filters",
    "PyMuPDF + pdfplumber",
    "LangSmith",
)


def main() -> None:
    run_steps("Lab 8: Domain-specific and multimodal RAG", {1: step1_glossary, 2: step2_filters,
                                                             4: step4_extract, 6: step6_answers}, tools=AI_TOOLS)


if __name__ == "__main__":
    main()

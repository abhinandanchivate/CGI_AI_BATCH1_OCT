"""Lab 9: Agentic RAG with real-time retrieval.

Sessions: S043 Agentic RAG, S039 Real-Time Information Retrieval Using RAG.
Run:      python -m bankassist.lab [--step N]
"""

from __future__ import annotations

from langchain.agents import create_agent
from langchain_core.tools import tool

from bankassist.agentic_rag import build_agentic_rag, make_web_search
from bankassist.cli import run_steps
from bankassist.config import get_llm
from bankassist.retrievers import format_docs, get_advanced_retriever


def step1_agentic_lite() -> None:
    """Agentic RAG lite: the retriever and web search as agent tools."""
    retriever, web = get_advanced_retriever(), make_web_search()

    @tool
    def search_bank_policies(query: str) -> str:
        """Search Apex National Bank's policy documents (fees, accounts, loans, cards, KYC)."""
        return format_docs(retriever.invoke(query))

    @tool
    def search_trusted_web(query: str) -> str:
        """Search RBI and government sites for live public data such as the current repo rate."""
        return format_docs(web(query)) or "No results."

    agent = create_agent(get_llm(), tools=[search_bank_policies, search_trusted_web], system_prompt=(
        "You are BankAssist. Use search_bank_policies for this bank's products. Use search_trusted_web "
        "only for live public data. Cite [doc_id] or the URL. If nothing relevant is found, say so."))
    out = agent.invoke({"messages": [{"role": "user", "content": "What is the current RBI repo rate?"}]})
    print(out["messages"][-1].content)


def step5_graph() -> None:
    """Run the five test questions through the corrective RAG graph."""
    graph = build_agentic_rag()
    for q in ["Prepayment charges on a floating home loan?", "What is the current RBI repo rate?",
              "bounce fee?", "What is the bank's yacht loan rate?", "Thanks!"]:
        out = graph.invoke({"question": q})
        print(f"> {q}\n  route={out['route']} rewrites={out.get('rewrites', 0)} "
              f"grounded={out.get('grounded')}\n  {out['answer'][:300]}\n")


AI_TOOLS = (  # what each does: README.md, 'AI tools used'
    "LangGraph corrective RAG",
    "Gemini 3.8 Flash",
    "Gemini 3.5 Flash-Lite",
    "Tavily search",
    "Cross-encoder",
    "LangSmith",
)


def main() -> None:
    run_steps("Lab 9: Agentic RAG", {1: step1_agentic_lite, 5: step5_graph}, tools=AI_TOOLS)


if __name__ == "__main__":
    main()

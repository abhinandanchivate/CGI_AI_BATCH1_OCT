"""Lab 10: RAG evaluation, optimisation and release gate.

Sessions: S044 RAG Evaluation, S038 Optimizing RAG at Scale, S045 Guidelines and Best Practices.
Run:      python -m bankassist.lab [--step N]
Gate:     python -m scripts.release_gate
API:      uvicorn bankassist.api:api --reload   (capstone)
"""

from __future__ import annotations

from bankassist.cli import run_steps
from bankassist.evaluation import enable_optimisations, ensure_dataset, make_targets, run_experiment, summarise


def step1_dataset() -> None:
    """Create the LangSmith dataset."""
    print("Dataset ready:", ensure_dataset())


def step5_compare() -> None:
    """Run all three RAG versions as experiments and print the comparison table."""
    rows = {name: summarise(run_experiment(name, fn)) for name, fn in make_targets().items()}
    metrics = ["retrieval_precision", "retrieval_recall", "faithfulness", "correctness"]
    print(f"{'version':16}" + "".join(f"{m:>22}" for m in metrics))
    for name, scores in rows.items():
        print(f"{name:16}" + "".join(f"{scores.get(m, float('nan')):>22.2f}" for m in metrics))


def step6_optimised() -> None:
    """Re-run the agentic version with caching and model tiering."""
    enable_optimisations()
    scores = summarise(run_experiment("lab9-optimised", make_targets()["lab9-agentic"]))
    print(scores)


def step8_feedback() -> None:
    """Capture a run ID and attach user feedback to it."""
    from langchain_core.tracers.context import collect_runs
    from langsmith import Client

    from bankassist.agentic_rag import build_agentic_rag

    with collect_runs() as cb:
        build_agentic_rag().invoke({"question": "What is the cheque return charge?"})
        run_id = cb.traced_runs[0].id
    Client().create_feedback(run_id, key="user_score", score=0, comment="Example thumbs-down from the app")
    print("Feedback attached to run", run_id)


AI_TOOLS = (  # what each does: README.md, 'AI tools used'
    "LangSmith datasets + evaluators",
    "Gemini 4 Argon (judge)",
    "Gemini 3.8 Flash + Flash-Lite",
    "LLM cache (SQLite)",
    "FastAPI + LangGraph",
)


def main() -> None:
    run_steps("Lab 10: Evaluation and release gate", {1: step1_dataset, 5: step5_compare,
                                                      6: step6_optimised, 8: step8_feedback}, tools=AI_TOOLS)


if __name__ == "__main__":
    main()

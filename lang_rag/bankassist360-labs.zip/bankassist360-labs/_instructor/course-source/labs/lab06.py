"""Lab 6: Chunking strategies and semantic versus exact matching.

Sessions: S035 Chunking Strategies, S036 Semantic Search vs. Exact Matching.
Run:      python -m bankassist.lab [--step N]
"""

from __future__ import annotations

from langchain_core.documents import Document
from langchain_text_splitters import CharacterTextSplitter, RecursiveCharacterTextSplitter
from langsmith import traceable

from bankassist.cli import run_steps
from bankassist.config import get_embeddings
from bankassist.retrievers import exact_code_lookup, hit_rate, load_eval, load_policies, split_markdown


@traceable(name="chunk_eval")
def evaluate_chunks(name: str, chunks: list[Document], k: int = 4, embeddings=None) -> dict:
    """Build a temporary FAISS index for one strategy and score it."""
    from langchain_community.vectorstores import FAISS

    store = FAISS.from_documents(chunks, embeddings or get_embeddings())
    score = hit_rate(lambda q: store.similarity_search(q, k=k), load_eval("chunk_eval.jsonl"), k)
    avg = sum(len(c.page_content) for c in chunks) / len(chunks)
    result = {"strategy": name, "chunks": len(chunks), "avg_chars": round(avg), f"hit@{k}": round(score, 2)}
    print(f"{name:28} chunks={len(chunks):4} avg_chars={avg:6.0f} hit@{k}={score:.0%}")
    return result


def strategies(docs: list[Document]) -> dict[str, list[Document]]:
    """The five strategies compared in this lab."""
    from langchain_experimental.text_splitter import SemanticChunker

    return {
        "fixed-500": CharacterTextSplitter(separator="", chunk_size=500, chunk_overlap=0).split_documents(docs),
        "recursive-800": RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=100).split_documents(docs),
        "recursive-400": RecursiveCharacterTextSplitter(chunk_size=400, chunk_overlap=50).split_documents(docs),
        "markdown-header+recursive": split_markdown(docs),
        "semantic": SemanticChunker(get_embeddings(), breakpoint_threshold_type="percentile").split_documents(docs),
    }


def step1_5_compare_chunkers() -> None:
    """Score five chunking strategies on the same labelled questions."""
    docs = [d for d in load_policies() if d.metadata["is_current"]]
    results = [evaluate_chunks(name, chunks) for name, chunks in strategies(docs).items()]
    best = max(results, key=lambda r: r["hit@4"])
    print(f"\nWinner: {best['strategy']} -> record it in your lab notes.")
    print("build_chunks() in src/bankassist/retrievers.py defaults to markdown-header chunking.")


def step6_bm25_vs_vector() -> None:
    """Compare BM25 (exact tokens) with vector search (meaning)."""
    from langchain_community.retrievers import BM25Retriever
    from langchain_community.vectorstores import FAISS

    chunks = split_markdown([d for d in load_policies() if d.metadata["is_current"]])
    bm25 = BM25Retriever.from_documents(chunks, k=4)
    vec = FAISS.from_documents(chunks, get_embeddings()).as_retriever(search_kwargs={"k": 4})
    queries = {"paraphrase": ["what do I pay if my cheque bounces", "fee for using another bank's ATM too often"],
               "exact": ["CHG-ATM-07", "CHG-CHQ-11", "Form 60"]}
    for qtype, qs in queries.items():
        for q in qs:
            b = bm25.invoke(q)[0].page_content[:70].replace("\n", " ")
            v = vec.invoke(q)[0].page_content[:70].replace("\n", " ")
            print(f"[{qtype}] {q}\n  BM25  : {b}\n  Vector: {v}\n")


def step7_exact_lookup() -> None:
    """Direct exact-code lookup, no ranking needed."""
    chunks = split_markdown(load_policies())
    for q in ["what is chg-atm-07?", "CHG-STP-03 charge", "explain CHG-MAB-01"]:
        print(q, "->", sorted({c.metadata["source_ref"] for c in exact_code_lookup(q, chunks)}))


AI_TOOLS = (  # what each does: README.md, 'AI tools used'
    "Gemini Embedding 2",
    "LangChain text splitters",
    "SemanticChunker",
    "FAISS",
    "BM25",
    "LangSmith",
)


def main() -> None:
    run_steps("Lab 6: Chunking and matching", {1: step1_5_compare_chunkers, 6: step6_bm25_vs_vector,
                                               7: step7_exact_lookup}, tools=AI_TOOLS)


if __name__ == "__main__":
    main()

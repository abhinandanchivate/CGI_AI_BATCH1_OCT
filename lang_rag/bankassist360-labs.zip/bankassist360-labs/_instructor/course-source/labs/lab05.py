"""Lab 5: Policy Q&A with RAG, FAISS and Chroma.

Sessions: S033 Introduction to RAG, S034 Vector Databases for RAG (FAISS, Chroma).
Run:      python -m bankassist.lab [--step N]
"""

from __future__ import annotations

from bankassist.cli import run_steps
from bankassist.config import get_llm
from bankassist.rag import baseline_chunks, build_basic_rag
from bankassist.retrievers import build_chroma, build_faiss, load_faiss, load_policies

TEST_QUESTIONS = [
    "What is the minimum balance for Classic Savings in a metro branch?",
    "What is the savings interest rate above 5 lakh?",
    "Which documents are accepted for KYC?",
    "Are there prepayment charges on a floating home loan?",
    "What is the bank's car loan rate?",  # out of scope: must refuse
]


def step1_without_rag() -> None:
    """Show the problem: the model does not know this bank's policy."""
    print(get_llm().invoke("What is the minimum balance for an Apex National Bank Classic Savings account?").content)


def step2_3_load_split() -> None:
    """Load documents with metadata and split them into chunks."""
    docs = load_policies()
    print(f"{len(docs)} documents; first metadata: {docs[0].metadata}")
    chunks = baseline_chunks()
    print(f"{len(chunks)} chunks; example id: {chunks[0].metadata['chunk_id']}")


def step4_faiss() -> None:
    """Embed into FAISS, save, reload and search."""
    build_faiss(baseline_chunks())
    store = load_faiss()
    for doc, score in store.similarity_search_with_score("minimum balance classic savings metro", k=3):
        print(f"{score:.3f} {doc.metadata['chunk_id']}: {doc.page_content[:70]!r}")


def step5_chroma() -> None:
    """Index the same chunks in Chroma and use a metadata filter."""
    store = build_chroma(baseline_chunks())
    print(f"Chroma collection holds {store._collection.count()} chunks (rerun: the count must not change)")
    for h in store.similarity_search("prepayment charges", k=3, filter={"category": "home"}):
        print(h.metadata["chunk_id"], h.page_content[:70].replace("\n", " "))


def step6_rag_chain() -> None:
    """Answer the test questions with citations (and refuse the out-of-scope one)."""
    chain = build_basic_rag()
    for q in TEST_QUESTIONS:
        out = chain.invoke(q)
        print(f"> {q}\n{out['answer']}\n  sources: {[d.metadata['chunk_id'] for d in out['docs']]}\n")


AI_TOOLS = (  # what each does: README.md, 'AI tools used'
    "Gemini 3.8 Flash",
    "Gemini Embedding 2",
    "FAISS",
    "Chroma",
    "LangChain RAG chain",
    "LangSmith",
)


def main() -> None:
    run_steps("Lab 5: RAG with FAISS and Chroma", {
        1: step1_without_rag, 2: step2_3_load_split, 4: step4_faiss, 5: step5_chroma, 6: step6_rag_chain,
    }, tools=AI_TOOLS)


if __name__ == "__main__":
    main()


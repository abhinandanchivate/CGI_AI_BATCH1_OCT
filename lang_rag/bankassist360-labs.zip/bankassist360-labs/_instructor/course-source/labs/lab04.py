"""Lab 4: Smart banking helpdesk with LangGraph (controlled workflow: routing + human approval).

Session: S032 Hands-on Workflow Creation.
Run:     python -m bankassist.lab [--step N]
"""

from __future__ import annotations

import json

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

from bankassist.chains import INTENTS, build_triage_chain
from bankassist.cli import run_steps
from bankassist.config import EVAL_DIR
from bankassist.data_access import get_customer
from bankassist.workflow import build_workflow_builder


def step4_draw() -> None:
    """Compile the graph and print its Mermaid diagram."""
    app = build_workflow_builder().compile(checkpointer=InMemorySaver())
    print(app.get_graph().draw_mermaid())


def step5_approval() -> None:
    """Run, pause at the interrupt, inspect state, then resume with approve."""
    app = build_workflow_builder().compile(checkpointer=InMemorySaver())
    cfg = {"configurable": {"thread_id": "C1001-s4", "customer_id": "C1001"}}
    result = app.invoke({"messages": [{"role": "user",
                                       "content": "Please block my debit card ending 4321, I lost it"}]}, cfg)
    print("Interrupt payload:", result["__interrupt__"][0].value)
    print("Waiting at:", app.get_state(cfg).next)
    final = app.invoke(Command(resume="approve"), {**cfg, "metadata": {"approved_by": "reviewer.rahul"}})
    print(final["messages"][-1].content)
    print("Card status now:", get_customer("C1001")["cards"][0]["status"])


def step6_routing_accuracy() -> None:
    """Measure routing accuracy on the labelled routing set."""
    rows = [json.loads(line) for line in (EVAL_DIR / "routing_set.jsonl").read_text().splitlines() if line]
    tickets = build_triage_chain().batch([{"intents": INTENTS, "message": r["message"]} for r in rows],
                                         config={"max_concurrency": 5})
    misses = [(r["message"], r["intent"], t.intent) for r, t in zip(rows, tickets, strict=True)
              if t.intent != r["intent"]]
    print(f"Routing accuracy: {1 - len(misses) / len(rows):.0%}")
    for msg, want, got in misses:
        print(f"  MISS expected={want} got={got}: {msg}")


AI_TOOLS = (  # what each does: README.md, 'AI tools used'
    "Gemini 3.8 Flash",
    "LangGraph StateGraph",
    "LangGraph interrupt (human-in-the-loop)",
    "LangSmith tracing",
)


def main() -> None:
    run_steps("Lab 4: Smart banking helpdesk with LangGraph",
              {4: step4_draw, 5: step5_approval, 6: step6_routing_accuracy}, tools=AI_TOOLS)


if __name__ == "__main__":
    main()

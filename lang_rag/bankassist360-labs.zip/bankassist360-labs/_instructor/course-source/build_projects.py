"""Assemble the 10 standalone BankAssist 360 lab projects from one shared source.

Each lab project is a snapshot: every module built up to that lab, the lab's own
steps (``bankassist.lab``), only the data, tests and dependencies it needs, and
standard project tooling (pyproject, Makefile, CI, pre-commit, README).

Modules may contain ``# region labN`` / ``# endregion labN`` blocks: the block is kept
only in projects for lab N and later. This is how ``retrievers.py`` grows from Lab 5 to 8
while the code stays in one place.

Usage:
    python build_projects.py <output_dir>
"""

from __future__ import annotations

import ast
import json
import re
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path

from ai_tools import MODEL_IDS, TOOLS
from ai_tools import names as tool_names
from prompt_notes import NOTES
from run_notes import KEYS_OPTIONAL, KEYS_REQUIRED, RUN, TESTS, TROUBLESHOOTING

SRC = Path(__file__).resolve().parent
SLIDES_CONTENT = SRC / "slides"  # deck text, reused for README content
RUFF_VERSION = "0.17.3"

BASE_DEPS = ["langchain>=1.0,<2", "langchain-core>=1.0,<2", "langchain-google-genai>=4.4",
             "langsmith>=0.4", "pydantic>=2.6", "python-dotenv>=1.0"]
DEPS_FROM = {
    2: ["langgraph>=1.0,<2"],
    3: ["pandas>=2.0"],
    5: ["langchain-community>=0.4", "langchain-chroma>=1.0", "langchain-text-splitters>=1.0",
        "faiss-cpu>=1.8", "chromadb>=0.5"],
    6: ["rank_bm25>=0.2", "langchain-experimental>=0.4"],
    7: ["sentence-transformers>=3.0"],
    8: ["pymupdf>=1.24", "pdfplumber>=0.11", "reportlab>=4.0", "matplotlib>=3.8"],
    9: ["langchain-tavily>=0.2"],
    10: ["fastapi>=0.110", "uvicorn>=0.29", "langgraph-checkpoint-sqlite>=2.0"],
}
MODULES_FROM = {  # module -> first lab that has it
    "__init__": 1, "config": 1, "cli": 1, "chains": 1, "memory": 2, "data_access": 3, "tools": 3,
    "agent": 3, "workflow": 4, "guardrails": 5, "prompts": 5, "retrievers": 5, "rag": 5,
    "multimodal": 8, "agentic_rag": 9, "evaluation": 10, "api": 10,
}
MODULE_ROLE = {
    "__init__": "package marker and version", "config": "settings, paths, logging, Gemini model factories",
    "cli": "--step runner", "chains": "triage chain and Ticket schema",
    "memory": "trimming, summaries, checkpointer, store",
    "data_access": "synthetic core-banking data", "tools": "banking tools (identity from config)",
    "agent": "create_agent banking agent", "workflow": "LangGraph routing + human approval",
    "guardrails": "PII masking, injection guard", "prompts": "RAG and domain prompts",
    "retrievers": "loading, chunking, vector stores, matching, hybrid, glossary",
    "rag": "RAG chains returning answer + evidence", "multimodal": "PDF tables/images, filtered retrieval",
    "agentic_rag": "corrective RAG graph with live search", "evaluation": "dataset, evaluators, experiments, gate",
    "api": "capstone FastAPI service",
}
TESTS_FROM = {
    "conftest": 1, "test_config": 1, "test_chains": 1, "test_memory": 2, "test_tools": 3, "test_workflow": 4,
    "test_guardrails": 5, "test_loaders": 5, "test_matching": 6, "test_hybrid": 7, "test_glossary": 8,
    "test_multimodal": 8, "test_agentic_rag": 9, "test_evaluation": 10,
}
DATA_FROM = {
    "eval/routing_set.jsonl": 1, "customers.json": 3, "transactions.csv": 3, "policies": 5,
    "eval/chunk_eval.jsonl": 6, "eval/hard_set.jsonl": 7, "pdfs": 8, "eval/golden_set.jsonl": 10,
}
SCRIPTS_FROM = {"generate_sample_data": 3, "generate_pdfs": 8, "release_gate": 10}
SLUGS = {1: "lab01-query-triage", 2: "lab02-conversational-memory", 3: "lab03-banking-agent",
         4: "lab04-langgraph-workflow", 5: "lab05-policy-rag", 6: "lab06-chunking-matching",
         7: "lab07-hybrid-rerank", 8: "lab08-domain-multimodal", 9: "lab09-agentic-rag",
         10: "lab10-evaluation-release"}

REGION = re.compile(r"^# region lab(\d+)\n(.*?)^# endregion lab\1\n", re.MULTILINE | re.DOTALL)


def node_json(module: str):
    out = subprocess.run(["node", "-e", f"console.log(JSON.stringify(require('{SLIDES_CONTENT / module}')))"],
                         capture_output=True, text=True, check=True)
    return json.loads(out.stdout)


def strip_regions(text: str, lab: int) -> str:
    return REGION.sub(lambda m: m.group(2) if int(m.group(1)) <= lab else "", text)


def env_example(lab: int) -> str:
    lines = ["# Copy to .env and fill in. Never commit .env.",
             "# Google AI Studio key: https://aistudio.google.com/apikey", "GOOGLE_API_KEY=...", "",
             "# Gemini model IDs checked 3 Nov 2026: https://ai.google.dev/gemini-api/docs/changelog",
             "LLM_MODEL=google_genai:gemini-3.8-flash"]
    if lab >= 7:
        lines.append("FAST_LLM_MODEL=google_genai:gemini-3.5-flash-lite")
    if lab >= 10:
        lines.append("JUDGE_MODEL=google_genai:gemini-4-argon")
    if lab >= 5:
        lines += ["EMBED_PROVIDER=google_genai", "EMBED_MODEL=gemini-embedding-2"]
    lines += ["# Gemini 3+ deprecates temperature; set reasoning depth instead", "THINKING_LEVEL=low",
              "LOG_LEVEL=INFO", "", "# LangSmith tracing (on from Lab 1)", "LANGSMITH_TRACING=true",
              "LANGSMITH_API_KEY=lsv2_...", "LANGSMITH_PROJECT=bankassist360",
              "LANGSMITH_ENDPOINT=https://api.smith.langchain.com"]
    if lab >= 9:
        lines += ["", "# Live search for the 'live' route (optional)", "TAVILY_API_KEY=tvly-..."]
    return "\n".join(lines) + "\n"


def pyproject(lab: int, title: str, deps: list[str]) -> str:
    dep_lines = "\n".join(f'    "{d}",' for d in deps)
    return f'''[build-system]
requires = ["setuptools>=69"]
build-backend = "setuptools.build_meta"

[project]
name = "bankassist-lab{lab:02d}"
version = "1.0.0"
description = "BankAssist 360, Lab {lab}: {title}"
readme = "README.md"
requires-python = ">=3.11"
dependencies = [
{dep_lines}
]

[project.optional-dependencies]
dev = ["pytest>=8.0", "ruff>={RUFF_VERSION}", "pre-commit>=3.7"]

[project.scripts]
bankassist-lab = "bankassist.lab:main"

[tool.setuptools.packages.find]
where = ["src"]

[tool.ruff]
line-length = 120
target-version = "py311"

[tool.ruff.lint]
select = ["E", "F", "W", "I", "B", "UP", "SIM", "RUF"]
ignore = ["RUF001", "RUF002", "RUF003"]

[tool.ruff.lint.isort]
known-first-party = ["bankassist"]

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src", "."]
addopts = "-q"
'''


def makefile(lab: int) -> str:
    phony = "install test lint run clean" + (" data" if lab >= 3 else "") + (" api gate" if lab >= 10 else "")
    targets = [f".PHONY: {phony}",
               "", "install:        ## editable install with dev tools", '\tpython -m pip install -e ".[dev]"',
               "\tpre-commit install || true", "",
               "test:           ## offline tests (no API keys needed)", "\tpytest", "",
               "lint:", "\truff check .", "",
               "run:            ## run every step of this lab (STEP=3 for one step)",
               "\tpython -m bankassist.lab $(if $(STEP),--step $(STEP),)", "",
               "clean:          ## delete generated indexes and caches",
               "\trm -rf indexes/* .pytest_cache .ruff_cache", "\ttouch indexes/.gitkeep"]
    if lab >= 3:
        targets += ["", "data:           ## regenerate synthetic data", "\tpython -m scripts.generate_sample_data"]
        if lab >= 8:
            targets.append("\tpython -m scripts.generate_pdfs")
    if lab >= 10:
        targets += ["", "api:            ## capstone API", "\tuvicorn bankassist.api:api --reload", "",
                    "gate:           ## release gate (needs API keys)", "\tpython -m scripts.release_gate"]
    return "\n".join(targets) + "\n"


CI = """name: ci
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.11", "3.12"]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - run: python -m pip install -e ".[dev]"
      - run: ruff check .
      - run: pytest   # offline: tests use fake keys and fake embeddings
"""

PRECOMMIT = f"""repos:
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v{RUFF_VERSION}
    hooks:
      - id: ruff
        args: [--fix]
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v5.0.0
    hooks:
      - id: end-of-file-fixer
      - id: trailing-whitespace
      - id: check-added-large-files
      - id: detect-private-key
"""

GITIGNORE = """.env
.venv/
__pycache__/
*.py[cod]
*.egg-info/
build/
dist/
.pytest_cache/
.ruff_cache/
indexes/*
!indexes/.gitkeep
*.db
"""


def tree(lab: int, modules: list[str], tests: list[str], data: list[str], scripts: list[str]) -> str:
    new = lambda first: "   <- new in this lab" if first == lab else ""  # noqa: E731
    lines = [f"{SLUGS[lab]}/", "  pyproject.toml          dependencies, ruff, pytest", "  Makefile",
             "  README.md", "  .env.example", "  .github/workflows/ci.yml", "  .pre-commit-config.yaml",
             "  src/bankassist/"]
    for m in modules:
        lines.append(f"    {m + '.py':22} {MODULE_ROLE[m]}{new(MODULES_FROM[m])}")
    lines.append(f"    {'lab.py':22} this lab's runnable steps   <- new in this lab")
    lines.append(f"    {'assignments/':22} your part 12 and 13 work")
    if scripts:
        lines.append("  scripts/")
        lines += [f"    {s}.py{new(SCRIPTS_FROM[s])}" for s in scripts]
    lines.append("  data/")
    lines += [f"    {d}{new(DATA_FROM[d])}" for d in data]
    lines.append("  tests/")
    lines += [f"    {t}.py{new(TESTS_FROM[t])}" for t in tests]
    lines += ["  indexes/                generated at run time (git-ignored)", f"  docs/Lab{lab:02d}.pptx",
              "  docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant"]
    if lab >= 10:
        lines.append("  docs/MODEL_CARD.md      capstone model card template (stretch goal)")
    return "\n".join(lines)


def lab_steps(lab_src: str) -> list[tuple[int, str]]:
    """(step number, first docstring line) for every entry in the lab's run_steps(...) dict."""
    tree_ = ast.parse(lab_src)
    docs = {f.name: (ast.get_docstring(f) or f.name).splitlines()[0].rstrip(".")
            for f in ast.walk(tree_) if isinstance(f, ast.FunctionDef)}
    for node in ast.walk(tree_):
        if isinstance(node, ast.Call) and getattr(node.func, "id", "") == "run_steps":
            mapping = node.args[1]
            return [(k.value, docs[v.id]) for k, v in zip(mapping.keys, mapping.values, strict=True)]
    raise ValueError("run_steps(...) not found")


def readme(lab: int, info: dict, extra: dict, steps: list[tuple[int, str]], structure: str, prev_new: list[str]) -> str:
    steps_table = "\n".join(f"| `--step {k}` | {desc} |" for k, desc in steps)
    concepts = "\n".join(f"- **{t}:** {m}" for t, m in extra["concepts"])
    outputs = "\n".join(f"- {o}" for o in info["outputs"])
    nxt = f"[Lab {lab + 1}](../{SLUGS[lab + 1]}/)" if lab < 10 else "the capstone (`make api`, then `make gate`)"
    carried = ", ".join(f"`{m}.py`" for m in prev_new) or "nothing (first lab)"
    keys = " and ".join(f"`{k}`" for k in KEYS_REQUIRED.split(", "))
    if lab in KEYS_OPTIONAL:
        keys += f", plus optional `{KEYS_OPTIONAL[lab]}` for live search"
    run_notes = "\n".join(f"- {n}" for n in RUN[lab])
    data_note = "; `make data` regenerates the sample data" + (" and PDFs" if lab >= 8 else "") if lab >= 3 else ""
    trouble = "\n".join(f"| {a} | {b} | {c} |" for a, b, c in TROUBLESHOOTING)
    tests, first_step = TESTS[lab], steps[-1][0]
    tools_table = "\n".join(f"| {t} | {r} |" for t, r in TOOLS[lab])
    make_step = f"make run STEP={first_step}".ljust(29)
    py_all, py_step = "python -m bankassist.lab".ljust(29), f"python -m bankassist.lab --step {first_step}  "
    return f"""# BankAssist 360, Lab {lab}: {info['title']}

{info['sessions']}

{info['lead']}

This project is standalone: it contains everything built in earlier labs ({carried}), so you can
start here without finishing the previous lab. Code from earlier labs is identical to their projects.

## How to run this lab

You need Python 3.11 or 3.12 and these keys in `.env`: {keys}. Tests need no keys.

macOS or Linux:

```bash
python3 -m venv .venv && source .venv/bin/activate
make install                 # pip install -e ".[dev]" + pre-commit hooks
cp .env.example .env         # then add your keys
make test                    # offline: expect {tests} passed
make run                     # every step in order
{make_step}# one step
```

Windows (PowerShell, no make needed):

```powershell
py -3.11 -m venv .venv; .venv\\Scripts\\Activate.ps1
python -m pip install -e ".[dev]"
Copy-Item .env.example .env  # then add your keys
pytest                       # offline: expect {tests} passed
{py_all}# every step in order
{py_step}# one step
```

`python -m bankassist.lab --help` lists the steps. Step numbers match the implementation steps in the lab
guide; guide steps without their own command are code you read in `src/bankassist/`, and their effect shows
in the next step that runs.

What to expect when you run it:

{run_notes}

Start again from a clean state with `make clean` (deletes `indexes/`){data_note}.

## Steps in this lab

| Command | What it does |
| --- | --- |
{steps_table}

The full walkthrough, code explanations, knowledge check, assignment and modification tasks are in
the BankAssist 360 lab guide (Lab {lab}). Slides: `docs/Lab{lab:02d}.pptx`. To rebuild this project with an AI
coding assistant, use the prompt in `docs/BUILD_PROMPT.md`.

## AI tools used

| Tool | Role in this lab |
| --- | --- |
{tools_table}

Model names are the defaults in `.env.example`; change them there, never in code. `python -m bankassist.lab --help`
lists the same tools.

## Expected outputs

{outputs}

## Concepts covered

{concepts}

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
{trouble}

## Project structure

```text
{structure}
```

## Standards used

- `src/` layout, installable package, one source of truth for dependencies (`pyproject.toml`)
- Configuration only through `.env` (see `.env.example`); no keys in code
- No import-time side effects: models, indexes and graphs are built by `build_*` / `get_*` functions
- Type hints, docstrings, Pydantic schemas for every structured model output
- `ruff` lint, `pytest` offline tests, pre-commit hooks and a GitHub Actions workflow
- Gemini 3+ models: no `temperature`; `thinking_level` instead (set in `.env`)

## Next

Continue with {nxt}.
"""



# ---------------------------------------------------------------------------------------------------------------------
# Build prompts: a ready-to-paste prompt per lab, generated from the real source so it never drifts from the code.
# ---------------------------------------------------------------------------------------------------------------------
STANDARDS = """- Python 3.11+, src layout: package `bankassist` under `src/`,
  installable with `pip install -e ".[dev]"`.
- `pyproject.toml` is the single source of dependencies (setuptools build, `dev` extra with pytest, ruff,
  pre-commit), ruff (line length 120; rules E, F, W, I, B, UP, SIM, RUF; `bankassist` is first-party) and
  pytest settings (`testpaths = ["tests"]`, `pythonpath = ["src", "."]`).
- Configuration only through `.env`, loaded once in `config.py`; never hard-code keys. Ship `.env.example`.
- Models: `init_chat_model("google_genai:<model>")`. Gemini 3+ deprecates temperature, top_p and top_k:
  never pass them for Gemini; pass `thinking_level` from `THINKING_LEVEL` instead. Embeddings:
  `GoogleGenerativeAIEmbeddings(model="gemini-embedding-2")`. Default models: main `gemini-3.8-flash`,
  fast `gemini-3.5-flash-lite`, judge `gemini-4-argon`.
- No import-time side effects: models, indexes and graphs are created by `build_*` / `get_*` functions,
  cached with `functools.lru_cache` where reuse matters. Pass dependencies (retriever, models, embeddings)
  as arguments so tests can inject fakes.
- Type hints and a docstring on every module and public function; Pydantic models for every structured LLM output.
- Library modules log with `get_logger(__name__)`; only `lab.py` prints results.
- Security: customer identity comes from `RunnableConfig["configurable"]["customer_id"]`, never from model
  arguments; money-moving actions need human approval; mask PII before it reaches a model or a trace.
- Tests run offline: `tests/conftest.py` sets a fake `GOOGLE_API_KEY`, `LANGSMITH_TRACING=false` and provides a
  `DeterministicFakeEmbedding` fixture. No test may call a real API.
- `lab.py` exposes `main()` that calls `bankassist.cli.run_steps(title, {number: step_function}, tools=AI_TOOLS)`;
  each step function's first docstring line is its description, and `AI_TOOLS` (a module-level tuple) names the
  lab's AI tools, shown by `--help`. `python -m bankassist.lab --step N` runs one step."""


def _sig(node: ast.FunctionDef) -> str:
    ret = f" -> {ast.unparse(node.returns)}" if node.returns else ""
    return f"{node.name}({ast.unparse(node.args)}){ret}"


def _doc1(node) -> str:
    doc = ast.get_docstring(node)
    return doc.strip().splitlines()[0] if doc else ""


def api_lines(src: str, only: set[str] | None = None) -> list[str]:
    """Public API of a module: constants, functions (with signatures) and classes (with public methods)."""
    out: list[str] = []
    for node in ast.parse(src).body:
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for t in targets:
                public = isinstance(t, ast.Name) and t.id.isupper() and not t.id.startswith("_")
                if public and (only is None or t.id in only):
                    value = ast.unparse(node.value) if node.value is not None else ""
                    out.append(f"    constant {t.id} = {value}" if 0 < len(value) <= 70 else f"    constant {t.id}")
        elif isinstance(node, ast.FunctionDef) and not node.name.startswith("_"):
            if only is None or node.name in only:
                out += [f"    @{ast.unparse(d)}" for d in node.decorator_list]
                out.append(f"    def {_sig(node)}")
                if _doc1(node):
                    out.append(f"        # {_doc1(node)}")
        elif isinstance(node, ast.ClassDef) and (only is None or node.name in only):
            bases = ", ".join(ast.unparse(b) for b in node.bases)
            out.append(f"    class {node.name}({bases})")
            if _doc1(node):
                out.append(f"        # {_doc1(node)}")
            for item in node.body:
                if isinstance(item, ast.FunctionDef) and (not item.name.startswith("_") or item.name == "__init__"):
                    out.append(f"        def {_sig(item)}")
                elif isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                    out.append(f"        field {item.target.id}: {ast.unparse(item.annotation)}")
    return out


def symbols(src: str) -> set[str]:
    names: set[str] = set()
    for node in ast.parse(src).body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Assign):
            names |= {t.id for t in node.targets if isinstance(t, ast.Name)}
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
    return names


def test_lines(src: str) -> list[str]:
    out: list[str] = []
    for n in ast.parse(src).body:
        if isinstance(n, ast.FunctionDef) and n.name.startswith("test_"):
            out += [f"    {n.name}", f"        # checks: {_doc1(n) or n.name.removeprefix('test_').replace('_', ' ')}"]
    return out


def build_prompt(lab: int, info: dict, steps: list[tuple[int, str]], structure: str, deps: list[str]) -> str:
    modules_now = [m for m, f in MODULES_FROM.items() if f <= lab]
    new_mods = [m for m in modules_now if MODULES_FROM[m] == lab]
    grown: dict[str, set[str]] = {}
    for m in modules_now:
        if MODULES_FROM[m] < lab:
            raw = (SRC / "modules" / f"{m}.py").read_text()
            added = symbols(strip_regions(raw, lab)) - symbols(strip_regions(raw, lab - 1))
            if added:
                grown[m] = added
    carried = [m for m in modules_now if MODULES_FROM[m] < lab]
    lines = [f"# Build prompt: BankAssist 360, Lab {lab} ({SLUGS[lab]})", "",
             "Paste everything below into an AI coding assistant (Gemini, Claude, Copilot Chat) from the project",
             "root. Review every file it returns, then run `make install && make test`.", "", "---", "",
             "You are a senior Python engineer building one lab of the BankAssist 360 course: a retail-banking",
             "assistant for the fictional Apex National Bank (India, amounts in INR), built with LangChain v1,",
             "LangGraph v1, LangSmith and Google Gemini.", "",
             f"GOAL (Lab {lab}: {info['title']})", f"Sessions: {info['sessions']}",
             textwrap.fill(info["lead"], 110), "",
             "STARTING POINT:"]
    if lab == 1:
        lines.append("Create a new project from scratch.")
    else:
        lines += [f"Copy the project `{SLUGS[lab - 1]}` to `{SLUGS[lab]}`, delete its `src/bankassist/lab.py`,",
                  "and keep these files unchanged unless this prompt says the file grows:",
                  textwrap.fill(", ".join(f"{m}.py" for m in carried if m != "__init__"), 100,
                                initial_indent="    src/bankassist/: ", subsequent_indent="    ")]
    lines += ["", "PROJECT STRUCTURE (create exactly this; '<- new in this lab' marks what you write now):", ""]
    lines += ["    " + ln for ln in structure.splitlines()]
    lines += ["", "DEPENDENCIES (pyproject.toml [project].dependencies):",
              textwrap.fill(", ".join(deps), 100, initial_indent="    ", subsequent_indent="    "), "",
              "AI TOOLS (use exactly these; declare their names in lab.py as AI_TOOLS, in this order):",
              *[textwrap.fill(f"{t}: {r}", 110, initial_indent="    - ", subsequent_indent="      ")
                for t, r in TOOLS[lab]],
              "    Model IDs come from .env: " + "; ".join(v for k, v in MODEL_IDS.items()
                                                     if any(k in t for t in tool_names(lab))), "",
              "CODING STANDARDS:", STANDARDS, "", "FILES TO WRITE:"]
    for m in new_mods:
        src = strip_regions((SRC / "modules" / f"{m}.py").read_text(), lab)
        doc = (ast.get_docstring(ast.parse(src)) or MODULE_ROLE[m]).strip().splitlines()[0]
        lines += ["", textwrap.fill(f"src/bankassist/{m}.py: {doc}", 110, subsequent_indent="  "),
                  "  Public API (implement exactly these names and signatures):"]
        lines += api_lines(src) or ["    (package marker: `__version__ = \"1.0.0\"`)"]
    for m, added in grown.items():
        src = strip_regions((SRC / "modules" / f"{m}.py").read_text(), lab)
        lines += ["", f"src/bankassist/{m}.py GROWS: add these to the existing module, change nothing else:"]
        lines += api_lines(src, only=added)
    lines += ["", "IMPLEMENTATION RULES (the tests and the lab guide depend on these):"]
    for note in NOTES[lab]:
        lines.append(textwrap.fill(note, 110, initial_indent="    - ", subsequent_indent="      "))
    lines += ["", "src/bankassist/lab.py: this lab's runnable steps, registered in run_steps() with these numbers:"]
    lines += [f"    --step {k}: {d}" for k, d in steps]
    lines += ["", "DATA (provided by the course; copy it, do not invent it):"]
    data_now = [d for d, f in DATA_FROM.items() if f <= lab]
    data_lines = [f"    data/{d}" + ("   <- new in this lab" if DATA_FROM[d] == lab else "") for d in data_now]
    lines += data_lines or ["    none"]
    new_tests = [t for t, f in TESTS_FROM.items() if f == lab and t != "conftest"]
    lines += ["", "TESTS (offline, pytest). Write these new test functions:"]
    for t in new_tests:
        lines += [f"  tests/{t}.py", *test_lines((SRC / "tests" / f"{t}.py").read_text())]
    if lab == 1:
        lines += ["  tests/conftest.py: fake GOOGLE_API_KEY, LANGSMITH_TRACING=false, fake_embeddings fixture"]
    make_targets = "install, test, lint, run STEP=N"
    make_targets += (", data" if lab >= 3 else "") + (", api, gate" if lab >= 10 else "")
    lines += ["", "ALSO WRITE OR UPDATE: README.md (setup, steps table, expected outputs, structure),",
              f".env.example (only the keys this lab needs), Makefile ({make_targets}), .gitignore,",
              ".pre-commit-config.yaml (ruff, private-key detection), .github/workflows/ci.yml",
              "(ruff + pytest on Python 3.11 and 3.12).", "",
              "EXPECTED BEHAVIOUR WHEN RUN WITH REAL KEYS:"]
    lines += [f"    - {o}" for o in info["outputs"]]
    lines += ["", "ACCEPTANCE CHECKS (all must pass before you finish):",
              "    1. `ruff check .` reports no issues.",
              "    2. `pytest` passes offline with no API keys and no network calls.",
              f"    3. `python -m bankassist.lab --help` lists steps {', '.join(str(k) for k, _ in steps)}.",
              "    4. No module creates a model, index or graph at import time.",
              "    5. Gemini models are never given a temperature.", "",
              "OUTPUT FORMAT: return every new or changed file in full, each preceded by a line",
              "`=== path/to/file ===`.",
              "No placeholders, no 'rest unchanged' comments. After the files, list any assumption you made."]
    return "\n".join(lines) + "\n"


def build(out_root: Path) -> None:
    labs = {d["n"]: d for d in node_json("content.js")}
    extras = {int(k): v for k, v in node_json("content_extra.js").items()}
    out_root.mkdir(parents=True, exist_ok=True)
    for lab in range(1, 11):
        proj = out_root / SLUGS[lab]
        kept_docs = None
        if proj.exists():
            if (proj / "docs").exists():  # slides are added after generation; keep them across rebuilds
                kept_docs = Path(shutil.copytree(proj / "docs", out_root / f".docs-{lab:02d}"))
            shutil.rmtree(proj)
        pkg = proj / "src" / "bankassist"
        pkg.mkdir(parents=True)
        modules = [m for m, first in MODULES_FROM.items() if first <= lab]
        for m in modules:
            (pkg / f"{m}.py").write_text(strip_regions((SRC / "modules" / f"{m}.py").read_text(), lab))
        lab_src = (SRC / "labs" / f"lab{lab:02d}.py").read_text()
        declared = next(ast.literal_eval(n.value) for n in ast.parse(lab_src).body
                        if isinstance(n, ast.Assign) and getattr(n.targets[0], "id", "") == "AI_TOOLS")
        assert list(declared) == tool_names(lab), f"lab{lab:02d}.py AI_TOOLS differs from ai_tools.py"
        (pkg / "lab.py").write_text(lab_src)
        (pkg / "assignments").mkdir()
        (pkg / "assignments" / "__init__.py").write_text(
            '"""Your solutions for the assignment (part 12) and modification tasks (part 13)."""\n')

        tests = [t for t, first in TESTS_FROM.items() if first <= lab]
        (proj / "tests").mkdir()
        (proj / "tests" / "__init__.py").write_text("")
        for t in tests:
            shutil.copy(SRC / "tests" / f"{t}.py", proj / "tests" / f"{t}.py")

        data = [d for d, first in DATA_FROM.items() if first <= lab]
        (proj / "data").mkdir()
        for d in data:
            src, dst = SRC / "data" / d, proj / "data" / d
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(src, dst) if src.is_dir() else shutil.copy(src, dst)
        if not data:
            (proj / "data" / ".gitkeep").write_text("")

        scripts = [s for s, first in SCRIPTS_FROM.items() if first <= lab]
        if scripts:
            (proj / "scripts").mkdir()
            (proj / "scripts" / "__init__.py").write_text("")
            for s in scripts:
                shutil.copy(SRC / "scripts" / f"{s}.py", proj / "scripts" / f"{s}.py")

        deps = BASE_DEPS + [d for first, ds in sorted(DEPS_FROM.items()) if first <= lab for d in ds]
        (proj / "pyproject.toml").write_text(pyproject(lab, labs[lab]["title"], deps))
        (proj / "requirements.txt").write_text(
            "# Generated from pyproject.toml for tools that need a requirements file.\n"
            "# Prefer: pip install -e \".[dev]\"\n" + "\n".join(deps) + "\n")
        (proj / ".env.example").write_text(env_example(lab))
        (proj / ".gitignore").write_text(GITIGNORE)
        (proj / "Makefile").write_text(makefile(lab))
        (proj / ".pre-commit-config.yaml").write_text(PRECOMMIT)
        (proj / ".github" / "workflows").mkdir(parents=True)
        (proj / ".github" / "workflows" / "ci.yml").write_text(CI)
        (proj / "indexes").mkdir()
        (proj / "indexes" / ".gitkeep").write_text("")
        if kept_docs:
            shutil.move(str(kept_docs), proj / "docs")
        else:
            (proj / "docs").mkdir()

        steps = lab_steps(lab_src)
        prev_new = [m for m in modules if MODULES_FROM[m] < lab and m not in ("__init__", "config", "cli")]
        structure = tree(lab, modules, tests, data, scripts)
        (proj / "README.md").write_text(readme(lab, labs[lab], extras[lab], steps, structure, prev_new))
        (proj / "docs" / "BUILD_PROMPT.md").write_text(build_prompt(lab, labs[lab], steps, structure, deps))
        if lab >= 10:
            shutil.copy(SRC / "templates" / "MODEL_CARD.md", proj / "docs" / "MODEL_CARD.md")

        # Tidy import order where region blocks were removed, then lint strictly.
        subprocess.run(["ruff", "check", "--fix", "--select", "I,F401", "-q", "."], cwd=proj, check=False)
        print(f"built {SLUGS[lab]}: {len(modules)} modules, {len(tests)} test files, steps {[k for k, _ in steps]}")


if __name__ == "__main__":
    build(Path(sys.argv[1]) if len(sys.argv) > 1 else Path("bankassist360-labs"))

"""AI tools used in each lab, with the role each plays. Single source of truth.

Used by build_projects.py (lab.py, README, BUILD_PROMPT), the lab decks (via slides/src/ai_tools.json) and the
lab guide. The names match the "AI TOOLS" chips in the theory deck. Model names are the .env defaults.
Checked against modules/ and labs/: update both when the code changes.
"""

TOOLS: dict[int, list[tuple[str, str]]] = {
    1: [
        ("Gemini 3.8 Flash", "Triage, reply drafting and the language and PII checks"),
        ("LangChain LCEL", "Pipelines built with the pipe operator (prompt, model, parser), RunnableParallel, batch and stream"),
        ("Pydantic structured output", "The Ticket schema via with_structured_output"),
        ("LangSmith tracing", "Runs, tags and metadata; @traceable on plain functions"),
    ],
    2: [
        ("Gemini 3.8 Flash", "Chat answers and running summaries"),
        ("LangChain message history", "MessagesPlaceholder, RunnableWithMessageHistory and trim_messages"),
        ("LangGraph checkpointer + store", "InMemorySaver for thread memory, InMemoryStore for customer profiles"),
        ("LangSmith tracing", "Inspect the summary and trimming calls"),
    ],
    3: [
        ("Gemini 3.8 Flash", "The tool-calling agent model"),
        ("LangChain create_agent", "The ReAct agent loop"),
        ("LangChain @tool", "Balance, transactions, EMI and card-block tools with the customer injected from config"),
        ("LangGraph runtime", "Runs the agent graph, its checkpointer and streaming"),
        ("LangSmith tracing", "Every tool call and result"),
    ],
    4: [
        ("Gemini 3.8 Flash", "Intent triage and block-request extraction"),
        ("LangGraph StateGraph", "The intent-routing graph over BankState"),
        ("LangGraph interrupt (human-in-the-loop)", "interrupt and Command(resume=...) before any card block"),
        ("LangSmith tracing", "Graph runs and routing-accuracy review"),
    ],
    5: [
        ("Gemini 3.8 Flash", "Cited answers, or the not-found refusal"),
        ("Gemini Embedding 2", "Chunk and query embeddings"),
        ("FAISS", "Local vector index, saved and reloaded"),
        ("Chroma", "Persistent vector store with metadata filters"),
        ("LangChain RAG chain", "Loaders, splitters, retriever and prompt returning answer + evidence"),
        ("LangSmith", "RAG traces showing the retrieved chunks"),
    ],
    6: [
        ("Gemini Embedding 2", "Embeddings for one temporary index per chunking strategy"),
        ("LangChain text splitters", "Fixed, recursive and markdown-header chunkers"),
        ("SemanticChunker", "Embedding-based breakpoints (langchain-experimental)"),
        ("FAISS", "The vector side of each comparison"),
        ("BM25", "Keyword retrieval with BM25Retriever (rank_bm25)"),
        ("LangSmith", "Retriever traces for each query"),
    ],
    7: [
        ("Gemini 3.8 Flash", "Answer generation"),
        ("Gemini 3.5 Flash-Lite", "Multi-query rephrasings (the fast tier)"),
        ("Gemini Embedding 2", "The vector side of hybrid search"),
        ("BM25 + FAISS", "Hybrid retrieval fused with Reciprocal Rank Fusion"),
        ("Cross-encoder (MiniLM)", "Re-ranking with cross-encoder/ms-marco-MiniLM-L-6-v2"),
        ("LangSmith", "Compare retriever configurations"),
    ],
    8: [
        ("Gemini 3.8 Flash (vision)", "Table summaries, chart captions and multimodal answers"),
        ("Gemini Embedding 2", "Embeddings for the policies_v2 collection"),
        ("Chroma metadata filters", "Current-version and audience filters before generation"),
        ("PyMuPDF + pdfplumber", "PDF text, image and table extraction"),
        ("LangSmith", "Multimodal traces"),
    ],
    9: [
        ("LangGraph corrective RAG", "Route, grade, rewrite, generate and check grounding"),
        ("Gemini 3.8 Flash", "Answer generation and direct replies"),
        ("Gemini 3.5 Flash-Lite", "Routing, grading, query rewrites and grounding checks"),
        ("Tavily search", "Live search restricted to trusted domains"),
        ("Cross-encoder", "Re-ranking inside the Lab 7 hybrid retriever"),
        ("LangSmith", "Graph traces showing every loop"),
    ],
    10: [
        ("LangSmith datasets + evaluators", "Golden dataset, client.evaluate experiments and user feedback"),
        ("Gemini 4 Argon (judge)", "Faithfulness and correctness judging"),
        ("Gemini 3.8 Flash + Flash-Lite", "The RAG versions under test, with model tiering"),
        ("LLM cache (SQLite)", "SQLiteCache for repeated prompts"),
        ("FastAPI + LangGraph", "The capstone API with a SqliteSaver checkpointer"),
    ],
}

# Matched by substring against the tool names, so "Gemini 3.8 Flash + Flash-Lite" maps to both chat models.
MODEL_IDS = {
    "3.8 Flash": "LLM_MODEL=google_genai:gemini-3.8-flash",
    "Flash-Lite": "FAST_LLM_MODEL=google_genai:gemini-3.5-flash-lite",
    "Argon": "JUDGE_MODEL=google_genai:gemini-4-argon",
    "Embedding 2": "EMBED_MODEL=gemini-embedding-2",
}


def names(lab: int) -> list[str]:
    return [n for n, _ in TOOLS[lab]]

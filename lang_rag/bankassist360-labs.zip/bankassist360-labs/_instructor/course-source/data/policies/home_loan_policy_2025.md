# Home Loan Policy (Superseded)
Document ID: POL-HL-2025 | Effective: 01-Apr-2025 | Owner: Retail Lending | Audience: public | Status: superseded by POL-HL-2026

## 3. Interest rates
Current floating rate range: 8.75% to 9.50% p.a.

## 4. Processing fee
0.75% of the loan amount, subject to a maximum of INR 15,000, plus GST.

## 5. Prepayment and foreclosure
Floating-rate loans to individuals: no prepayment charges.
Fixed-rate loans: 3% of the outstanding principal.

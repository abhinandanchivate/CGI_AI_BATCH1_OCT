# Fee Schedule
Document ID: POL-FEE-2026 | Effective: 01-Apr-2026 | Owner: Retail Products | Audience: public

## 1. How to read this schedule
Every charge has a charge code that appears on the customer's statement. All amounts are in INR and exclude GST unless stated.

## 2. Charges by code
| Charge code | Description | Amount (INR) |
|---|---|---|
| CHG-ATM-07 | ATM withdrawal at other-bank ATM beyond 5 free per month | 23 per transaction |
| CHG-ATM-02 | ATM withdrawal at Apex ATM beyond 5 free per month | 21 per transaction |
| CHG-ATM-09 | Balance enquiry at other-bank ATM beyond free limit | 10 per enquiry |
| CHG-DC-02 | Debit card annual fee, Classic | 250 |
| CHG-DC-05 | Debit card replacement (lost or damaged) | 200 |
| CHG-CHQ-11 | Cheque return, insufficient funds (outward) | 500 per instance |
| CHG-CHQ-12 | Cheque return, technical reasons | Nil |
| CHG-CHQ-04 | Additional cheque book beyond 25 free leaves per year | 4 per leaf |
| CHG-STP-03 | Stop payment of cheque | 100 per instruction |
| CHG-MAB-01 | Minimum balance shortfall | 6% of shortfall, max 500 per month |
| CHG-SMS-01 | SMS alerts | 15 per quarter |
| CHG-NEFT-01 | NEFT at branch, up to INR 10,000 | 2.50 per transaction |
| CHG-CLS-01 | Account closure after 14 days and within 1 year | 500 |

## 3. Free services
Online NEFT, RTGS and IMPS transfers through internet or mobile banking are free.
Passbook updates and e-statements are free.

## 4. Reversal of charges
Charges levied in error are reversed within 7 working days of a valid complaint.

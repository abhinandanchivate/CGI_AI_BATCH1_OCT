# Home Loan Policy
Document ID: POL-HL-2026 | Effective: 01-Apr-2026 | Owner: Retail Lending | Audience: public

## 1. Eligibility
Resident Indian individuals aged 21 years or above.
The loan must be repaid before the borrower turns 70.
Minimum net monthly income: INR 25,000 (salaried) or INR 3 lakh annual income (self-employed).

## 2. Loan to value (LTV)
| Loan amount | Maximum LTV |
|---|---|
| Up to INR 30 lakh | 90% |
| Above INR 30 lakh up to INR 75 lakh | 80% |
| Above INR 75 lakh | 75% |

## 3. Interest rates
Floating rates are linked to the External Benchmark Lending Rate (EBLR), which is the RBI repo rate plus a spread.
Current floating rate range: 8.50% to 9.25% p.a., depending on credit score and loan amount.
Fixed rate (first 3 years, then floating): 9.50% p.a.

## 4. Processing fee
Up to 0.50% of the loan amount (slab-wise, see RATECARD-2026), subject to a maximum of INR 10,000, plus GST.
Processing fee is waived for women borrowers who are the primary applicant.

## 5. Prepayment and foreclosure
Floating-rate loans to individuals: no prepayment or foreclosure charges.
Fixed-rate loans: 2% of the outstanding principal if refinanced from another lender; nil if prepaid from own funds.

## 6. Tenure
Maximum tenure: 30 years, subject to the age limit in Section 1.

## 7. Documents
KYC documents (see POL-KYC-2026), last 6 months' salary slips or 2 years' ITR, 6 months' bank statements, and property documents.

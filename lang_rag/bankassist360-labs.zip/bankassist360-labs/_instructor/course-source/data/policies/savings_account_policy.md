# Savings Account Policy
Document ID: POL-SAV-2026 | Effective: 01-Apr-2026 | Owner: Retail Products | Audience: public

## 1. Account variants
| Variant | Monthly Average Balance (Metro/Urban) | MAB (Semi-urban/Rural) |
|---|---|---|
| Classic Savings | INR 10,000 | INR 2,500 |
| Salary Plus | Nil (monthly salary credit required) | Nil |
| Senior Citizen | INR 5,000 | INR 1,000 |

Senior Citizen accounts are available to resident individuals aged 60 years or above.
Salary Plus accounts convert to Classic Savings if no salary is credited for 3 consecutive months.

## 2. Non-maintenance charges
If the monthly average balance (MAB) falls below the required amount, charge code CHG-MAB-01 applies:
6% of the shortfall, capped at INR 500 per month, plus GST.
No charge applies to Salary Plus accounts while salary credits continue.

## 3. Savings interest rates
Balance up to INR 5 lakh: 3.00% p.a.
Balance above INR 5 lakh: 3.50% p.a.
Interest is calculated on the daily closing balance and credited quarterly.

## 4. ATM usage
Customers get 5 free withdrawals per month at Apex ATMs and 5 free withdrawals per month at other-bank ATMs.
Each other-bank ATM withdrawal beyond the free limit is charged under CHG-ATM-07 (see Fee Schedule POL-FEE-2026).

## 5. Fixed deposits linked to savings accounts
| Tenure | General rate (p.a.) | Senior citizen rate (p.a.) |
|---|---|---|
| 7 days to 1 year | 5.50% | 6.00% |
| 1 year to 2 years | 6.75% | 7.25% |
| 2 years to 5 years | 7.00% | 7.50% |
| Above 5 years | 6.50% | 7.00% |

Senior citizens receive an additional 0.50% p.a. over the general rate on all tenures.
Premature withdrawal attracts a penalty of 1.00% on the applicable rate.

## 6. Account closure
Closure within 14 days of opening: free.
Closure after 14 days and within 1 year: INR 500 (charge code CHG-CLS-01).
Closure after 1 year: free.

## 7. Inoperative accounts
An account with no customer-initiated transaction for 24 months is classified as inoperative.
It can be reactivated at any branch after KYC verification, free of charge.

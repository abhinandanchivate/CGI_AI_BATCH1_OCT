# KYC Policy
Document ID: POL-KYC-2026 | Effective: 01-Apr-2026 | Owner: Compliance | Audience: public

## 1. Officially valid documents (OVD)
Any one of: passport, driving licence, voter ID card, Aadhaar (with the first 8 digits masked), NREGA job card, or letter from the National Population Register.

## 2. PAN requirement
PAN is mandatory for opening an account. Customers without PAN must submit Form 60.

## 3. Video KYC
Customers can complete KYC through a live video call with a bank official using Aadhaar-based verification and original PAN.

## 4. Periodic re-KYC
| Customer risk category | Re-KYC frequency |
|---|---|
| High risk | Every 2 years |
| Medium risk | Every 8 years |
| Low risk | Every 10 years |

## 5. Non-resident Indians (NRI)
NRIs must submit a valid passport, a valid visa or residence permit, and overseas address proof.
Re-KYC for NRIs follows the same risk-based frequency as Section 4.

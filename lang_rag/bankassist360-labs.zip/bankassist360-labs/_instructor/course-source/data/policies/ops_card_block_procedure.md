# Card Hotlisting Procedure (Internal)
Document ID: OPS-CB-2026 | Effective: 01-Apr-2026 | Owner: Card Operations | Audience: staff

## 1. Steps to hotlist a card
1. Verify the caller with two of: registered mobile OTP, date of birth, last 3 transactions.
2. Open the Card Management System (CMS) and search by the last 4 digits and customer ID.
3. Set status to HOTLISTED with reason code LOST, STOLEN or FRAUD.
4. Record the request ID in the CRM ticket and send the confirmation SMS template CB-01.
5. For fraud, escalate to the Fraud Risk Unit within 30 minutes.

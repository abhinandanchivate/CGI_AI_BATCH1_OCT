# Credit Card Policy
Document ID: POL-CC-2026 | Effective: 01-Apr-2026 | Owner: Cards | Audience: public

## 1. Card variants
| Variant | Annual fee (INR) | Fee waiver |
|---|---|---|
| Apex Classic | 499 | Waived on annual spends of INR 1.5 lakh |
| Apex Rewards | 1,499 | Waived on annual spends of INR 3 lakh |
| Apex Signature | 4,999 | Waived on annual spends of INR 8 lakh |

## 2. Lost or stolen card
Report a lost or stolen card immediately through the mobile app, internet banking or the 24x7 helpline 1800-XXX-XXXX.
The card is hotlisted as soon as the report is verified.
Customer liability is zero for fraudulent transactions reported within 3 working days of receiving the transaction alert.
A replacement card is issued within 7 working days.

## 3. Disputed transactions
A disputed or duplicate transaction must be raised within 30 days of the statement date.
A temporary credit is given within 7 working days of raising a valid dispute.
Disputes are resolved within 45 days; chargeback with the merchant's bank may take up to 90 days.

## 4. Charges
Finance charges: 3.50% per month on revolving balances.
Late payment fee: INR 500 for dues up to INR 10,000; INR 1,000 for dues above INR 10,000.
Cash withdrawal fee: 2.5% of the amount, minimum INR 500.

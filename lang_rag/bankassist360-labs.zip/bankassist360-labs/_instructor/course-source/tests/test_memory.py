from langchain_core.language_models.fake_chat_models import FakeListChatModel
from langgraph.store.memory import InMemoryStore

import bankassist.memory as mem


def test_threads_are_isolated_and_long_threads_are_summarised(monkeypatch):
    fake = FakeListChatModel(responses=["ok"] * 50)
    monkeypatch.setattr(mem, "get_llm", lambda *a, **k: fake)
    graph = mem.build_memory_graph(store=InMemoryStore())
    a = {"configurable": {"thread_id": "A", "customer_id": "C1001"}}
    b = {"configurable": {"thread_id": "B", "customer_id": "C1002"}}

    for i in range(7):  # 14 messages on thread A -> crosses the summary trigger
        graph.invoke({"messages": [{"role": "user", "content": f"q{i}"}]}, a)
    graph.invoke({"messages": [{"role": "user", "content": "hello"}]}, b)

    state_a, state_b = graph.get_state(a).values, graph.get_state(b).values
    assert state_a.get("summary")
    assert len(state_a["messages"]) <= mem.SUMMARY_TRIGGER
    assert [m.content for m in state_b["messages"]] == ["hello", "ok"]

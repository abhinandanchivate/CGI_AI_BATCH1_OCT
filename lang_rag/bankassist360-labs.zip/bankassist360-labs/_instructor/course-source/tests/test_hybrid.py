from langchain_core.documents import Document

from bankassist.retrievers import AdvancedRetriever, build_chunks, rrf


def _doc(cid: str) -> Document:
    return Document(page_content=cid, metadata={"chunk_id": cid})


def test_rrf_rewards_agreement():
    fused = rrf([[_doc("a"), _doc("b"), _doc("c")], [_doc("b"), _doc("d")]])
    assert fused[0].metadata["chunk_id"] == "b"


def test_hybrid_search_finds_code_with_fake_embeddings(fake_embeddings):
    retriever = AdvancedRetriever(build_chunks(), embeddings=fake_embeddings,
                                  use_multi_query=False, use_rerank=False)
    top = retriever.retrieve("CHG-CHQ-11", top_n=3)
    assert any("CHG-CHQ-11" in d.page_content for d in top)


def test_injected_query_generator_is_used(fake_embeddings):
    seen = []
    retriever = AdvancedRetriever(build_chunks(), embeddings=fake_embeddings, use_rerank=False,
                                  query_generator=lambda q: seen.append(q) or ["cheque return charge"])
    retriever.retrieve("bounce fee")
    assert seen

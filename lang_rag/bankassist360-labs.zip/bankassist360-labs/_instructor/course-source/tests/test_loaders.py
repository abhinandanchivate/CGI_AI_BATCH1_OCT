from bankassist.retrievers import build_chroma, build_chunks, load_policies, split_recursive


def test_policies_load_with_metadata():
    docs = {d.metadata["doc_id"]: d.metadata for d in load_policies()}
    assert {"POL-SAV-2026", "POL-FEE-2026", "POL-HL-2026", "POL-KYC-2026", "OPS-CB-2026"} <= docs.keys()
    assert docs["POL-HL-2025"]["is_current"] is False
    assert docs["POL-HL-2026"]["is_current"] is True
    assert docs["OPS-CB-2026"]["audience"] == "staff"


def test_markdown_chunks_have_unique_ids_and_section_refs():
    chunks = build_chunks()
    ids = [c.metadata["chunk_id"] for c in chunks]
    assert len(ids) == len(set(ids))
    assert any(c.metadata["source_ref"] == "POL-SAV-2026#1" for c in chunks)


def test_tables_stay_with_their_section():
    chunk = next(c for c in build_chunks() if c.metadata["source_ref"] == "POL-FEE-2026#2")
    assert "| Charge code |" in chunk.page_content and "CHG-ATM-07" in chunk.page_content


def test_recursive_chunks_also_get_section_refs():
    refs = {c.metadata["source_ref"] for c in split_recursive(load_policies())}
    assert "POL-SAV-2026#1" in refs and "POL-FEE-2026#2" in refs


def test_chroma_reindex_is_idempotent(tmp_path, fake_embeddings):
    chunks = build_chunks()
    build_chroma(chunks, embeddings=fake_embeddings, collection="test_policies", persist_dir=tmp_path)
    store = build_chroma(chunks, embeddings=fake_embeddings, collection="test_policies", persist_dir=tmp_path)
    assert len(store.get()["ids"]) == len(chunks)

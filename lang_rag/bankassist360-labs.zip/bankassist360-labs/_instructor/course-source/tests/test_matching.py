from langchain_core.documents import Document

from bankassist.retrievers import build_chunks, exact_code_lookup, hit_rate, load_eval


def test_exact_code_lookup_is_case_insensitive():
    hits = exact_code_lookup("what is chg-atm-07?", build_chunks())
    assert hits and all("CHG-ATM-07" in h.page_content for h in hits)


def test_exact_code_lookup_ignores_plain_questions():
    assert exact_code_lookup("what is the ATM fee?", build_chunks()) == []


def test_hit_rate_counts_gold_phrases():
    rows = [{"question": "q1", "gold_text": "INR 10,000"}, {"question": "q2", "gold_text": "missing"}]
    retrieve = lambda q: [Document(page_content="Classic Savings MAB is INR 10,000")]  # noqa: E731
    assert hit_rate(retrieve, rows, k=4) == 0.5


def test_eval_sets_load():
    assert len(load_eval("chunk_eval.jsonl")) == 15

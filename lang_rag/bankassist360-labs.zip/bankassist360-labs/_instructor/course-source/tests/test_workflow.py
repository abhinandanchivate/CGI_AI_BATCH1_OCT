import pytest
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

import bankassist.workflow as wf
from bankassist.data_access import get_customer


@pytest.mark.parametrize("intent,node", [
    ("card_block", "prepare_block"), ("balance_enquiry", "banking_agent"), ("kyc", "policy_qa"),
    ("complaint", "create_complaint"), ("other", "general_reply"),
])
def test_route_by_intent(intent, node):
    assert wf.route_by_intent({"ticket": {"intent": intent}}) == node


def test_only_explicit_approve_executes():
    assert wf.route_after_approval({"decision": "approve"}) == "execute_block"
    assert wf.route_after_approval({"decision": "yes please"}) == "block_rejected"


@pytest.fixture
def offline_graph(monkeypatch):
    """Replace the two LLM-backed nodes with deterministic stubs."""
    monkeypatch.setattr(wf, "classify", lambda s: {"ticket": {"intent": "card_block", "summary": "lost card"}})
    monkeypatch.setattr(wf, "prepare_block", lambda s, config: {"block_request": {
        "card_last4": "4321", "reason": "lost", "customer_id": config["configurable"]["customer_id"]}})
    return wf.build_workflow_builder().compile(checkpointer=InMemorySaver())


@pytest.mark.parametrize("decision,expected", [("approve", "blocked"), ("reject", "active")])
def test_card_block_requires_human_decision(offline_graph, decision, expected):
    cfg = {"configurable": {"thread_id": f"t-{decision}", "customer_id": "C1001"}}
    first = offline_graph.invoke({"messages": [{"role": "user", "content": "block card 4321"}]}, cfg)
    assert first["__interrupt__"][0].value["card_last4"] == "4321"
    assert get_customer("C1001")["cards"][0]["status"] == "active"  # nothing happens before approval
    offline_graph.invoke(Command(resume=decision), cfg)
    assert get_customer("C1001")["cards"][0]["status"] == expected

import pytest

from bankassist.guardrails import mask_pii


@pytest.mark.parametrize("text,label", [
    ("card 4111 1111 1111 1111 misused", "<CARD>"),
    ("aadhaar 1234 5678 9012", "<AADHAAR>"),
    ("PAN ABCDE1234F", "<PAN>"),
    ("call me on +91 9876543210", "<PHONE>"),
    ("mail priya.s@example.com", "<EMAIL>"),
])
def test_identifiers_are_masked(text, label):
    assert label in mask_pii(text)


def test_card_not_partly_masked_as_aadhaar():
    assert mask_pii("4111111111111111") == "<CARD>"


def test_plain_text_unchanged():
    text = "What is the FD rate for 2 years?"
    assert mask_pii(text) == text

from bankassist import retrievers
from bankassist.retrievers import expand_query


def test_expand_query_keeps_original_words():
    assert expand_query("MAB for Classic?").startswith("MAB for Classic?")
    assert "monthly average balance" in expand_query("MAB for Classic?")
    assert expand_query("hello") == "hello"


def test_glossary_is_the_default_query_transform():
    assert retrievers.DEFAULT_QUERY_TRANSFORM is expand_query

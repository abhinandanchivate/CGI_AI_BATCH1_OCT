from langchain_core.documents import Document

from bankassist.evaluation import failed_targets, pack, retrieval_precision, retrieval_recall

REF = {"relevant_sources": ["POL-SAV-2026#1", "POL-FEE-2026#2"]}


def test_precision_and_recall():
    out = {"retrieved_ids": ["POL-SAV-2026#1", "POL-KYC-2026#4", "POL-FEE-2026#2", "X#1"]}
    assert retrieval_precision(out, REF)["score"] == 0.5
    assert retrieval_recall(out, REF)["score"] == 1.0


def test_out_of_scope_questions_are_skipped():
    out = {"retrieved_ids": ["POL-SAV-2026#1"]}
    assert retrieval_precision(out, {"relevant_sources": []})["score"] is None


def test_pack_deduplicates_sections_in_order():
    docs = [Document(page_content="a", metadata={"source_ref": "A#1"}),
            Document(page_content="b", metadata={"source_ref": "A#1"}),
            Document(page_content="c", metadata={"source_ref": "B#2"})]
    assert pack("ans", docs)["retrieved_ids"] == ["A#1", "B#2"]


def test_gate_fails_on_missing_or_low_metric():
    failed = failed_targets({"faithfulness": 0.95, "retrieval_recall": 0.5}, {"faithfulness": 0.9,
                            "retrieval_recall": 0.85, "correctness": 0.85})
    assert set(failed) == {"retrieval_recall", "correctness"}

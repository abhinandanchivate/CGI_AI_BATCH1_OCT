from bankassist.config import PDF_DIR
from bankassist.multimodal import extract_pdf, table_to_markdown


def test_table_to_markdown_keeps_header():
    md = table_to_markdown([["Slab", "Rate"], ["Up to 30 lakh", "8.50%"], [None, "9.00%"]])
    assert md.splitlines()[0] == "| Slab | Rate |"
    assert "|  | 9.00% |" in md


def test_rate_card_has_text_table_and_image():
    kinds = {item["type"] for item in extract_pdf(PDF_DIR / "loan_rate_card.pdf")}
    assert kinds == {"text", "table", "image"}

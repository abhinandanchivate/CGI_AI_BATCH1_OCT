import pytest

from bankassist.tools import (
    calculate_emi,
    emi_amount,
    get_account_balance,
    get_recent_transactions,
    raise_card_block_request,
)

CFG = {"configurable": {"customer_id": "C1001"}}


def test_emi_matches_lab_guide():
    assert round(emi_amount(2_500_000, 8.5, 20)) == 21_696


def test_emi_zero_rate_is_simple_division():
    assert emi_amount(120_000, 0, 1) == pytest.approx(10_000)


@pytest.mark.parametrize("principal,years", [(0, 10), (100_000, 0), (-5, 5)])
def test_emi_rejects_invalid_input(principal, years):
    with pytest.raises(ValueError):
        emi_amount(principal, 8.5, years)


def test_calculate_emi_tool_formats_inr():
    out = calculate_emi.invoke({"principal_inr": 2_500_000, "annual_rate_pct": 8.5, "tenure_years": 20})
    assert out.startswith("EMI: INR 21,696")


def test_customer_identity_is_hidden_from_the_model():
    """The model-facing schema must not expose config or customer_id."""
    for t in (get_account_balance, get_recent_transactions, raise_card_block_request):
        props = t.tool_call_schema.model_json_schema().get("properties", {})
        assert "config" not in props and "customer_id" not in props


def test_balance_uses_injected_customer():
    assert "XXXX4521" in get_account_balance.invoke({}, config=CFG)


def test_recent_transactions_newest_first_and_capped():
    rows = get_recent_transactions.invoke({"limit": 100}, config=CFG)
    assert len(rows) <= 20
    dates = [r["date"] for r in rows]
    assert dates == sorted(dates, reverse=True)


def test_block_request_for_unknown_card_returns_error():
    out = raise_card_block_request.invoke({"card_last4": "9999", "reason": "lost"}, config=CFG)
    assert out.startswith("ERROR")


def test_block_request_does_not_block_immediately():
    out = raise_card_block_request.invoke({"card_last4": "4321", "reason": "lost"}, config=CFG)
    assert "pending_verification" in out

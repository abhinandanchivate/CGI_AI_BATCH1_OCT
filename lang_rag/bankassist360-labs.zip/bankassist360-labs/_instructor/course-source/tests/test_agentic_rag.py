from langchain_core.language_models.fake_chat_models import FakeListChatModel
from langchain_core.runnables import RunnableLambda

from bankassist.agentic_rag import build_agentic_rag


def test_graph_has_all_corrective_rag_nodes():
    fake = FakeListChatModel(responses=["unused"])
    graph = build_agentic_rag(retriever=RunnableLambda(lambda q: []), web_search=lambda q: [],
                              llm=fake, fast_llm=fake)
    nodes = set(graph.get_graph().nodes)
    assert {"route_question", "retrieve", "grade_documents", "rewrite_query", "web_search", "generate",
            "check_grounding", "not_found", "direct_answer", "flag_unverified"} <= nodes

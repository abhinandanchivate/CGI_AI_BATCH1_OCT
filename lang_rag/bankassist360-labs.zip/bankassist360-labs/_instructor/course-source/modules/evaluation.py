"""RAG evaluation (Lab 10): dataset, evaluators, experiments, optimisation and the release gate.

Gate: python -m scripts.release_gate
"""

from __future__ import annotations

import json
from collections.abc import Callable

from langchain_core.documents import Document
from pydantic import BaseModel, Field

from bankassist.config import EVAL_DIR, INDEX_DIR, get_judge_llm, get_logger

log = get_logger(__name__)

DATASET = "bankassist-golden-v1"
TOP_K = 5
TARGETS = {"faithfulness": 0.90, "retrieval_recall": 0.85, "retrieval_precision": 0.60, "correctness": 0.85}


# ------------------------------------------------------------------ dataset
def load_golden() -> list[dict]:
    return [json.loads(line) for line in (EVAL_DIR / "golden_set.jsonl").read_text().splitlines() if line]


def ensure_dataset(client=None) -> str:
    """Create the LangSmith dataset once (idempotent)."""
    from langsmith import Client

    client = client or Client()
    if not client.has_dataset(dataset_name=DATASET):
        ds = client.create_dataset(DATASET, description="BankAssist 360 golden Q&A with source labels")
        client.create_examples(dataset_id=ds.id, examples=[
            {"inputs": {"question": r["question"]},
             "outputs": {"answer": r["reference_answer"], "relevant_sources": r["relevant_sources"]}}
            for r in load_golden()])
        log.info("Created dataset %s", DATASET)
    return DATASET


# ------------------------------------------------------------------ targets
def pack(answer: str, docs: list[Document]) -> dict:
    """Normalise every RAG version's output for the evaluators."""
    refs: list[str] = []
    for d in docs:
        ref = d.metadata.get("source_ref", d.metadata.get("doc_id", "unknown"))
        if ref not in refs:
            refs.append(ref)
    return {"answer": answer, "retrieved_ids": refs, "contexts": [d.page_content for d in docs]}


def make_targets() -> dict[str, Callable[[dict], dict]]:
    """Build one target per RAG version (imports are lazy: each version builds indexes)."""
    from bankassist.agentic_rag import build_agentic_rag
    from bankassist.rag import build_advanced_rag, build_basic_rag

    basic, advanced, agentic = build_basic_rag(), build_advanced_rag(), build_agentic_rag()

    def target_basic(inputs: dict) -> dict:
        out = basic.invoke(inputs["question"])
        return pack(out["answer"], out["docs"])

    def target_advanced(inputs: dict) -> dict:
        out = advanced.invoke(inputs["question"])
        return pack(out["answer"], out["docs"])

    def target_agentic(inputs: dict) -> dict:
        out = agentic.invoke({"question": inputs["question"]})
        return pack(out["answer"], out.get("docs", []))

    return {"lab5-basic": target_basic, "lab7-advanced": target_advanced, "lab9-agentic": target_agentic}


# ------------------------------------------------------------------ code evaluators (deterministic, unit tested)
def _relevant(reference_outputs: dict) -> set[str]:
    return set(reference_outputs.get("relevant_sources", []))


def retrieval_precision(outputs: dict, reference_outputs: dict) -> dict:
    """Share of the top-k retrieved sections that are relevant. None for out-of-scope questions."""
    rel, got = _relevant(reference_outputs), outputs["retrieved_ids"][:TOP_K]
    if not rel:
        return {"key": "retrieval_precision", "score": None}
    return {"key": "retrieval_precision", "score": sum(g in rel for g in got) / max(len(got), 1)}


def retrieval_recall(outputs: dict, reference_outputs: dict) -> dict:
    """Share of relevant sections that appear in the top-k. None for out-of-scope questions."""
    rel, got = _relevant(reference_outputs), set(outputs["retrieved_ids"][:TOP_K])
    if not rel:
        return {"key": "retrieval_recall", "score": None}
    return {"key": "retrieval_recall", "score": len(rel & got) / len(rel)}


# ------------------------------------------------------------------ LLM-as-judge evaluators
class Verdict(BaseModel):
    reasoning: str = Field(description="Short explanation, written before the score")
    score: float = Field(ge=0, le=1)


def faithfulness(outputs: dict) -> dict:
    """Supported claims / total claims, judged only against the retrieved context."""
    ctx = "\n---\n".join(outputs["contexts"]) or "(no context)"
    v = get_judge_llm().with_structured_output(Verdict).invoke(
        "List each factual claim in the ANSWER. Score = supported claims / total claims, using ONLY the "
        "CONTEXT. A refusal with no factual claims scores 1.\n"
        f"CONTEXT:\n{ctx}\n\nANSWER:\n{outputs['answer']}")
    return {"key": "faithfulness", "score": v.score, "comment": v.reasoning}


def correctness(inputs: dict, outputs: dict, reference_outputs: dict) -> dict:
    """Does the answer contain the reference's key facts (or refuse when out of scope)?"""
    v = get_judge_llm().with_structured_output(Verdict).invoke(
        "Score 1 if the ANSWER contains the key facts of the REFERENCE with no contradiction, 0.5 if partly, "
        "0 if wrong or missing. If the REFERENCE says out of scope, score 1 only if the answer refuses.\n"
        f"QUESTION: {inputs['question']}\nREFERENCE: {reference_outputs['answer']}\nANSWER: {outputs['answer']}")
    return {"key": "correctness", "score": v.score, "comment": v.reasoning}


EVALUATORS = [retrieval_precision, retrieval_recall, faithfulness, correctness]


# ------------------------------------------------------------------ experiments and gate
def run_experiment(name: str, target: Callable[[dict], dict], client=None):
    from langsmith import Client

    client = client or Client()
    return client.evaluate(target, data=ensure_dataset(client), evaluators=EVALUATORS,
                           experiment_prefix=name, max_concurrency=4)


def summarise(results) -> dict[str, float]:
    """Average each feedback metric from an ExperimentResults object."""
    df = results.to_pandas()
    cols = [c for c in df.columns if c.startswith("feedback.")]
    return {c.removeprefix("feedback."): round(float(df[c].mean()), 3) for c in cols}


def failed_targets(scores: dict[str, float], targets: dict[str, float] = TARGETS) -> dict[str, float]:
    """Metrics below target (a missing metric counts as failed)."""
    return {k: scores.get(k, 0.0) for k, t in targets.items() if scores.get(k, 0.0) < t}


def enable_optimisations() -> None:
    """Persistent LLM cache: identical prompts (repeated FAQs, re-runs) cost nothing."""
    from langchain_community.cache import SQLiteCache
    from langchain_core.globals import set_llm_cache

    INDEX_DIR.mkdir(exist_ok=True)
    set_llm_cache(SQLiteCache(database_path=str(INDEX_DIR / "llm_cache.db")))
    log.info("LLM cache enabled. Clear indexes/llm_cache.db after re-indexing policies.")

"""Data access layer for the synthetic core-banking data.

In production these functions would call the core-banking and card-management
APIs. Keeping them in one module means only this file changes when that happens.
"""

from __future__ import annotations

import copy
import json
from functools import lru_cache

import pandas as pd

from bankassist.config import DATA_DIR, get_logger

log = get_logger(__name__)


@lru_cache(maxsize=1)
def _customers() -> dict[str, dict]:
    records = json.loads((DATA_DIR / "customers.json").read_text(encoding="utf-8"))
    return {c["customer_id"]: c for c in records}


@lru_cache(maxsize=1)
def _transactions() -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / "transactions.csv")


def get_customer(customer_id: str) -> dict | None:
    """Return a copy of the customer record, or None if the ID is unknown."""
    cust = _customers().get(customer_id)
    return copy.deepcopy(cust) if cust else None


def get_transactions(customer_id: str, limit: int = 5) -> list[dict]:
    """Return the customer's most recent transactions, newest first."""
    df = _transactions()
    rows = df[df.customer_id == customer_id].sort_values(["date", "txn_id"], ascending=False)
    return rows.head(limit).to_dict(orient="records")


def set_card_status(customer_id: str, card_last4: str, status: str) -> bool:
    """Update a card's status in the in-memory store. Returns True if a card was updated.

    Production: replace with a call to the card-management system.
    """
    cust = _customers().get(customer_id)
    if not cust:
        return False
    for card in cust["cards"]:
        if card["card_last4"] == card_last4:
            card["status"] = status
            log.info("Card %s for %s set to %s", card_last4, customer_id, status)
            return True
    return False

"""Banking agent (Lab 3): create_agent with the banking tools."""

from __future__ import annotations

from langchain.agents import create_agent
from langgraph.checkpoint.memory import InMemorySaver

from bankassist.config import get_llm
from bankassist.tools import BANKING_TOOLS

SYSTEM_PROMPT = """You are BankAssist for Apex National Bank.
- Use tools for any account data or calculation; never guess numbers.
- Mask account numbers except the last 4 digits.
- For card blocking, raise a request and tell the customer verification is pending.
- You cannot transfer money or give investment advice; say so politely.
- If a tool returns ERROR, explain it simply and suggest the next step."""

DEFAULT_CONFIG = {"configurable": {"thread_id": "C1001-s3", "customer_id": "C1001"}, "recursion_limit": 12}


def build_banking_agent(with_memory: bool = True):
    """ReAct agent on LangGraph. Memory is optional so it can be nested in the Lab 4 workflow."""
    return create_agent(model=get_llm(), tools=BANKING_TOOLS, system_prompt=SYSTEM_PROMPT,
                        checkpointer=InMemorySaver() if with_memory else None)


def ask(agent, question: str, config: dict | None = None) -> str:
    """Send one question and return the final answer text."""
    out = agent.invoke({"messages": [{"role": "user", "content": question}]}, config or DEFAULT_CONFIG)
    return out["messages"][-1].content

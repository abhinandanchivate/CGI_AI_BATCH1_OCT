"""Agentic RAG (Lab 9): routing, grading, query rewriting, live search and grounding checks.

``build_agentic_rag`` takes its retriever, web search and models as arguments
(dependency injection), so tests and Lab 10 can swap them without patching.
"""

from __future__ import annotations

import os
from collections.abc import Callable
from typing import Literal, TypedDict

from langchain_core.documents import Document
from langchain_core.messages import AIMessage
from langchain_core.runnables import Runnable
from langgraph.graph import END, START, StateGraph
from langgraph.graph.state import CompiledStateGraph
from pydantic import BaseModel

from bankassist.config import get_fast_llm, get_llm, get_logger
from bankassist.prompts import BANK_PROMPT, NOT_FOUND
from bankassist.retrievers import format_docs, get_advanced_retriever

log = get_logger(__name__)

MAX_REWRITES = 2
MAX_GENERATIONS = 2
TRUSTED_DOMAINS = ["rbi.org.in", "pib.gov.in"]
HELPLINE_TEXT = " Please call 1800-XXX-XXXX or visit your branch."
STRICT_SUFFIX = "\nSTRICT: use only exact facts from the context; omit anything else."


class Route(BaseModel):
    route: Literal["policy", "live", "direct"]


class Grade(BaseModel):
    relevant: Literal["yes", "no"]


class Grounded(BaseModel):
    grounded: Literal["yes", "no"]
    unsupported_claims: list[str]


class RAGState(TypedDict, total=False):
    question: str          # original question, never changed
    query: str             # current search query, may be rewritten
    route: str
    docs: list[Document]
    answer: str
    rewrites: int
    gen_attempts: int
    grounded: bool


def make_web_search() -> Callable[[str], list[Document]]:
    """Tavily search restricted to trusted domains; returns [] when no API key is set."""
    if not os.getenv("TAVILY_API_KEY"):
        log.warning("TAVILY_API_KEY not set: live route will find nothing")
        return lambda _query: []
    from langchain_tavily import TavilySearch

    tavily = TavilySearch(max_results=3, include_domains=TRUSTED_DOMAINS)

    def search(query: str) -> list[Document]:
        res = tavily.invoke({"query": query})
        return [Document(page_content=r["content"], metadata={"doc_id": r["url"], "source_ref": r["url"]})
                for r in res.get("results", [])]

    return search


def build_agentic_rag(retriever: Runnable | None = None,
                      web_search: Callable[[str], list[Document]] | None = None,
                      llm=None, fast_llm=None) -> CompiledStateGraph:
    """Corrective RAG graph: route -> retrieve -> grade -> (rewrite) -> generate -> verify."""
    retriever = retriever or get_advanced_retriever()
    web_search = web_search or make_web_search()
    llm = llm or get_llm()
    fast = fast_llm or get_fast_llm()

    def route_question(s: RAGState) -> dict:
        r = fast.with_structured_output(Route).invoke(
            "Classify the banking question. policy = about this bank's products, fees, rules, documents. "
            "live = needs current public data such as today's RBI repo rate or a new circular. "
            f"direct = greeting or chit-chat.\nQuestion: {s['question']}")
        return {"route": r.route, "query": s["question"], "rewrites": 0, "gen_attempts": 0, "docs": []}

    def retrieve(s: RAGState) -> dict:
        return {"docs": retriever.invoke(s["query"])}

    def grade_documents(s: RAGState) -> dict:
        if not s["docs"]:
            return {"docs": []}
        prompts = [f"Does this text help answer the question? Answer yes or no.\n"
                   f"Question: {s['question']}\nText: {d.page_content}" for d in s["docs"]]
        grades = fast.with_structured_output(Grade).batch(prompts)
        return {"docs": [d for d, g in zip(s["docs"], grades, strict=True) if g.relevant == "yes"]}

    def rewrite_query(s: RAGState) -> dict:
        q = fast.invoke(f"The search '{s['query']}' found nothing relevant in Indian bank policy documents. "
                        "Write one better search query using formal banking terms. Return only the query.").content
        return {"query": q.strip(), "rewrites": s["rewrites"] + 1}

    def web_search_node(s: RAGState) -> dict:
        return {"docs": web_search(s["question"])}

    def generate(s: RAGState) -> dict:
        strict = "" if s["gen_attempts"] == 0 else STRICT_SUFFIX
        answer = llm.invoke(BANK_PROMPT.format(role="customer", context=format_docs(s["docs"]) or "(none)",
                                               question=s["question"] + strict)).content
        return {"answer": answer, "gen_attempts": s["gen_attempts"] + 1}

    def check_grounding(s: RAGState) -> dict:
        if not s["docs"]:  # nothing to ground against: only a refusal is acceptable
            return {"grounded": NOT_FOUND.lower()[:30] in s["answer"].lower()}
        g = fast.with_structured_output(Grounded).invoke(
            f"Context:\n{format_docs(s['docs'])}\n\nAnswer:\n{s['answer']}\n\n"
            "Is every factual claim in the answer supported by the context?")
        return {"grounded": g.grounded == "yes"}

    def not_found(_: RAGState) -> dict:
        return {"answer": NOT_FOUND + HELPLINE_TEXT}

    def direct_answer(s: RAGState) -> dict:
        return {"answer": llm.invoke(f"Reply briefly and politely as BankAssist: {s['question']}").content}

    def flag_unverified(s: RAGState) -> dict:
        return {"answer": s["answer"] + "\n\nNote: please verify this with your branch."}

    def after_grade(s: RAGState) -> str:
        if s["docs"]:
            return "generate"
        return "rewrite_query" if s["rewrites"] < MAX_REWRITES else "not_found"

    def after_grounding(s: RAGState) -> str:
        if s["grounded"]:
            return END
        return "generate" if s["gen_attempts"] < MAX_GENERATIONS else "flag_unverified"

    g = StateGraph(RAGState)
    for name, fn in [("route_question", route_question), ("retrieve", retrieve),
                     ("grade_documents", grade_documents), ("rewrite_query", rewrite_query),
                     ("web_search", web_search_node), ("generate", generate),
                     ("check_grounding", check_grounding), ("not_found", not_found),
                     ("direct_answer", direct_answer), ("flag_unverified", flag_unverified)]:
        g.add_node(name, fn)
    g.add_edge(START, "route_question")
    g.add_conditional_edges("route_question", lambda s: s["route"],
                            {"policy": "retrieve", "live": "web_search", "direct": "direct_answer"})
    g.add_edge("retrieve", "grade_documents")
    g.add_conditional_edges("grade_documents", after_grade)
    g.add_edge("rewrite_query", "retrieve")
    g.add_edge("web_search", "generate")
    g.add_edge("generate", "check_grounding")
    g.add_conditional_edges("check_grounding", after_grounding)
    for node in ["not_found", "direct_answer", "flag_unverified"]:
        g.add_edge(node, END)
    return g.compile(name="agentic_rag")


def make_policy_qa_node(agentic_rag: CompiledStateGraph | None = None) -> Callable:
    """Drop-in policy_qa node for the Lab 4 workflow."""
    graph = agentic_rag or build_agentic_rag()

    def policy_qa(state) -> dict:
        out = graph.invoke({"question": state["messages"][-1].content})
        return {"messages": [AIMessage(out["answer"])]}

    return policy_qa

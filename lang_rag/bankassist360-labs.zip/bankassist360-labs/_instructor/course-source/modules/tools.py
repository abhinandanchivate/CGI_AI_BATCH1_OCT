"""Banking tools for the Lab 3 agent and the Lab 4 workflow.

Security rule: the customer's identity is read from ``RunnableConfig``
(``configurable.customer_id``), which LangChain injects at run time and hides from
the model. The model can never choose whose data to read.
"""

from __future__ import annotations

import uuid

from langchain_core.runnables import RunnableConfig
from langchain_core.tools import tool

from bankassist.data_access import get_customer, get_transactions

MAX_TXN_LIMIT = 20


def _customer_id(config: RunnableConfig) -> str:
    try:
        return config["configurable"]["customer_id"]
    except (KeyError, TypeError) as exc:
        raise ValueError("customer_id missing from config['configurable']") from exc


def emi_amount(principal_inr: float, annual_rate_pct: float, tenure_years: int) -> float:
    """Standard EMI formula: P * r * (1+r)^n / ((1+r)^n - 1). Pure function, unit tested."""
    if principal_inr <= 0 or tenure_years <= 0:
        raise ValueError("principal and tenure must be positive")
    n = tenure_years * 12
    r = annual_rate_pct / 12 / 100
    if r == 0:
        return principal_inr / n
    growth = (1 + r) ** n
    return principal_inr * r * growth / (growth - 1)


@tool
def get_account_balance(config: RunnableConfig) -> str:
    """Get the current balance of the logged-in customer's accounts."""
    cust = get_customer(_customer_id(config))
    if not cust:
        return "ERROR: customer not found"
    return "; ".join(f"{a['account_no']} ({a['type']}): INR {a['balance']:,.2f}" for a in cust["accounts"])


@tool
def get_recent_transactions(limit: int, config: RunnableConfig) -> list[dict]:
    """Get the logged-in customer's most recent transactions, newest first. limit: 1-20."""
    return get_transactions(_customer_id(config), max(1, min(limit, MAX_TXN_LIMIT)))


@tool
def calculate_emi(principal_inr: float, annual_rate_pct: float, tenure_years: int) -> str:
    """Calculate the monthly EMI for a loan. Use for any EMI or loan instalment question."""
    try:
        emi = emi_amount(principal_inr, annual_rate_pct, tenure_years)
    except ValueError as exc:
        return f"ERROR: {exc}"
    total_interest = emi * tenure_years * 12 - principal_inr
    return f"EMI: INR {emi:,.0f} per month; total interest: INR {total_interest:,.0f}"


@tool
def raise_card_block_request(card_last4: str, reason: str, config: RunnableConfig) -> str:
    """Raise a request to block the customer's card. Does NOT block immediately."""
    cust = get_customer(_customer_id(config))
    if not cust:
        return "ERROR: customer not found"
    if not any(c["card_last4"] == card_last4 for c in cust["cards"]):
        return f"ERROR: no card ending {card_last4} on this profile"
    return f"Request BLK-{uuid.uuid4().hex[:6].upper()} created for reason '{reason}', status pending_verification"


BANKING_TOOLS = [get_account_balance, get_recent_transactions, calculate_emi, raise_card_block_request]

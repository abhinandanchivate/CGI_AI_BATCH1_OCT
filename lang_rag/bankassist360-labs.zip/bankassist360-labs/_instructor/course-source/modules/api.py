"""Capstone: BankAssist 360 as an HTTP API.

Run:  uvicorn bankassist.api:api --reload     then open http://127.0.0.1:8000/docs

The Lab 4 workflow is compiled with a SQLite checkpointer (threads and pending
approvals survive restarts) and Agentic RAG (Lab 9) as its policy_qa node.
"""

from __future__ import annotations

import sqlite3
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import FastAPI, HTTPException
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.types import Command
from pydantic import BaseModel, Field

from bankassist.config import INDEX_DIR, get_logger
from bankassist.guardrails import mask_pii
from bankassist.workflow import build_workflow_builder
from bankassist.agentic_rag import make_policy_qa_node

log = get_logger(__name__)
STATE: dict = {}


@asynccontextmanager
async def lifespan(_: FastAPI):
    INDEX_DIR.mkdir(exist_ok=True)
    conn = sqlite3.connect(INDEX_DIR / "threads.db", check_same_thread=False)
    STATE["graph"] = build_workflow_builder(policy_qa=make_policy_qa_node()).compile(
        checkpointer=SqliteSaver(conn))
    log.info("BankAssist 360 workflow ready")
    yield
    conn.close()


api = FastAPI(title="BankAssist 360", version="1.0.0", lifespan=lifespan)


class ChatIn(BaseModel):
    customer_id: str = Field(description="Production: take this from the auth token, not the body")
    session_id: str
    message: str = Field(min_length=1, max_length=2000)


class ApprovalIn(BaseModel):
    customer_id: str
    session_id: str
    decision: Literal["approve", "reject"]
    reviewer: str


def _config(customer_id: str, session_id: str, **metadata) -> dict:
    return {"configurable": {"thread_id": f"{customer_id}-{session_id}", "customer_id": customer_id},
            "metadata": metadata}


@api.get("/health")
def health() -> dict:
    return {"status": "ok", "ready": "graph" in STATE}


@api.post("/chat")
def chat(req: ChatIn) -> dict:
    graph = STATE["graph"]
    out = graph.invoke({"messages": [{"role": "user", "content": mask_pii(req.message)}]},
                       _config(req.customer_id, req.session_id, channel="api"))
    if "__interrupt__" in out:
        return {"status": "pending_approval", "details": out["__interrupt__"][0].value}
    return {"status": "ok", "answer": out["messages"][-1].content}


@api.post("/approve")
def approve(req: ApprovalIn) -> dict:
    graph = STATE["graph"]
    cfg = _config(req.customer_id, req.session_id, approved_by=req.reviewer)
    if not graph.get_state(cfg).next:
        raise HTTPException(status_code=409, detail="No action is waiting for approval on this session")
    out = graph.invoke(Command(resume=req.decision), cfg)
    return {"status": "ok", "answer": out["messages"][-1].content}

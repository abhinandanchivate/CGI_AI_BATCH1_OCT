"""Conversation memory (Lab 2): trimming, summarisation, thread checkpointer and long-term store."""

from __future__ import annotations

from langchain_core.messages import HumanMessage, RemoveMessage, SystemMessage, trim_messages
from langchain_core.messages.utils import count_tokens_approximately
from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.graph.state import CompiledStateGraph
from langgraph.store.base import BaseStore
from langgraph.store.memory import InMemoryStore

from bankassist.config import get_llm

SYSTEM_TEXT = "You are BankAssist for Apex National Bank. Be concise."
SUMMARY_TRIGGER = 10      # summarise when the thread holds more messages than this
KEEP_RECENT = 4           # messages kept verbatim after summarising
TOKEN_BUDGET = 1000

trimmer = trim_messages(max_tokens=TOKEN_BUDGET, strategy="last",
                        token_counter=count_tokens_approximately,
                        include_system=True, start_on="human")


class ChatState(MessagesState):
    """Messages (appended by reducer) plus a running summary."""

    summary: str


def summarize(state: ChatState) -> dict:
    """Fold older messages into the summary and delete them from state."""
    msgs = state["messages"]
    if len(msgs) <= SUMMARY_TRIGGER:
        return {}
    older = msgs[:-KEEP_RECENT]
    text = get_llm().invoke([HumanMessage(
        f"Existing summary: {state.get('summary', '')}\n"
        "Extend it with the key facts (names, products, amounts) from:\n"
        + "\n".join(f"{m.type}: {m.content}" for m in older))]).content
    return {"summary": text, "messages": [RemoveMessage(id=m.id) for m in older]}


def respond(state: ChatState, config: RunnableConfig, *, store: BaseStore) -> dict:
    """Answer using summary, trimmed history and the customer's long-term profile."""
    customer_id = config["configurable"].get("customer_id", "anonymous")
    item = store.get((customer_id, "profile"), "prefs")
    profile = item.value if item else {}
    system = SystemMessage(f"{SYSTEM_TEXT} Customer profile: {profile}. "
                           f"Conversation summary so far: {state.get('summary') or 'none'}")
    return {"messages": [get_llm().invoke([system, *trimmer.invoke(state["messages"])])]}


def build_memory_graph(store: BaseStore | None = None, checkpointer=None) -> CompiledStateGraph:
    """summarize -> respond, with thread memory (checkpointer) and long-term memory (store)."""
    builder = StateGraph(ChatState)
    builder.add_node("summarize", summarize)
    builder.add_node("respond", respond)
    builder.add_edge(START, "summarize")
    builder.add_edge("summarize", "respond")
    builder.add_edge("respond", END)
    return builder.compile(checkpointer=checkpointer or InMemorySaver(), store=store or InMemoryStore())

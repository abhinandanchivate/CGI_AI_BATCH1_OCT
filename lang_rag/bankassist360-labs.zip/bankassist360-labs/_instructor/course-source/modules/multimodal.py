"""Domain-specific and multimodal RAG (Lab 8): PDF extraction, captions, filtered retrieval.

Images are saved under indexes/images/ and only their path is stored in metadata
(keeps the vector store small; Chroma metadata must be scalar values).
"""

from __future__ import annotations

import base64
from functools import lru_cache
from pathlib import Path

from langchain_core.documents import Document
from langchain_core.messages import HumanMessage
from langchain_core.runnables import Runnable

from bankassist.config import INDEX_DIR, PDF_DIR, get_llm
from bankassist.prompts import BANK_PROMPT
from bankassist.retrievers import build_chroma, build_chunks, expand_query

IMAGE_DIR = INDEX_DIR / "images"
COLLECTION = "policies_v2"
ROLE_AUDIENCES = {"customer": ["public"], "staff": ["public", "staff"]}


# ------------------------------------------------------------------ PDF extraction
def table_to_markdown(rows: list[list[str | None]]) -> str:
    """Convert pdfplumber rows to a markdown table so headers stay attached to values."""
    rows = [[(cell or "").strip() for cell in row] for row in rows if row]
    if not rows:
        return ""
    head = "| " + " | ".join(rows[0]) + " |\n|" + "---|" * len(rows[0])
    body = "\n".join("| " + " | ".join(r) + " |" for r in rows[1:])
    return f"{head}\n{body}"


def extract_pdf(path: Path) -> list[dict]:
    """Return text, table and image items with page numbers."""
    import pdfplumber
    import pymupdf

    items: list[dict] = []
    IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    with pymupdf.open(path) as pdf:
        for pno, page in enumerate(pdf, start=1):
            items.append({"type": "text", "page": pno, "content": page.get_text()})
            for idx, img in enumerate(page.get_images(full=True)):
                data = pdf.extract_image(img[0])
                img_path = IMAGE_DIR / f"{path.stem}_p{pno}_{idx}.{data['ext']}"
                img_path.write_bytes(data["image"])
                items.append({"type": "image", "page": pno, "path": str(img_path), "ext": data["ext"]})
    with pdfplumber.open(path) as pdf:
        for pno, page in enumerate(pdf.pages, start=1):
            for table in page.extract_tables():
                items.append({"type": "table", "page": pno, "content": table_to_markdown(table)})
    return items


def image_message(path: str, ext: str, text: str) -> HumanMessage:
    b64 = base64.b64encode(Path(path).read_bytes()).decode()
    return HumanMessage(content=[{"type": "text", "text": text},
                                 {"type": "image_url", "image_url": {"url": f"data:image/{ext};base64,{b64}"}}])


def pdf_to_documents(path: Path, doc_id: str) -> list[Document]:
    """Multi-vector pattern: embed a summary or caption, keep the raw table or image for answering."""
    llm = get_llm()  # must be vision-capable for captions
    docs: list[Document] = []
    for i, item in enumerate(extract_pdf(path)):
        meta = {"doc_id": doc_id, "source": path.name, "page": item["page"], "type": item["type"],
                "chunk_id": f"{doc_id}-{i:03d}", "source_ref": f"{doc_id}#p{item['page']}",
                "is_current": True, "audience": "public"}
        if item["type"] == "table":
            summary = llm.invoke(f"Summarise this loan table for search, keep all numbers:\n{item['content']}").content
            docs.append(Document(page_content=summary, metadata={**meta, "raw": item["content"]}))
        elif item["type"] == "image":
            caption = llm.invoke([image_message(item["path"], item["ext"],
                                                "Describe this banking chart for search. List every label, "
                                                "axis, value and the main takeaway.")]).content
            docs.append(Document(page_content=caption, metadata={**meta, "image_path": item["path"],
                                                                 "ext": item["ext"]}))
        elif item["content"].strip():
            docs.append(Document(page_content=item["content"], metadata=meta))
    return docs


# ------------------------------------------------------------------ index and retrieval
@lru_cache(maxsize=1)
def build_domain_index():
    """All policies (incl. superseded and staff-only, filtered at query time) + the rate card PDF."""
    chunks = build_chunks() + pdf_to_documents(PDF_DIR / "loan_rate_card.pdf", "RATECARD-2026")
    return build_chroma(chunks, collection=COLLECTION)


def retriever_for(role: str, k: int = 5) -> Runnable:
    """Filters run BEFORE the LLM sees anything: current versions only, audience by role."""
    audiences = ROLE_AUDIENCES.get(role, ["public"])
    return build_domain_index().as_retriever(search_kwargs={"k": k, "filter": {
        "$and": [{"is_current": True}, {"audience": {"$in": audiences}}]}})


def multimodal_answer(question: str, role: str = "customer") -> str:
    """Retrieve, swap in raw tables and images, answer with a vision-capable model."""
    docs = retriever_for(role).invoke(expand_query(question))
    image_parts, context = [], []
    for d in docs:
        tag = f"[{d.metadata['doc_id']}, {d.metadata.get('section') or 'p' + str(d.metadata.get('page', '-'))}]"
        if d.metadata.get("type") == "image":
            b64 = base64.b64encode(Path(d.metadata["image_path"]).read_bytes()).decode()
            image_parts.append({"type": "image_url",
                                "image_url": {"url": f"data:image/{d.metadata['ext']};base64,{b64}"}})
            context.append(f"{tag} (image attached) {d.page_content}")
        else:
            context.append(f"{tag} {d.metadata.get('raw', d.page_content)}")
    prompt = BANK_PROMPT.format(role=role, context="\n\n".join(context), question=question)
    return get_llm().invoke([HumanMessage(content=[{"type": "text", "text": prompt}, *image_parts])]).content

"""Generate the multimodal PDFs used in Lab 8.

loan_rate_card.pdf        a gridded table of loan slabs and an embedded bar chart image
annual_report_extract.pdf prose plus an embedded line chart image

Usage:
    python -m scripts.generate_pdfs
"""

from __future__ import annotations

import io
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless backend, no display needed
import matplotlib.pyplot as plt
from reportlab import rl_config
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

rl_config.invariant = 1  # no timestamps or random IDs: regenerated PDFs are byte-identical

PDF_DIR = Path(__file__).resolve().parent.parent / "data" / "pdfs"

LOAN_SLABS = [
    ["Loan slab", "Floating rate (p.a.)", "Processing fee"],
    ["Up to INR 30 lakh", "8.50%", "0.50%, max INR 10,000"],
    ["INR 30 lakh to 75 lakh", "8.75%", "0.50%, max INR 10,000"],
    ["INR 75 lakh to 2 crore", "9.00%", "0.40%, max INR 10,000"],
    ["Above INR 2 crore", "9.25%", "0.25%, max INR 10,000"],
]
RATE_BY_TENURE = {"5 yrs": 8.50, "10 yrs": 8.60, "15 yrs": 8.75, "20 yrs": 8.90, "30 yrs": 9.10}
NIM_BY_YEAR = {"FY22": 3.1, "FY23": 3.3, "FY24": 3.4, "FY25": 3.2, "FY26": 3.5}


def _chart_png(kind: str) -> io.BytesIO:
    """Render a small chart to PNG bytes."""
    fig, ax = plt.subplots(figsize=(6, 3), dpi=150)
    if kind == "rates":
        bars = ax.bar(list(RATE_BY_TENURE), list(RATE_BY_TENURE.values()), color="#0B3C49")
        ax.bar_label(bars, fmt="%.2f%%", fontsize=8)
        ax.set_ylim(8.0, 9.4)
        ax.set_ylabel("Floating rate (% p.a.)")
        ax.set_title("Home loan rate by tenure, Apex National Bank, Nov 2026")
    else:
        ax.plot(list(NIM_BY_YEAR), list(NIM_BY_YEAR.values()), marker="o", color="#0B3C49")
        for x, y in NIM_BY_YEAR.items():
            ax.annotate(f"{y:.1f}%", (x, y), textcoords="offset points", xytext=(0, 6),
                        ha="center", fontsize=8)
        ax.set_ylabel("Net interest margin (%)")
        ax.set_title("Net interest margin, FY22 to FY26")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", metadata={"Software": None})
    plt.close(fig)
    buf.seek(0)
    return buf


def build_rate_card(path: Path) -> None:
    styles = getSampleStyleSheet()
    table = Table(LOAN_SLABS, colWidths=[5.5 * cm, 4.5 * cm, 6 * cm])
    table.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.75, colors.black),  # grid lines help pdfplumber detect cells
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E8F1F2")),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
    ]))
    story = [
        Paragraph("Apex National Bank: Home Loan Rate Card", styles["Title"]),
        Paragraph("Document ID: RATECARD-2026 | Effective: 01-Nov-2026 | Audience: public", styles["Normal"]),
        Spacer(1, 12),
        Paragraph("Rates and processing fees by loan slab. Rates are floating and linked to EBLR.",
                  styles["Normal"]),
        Spacer(1, 8),
        table,
        Spacer(1, 16),
        Image(_chart_png("rates"), width=15 * cm, height=7.5 * cm),
    ]
    SimpleDocTemplate(str(path), pagesize=A4).build(story)


def build_annual_report(path: Path) -> None:
    styles = getSampleStyleSheet()
    story = [
        Paragraph("Apex National Bank: Annual Report FY26 (Extract)", styles["Title"]),
        Paragraph("Document ID: AR-FY26 | Audience: public", styles["Normal"]),
        Spacer(1, 12),
        Paragraph(
            "Retail deposits grew 14% year on year, led by Salary Plus accounts. "
            "Digital channels handled 82% of customer service requests. "
            "The bank launched BankAssist 360, an AI assistant for policy and account queries.",
            styles["Normal"]),
        Spacer(1, 12),
        Image(_chart_png("nim"), width=15 * cm, height=7.5 * cm),
    ]
    SimpleDocTemplate(str(path), pagesize=A4).build(story)


def main() -> None:
    PDF_DIR.mkdir(parents=True, exist_ok=True)
    build_rate_card(PDF_DIR / "loan_rate_card.pdf")
    build_annual_report(PDF_DIR / "annual_report_extract.pdf")
    print(f"Wrote PDFs to {PDF_DIR}")


if __name__ == "__main__":
    main()

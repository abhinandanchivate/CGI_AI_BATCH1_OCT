"""Release gate: evaluate the release candidate and exit 1 if any metric misses its target.

Usage (CI):
    python -m scripts.release_gate
"""

from __future__ import annotations

import sys

from bankassist.evaluation import TARGETS, failed_targets, make_targets, run_experiment, summarise


def main() -> int:
    scores = summarise(run_experiment("release-candidate", make_targets()["lab9-agentic"]))
    failed = failed_targets(scores)
    print("Targets:", TARGETS)
    print("Scores :", scores)
    if failed:
        print("FAILED:", failed)
        return 1
    print("PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())

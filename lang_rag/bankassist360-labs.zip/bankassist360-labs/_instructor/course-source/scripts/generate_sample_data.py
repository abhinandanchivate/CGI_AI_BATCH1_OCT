"""Generate synthetic customers and transactions for BankAssist 360.

The output is deterministic (fixed seed), so every learner gets identical data
and the expected outputs in the lab guide stay valid.

Usage:
    python -m scripts.generate_sample_data
"""

from __future__ import annotations

import csv
import json
import random
from datetime import date, timedelta
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
SEED = 2026

CUSTOMERS: list[dict] = [
    {
        "customer_id": "C1001",
        "name": "Priya Sharma",
        "segment": "Salary Plus",
        "city_type": "metro",
        "senior_citizen": False,
        "accounts": [{"account_no": "XXXX4521", "type": "savings", "balance": 84250.75}],
        "cards": [
            {"card_last4": "4321", "type": "debit", "status": "active"},
            {"card_last4": "8810", "type": "credit", "variant": "Apex Rewards", "status": "active"},
        ],
    },
    {
        "customer_id": "C1002",
        "name": "Rahul Verma",
        "segment": "Classic Savings",
        "city_type": "metro",
        "senior_citizen": False,
        "accounts": [{"account_no": "XXXX7788", "type": "savings", "balance": 8120.00}],
        "cards": [{"card_last4": "5566", "type": "debit", "status": "active"}],
    },
    {
        "customer_id": "C1003",
        "name": "Meera Iyer",
        "segment": "Senior Citizen",
        "city_type": "urban",
        "senior_citizen": True,
        "accounts": [
            {"account_no": "XXXX1290", "type": "savings", "balance": 612400.00},
            {"account_no": "XXXX1291", "type": "fixed_deposit", "balance": 500000.00},
        ],
        "cards": [{"card_last4": "1209", "type": "debit", "status": "active"}],
    },
    {
        "customer_id": "C1004",
        "name": "Arjun Nair",
        "segment": "Classic Savings",
        "city_type": "rural",
        "senior_citizen": False,
        "accounts": [{"account_no": "XXXX3344", "type": "savings", "balance": 2950.50}],
        "cards": [{"card_last4": "7781", "type": "debit", "status": "blocked"}],
    },
    {
        "customer_id": "C1005",
        "name": "Fatima Khan",
        "segment": "Salary Plus",
        "city_type": "metro",
        "senior_citizen": False,
        "accounts": [{"account_no": "XXXX9001", "type": "savings", "balance": 150300.00}],
        "cards": [
            {"card_last4": "9002", "type": "debit", "status": "active"},
            {"card_last4": "3141", "type": "credit", "variant": "Apex Signature", "status": "active"},
        ],
    },
]

# Fixed rows that the lab guide refers to explicitly (duplicate charge, salary, ATM fee).
FIXED_TXNS: list[dict] = [
    {"txn_id": "T9001", "customer_id": "C1001", "date": "2026-10-28",
     "description": "BIG BAZAAR PUNE", "amount": 2450.00, "type": "debit"},
    {"txn_id": "T9002", "customer_id": "C1001", "date": "2026-10-28",
     "description": "BIG BAZAAR PUNE", "amount": 2450.00, "type": "debit"},
    {"txn_id": "T9003", "customer_id": "C1001", "date": "2026-10-30",
     "description": "SALARY OCT", "amount": 95000.00, "type": "credit"},
    {"txn_id": "T9004", "customer_id": "C1001", "date": "2026-11-01",
     "description": "ATM CHG-ATM-07", "amount": 23.00, "type": "debit"},
    {"txn_id": "T9005", "customer_id": "C1002", "date": "2026-10-25",
     "description": "CHQ RETURN CHG-CHQ-11", "amount": 500.00, "type": "debit"},
]

MERCHANTS = ["SWIGGY", "AMAZON PAY", "DMART", "UBER INDIA", "IRCTC", "BESCOM BILL",
             "AIRTEL POSTPAID", "APOLLO PHARMACY", "PVR CINEMAS", "ATM WDL"]


def build_transactions(n_total: int = 50) -> list[dict]:
    """Return FIXED_TXNS plus random rows, sorted by date, with sequential IDs."""
    rng = random.Random(SEED)
    rows = list(FIXED_TXNS)
    start = date(2026, 9, 15)
    next_id = 9006
    while len(rows) < n_total:
        cust = rng.choice(CUSTOMERS)["customer_id"]
        rows.append({
            "txn_id": f"T{next_id}",
            "customer_id": cust,
            "date": (start + timedelta(days=rng.randint(0, 47))).isoformat(),
            "description": rng.choice(MERCHANTS),
            "amount": round(rng.uniform(80, 6000), 2),
            "type": "debit",
        })
        next_id += 1
    return sorted(rows, key=lambda r: (r["date"], r["txn_id"]))


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    (DATA_DIR / "customers.json").write_text(json.dumps(CUSTOMERS, indent=2), encoding="utf-8")
    txns = build_transactions()
    with (DATA_DIR / "transactions.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(txns[0].keys()), lineterminator="\n")
        writer.writeheader()
        writer.writerows(txns)
    print(f"Wrote {len(CUSTOMERS)} customers and {len(txns)} transactions to {DATA_DIR}")


if __name__ == "__main__":
    main()

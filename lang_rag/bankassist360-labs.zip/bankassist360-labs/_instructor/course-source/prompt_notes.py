"""Must-have behaviours for each lab's build prompt.

Signatures alone do not pin down behaviour; these rules state the logic the tests and the lab guide rely on.
Keep them in sync with ``modules/`` when the code changes.
"""

NOTES: dict[int, list[str]] = {
    1: [
        "config.py: load `.env` from the project root (`Path(__file__).resolve().parents[2]`); `Settings` is a frozen "
        "dataclass read from env vars; `model_kwargs(model)` returns `{'thinking_level': ...}` for `google_genai:` "
        "models and `{'temperature': 0}` otherwise; `get_llm`, `get_embeddings` are `lru_cache`d.",
        "chains.py: `Intent` is a `Literal` of the 8 intents; `INTENTS` is built from `Intent.__args__` so the list "
        "exists once; `Ticket` has `intent`, `urgency` (low|medium|high), `sentiment` (positive|neutral|negative), "
        "`summary`.",
        "TRIAGE_PROMPT defines each intent and says urgency is high when money or a card is lost or fraud is "
        "suspected. REPLY_PROMPT: max 80 words, polite, never promises a refund.",
        "`build_triage_chain()` = TRIAGE_PROMPT | llm.with_structured_output(Ticket), run name `triage`; "
        "`build_reply_chain()` = REPLY_PROMPT | llm | StrOutputParser(), run name `draft_reply`.",
        "lab.py: step 4 is a sequential pipeline using `RunnablePassthrough.assign` twice (ticket, then "
        "draft_reply) named `triage_pipeline`; step 5 uses "
        "`RunnableParallel(ticket=..., language=..., has_pii=...)`; step 7 wraps a function with "
        "`@traceable(name='triage_api', tags=['lab1'], metadata={'prompt_version': 'v1'})`.",
    ],
    2: [
        "Constants: SUMMARY_TRIGGER = 10, KEEP_RECENT = 4, TOKEN_BUDGET = 1000.",
        "`trimmer = trim_messages(max_tokens=TOKEN_BUDGET, strategy='last', token_counter=count_tokens_approximately, "
        "include_system=True, start_on='human')`.",
        "`summarize`: when the thread has more than SUMMARY_TRIGGER messages, fold all but the last KEEP_RECENT into "
        "`summary` with one LLM call and delete them with `RemoveMessage`; otherwise return `{}`.",
        "`respond`: read the profile from the store at namespace `(customer_id, 'profile')`, key `'prefs'`; put the "
        "profile and summary in the system message; send system + trimmed history to the model.",
        "`build_memory_graph(store=None, checkpointer=None)`: START -> summarize -> respond -> END, defaulting to "
        "`InMemorySaver()` and `InMemoryStore()`.",
    ],
    3: [
        "`emi_amount`: P*r*(1+r)^n / ((1+r)^n - 1) with r = annual/12/100, n = years*12; if r == 0 return P/n; "
        "raise ValueError for non-positive principal or tenure. 25 lakh at 8.5% for 20 years = INR 21,696.",
        "Tools read the customer from `config['configurable']['customer_id']` via a `config: RunnableConfig` "
        "parameter, so the model-facing schema has no customer_id. Tools return `'ERROR: ...'` strings instead of "
        "raising.",
        "`get_recent_transactions` clamps limit to 1..20 (MAX_TXN_LIMIT), newest first. `raise_card_block_request` "
        "checks the card belongs to the customer and returns `Request BLK-XXXXXX ... status pending_verification`; "
        "it never blocks the card.",
        "data_access.py loads customers.json and transactions.csv lazily with `lru_cache`, returns deep copies from "
        "`get_customer`, and `set_card_status` mutates the cached record.",
        "agent.py: `build_banking_agent(with_memory=True)` = `create_agent(model, tools=BANKING_TOOLS, "
        "system_prompt=SYSTEM_PROMPT, checkpointer=InMemorySaver() if with_memory else None)`; DEFAULT_CONFIG has "
        "thread_id C1001-s3, customer_id C1001 and recursion_limit 12.",
    ],
    4: [
        "`BankState(MessagesState)` adds `ticket: dict`, `block_request: dict`, `decision: str`.",
        "ROUTES maps card_block -> prepare_block; balance_enquiry, transaction_dispute, loan_enquiry -> banking_agent; "
        "fee_query, kyc -> policy_qa; complaint -> create_complaint; anything else -> general_reply.",
        "`human_approval` calls `interrupt({'action': 'block_card', **block_request})` and stores the lower-cased "
        "decision; `route_after_approval` goes to execute_block only for exactly 'approve', else block_rejected.",
        "`prepare_block` extracts card_last4 and reason with structured output (`BlockReq`) and adds customer_id "
        "from config. `execute_block` calls `set_card_status(..., 'blocked')`.",
        "`build_workflow_builder(policy_qa=policy_qa_stub)` returns the UNCOMPILED StateGraph; the banking agent "
        "node uses `build_banking_agent(with_memory=False)` because the parent graph owns the checkpointer.",
    ],
    5: [
        "`load_policies`: doc_id, effective and audience come from the header line (`Document ID: ...`, "
        "`Effective: ...`, `Audience: ...`); is_current is False when the second line contains 'superseded'; "
        "category is the filename prefix.",
        "`_assign_ids`: section number from `section` metadata or the first `## N.` heading in the chunk; a chunk "
        "without a heading inherits the previous chunk's section in the same document; source_ref = "
        "`{doc_id}#{section}`, chunk_id = `{source_ref}-{nn:02d}`.",
        "`split_recursive` separators: '\\n## ', '\\n\\n', '\\n', '. ', ' '. `split_markdown` splits on '#' and "
        "'##' (strip_headers=False), merges parent metadata, then sizes with a recursive splitter.",
        "`load_faiss` uses `allow_dangerous_deserialization=True` (own files only). `build_chroma` deletes existing "
        "ids before `add_documents(ids=...)` so re-indexing is idempotent.",
        "rag.py: `build_rag_chain` returns {'question', 'docs', 'answer'} (RunnableParallel + assign); "
        "`baseline_chunks` = recursive chunks that are current AND public; `build_basic_rag` reloads FAISS if "
        "indexes/faiss_policies/index.faiss exists.",
        "guardrails.py: mask CARD before AADHAAR so a 16-digit number is not partly masked; prompts.py: RAG_PROMPT "
        "cites `[doc_id]`, refuses with NOT_FOUND and includes INJECTION_GUARD.",
    ],
    6: [
        "CODE_PATTERN = r'\\b(?:CHG|POL|OPS)-[A-Z]+-\\d{2,4}\\b', matched against the UPPER-CASED query.",
        "`hit_rate(retrieve, rows, k)`: share of rows where any of the top-k chunks contains `gold_text` "
        "(case-insensitive). `load_eval(name)` reads JSONL from data/eval/.",
        "lab.py compares five chunkers (fixed 500, recursive 800/100, recursive 400/50, markdown-header, semantic) "
        "with a temporary FAISS index each, then BM25 vs vector, then exact code lookup.",
    ],
    7: [
        "`rrf`: score += 1 / (k + rank + 1) with 0-based rank, merged by chunk_id, sorted descending, first top_n.",
        "`hybrid_search`: lists = [bm25, vector] plus exact_code_lookup results when any; fuse with rrf.",
        "`retrieve`: apply query_transform if set; variants = [query] + generated queries (if use_multi_query); "
        "rrf over hybrid_search of each variant; cross-encoder re-rank to top_n if use_rerank.",
        "`Queries.queries` has max_length 3. CrossEncoderReranker imports sentence-transformers lazily on first use "
        "and stores `rerank_score` in metadata.",
        "`get_advanced_retriever()` is `lru_cache`d, uses current AND public markdown chunks and "
        "`query_transform=DEFAULT_QUERY_TRANSFORM` (None in Lab 7).",
    ],
    8: [
        "GLOSSARY maps MAB, LTV, NACH, FD, EMI, KYC, ROI, OVD to their meanings; `expand_query` APPENDS "
        "`' | ABBR (meaning); ...'` and keeps the original text; set `DEFAULT_QUERY_TRANSFORM = expand_query`.",
        "BANK_PROMPT rules: cite [doc_id, section or page]; INR with Indian grouping; rate/fee disclaimer; never "
        "share internal content; helpline 1800-XXX-XXXX for disputes; refuse with NOT_FOUND; inputs role, context, "
        "question.",
        "multimodal.py: `extract_pdf` returns text (PyMuPDF), images (saved under indexes/images, path kept) and "
        "tables (pdfplumber -> markdown). `pdf_to_documents` embeds an LLM summary or caption and keeps the raw "
        "table or image path in metadata (multi-vector).",
        "`build_domain_index` (lru_cache) indexes ALL chunks, including superseded and staff-only, plus the rate "
        "card into Chroma collection 'policies_v2'; filtering happens at query time.",
        "`retriever_for(role)` filters `{'$and': [{'is_current': True}, {'audience': {'$in': audiences}}]}` with "
        "ROLE_AUDIENCES customer -> [public], staff -> [public, staff]. `multimodal_answer` swaps in raw tables and "
        "attaches images as base64 `image_url` content blocks.",
    ],
    9: [
        "Constants: MAX_REWRITES = 2, MAX_GENERATIONS = 2, TRUSTED_DOMAINS = ['rbi.org.in', 'pib.gov.in'].",
        "`build_agentic_rag(retriever=None, web_search=None, llm=None, fast_llm=None)`: all dependencies injected; "
        "defaults are get_advanced_retriever(), make_web_search(), get_llm(), get_fast_llm(); compile with "
        "`name='agentic_rag'`.",
        "Graph: START -> route_question (fast model, Route: policy|live|direct) -> retrieve | web_search | "
        "direct_answer. retrieve -> grade_documents (fast model, Grade per chunk via .batch) -> generate if any "
        "relevant, else rewrite_query while rewrites < MAX_REWRITES, else not_found. rewrite_query -> retrieve.",
        "generate uses BANK_PROMPT (role customer) and adds STRICT_SUFFIX after the first attempt; check_grounding "
        "(Grounded) -> END if grounded, else generate while gen_attempts < MAX_GENERATIONS, else flag_unverified. "
        "With no docs, grounded only if the answer is the NOT_FOUND refusal.",
        "State keeps `question` (never changed) separate from `query` (rewritten). `make_web_search` returns a "
        "function that returns [] when TAVILY_API_KEY is unset. `make_policy_qa_node` adapts the graph to the "
        "Lab 4 workflow's policy_qa node.",
    ],
    10: [
        "DATASET = 'bankassist-golden-v1', TOP_K = 5, TARGETS = faithfulness 0.90, retrieval_recall 0.85, "
        "retrieval_precision 0.60, correctness 0.85.",
        "`ensure_dataset` is idempotent (`client.has_dataset`), examples are {inputs: {question}, outputs: {answer, "
        "relevant_sources}}. `pack` returns answer, retrieved_ids (unique source_ref in order) and contexts.",
        "Retrieval evaluators return score None when relevant_sources is empty (out of scope). Judges use "
        "`Verdict(reasoning, score in 0..1)` with reasoning before the score, on the JUDGE_MODEL.",
        "`run_experiment` = client.evaluate(target, data=dataset, evaluators=EVALUATORS, experiment_prefix=name, "
        "max_concurrency=4); `summarise` averages `feedback.*` columns; `failed_targets` treats a missing metric as 0.",
        "`enable_optimisations` sets a SQLiteCache at indexes/llm_cache.db. scripts/release_gate.py exits 1 when "
        "any target fails.",
        "api.py: FastAPI lifespan compiles `build_workflow_builder(policy_qa=make_policy_qa_node())` with a "
        "SqliteSaver at indexes/threads.db; /health; /chat masks PII and returns pending_approval on interrupt; "
        "/approve returns 409 when nothing is waiting, else resumes with Command(resume=decision).",
    ],
}

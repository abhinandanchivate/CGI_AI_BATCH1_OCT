"""Run every step of one lab project offline: fake chat model, fake embeddings, no re-ranker download.

Usage: python tools/smoke.py <project_dir> <lab_number>   (set SMOKE_SHOW=1 to print step output)
Prints one line per step: OK or FAIL with the error. Exit code 1 if anything failed.
"""

from __future__ import annotations

import contextlib
import io
import os
import re
import sys
import traceback
import typing
from pathlib import Path

project, lab = Path(sys.argv[1]).resolve(), int(sys.argv[2])
os.chdir(project)
sys.path[:0] = [str(project / "src"), str(project)]
os.environ.update(GOOGLE_API_KEY="fake", LANGSMITH_TRACING="false", TAVILY_API_KEY="")
os.environ.pop("TAVILY_API_KEY")

from langchain_core.embeddings import DeterministicFakeEmbedding  # noqa: E402
from langchain_core.language_models.chat_models import BaseChatModel  # noqa: E402
from langchain_core.messages import AIMessage  # noqa: E402
from langchain_core.outputs import ChatGeneration, ChatResult  # noqa: E402
from langchain_core.runnables import RunnableLambda  # noqa: E402
from pydantic import BaseModel  # noqa: E402

REFUSAL = "I could not find this in the bank's policy documents."


def _text(x) -> str:
    if isinstance(x, str):
        return x
    if hasattr(x, "to_string"):
        return x.to_string()
    if isinstance(x, list):
        return " ".join(_text(m) for m in x)
    return str(getattr(x, "content", x))


def fake_instance(schema: type[BaseModel], prompt: str) -> BaseModel:
    """A valid instance of `schema`, with a few keyword-driven choices so the labs take realistic paths."""
    low = prompt.lower()
    values = {}
    for name, field in schema.model_fields.items():
        ann = field.annotation
        args = typing.get_args(ann)
        if typing.get_origin(ann) is typing.Literal:
            choice = args[0]
            if name == "intent":
                for key, intent in [("block", "card_block"), ("lost", "card_block"), ("charged twice", "transaction_dispute"),
                                    ("balance", "balance_enquiry"), ("fee", "fee_query"), ("kyc", "kyc")]:
                    if key in low:
                        choice = intent
                        break
            if name == "route":
                choice = "live" if "repo rate" in low else "direct" if "thanks" in low else "policy"
            values[name] = choice
        elif ann is str:
            digits = re.search(r"\b(\d{4})\b", prompt)
            values[name] = digits.group(1) if name == "card_last4" and digits else f"fake {name}"
        elif ann is float:
            values[name] = 1.0
        elif ann is int:
            values[name] = 0
        elif typing.get_origin(ann) is list:
            values[name] = ["cheque return charge"] if name == "queries" else []
        else:
            values[name] = None
    return schema(**values)


class FakeChat(BaseChatModel):
    """Deterministic chat model: plain answers, no tool calls, valid structured output."""

    @property
    def _llm_type(self) -> str:
        return "fake-chat"

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        return ChatResult(generations=[ChatGeneration(message=AIMessage(content=f"Fake answer. {REFUSAL}"))])

    def bind_tools(self, tools, **kwargs):
        return self

    def with_structured_output(self, schema, **kwargs):
        return RunnableLambda(lambda inp: fake_instance(schema, _text(inp)))


import bankassist.config as config  # noqa: E402

FAKE = FakeChat()
config.get_llm = lambda *a, **k: FAKE
config.get_fast_llm = lambda: FAKE
config.get_judge_llm = lambda: FAKE
config.get_embeddings = lambda: DeterministicFakeEmbedding(size=64)
with contextlib.suppress(ImportError, AttributeError):
    import bankassist.retrievers as retrievers

    retrievers.CrossEncoderReranker.rerank = lambda self, q, docs, top_n=5: docs[:top_n]

if lab == 10:  # LangSmith is unreachable offline: a fake client runs targets and evaluators locally
    import inspect

    import langsmith
    import pandas as pd

    class FakeResults:
        def __init__(self, rows):
            self.rows = rows

        def to_pandas(self):
            return pd.DataFrame(self.rows)

    class FakeClient:
        def has_dataset(self, dataset_name=None, dataset_id=None):
            return True

        def create_feedback(self, run_id, key, score=None, comment=None, **kw):
            return {"run_id": run_id, "key": key}

        def evaluate(self, target, data, evaluators, experiment_prefix, max_concurrency=1, **kw):
            from bankassist.evaluation import load_golden

            rows = []
            for ex in load_golden()[:3]:
                inputs = {"question": ex["question"]}
                ref = {"answer": ex["reference_answer"], "relevant_sources": ex["relevant_sources"]}
                out = target(inputs)
                row = {}
                for ev in evaluators:
                    params = inspect.signature(ev).parameters
                    kwargs = {k: v for k, v in {"inputs": inputs, "outputs": out, "reference_outputs": ref}.items()
                              if k in params}
                    res = ev(**kwargs)
                    row[f"feedback.{res['key']}"] = res["score"]
                rows.append(row)
            return FakeResults(rows)

    langsmith.Client = FakeClient

import bankassist.lab as labmod  # noqa: E402
from bankassist.cli import run_steps  # noqa: E402,F401

steps: dict[int, typing.Callable] = {}
labmod.run_steps = lambda title, s, tools=(): steps.update(s)
labmod.main()

failed = 0
outputs: dict[int, str] = {}
for number, fn in steps.items():
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            fn()
        outputs[number] = buf.getvalue()
        print(f"  step {number}: OK   ({fn.__name__})")
    except Exception as exc:  # noqa: BLE001
        failed += 1
        print(f"  step {number}: FAIL ({fn.__name__}) {type(exc).__name__}: {exc}")
        traceback.print_exc(limit=3)

if os.environ.get("SMOKE_SHOW"):
    for number, text in outputs.items():
        print(f"===== step {number} output =====\n{text}")

# Lab-specific checks on deterministic output
checks = {
    2: [(4, "81 messages ->")],
    4: [(5, "Card status now: blocked")],
    5: [(2, "7 documents"), (2, "13 chunks"), (2, "POL-CC-2026#1-00")],
    6: [(7, "what is chg-atm-07? -> ['POL-FEE-2026#2', 'POL-SAV-2026#4']"), (7, "CHG-STP-03 charge -> ['POL-FEE-2026#2']"),
        (7, "explain CHG-MAB-01 -> ['POL-FEE-2026#2', 'POL-SAV-2026#2']")],
    8: [(1, "MAB (monthly average balance)"), (4, "loan_rate_card_p1_0.png"), (4, "table 1")],
}
for step, needle in checks.get(lab, []):
    ok = needle in outputs.get(step, "")
    failed += not ok
    print(f"  check step {step}: {'OK  ' if ok else 'FAIL'} expects {needle!r}")

if lab == 10:  # targets and capstone API, offline
    from bankassist.evaluation import make_targets

    for name, target in make_targets().items():
        try:
            out = target({"question": "What is the MAB for a Classic Savings account in a metro branch?"})
            assert {"answer", "retrieved_ids", "contexts"} <= out.keys()
            print(f"  target {name}: OK   retrieved {out['retrieved_ids'][:3]}")
        except Exception as exc:  # noqa: BLE001
            failed += 1
            print(f"  target {name}: FAIL {type(exc).__name__}: {exc}")
    from fastapi.testclient import TestClient

    from bankassist.api import api

    with TestClient(api) as client:
        h = client.get("/health").json()
        r1 = client.post("/chat", json={"customer_id": "C1001", "session_id": "smoke",
                                         "message": "Please block my debit card ending 4321, my PAN ABCDE1234F"}).json()
        r0 = client.post("/approve", json={"customer_id": "C1001", "session_id": "nothing", "decision": "approve",
                                           "reviewer": "qa"})
        r2 = client.post("/approve", json={"customer_id": "C1001", "session_id": "smoke", "decision": "approve",
                                           "reviewer": "qa"}).json()
    api_ok = (h["ready"] and r1["status"] == "pending_approval" and r1["details"]["card_last4"] == "4321"
              and r0.status_code == 409 and "blocked" in r2["answer"])
    failed += not api_ok
    print(f"  capstone API: {'OK  ' if api_ok else 'FAIL'} health={h} chat={r1['status']} "
          f"409-when-idle={r0.status_code == 409} approve={r2.get('answer')}")

print(f"RESULT lab{lab:02d}: {'PASS' if not failed else f'{failed} FAILURE(S)'}")
sys.exit(1 if failed else 0)

# Model card: BankAssist 360 (capstone)

A one-page record for model-risk review. Fill in every field marked _(fill in)_ from your Lab 10 runs; the rest
is already true of the reference build. Stretch goal of the capstone (theory deck, "Capstone lab").

## Overview

| Field | Value |
| --- | --- |
| System | BankAssist 360, retail-banking assistant for Apex National Bank (India, INR) |
| Version | _(fill in: git commit or tag of `lab10-evaluation-release`)_ |
| Owner | _(fill in: team and accountable person)_ |
| Risk tier | _(fill in: your bank's model-risk tier)_ |
| Date | _(fill in)_ |

## Intended use

Customer-facing answers about the bank's own published policies (fees, savings, cards, home loans, KYC), account
queries for the logged-in customer (balance, recent transactions, EMI), and card-block requests that a human
approves before anything changes.

## Out of scope

Investment, tax or legal advice; money transfers (no transfer tool exists); decisions about credit or
complaints; any customer other than the logged-in one; staff-only procedures for customers.

## Models and tools

| Role | Model or tool | Setting |
| --- | --- | --- |
| Answers, agent, vision | Gemini 3.8 Flash | `LLM_MODEL=google_genai:gemini-3.8-flash` |
| Routing, grading, rewrites | Gemini 3.5 Flash-Lite | `FAST_LLM_MODEL=google_genai:gemini-3.5-flash-lite` |
| Evaluation judge | Gemini 4 Argon | `JUDGE_MODEL=google_genai:gemini-4-argon` |
| Embeddings | Gemini Embedding 2 | `EMBED_MODEL=gemini-embedding-2` |
| Retrieval | BM25 + FAISS, RRF, cross-encoder re-ranking | Lab 7 advanced retriever |
| Orchestration | LangGraph (workflow, corrective RAG), LangChain v1 | Labs 4 and 9 |
| Observability | LangSmith (project `bankassist360`) | Traces, datasets, feedback |

Model IDs verified against the Gemini API changelog on _(fill in date)_.

## Data

Seven policy documents in `data/policies/` (one superseded, one staff-only), the loan rate-card PDF, and synthetic
customers and transactions. No real customer data. Evaluation: `data/eval/golden_set.jsonl` (30 questions,
including out-of-scope ones).

## Evaluation

Results of the release-candidate experiment (`make gate`, LangSmith experiment `release-candidate`).

| Metric | Target | Result | Pass |
| --- | --- | --- | --- |
| Faithfulness | 0.90 | _(fill in)_ | _(fill in)_ |
| Retrieval recall@5 | 0.85 | _(fill in)_ | _(fill in)_ |
| Retrieval precision@5 | 0.60 | _(fill in)_ | _(fill in)_ |
| Correctness | 0.85 | _(fill in)_ | _(fill in)_ |

Link to the LangSmith experiment: _(fill in)_

## Controls

| Risk | Control | Where |
| --- | --- | --- |
| Acting for the wrong customer | Customer ID injected from run config, never from the model | `tools.py` |
| Unapproved card blocks | `interrupt` + human `approve` before `execute_block` | `workflow.py` |
| PII in prompts and traces | `mask_pii()` at every entry point | `guardrails.py`, `api.py` |
| Prompt injection from documents | Context marked as reference data, not instructions | `prompts.py` |
| Outdated or internal policy | Only current, public chunks are indexed for customers; Lab 8 adds metadata filters by role | `retrievers.py`, `multimodal.py` |
| Ungrounded answers | Grounding check, then retry or flag | `agentic_rag.py` |
| Quality regressions | Release gate on the golden set | `scripts/release_gate.py` |

## Known limitations

_(fill in from your failure review: which golden-set questions fail and why)_

## Monitoring

Production traces in LangSmith with user feedback (`user_score`); rerun the release gate on every change to
prompts, models, chunking or policy documents. Review owner and frequency: _(fill in)_

## Approval

| Role | Name | Date |
| --- | --- | --- |
| Model owner | _(fill in)_ | _(fill in)_ |
| Model risk | _(fill in)_ | _(fill in)_ |
| Compliance | _(fill in)_ | _(fill in)_ |

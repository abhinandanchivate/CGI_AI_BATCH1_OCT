"""How to run each lab: keys, first-run behaviour and files created. Used by README generation and the lab guide.

Keep in sync with labs/ and modules/ (checked by the offline smoke run in tools/smoke.py).
"""

TESTS = {1: 6, 2: 7, 3: 18, 4: 26, 5: 38, 6: 42, 7: 45, 8: 49, 9: 50, 10: 54}

KEYS_REQUIRED = "GOOGLE_API_KEY, LANGSMITH_API_KEY"
KEYS_OPTIONAL = {9: "TAVILY_API_KEY", 10: "TAVILY_API_KEY"}

RUN: dict[int, list[str]] = {
    1: [
        "Steps 4, 5 and 7 are best inspected in LangSmith (project `bankassist360`): keep `LANGSMITH_TRACING=true`.",
        "Step 6 sends a batch of five messages with `max_concurrency=3`, then streams one reply token by token.",
        "Nothing is written to disk.",
    ],
    2: [
        "All memory is in-process (`InMemorySaver`, `InMemoryStore`), so every run starts fresh. That is intended.",
        "Step 4 makes no model call: it only trims an 81-message history and prints the count.",
        "Step 5 summarises once a thread passes 10 messages; look for the summary call in LangSmith.",
    ],
    3: [
        "Uses `data/customers.json` and `data/transactions.csv`; `make data` regenerates them identically.",
        "The agent always acts for customer C1001 (from the run config), whatever the message says.",
        "Card status changes live in memory only; rerunning resets them.",
    ],
    4: [
        "Step 5 pauses at the human-approval interrupt and resumes with `approve` in the same run.",
        "Step 6 classifies the 20 questions in `data/eval/routing_set.jsonl` (20 model calls).",
        "Card 4321 is blocked in memory only; rerunning resets it.",
    ],
    5: [
        "Step 4 saves FAISS to `indexes/faiss_policies/`; step 6 reloads it. Step 5 persists Chroma in "
        "`indexes/chroma_policies/` (13 chunks; rerunning keeps 13).",
        "Run `make clean` after changing `EMBED_MODEL`: old vectors have a different size.",
    ],
    6: [
        "Step 1 builds five temporary FAISS indexes and the semantic chunker embeds every sentence: the most "
        "embedding-heavy step of the course. Expect a minute or two.",
        "Step 7 makes no API calls at all (exact code lookup).",
    ],
    7: [
        "`make install` pulls in sentence-transformers (and PyTorch): a large first download.",
        "The first re-ranked query downloads `cross-encoder/ms-marco-MiniLM-L-6-v2` (about 90 MB) from Hugging Face "
        "and caches it.",
        "Step 5 runs the 15 hard-set questions through five configurations; multi-query adds one fast-model call per "
        "question.",
    ],
    8: [
        "Steps 2 and 6 build the Chroma collection `policies_v2` (all policies plus the rate card). Building it "
        "summarises the table and captions the chart (two extra model calls) each run.",
        "Step 4 writes the extracted chart to `indexes/images/loan_rate_card_p1_0.png`.",
        "`make data` regenerates the data and both PDFs.",
    ],
    9: [
        "Without `TAVILY_API_KEY` the live route returns no documents, so the repo-rate question ends with the "
        "not-found reply. Everything else works.",
        "The graph uses the Lab 7 advanced retriever (glossary on), so the first query builds the indexes and loads "
        "the cross-encoder.",
    ],
    10: [
        "Steps 1, 5, 6 and 8 talk to LangSmith: `LANGSMITH_API_KEY` is required.",
        "Step 5 runs 30 questions through three versions plus judge calls: allow several minutes. On a free-tier "
        "Gemini key, lower `max_concurrency` in `run_experiment` if you hit 429 errors.",
        "Step 6 enables the SQLite LLM cache at `indexes/llm_cache.db`: run it twice and compare latency.",
        "`make api` serves the capstone at http://127.0.0.1:8000/docs (thread state in `indexes/threads.db`); "
        "`make gate` exits 1 when any target is missed.",
        "Stretch goal: complete `docs/MODEL_CARD.md` from your release-gate results.",
    ],
}

TROUBLESHOOTING = [
    ("`ModuleNotFoundError: bankassist`", "The virtual environment is not active or the project is not installed.",
     "Activate `.venv`, then `make install` (or `python -m pip install -e \".[dev]\"`)."),
    ("`make: command not found` (Windows)", "make is not installed.",
     "Run the commands directly: `pytest`, `python -m bankassist.lab --step N`."),
    ("`Activate.ps1 cannot be loaded` (Windows)", "PowerShell blocks local scripts by default.",
     "Run `Set-ExecutionPolicy -Scope Process RemoteSigned`, then activate again."),
    ("400 or 404 from Gemini naming the model", "The model ID in `.env` is retired or mistyped.",
     "Check the IDs against the Gemini API changelog and update `LLM_MODEL`, `FAST_LLM_MODEL`, `JUDGE_MODEL`."),
    ("429 or `RESOURCE_EXHAUSTED`", "Free-tier rate limit.",
     "Wait a minute, lower concurrency (Lab 1 step 6, Lab 10 `run_experiment`), or use a paid key."),
    ("No traces in LangSmith", "Tracing is off, the key is wrong, or you are looking at another project.",
     "Set `LANGSMITH_TRACING=true` and `LANGSMITH_API_KEY`; open project `bankassist360`."),
    ("Chroma or FAISS dimension error", "Indexes were built with another embedding model.",
     "`make clean`, then rerun the step."),
    ("Lab 7 or later: first query is slow", "The cross-encoder is downloading.", "Wait once; it is cached afterwards."),
    ("Lab 10 `/approve` returns 409", "Nothing is waiting for approval on that session.",
     "Send a card-block request to `/chat` first with the same `session_id`."),
]

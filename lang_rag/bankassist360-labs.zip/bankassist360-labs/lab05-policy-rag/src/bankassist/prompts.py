"""Prompt templates for the RAG labs: RAG_PROMPT (Lab 5) and the banking domain prompt (Lab 8)."""

from __future__ import annotations

from langchain_core.prompts import ChatPromptTemplate

from bankassist.guardrails import INJECTION_GUARD

NOT_FOUND = "I could not find this in the bank's policy documents."

RAG_PROMPT = ChatPromptTemplate.from_template(
    "You are BankAssist. Answer ONLY from the context below.\n"
    "Cite the document ID in square brackets after each fact.\n"
    f"If the answer is not in the context, say: '{NOT_FOUND}'\n"
    f"{INJECTION_GUARD}\n\n"
    "Context:\n{context}\n\nQuestion: {question}"
)

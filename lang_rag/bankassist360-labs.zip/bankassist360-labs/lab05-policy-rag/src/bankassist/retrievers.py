"""Retrieval building blocks.

Lab 5: load_policies, split_recursive / split_markdown, build_chunks, format_docs, FAISS and Chroma
Lab 6: exact_code_lookup, load_eval, hit_rate
Lab 7: rrf, CrossEncoderReranker, AdvancedRetriever, get_advanced_retriever
Lab 8: GLOSSARY, expand_query (plugged into the advanced retriever)

Functions that need embeddings accept an ``embeddings`` argument, so tests can pass a fake.
"""

from __future__ import annotations

import re
from collections import defaultdict
from collections.abc import Iterable
from pathlib import Path

from langchain_core.documents import Document
from langchain_text_splitters import MarkdownHeaderTextSplitter, RecursiveCharacterTextSplitter

from bankassist.config import INDEX_DIR, POLICY_DIR, get_embeddings, get_logger

log = get_logger(__name__)

FAISS_DIR = INDEX_DIR / "faiss_policies"
CHROMA_DIR = INDEX_DIR / "chroma_policies"

_HEADER_FIELDS = {
    "doc_id": re.compile(r"Document ID:\s*([\w-]+)"),
    "effective": re.compile(r"Effective:\s*([\w-]+)"),
    "audience": re.compile(r"Audience:\s*(\w+)"),
}
_SECTION_IN_TEXT = re.compile(r"^##\s*(\d+)\.", re.MULTILINE)  # first section heading in a chunk


# ---------------------------------------------------------------- loading (Lab 5)
def load_policies(folder: Path = POLICY_DIR) -> list[Document]:
    """Load every markdown policy with document-level metadata."""
    docs: list[Document] = []
    for path in sorted(Path(folder).glob("*.md")):
        text = path.read_text(encoding="utf-8")
        meta = {"source": path.name, "title": text.splitlines()[0].lstrip("# ").strip(),
                "category": path.stem.split("_")[0]}
        for key, pattern in _HEADER_FIELDS.items():
            match = pattern.search(text)
            meta[key] = match.group(1) if match else "unknown"
        if meta["doc_id"] == "unknown":
            meta["doc_id"] = path.stem
        meta["is_current"] = "superseded" not in text.splitlines()[1].lower()
        docs.append(Document(page_content=text, metadata=meta))
    log.info("Loaded %d policy documents from %s", len(docs), folder)
    return docs


# ---------------------------------------------------------------- chunking (Lab 5)
def _assign_ids(chunks: list[Document]) -> list[Document]:
    """Give every chunk a stable ``chunk_id`` and a ``source_ref`` (doc_id#section)."""
    counters: dict[str, int] = defaultdict(int)
    last_section: dict[str, str] = {}
    for c in chunks:
        section = c.metadata.get("section", "")
        match = re.match(r"(\d+)", section) or _SECTION_IN_TEXT.search(c.page_content)
        # A chunk that starts mid-section inherits the previous chunk's section in the same document.
        sec_no = match.group(1) if match else last_section.get(c.metadata["doc_id"], "0")
        last_section[c.metadata["doc_id"]] = sec_no
        ref = f"{c.metadata['doc_id']}#{sec_no}"
        c.metadata["source_ref"] = ref
        c.metadata["chunk_id"] = f"{ref}-{counters[ref]:02d}"
        counters[ref] += 1
    return chunks


def split_recursive(docs: list[Document], chunk_size: int = 800, overlap: int = 100) -> list[Document]:
    """Baseline: recursive character splitting that prefers headings and paragraphs."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, chunk_overlap=overlap,
        separators=["\n## ", "\n\n", "\n", ". ", " "])
    return _assign_ids(splitter.split_documents(docs))


def split_markdown(docs: list[Document], max_size: int = 1000, overlap: int = 100) -> list[Document]:
    """Structure-aware: split on '#'/'##' headings, then by size. Keeps tables with their section."""
    header_splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=[("#", "doc_title"), ("##", "section")], strip_headers=False)
    sizer = RecursiveCharacterTextSplitter(chunk_size=max_size, chunk_overlap=overlap)
    chunks: list[Document] = []
    for doc in docs:
        for sec in header_splitter.split_text(doc.page_content):
            sec.metadata = {**doc.metadata, **sec.metadata}
            chunks.extend(sizer.split_documents([sec]))
    return _assign_ids(chunks)


def build_chunks(strategy: str = "markdown", folder: Path = POLICY_DIR) -> list[Document]:
    """Load and chunk policies (markdown-header chunking is the Lab 6 winner)."""
    docs = load_policies(folder)
    if strategy == "markdown":
        return split_markdown(docs)
    if strategy == "recursive":
        return split_recursive(docs)
    raise ValueError(f"unknown chunking strategy: {strategy}")


def format_docs(docs: Iterable[Document]) -> str:
    """Render chunks for a prompt, each tagged with its citation reference."""
    return "\n\n".join(
        f"[{d.metadata.get('source_ref', d.metadata.get('doc_id', 'unknown'))}] {d.page_content}"
        for d in docs)


# ---------------------------------------------------------------- vector stores (Lab 5)
def build_faiss(chunks: list[Document], embeddings=None, save_dir: Path | None = FAISS_DIR):
    """Embed chunks into a FAISS index and optionally save it."""
    from langchain_community.vectorstores import FAISS

    store = FAISS.from_documents(chunks, embeddings or get_embeddings())
    if save_dir:
        store.save_local(str(save_dir))
        log.info("Saved FAISS index (%d chunks) to %s", len(chunks), save_dir)
    return store


def load_faiss(embeddings=None, load_dir: Path = FAISS_DIR):
    """Reload a FAISS index we created ourselves (pickle => only trust your own files)."""
    from langchain_community.vectorstores import FAISS

    return FAISS.load_local(str(load_dir), embeddings or get_embeddings(),
                            allow_dangerous_deserialization=True)


def build_chroma(chunks: list[Document], embeddings=None, collection: str = "policies",
                 persist_dir: Path | None = CHROMA_DIR):
    """Embed chunks into a persistent Chroma collection. Stable IDs make re-runs idempotent."""
    from langchain_chroma import Chroma

    kwargs = {"persist_directory": str(persist_dir)} if persist_dir else {}
    store = Chroma(collection_name=collection, embedding_function=embeddings or get_embeddings(), **kwargs)
    ids = [c.metadata["chunk_id"] for c in chunks]
    existing = set(store.get(ids=ids)["ids"]) if ids else set()
    if existing:
        store.delete(ids=list(existing))  # replace changed chunks instead of duplicating
    store.add_documents(chunks, ids=ids)
    log.info("Chroma collection '%s' now holds %d chunks", collection, len(chunks))
    return store

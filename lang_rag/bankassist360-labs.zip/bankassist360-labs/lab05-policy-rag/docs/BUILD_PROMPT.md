# Build prompt: BankAssist 360, Lab 5 (lab05-policy-rag)

Paste everything below into an AI coding assistant (Gemini, Claude, Copilot Chat) from the project
root. Review every file it returns, then run `make install && make test`.

---

You are a senior Python engineer building one lab of the BankAssist 360 course: a retail-banking
assistant for the fictional Apex National Bank (India, amounts in INR), built with LangChain v1,
LangGraph v1, LangSmith and Google Gemini.

GOAL (Lab 5: Policy Q&A with RAG, FAISS and Chroma)
Sessions: S033 Introduction to RAG · S034 Vector Databases (FAISS, Chroma)
Answer policy questions from the bank's own documents, with citations, and refuse when the answer is not
there.

STARTING POINT:
Copy the project `lab04-langgraph-workflow` to `lab05-policy-rag`, delete its `src/bankassist/lab.py`,
and keep these files unchanged unless this prompt says the file grows:
    src/bankassist/: config.py, cli.py, chains.py, memory.py, data_access.py, tools.py, agent.py,
    workflow.py

PROJECT STRUCTURE (create exactly this; '<- new in this lab' marks what you write now):

    lab05-policy-rag/
      pyproject.toml          dependencies, ruff, pytest
      Makefile
      README.md
      .env.example
      .github/workflows/ci.yml
      .pre-commit-config.yaml
      src/bankassist/
        __init__.py            package marker and version
        config.py              settings, paths, logging, Gemini model factories
        cli.py                 --step runner
        chains.py              triage chain and Ticket schema
        memory.py              trimming, summaries, checkpointer, store
        data_access.py         synthetic core-banking data
        tools.py               banking tools (identity from config)
        agent.py               create_agent banking agent
        workflow.py            LangGraph routing + human approval
        guardrails.py          PII masking, injection guard   <- new in this lab
        prompts.py             RAG and domain prompts   <- new in this lab
        retrievers.py          loading, chunking, vector stores, matching, hybrid, glossary   <- new in this lab
        rag.py                 RAG chains returning answer + evidence   <- new in this lab
        lab.py                 this lab's runnable steps   <- new in this lab
        assignments/           your part 12 and 13 work
      scripts/
        generate_sample_data.py
      data/
        eval/routing_set.jsonl
        customers.json
        transactions.csv
        policies   <- new in this lab
      tests/
        conftest.py
        test_config.py
        test_chains.py
        test_memory.py
        test_tools.py
        test_workflow.py
        test_guardrails.py   <- new in this lab
        test_loaders.py   <- new in this lab
      indexes/                generated at run time (git-ignored)
      docs/Lab05.pptx
      docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant

DEPENDENCIES (pyproject.toml [project].dependencies):
    langchain>=1.0,<2, langchain-core>=1.0,<2, langchain-google-genai>=4.4, langsmith>=0.4,
    pydantic>=2.6, python-dotenv>=1.0, langgraph>=1.0,<2, pandas>=2.0, langchain-community>=0.4,
    langchain-chroma>=1.0, langchain-text-splitters>=1.0, faiss-cpu>=1.8, chromadb>=0.5

AI TOOLS (use exactly these; declare their names in lab.py as AI_TOOLS, in this order):
    - Gemini 3.8 Flash: Cited answers, or the not-found refusal
    - Gemini Embedding 2: Chunk and query embeddings
    - FAISS: Local vector index, saved and reloaded
    - Chroma: Persistent vector store with metadata filters
    - LangChain RAG chain: Loaders, splitters, retriever and prompt returning answer + evidence
    - LangSmith: RAG traces showing the retrieved chunks
    Model IDs come from .env: LLM_MODEL=google_genai:gemini-3.8-flash; EMBED_MODEL=gemini-embedding-2

CODING STANDARDS:
- Python 3.11+, src layout: package `bankassist` under `src/`,
  installable with `pip install -e ".[dev]"`.
- `pyproject.toml` is the single source of dependencies (setuptools build, `dev` extra with pytest, ruff,
  pre-commit), ruff (line length 120; rules E, F, W, I, B, UP, SIM, RUF; `bankassist` is first-party) and
  pytest settings (`testpaths = ["tests"]`, `pythonpath = ["src", "."]`).
- Configuration only through `.env`, loaded once in `config.py`; never hard-code keys. Ship `.env.example`.
- Models: `init_chat_model("google_genai:<model>")`. Gemini 3+ deprecates temperature, top_p and top_k:
  never pass them for Gemini; pass `thinking_level` from `THINKING_LEVEL` instead. Embeddings:
  `GoogleGenerativeAIEmbeddings(model="gemini-embedding-2")`. Default models: main `gemini-3.8-flash`,
  fast `gemini-3.5-flash-lite`, judge `gemini-4-argon`.
- No import-time side effects: models, indexes and graphs are created by `build_*` / `get_*` functions,
  cached with `functools.lru_cache` where reuse matters. Pass dependencies (retriever, models, embeddings)
  as arguments so tests can inject fakes.
- Type hints and a docstring on every module and public function; Pydantic models for every structured LLM output.
- Library modules log with `get_logger(__name__)`; only `lab.py` prints results.
- Security: customer identity comes from `RunnableConfig["configurable"]["customer_id"]`, never from model
  arguments; money-moving actions need human approval; mask PII before it reaches a model or a trace.
- Tests run offline: `tests/conftest.py` sets a fake `GOOGLE_API_KEY`, `LANGSMITH_TRACING=false` and provides a
  `DeterministicFakeEmbedding` fixture. No test may call a real API.
- `lab.py` exposes `main()` that calls `bankassist.cli.run_steps(title, {number: step_function}, tools=AI_TOOLS)`;
  each step function's first docstring line is its description, and `AI_TOOLS` (a module-level tuple) names the
  lab's AI tools, shown by `--help`. `python -m bankassist.lab --step N` runs one step.

FILES TO WRITE:

src/bankassist/guardrails.py: Guardrails shared by every entry point: PII masking and prompt-injection
  defence.
  Public API (implement exactly these names and signatures):
    constant PII_PATTERNS
    constant INJECTION_GUARD
    def mask_pii(text: str) -> str
        # Replace common Indian identifiers with labels such as <CARD> or <PAN>.

src/bankassist/prompts.py: Prompt templates for the RAG labs: RAG_PROMPT (Lab 5) and the banking domain prompt
  (Lab 8).
  Public API (implement exactly these names and signatures):
    constant NOT_FOUND = "I could not find this in the bank's policy documents."
    constant RAG_PROMPT

src/bankassist/retrievers.py: Retrieval building blocks.
  Public API (implement exactly these names and signatures):
    constant FAISS_DIR = INDEX_DIR / 'faiss_policies'
    constant CHROMA_DIR = INDEX_DIR / 'chroma_policies'
    def load_policies(folder: Path=POLICY_DIR) -> list[Document]
        # Load every markdown policy with document-level metadata.
    def split_recursive(docs: list[Document], chunk_size: int=800, overlap: int=100) -> list[Document]
        # Baseline: recursive character splitting that prefers headings and paragraphs.
    def split_markdown(docs: list[Document], max_size: int=1000, overlap: int=100) -> list[Document]
        # Structure-aware: split on '#'/'##' headings, then by size. Keeps tables with their section.
    def build_chunks(strategy: str='markdown', folder: Path=POLICY_DIR) -> list[Document]
        # Load and chunk policies (markdown-header chunking is the Lab 6 winner).
    def format_docs(docs: Iterable[Document]) -> str
        # Render chunks for a prompt, each tagged with its citation reference.
    def build_faiss(chunks: list[Document], embeddings=None, save_dir: Path | None=FAISS_DIR)
        # Embed chunks into a FAISS index and optionally save it.
    def load_faiss(embeddings=None, load_dir: Path=FAISS_DIR)
        # Reload a FAISS index we created ourselves (pickle => only trust your own files).
    def build_chroma(chunks: list[Document], embeddings=None, collection: str='policies', persist_dir: Path | None=CHROMA_DIR)
        # Embed chunks into a persistent Chroma collection. Stable IDs make re-runs idempotent.

src/bankassist/rag.py: RAG chains: the chain factory and baseline (Lab 5), the advanced chain (Lab 7).
  Public API (implement exactly these names and signatures):
    def build_rag_chain(retriever: Runnable, prompt: ChatPromptTemplate=RAG_PROMPT, llm=None, run_name: str='policy_rag') -> Runnable
        # question (str) -> {"question", "docs", "answer"}.
    def baseline_chunks()
        # Lab 5 baseline: recursive 800/100 over current, public documents (staff-only text never indexed).
    def build_basic_rag(k: int=4) -> Runnable
        # FAISS-backed RAG chain (reloads the saved index when present). Lab 10's baseline.
    def policy_qa_rag(state) -> dict
        # Drop-in replacement for the Lab 4 workflow's policy_qa stub.

IMPLEMENTATION RULES (the tests and the lab guide depend on these):
    - `load_policies`: doc_id, effective and audience come from the header line (`Document ID: ...`,
      `Effective: ...`, `Audience: ...`); is_current is False when the second line contains 'superseded';
      category is the filename prefix.
    - `_assign_ids`: section number from `section` metadata or the first `## N.` heading in the chunk; a chunk
      without a heading inherits the previous chunk's section in the same document; source_ref =
      `{doc_id}#{section}`, chunk_id = `{source_ref}-{nn:02d}`.
    - `split_recursive` separators: '\n## ', '\n\n', '\n', '. ', ' '. `split_markdown` splits on '#' and '##'
      (strip_headers=False), merges parent metadata, then sizes with a recursive splitter.
    - `load_faiss` uses `allow_dangerous_deserialization=True` (own files only). `build_chroma` deletes
      existing ids before `add_documents(ids=...)` so re-indexing is idempotent.
    - rag.py: `build_rag_chain` returns {'question', 'docs', 'answer'} (RunnableParallel + assign);
      `baseline_chunks` = recursive chunks that are current AND public; `build_basic_rag` reloads FAISS if
      indexes/faiss_policies/index.faiss exists.
    - guardrails.py: mask CARD before AADHAAR so a 16-digit number is not partly masked; prompts.py:
      RAG_PROMPT cites `[doc_id]`, refuses with NOT_FOUND and includes INJECTION_GUARD.

src/bankassist/lab.py: this lab's runnable steps, registered in run_steps() with these numbers:
    --step 1: Show the problem: the model does not know this bank's policy
    --step 2: Load documents with metadata and split them into chunks
    --step 4: Embed into FAISS, save, reload and search
    --step 5: Index the same chunks in Chroma and use a metadata filter
    --step 6: Answer the test questions with citations (and refuse the out-of-scope one)

DATA (provided by the course; copy it, do not invent it):
    data/eval/routing_set.jsonl
    data/customers.json
    data/transactions.csv
    data/policies   <- new in this lab

TESTS (offline, pytest). Write these new test functions:
  tests/test_guardrails.py
    test_identifiers_are_masked
        # checks: identifiers are masked
    test_card_not_partly_masked_as_aadhaar
        # checks: card not partly masked as aadhaar
    test_plain_text_unchanged
        # checks: plain text unchanged
  tests/test_loaders.py
    test_policies_load_with_metadata
        # checks: policies load with metadata
    test_markdown_chunks_have_unique_ids_and_section_refs
        # checks: markdown chunks have unique ids and section refs
    test_tables_stay_with_their_section
        # checks: tables stay with their section
    test_recursive_chunks_also_get_section_refs
        # checks: recursive chunks also get section refs
    test_chroma_reindex_is_idempotent
        # checks: chroma reindex is idempotent

ALSO WRITE OR UPDATE: README.md (setup, steps table, expected outputs, structure),
.env.example (only the keys this lab needs), Makefile (install, test, lint, run STEP=N, data), .gitignore,
.pre-commit-config.yaml (ruff, private-key detection), .github/workflows/ci.yml
(ruff + pytest on Python 3.11 and 3.12).

EXPECTED BEHAVIOUR WHEN RUN WITH REAL KEYS:
    - Classic Savings metro MAB: INR 10,000 [POL-SAV-2026#1]
    - Car loan question refused
    - Indexes saved under indexes/

ACCEPTANCE CHECKS (all must pass before you finish):
    1. `ruff check .` reports no issues.
    2. `pytest` passes offline with no API keys and no network calls.
    3. `python -m bankassist.lab --help` lists steps 1, 2, 4, 5, 6.
    4. No module creates a model, index or graph at import time.
    5. Gemini models are never given a temperature.

OUTPUT FORMAT: return every new or changed file in full, each preceded by a line
`=== path/to/file ===`.
No placeholders, no 'rest unchanged' comments. After the files, list any assumption you made.

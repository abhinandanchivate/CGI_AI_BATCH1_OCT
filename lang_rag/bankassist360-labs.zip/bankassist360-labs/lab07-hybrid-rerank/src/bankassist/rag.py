"""RAG chains: the chain factory and baseline (Lab 5), the advanced chain (Lab 7).

Every chain returns the answer AND the evidence (``docs``), because evaluation in
Lab 10 needs both.
"""

from __future__ import annotations

from langchain_core.messages import AIMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable, RunnableParallel, RunnablePassthrough

from bankassist.config import get_llm
from bankassist.prompts import RAG_PROMPT
from bankassist.retrievers import (
    FAISS_DIR,
    build_faiss,
    format_docs,
    get_advanced_retriever,
    load_faiss,
    load_policies,
    split_recursive,
)


def build_rag_chain(retriever: Runnable, prompt: ChatPromptTemplate = RAG_PROMPT,
                    llm=None, run_name: str = "policy_rag") -> Runnable:
    """question (str) -> {"question", "docs", "answer"}."""
    generate = (
        {"context": lambda x: format_docs(x["docs"]), "question": lambda x: x["question"]}
        | prompt
        | (llm or get_llm())
        | StrOutputParser()
    )
    chain = RunnableParallel(docs=retriever, question=RunnablePassthrough()) | RunnablePassthrough.assign(
        answer=generate)
    return chain.with_config(run_name=run_name)


def baseline_chunks():
    """Lab 5 baseline: recursive 800/100 over current, public documents (staff-only text never indexed)."""
    return [c for c in split_recursive(load_policies())
            if c.metadata["is_current"] and c.metadata["audience"] == "public"]


def build_basic_rag(k: int = 4) -> Runnable:
    """FAISS-backed RAG chain (reloads the saved index when present). Lab 10's baseline."""
    store = load_faiss() if (FAISS_DIR / "index.faiss").exists() else build_faiss(baseline_chunks())
    return build_rag_chain(store.as_retriever(search_kwargs={"k": k}), run_name="policy_rag_basic")


def policy_qa_rag(state) -> dict:
    """Drop-in replacement for the Lab 4 workflow's policy_qa stub."""
    out = build_basic_rag().invoke(state["messages"][-1].content)
    return {"messages": [AIMessage(out["answer"])]}


def build_advanced_rag() -> Runnable:
    """RAG chain on the advanced retriever (Lab 7). Used by Lab 10 as an experiment."""
    return build_rag_chain(get_advanced_retriever(), run_name="policy_rag_advanced")

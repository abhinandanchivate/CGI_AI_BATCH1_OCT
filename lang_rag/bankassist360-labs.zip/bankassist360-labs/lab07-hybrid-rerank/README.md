# BankAssist 360, Lab 7: Hybrid Search, Multi-Query and Re-ranking

S040 Challenges in RAG · S041 Hybrid Search & Multi-Query RAG

Diagnose where basic RAG fails, then fix it with query expansion, hybrid search fused by rank, and cross-encoder re-ranking.

This project is standalone: it contains everything built in earlier labs (`chains.py`, `memory.py`, `data_access.py`, `tools.py`, `agent.py`, `workflow.py`, `guardrails.py`, `prompts.py`, `retrievers.py`, `rag.py`), so you can
start here without finishing the previous lab. Code from earlier labs is identical to their projects.

## How to run this lab

You need Python 3.11 or 3.12 and these keys in `.env`: `GOOGLE_API_KEY` and `LANGSMITH_API_KEY`. Tests need no keys.

macOS or Linux:

```bash
python3 -m venv .venv && source .venv/bin/activate
make install                 # pip install -e ".[dev]" + pre-commit hooks
cp .env.example .env         # then add your keys
make test                    # offline: expect 45 passed
make run                     # every step in order
make run STEP=6              # one step
```

Windows (PowerShell, no make needed):

```powershell
py -3.11 -m venv .venv; .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
Copy-Item .env.example .env  # then add your keys
pytest                       # offline: expect 45 passed
python -m bankassist.lab     # every step in order
python -m bankassist.lab --step 6  # one step
```

`python -m bankassist.lab --help` lists the steps. Step numbers match the implementation steps in the lab
guide; guide steps without their own command are code you read in `src/bankassist/`, and their effect shows
in the next step that runs.

What to expect when you run it:

- `make install` pulls in sentence-transformers (and PyTorch): a large first download.
- The first re-ranked query downloads `cross-encoder/ms-marco-MiniLM-L-6-v2` (about 90 MB) from Hugging Face and caches it.
- Step 5 runs the 15 hard-set questions through five configurations; multi-query adds one fast-model call per question.

Start again from a clean state with `make clean` (deletes `indexes/`); `make data` regenerates the sample data.

## Steps in this lab

| Command | What it does |
| --- | --- |
| `--step 1` | Run the hard set through vector-only search and list the misses |
| `--step 5` | Measure hit@5 for five retriever configurations on the hard set |
| `--step 6` | Answer a mixed code-and-paraphrase question with the advanced pipeline |

The full walkthrough, code explanations, knowledge check, assignment and modification tasks are in
the BankAssist 360 lab guide (Lab 7). Slides: `docs/Lab07.pptx`. To rebuild this project with an AI
coding assistant, use the prompt in `docs/BUILD_PROMPT.md`.

## AI tools used

| Tool | Role in this lab |
| --- | --- |
| Gemini 3.8 Flash | Answer generation |
| Gemini 3.5 Flash-Lite | Multi-query rephrasings (the fast tier) |
| Gemini Embedding 2 | The vector side of hybrid search |
| BM25 + FAISS | Hybrid retrieval fused with Reciprocal Rank Fusion |
| Cross-encoder (MiniLM) | Re-ranking with cross-encoder/ms-marco-MiniLM-L-6-v2 |
| LangSmith | Compare retriever configurations |

Model names are the defaults in `.env.example`; change them there, never in code. `python -m bankassist.lab --help`
lists the same tools.

## Expected outputs

- Failure log with categorised misses
- hit@5 for 5 retriever configurations
- Full pipeline scores highest

## Concepts covered

- **Failure-mode analysis:** Label misses before fixing
- **Hybrid search:** BM25 + vector together
- **Reciprocal Rank Fusion:** Fuse by 1 / (k + rank)
- **Multi-query:** Rephrasings widen recall
- **Cross-encoder:** Reads question + chunk together
- **Ablation:** Measure each stage's gain

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `ModuleNotFoundError: bankassist` | The virtual environment is not active or the project is not installed. | Activate `.venv`, then `make install` (or `python -m pip install -e ".[dev]"`). |
| `make: command not found` (Windows) | make is not installed. | Run the commands directly: `pytest`, `python -m bankassist.lab --step N`. |
| `Activate.ps1 cannot be loaded` (Windows) | PowerShell blocks local scripts by default. | Run `Set-ExecutionPolicy -Scope Process RemoteSigned`, then activate again. |
| 400 or 404 from Gemini naming the model | The model ID in `.env` is retired or mistyped. | Check the IDs against the Gemini API changelog and update `LLM_MODEL`, `FAST_LLM_MODEL`, `JUDGE_MODEL`. |
| 429 or `RESOURCE_EXHAUSTED` | Free-tier rate limit. | Wait a minute, lower concurrency (Lab 1 step 6, Lab 10 `run_experiment`), or use a paid key. |
| No traces in LangSmith | Tracing is off, the key is wrong, or you are looking at another project. | Set `LANGSMITH_TRACING=true` and `LANGSMITH_API_KEY`; open project `bankassist360`. |
| Chroma or FAISS dimension error | Indexes were built with another embedding model. | `make clean`, then rerun the step. |
| Lab 7 or later: first query is slow | The cross-encoder is downloading. | Wait once; it is cached afterwards. |
| Lab 10 `/approve` returns 409 | Nothing is waiting for approval on that session. | Send a card-block request to `/chat` first with the same `session_id`. |

## Project structure

```text
lab07-hybrid-rerank/
  pyproject.toml          dependencies, ruff, pytest
  Makefile
  README.md
  .env.example
  .github/workflows/ci.yml
  .pre-commit-config.yaml
  src/bankassist/
    __init__.py            package marker and version
    config.py              settings, paths, logging, Gemini model factories
    cli.py                 --step runner
    chains.py              triage chain and Ticket schema
    memory.py              trimming, summaries, checkpointer, store
    data_access.py         synthetic core-banking data
    tools.py               banking tools (identity from config)
    agent.py               create_agent banking agent
    workflow.py            LangGraph routing + human approval
    guardrails.py          PII masking, injection guard
    prompts.py             RAG and domain prompts
    retrievers.py          loading, chunking, vector stores, matching, hybrid, glossary
    rag.py                 RAG chains returning answer + evidence
    lab.py                 this lab's runnable steps   <- new in this lab
    assignments/           your part 12 and 13 work
  scripts/
    generate_sample_data.py
  data/
    eval/routing_set.jsonl
    customers.json
    transactions.csv
    policies
    eval/chunk_eval.jsonl
    eval/hard_set.jsonl   <- new in this lab
  tests/
    conftest.py
    test_config.py
    test_chains.py
    test_memory.py
    test_tools.py
    test_workflow.py
    test_guardrails.py
    test_loaders.py
    test_matching.py
    test_hybrid.py   <- new in this lab
  indexes/                generated at run time (git-ignored)
  docs/Lab07.pptx
  docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant
```

## Standards used

- `src/` layout, installable package, one source of truth for dependencies (`pyproject.toml`)
- Configuration only through `.env` (see `.env.example`); no keys in code
- No import-time side effects: models, indexes and graphs are built by `build_*` / `get_*` functions
- Type hints, docstrings, Pydantic schemas for every structured model output
- `ruff` lint, `pytest` offline tests, pre-commit hooks and a GitHub Actions workflow
- Gemini 3+ models: no `temperature`; `thinking_level` instead (set in `.env`)

## Next

Continue with [Lab 8](../lab08-domain-multimodal/).

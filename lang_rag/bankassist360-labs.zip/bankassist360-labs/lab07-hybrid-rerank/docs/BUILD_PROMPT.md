# Build prompt: BankAssist 360, Lab 7 (lab07-hybrid-rerank)

Paste everything below into an AI coding assistant (Gemini, Claude, Copilot Chat) from the project
root. Review every file it returns, then run `make install && make test`.

---

You are a senior Python engineer building one lab of the BankAssist 360 course: a retail-banking
assistant for the fictional Apex National Bank (India, amounts in INR), built with LangChain v1,
LangGraph v1, LangSmith and Google Gemini.

GOAL (Lab 7: Hybrid Search, Multi-Query and Re-ranking)
Sessions: S040 Challenges in RAG · S041 Hybrid Search & Multi-Query RAG
Diagnose where basic RAG fails, then fix it with query expansion, hybrid search fused by rank, and cross-
encoder re-ranking.

STARTING POINT:
Copy the project `lab06-chunking-matching` to `lab07-hybrid-rerank`, delete its `src/bankassist/lab.py`,
and keep these files unchanged unless this prompt says the file grows:
    src/bankassist/: config.py, cli.py, chains.py, memory.py, data_access.py, tools.py, agent.py,
    workflow.py, guardrails.py, prompts.py, retrievers.py, rag.py

PROJECT STRUCTURE (create exactly this; '<- new in this lab' marks what you write now):

    lab07-hybrid-rerank/
      pyproject.toml          dependencies, ruff, pytest
      Makefile
      README.md
      .env.example
      .github/workflows/ci.yml
      .pre-commit-config.yaml
      src/bankassist/
        __init__.py            package marker and version
        config.py              settings, paths, logging, Gemini model factories
        cli.py                 --step runner
        chains.py              triage chain and Ticket schema
        memory.py              trimming, summaries, checkpointer, store
        data_access.py         synthetic core-banking data
        tools.py               banking tools (identity from config)
        agent.py               create_agent banking agent
        workflow.py            LangGraph routing + human approval
        guardrails.py          PII masking, injection guard
        prompts.py             RAG and domain prompts
        retrievers.py          loading, chunking, vector stores, matching, hybrid, glossary
        rag.py                 RAG chains returning answer + evidence
        lab.py                 this lab's runnable steps   <- new in this lab
        assignments/           your part 12 and 13 work
      scripts/
        generate_sample_data.py
      data/
        eval/routing_set.jsonl
        customers.json
        transactions.csv
        policies
        eval/chunk_eval.jsonl
        eval/hard_set.jsonl   <- new in this lab
      tests/
        conftest.py
        test_config.py
        test_chains.py
        test_memory.py
        test_tools.py
        test_workflow.py
        test_guardrails.py
        test_loaders.py
        test_matching.py
        test_hybrid.py   <- new in this lab
      indexes/                generated at run time (git-ignored)
      docs/Lab07.pptx
      docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant

DEPENDENCIES (pyproject.toml [project].dependencies):
    langchain>=1.0,<2, langchain-core>=1.0,<2, langchain-google-genai>=4.4, langsmith>=0.4,
    pydantic>=2.6, python-dotenv>=1.0, langgraph>=1.0,<2, pandas>=2.0, langchain-community>=0.4,
    langchain-chroma>=1.0, langchain-text-splitters>=1.0, faiss-cpu>=1.8, chromadb>=0.5,
    rank_bm25>=0.2, langchain-experimental>=0.4, sentence-transformers>=3.0

AI TOOLS (use exactly these; declare their names in lab.py as AI_TOOLS, in this order):
    - Gemini 3.8 Flash: Answer generation
    - Gemini 3.5 Flash-Lite: Multi-query rephrasings (the fast tier)
    - Gemini Embedding 2: The vector side of hybrid search
    - BM25 + FAISS: Hybrid retrieval fused with Reciprocal Rank Fusion
    - Cross-encoder (MiniLM): Re-ranking with cross-encoder/ms-marco-MiniLM-L-6-v2
    - LangSmith: Compare retriever configurations
    Model IDs come from .env: LLM_MODEL=google_genai:gemini-3.8-flash; FAST_LLM_MODEL=google_genai:gemini-3.5-flash-lite; EMBED_MODEL=gemini-embedding-2

CODING STANDARDS:
- Python 3.11+, src layout: package `bankassist` under `src/`,
  installable with `pip install -e ".[dev]"`.
- `pyproject.toml` is the single source of dependencies (setuptools build, `dev` extra with pytest, ruff,
  pre-commit), ruff (line length 120; rules E, F, W, I, B, UP, SIM, RUF; `bankassist` is first-party) and
  pytest settings (`testpaths = ["tests"]`, `pythonpath = ["src", "."]`).
- Configuration only through `.env`, loaded once in `config.py`; never hard-code keys. Ship `.env.example`.
- Models: `init_chat_model("google_genai:<model>")`. Gemini 3+ deprecates temperature, top_p and top_k:
  never pass them for Gemini; pass `thinking_level` from `THINKING_LEVEL` instead. Embeddings:
  `GoogleGenerativeAIEmbeddings(model="gemini-embedding-2")`. Default models: main `gemini-3.8-flash`,
  fast `gemini-3.5-flash-lite`, judge `gemini-4-argon`.
- No import-time side effects: models, indexes and graphs are created by `build_*` / `get_*` functions,
  cached with `functools.lru_cache` where reuse matters. Pass dependencies (retriever, models, embeddings)
  as arguments so tests can inject fakes.
- Type hints and a docstring on every module and public function; Pydantic models for every structured LLM output.
- Library modules log with `get_logger(__name__)`; only `lab.py` prints results.
- Security: customer identity comes from `RunnableConfig["configurable"]["customer_id"]`, never from model
  arguments; money-moving actions need human approval; mask PII before it reaches a model or a trace.
- Tests run offline: `tests/conftest.py` sets a fake `GOOGLE_API_KEY`, `LANGSMITH_TRACING=false` and provides a
  `DeterministicFakeEmbedding` fixture. No test may call a real API.
- `lab.py` exposes `main()` that calls `bankassist.cli.run_steps(title, {number: step_function}, tools=AI_TOOLS)`;
  each step function's first docstring line is its description, and `AI_TOOLS` (a module-level tuple) names the
  lab's AI tools, shown by `--help`. `python -m bankassist.lab --step N` runs one step.

FILES TO WRITE:

src/bankassist/retrievers.py GROWS: add these to the existing module, change nothing else:
    def rrf(result_lists: Iterable[list[Document]], k: int=60, top_n: int=20) -> list[Document]
        # Reciprocal Rank Fusion: score = sum over lists of 1 / (k + rank).
    class Queries(BaseModel)
        # Structured output for multi-query generation.
        field queries: list[str]
    constant MULTI_QUERY_PROMPT
    constant DEFAULT_QUERY_TRANSFORM = None
    class CrossEncoderReranker()
        # Lazy wrapper around a sentence-transformers cross-encoder.
        def __init__(self, model_name: str='cross-encoder/ms-marco-MiniLM-L-6-v2') -> None
        def rerank(self, query: str, docs: list[Document], top_n: int=5) -> list[Document]
    class AdvancedRetriever()
        # Multi-query expansion -> BM25 + vector + exact lookup -> RRF -> cross-encoder re-rank.
        def __init__(self, chunks: list[Document], embeddings=None, k: int=10, use_multi_query: bool=True, use_rerank: bool=True, query_generator: Callable[[str], list[str]] | None=None, query_transform: Callable[[str], str] | None=None, reranker: CrossEncoderReranker | None=None) -> None
        def hybrid_search(self, query: str) -> list[Document]
        def generate_queries(self, query: str) -> list[str]
        def retrieve(self, query: str, top_n: int=5) -> list[Document]
        def as_runnable(self, name: str='advanced_retriever') -> Runnable
    @lru_cache(maxsize=1)
    def get_advanced_retriever() -> Runnable
        # Default advanced retriever over current, public policies (built once per process).

src/bankassist/rag.py GROWS: add these to the existing module, change nothing else:
    def build_advanced_rag() -> Runnable
        # RAG chain on the advanced retriever (Lab 7). Used by Lab 10 as an experiment.

IMPLEMENTATION RULES (the tests and the lab guide depend on these):
    - `rrf`: score += 1 / (k + rank + 1) with 0-based rank, merged by chunk_id, sorted descending, first
      top_n.
    - `hybrid_search`: lists = [bm25, vector] plus exact_code_lookup results when any; fuse with rrf.
    - `retrieve`: apply query_transform if set; variants = [query] + generated queries (if use_multi_query);
      rrf over hybrid_search of each variant; cross-encoder re-rank to top_n if use_rerank.
    - `Queries.queries` has max_length 3. CrossEncoderReranker imports sentence-transformers lazily on first
      use and stores `rerank_score` in metadata.
    - `get_advanced_retriever()` is `lru_cache`d, uses current AND public markdown chunks and
      `query_transform=DEFAULT_QUERY_TRANSFORM` (None in Lab 7).

src/bankassist/lab.py: this lab's runnable steps, registered in run_steps() with these numbers:
    --step 1: Run the hard set through vector-only search and list the misses
    --step 5: Measure hit@5 for five retriever configurations on the hard set
    --step 6: Answer a mixed code-and-paraphrase question with the advanced pipeline

DATA (provided by the course; copy it, do not invent it):
    data/eval/routing_set.jsonl
    data/customers.json
    data/transactions.csv
    data/policies
    data/eval/chunk_eval.jsonl
    data/eval/hard_set.jsonl   <- new in this lab

TESTS (offline, pytest). Write these new test functions:
  tests/test_hybrid.py
    test_rrf_rewards_agreement
        # checks: rrf rewards agreement
    test_hybrid_search_finds_code_with_fake_embeddings
        # checks: hybrid search finds code with fake embeddings
    test_injected_query_generator_is_used
        # checks: injected query generator is used

ALSO WRITE OR UPDATE: README.md (setup, steps table, expected outputs, structure),
.env.example (only the keys this lab needs), Makefile (install, test, lint, run STEP=N, data), .gitignore,
.pre-commit-config.yaml (ruff, private-key detection), .github/workflows/ci.yml
(ruff + pytest on Python 3.11 and 3.12).

EXPECTED BEHAVIOUR WHEN RUN WITH REAL KEYS:
    - Failure log with categorised misses
    - hit@5 for 5 retriever configurations
    - Full pipeline scores highest

ACCEPTANCE CHECKS (all must pass before you finish):
    1. `ruff check .` reports no issues.
    2. `pytest` passes offline with no API keys and no network calls.
    3. `python -m bankassist.lab --help` lists steps 1, 5, 6.
    4. No module creates a model, index or graph at import time.
    5. Gemini models are never given a temperature.

OUTPUT FORMAT: return every new or changed file in full, each preceded by a line
`=== path/to/file ===`.
No placeholders, no 'rest unchanged' comments. After the files, list any assumption you made.

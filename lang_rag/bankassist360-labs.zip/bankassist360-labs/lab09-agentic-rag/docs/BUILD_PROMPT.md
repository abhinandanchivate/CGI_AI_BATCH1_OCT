# Build prompt: BankAssist 360, Lab 9 (lab09-agentic-rag)

Paste everything below into an AI coding assistant (Gemini, Claude, Copilot Chat) from the project
root. Review every file it returns, then run `make install && make test`.

---

You are a senior Python engineer building one lab of the BankAssist 360 course: a retail-banking
assistant for the fictional Apex National Bank (India, amounts in INR), built with LangChain v1,
LangGraph v1, LangSmith and Google Gemini.

GOAL (Lab 9: Agentic RAG with Real-Time Retrieval)
Sessions: S043 Agentic RAG · S039 Real-Time Information Retrieval
A retrieval agent that picks a source, grades what it found, rewrites poor queries and verifies grounding
before replying.

STARTING POINT:
Copy the project `lab08-domain-multimodal` to `lab09-agentic-rag`, delete its `src/bankassist/lab.py`,
and keep these files unchanged unless this prompt says the file grows:
    src/bankassist/: config.py, cli.py, chains.py, memory.py, data_access.py, tools.py, agent.py,
    workflow.py, guardrails.py, prompts.py, retrievers.py, rag.py, multimodal.py

PROJECT STRUCTURE (create exactly this; '<- new in this lab' marks what you write now):

    lab09-agentic-rag/
      pyproject.toml          dependencies, ruff, pytest
      Makefile
      README.md
      .env.example
      .github/workflows/ci.yml
      .pre-commit-config.yaml
      src/bankassist/
        __init__.py            package marker and version
        config.py              settings, paths, logging, Gemini model factories
        cli.py                 --step runner
        chains.py              triage chain and Ticket schema
        memory.py              trimming, summaries, checkpointer, store
        data_access.py         synthetic core-banking data
        tools.py               banking tools (identity from config)
        agent.py               create_agent banking agent
        workflow.py            LangGraph routing + human approval
        guardrails.py          PII masking, injection guard
        prompts.py             RAG and domain prompts
        retrievers.py          loading, chunking, vector stores, matching, hybrid, glossary
        rag.py                 RAG chains returning answer + evidence
        multimodal.py          PDF tables/images, filtered retrieval
        agentic_rag.py         corrective RAG graph with live search   <- new in this lab
        lab.py                 this lab's runnable steps   <- new in this lab
        assignments/           your part 12 and 13 work
      scripts/
        generate_sample_data.py
        generate_pdfs.py
      data/
        eval/routing_set.jsonl
        customers.json
        transactions.csv
        policies
        eval/chunk_eval.jsonl
        eval/hard_set.jsonl
        pdfs
      tests/
        conftest.py
        test_config.py
        test_chains.py
        test_memory.py
        test_tools.py
        test_workflow.py
        test_guardrails.py
        test_loaders.py
        test_matching.py
        test_hybrid.py
        test_glossary.py
        test_multimodal.py
        test_agentic_rag.py   <- new in this lab
      indexes/                generated at run time (git-ignored)
      docs/Lab09.pptx
      docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant

DEPENDENCIES (pyproject.toml [project].dependencies):
    langchain>=1.0,<2, langchain-core>=1.0,<2, langchain-google-genai>=4.4, langsmith>=0.4,
    pydantic>=2.6, python-dotenv>=1.0, langgraph>=1.0,<2, pandas>=2.0, langchain-community>=0.4,
    langchain-chroma>=1.0, langchain-text-splitters>=1.0, faiss-cpu>=1.8, chromadb>=0.5,
    rank_bm25>=0.2, langchain-experimental>=0.4, sentence-transformers>=3.0, pymupdf>=1.24,
    pdfplumber>=0.11, reportlab>=4.0, matplotlib>=3.8, langchain-tavily>=0.2

AI TOOLS (use exactly these; declare their names in lab.py as AI_TOOLS, in this order):
    - LangGraph corrective RAG: Route, grade, rewrite, generate and check grounding
    - Gemini 3.8 Flash: Answer generation and direct replies
    - Gemini 3.5 Flash-Lite: Routing, grading, query rewrites and grounding checks
    - Tavily search: Live search restricted to trusted domains
    - Cross-encoder: Re-ranking inside the Lab 7 hybrid retriever
    - LangSmith: Graph traces showing every loop
    Model IDs come from .env: LLM_MODEL=google_genai:gemini-3.8-flash; FAST_LLM_MODEL=google_genai:gemini-3.5-flash-lite

CODING STANDARDS:
- Python 3.11+, src layout: package `bankassist` under `src/`,
  installable with `pip install -e ".[dev]"`.
- `pyproject.toml` is the single source of dependencies (setuptools build, `dev` extra with pytest, ruff,
  pre-commit), ruff (line length 120; rules E, F, W, I, B, UP, SIM, RUF; `bankassist` is first-party) and
  pytest settings (`testpaths = ["tests"]`, `pythonpath = ["src", "."]`).
- Configuration only through `.env`, loaded once in `config.py`; never hard-code keys. Ship `.env.example`.
- Models: `init_chat_model("google_genai:<model>")`. Gemini 3+ deprecates temperature, top_p and top_k:
  never pass them for Gemini; pass `thinking_level` from `THINKING_LEVEL` instead. Embeddings:
  `GoogleGenerativeAIEmbeddings(model="gemini-embedding-2")`. Default models: main `gemini-3.8-flash`,
  fast `gemini-3.5-flash-lite`, judge `gemini-4-argon`.
- No import-time side effects: models, indexes and graphs are created by `build_*` / `get_*` functions,
  cached with `functools.lru_cache` where reuse matters. Pass dependencies (retriever, models, embeddings)
  as arguments so tests can inject fakes.
- Type hints and a docstring on every module and public function; Pydantic models for every structured LLM output.
- Library modules log with `get_logger(__name__)`; only `lab.py` prints results.
- Security: customer identity comes from `RunnableConfig["configurable"]["customer_id"]`, never from model
  arguments; money-moving actions need human approval; mask PII before it reaches a model or a trace.
- Tests run offline: `tests/conftest.py` sets a fake `GOOGLE_API_KEY`, `LANGSMITH_TRACING=false` and provides a
  `DeterministicFakeEmbedding` fixture. No test may call a real API.
- `lab.py` exposes `main()` that calls `bankassist.cli.run_steps(title, {number: step_function}, tools=AI_TOOLS)`;
  each step function's first docstring line is its description, and `AI_TOOLS` (a module-level tuple) names the
  lab's AI tools, shown by `--help`. `python -m bankassist.lab --step N` runs one step.

FILES TO WRITE:

src/bankassist/agentic_rag.py: Agentic RAG (Lab 9): routing, grading, query rewriting, live search and
  grounding checks.
  Public API (implement exactly these names and signatures):
    constant MAX_REWRITES = 2
    constant MAX_GENERATIONS = 2
    constant TRUSTED_DOMAINS = ['rbi.org.in', 'pib.gov.in']
    constant HELPLINE_TEXT = ' Please call 1800-XXX-XXXX or visit your branch.'
    constant STRICT_SUFFIX = '\nSTRICT: use only exact facts from the context; omit anything else.'
    class Route(BaseModel)
        field route: Literal['policy', 'live', 'direct']
    class Grade(BaseModel)
        field relevant: Literal['yes', 'no']
    class Grounded(BaseModel)
        field grounded: Literal['yes', 'no']
        field unsupported_claims: list[str]
    class RAGState(TypedDict)
        field question: str
        field query: str
        field route: str
        field docs: list[Document]
        field answer: str
        field rewrites: int
        field gen_attempts: int
        field grounded: bool
    def make_web_search() -> Callable[[str], list[Document]]
        # Tavily search restricted to trusted domains; returns [] when no API key is set.
    def build_agentic_rag(retriever: Runnable | None=None, web_search: Callable[[str], list[Document]] | None=None, llm=None, fast_llm=None) -> CompiledStateGraph
        # Corrective RAG graph: route -> retrieve -> grade -> (rewrite) -> generate -> verify.
    def make_policy_qa_node(agentic_rag: CompiledStateGraph | None=None) -> Callable
        # Drop-in policy_qa node for the Lab 4 workflow.

IMPLEMENTATION RULES (the tests and the lab guide depend on these):
    - Constants: MAX_REWRITES = 2, MAX_GENERATIONS = 2, TRUSTED_DOMAINS = ['rbi.org.in', 'pib.gov.in'].
    - `build_agentic_rag(retriever=None, web_search=None, llm=None, fast_llm=None)`: all dependencies
      injected; defaults are get_advanced_retriever(), make_web_search(), get_llm(), get_fast_llm(); compile
      with `name='agentic_rag'`.
    - Graph: START -> route_question (fast model, Route: policy|live|direct) -> retrieve | web_search |
      direct_answer. retrieve -> grade_documents (fast model, Grade per chunk via .batch) -> generate if any
      relevant, else rewrite_query while rewrites < MAX_REWRITES, else not_found. rewrite_query -> retrieve.
    - generate uses BANK_PROMPT (role customer) and adds STRICT_SUFFIX after the first attempt;
      check_grounding (Grounded) -> END if grounded, else generate while gen_attempts < MAX_GENERATIONS, else
      flag_unverified. With no docs, grounded only if the answer is the NOT_FOUND refusal.
    - State keeps `question` (never changed) separate from `query` (rewritten). `make_web_search` returns a
      function that returns [] when TAVILY_API_KEY is unset. `make_policy_qa_node` adapts the graph to the Lab
      4 workflow's policy_qa node.

src/bankassist/lab.py: this lab's runnable steps, registered in run_steps() with these numbers:
    --step 1: Agentic RAG lite: the retriever and web search as agent tools
    --step 5: Run the five test questions through the corrective RAG graph

DATA (provided by the course; copy it, do not invent it):
    data/eval/routing_set.jsonl
    data/customers.json
    data/transactions.csv
    data/policies
    data/eval/chunk_eval.jsonl
    data/eval/hard_set.jsonl
    data/pdfs

TESTS (offline, pytest). Write these new test functions:
  tests/test_agentic_rag.py
    test_graph_has_all_corrective_rag_nodes
        # checks: graph has all corrective rag nodes

ALSO WRITE OR UPDATE: README.md (setup, steps table, expected outputs, structure),
.env.example (only the keys this lab needs), Makefile (install, test, lint, run STEP=N, data), .gitignore,
.pre-commit-config.yaml (ruff, private-key detection), .github/workflows/ci.yml
(ruff + pytest on Python 3.11 and 3.12).

EXPECTED BEHAVIOUR WHEN RUN WITH REAL KEYS:
    - Policy question: grounded, cited answer
    - Repo rate: answer with rbi.org.in source
    - "bounce fee?": rewrite, then CHG-CHQ-11
    - Yacht loan: refused with helpline

ACCEPTANCE CHECKS (all must pass before you finish):
    1. `ruff check .` reports no issues.
    2. `pytest` passes offline with no API keys and no network calls.
    3. `python -m bankassist.lab --help` lists steps 1, 5.
    4. No module creates a model, index or graph at import time.
    5. Gemini models are never given a temperature.

OUTPUT FORMAT: return every new or changed file in full, each preceded by a line
`=== path/to/file ===`.
No placeholders, no 'rest unchanged' comments. After the files, list any assumption you made.

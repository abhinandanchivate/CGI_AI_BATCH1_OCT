# BankAssist 360, Lab 9: Agentic RAG with Real-Time Retrieval

S043 Agentic RAG · S039 Real-Time Information Retrieval

A retrieval agent that picks a source, grades what it found, rewrites poor queries and verifies grounding before replying.

This project is standalone: it contains everything built in earlier labs (`chains.py`, `memory.py`, `data_access.py`, `tools.py`, `agent.py`, `workflow.py`, `guardrails.py`, `prompts.py`, `retrievers.py`, `rag.py`, `multimodal.py`), so you can
start here without finishing the previous lab. Code from earlier labs is identical to their projects.

## How to run this lab

You need Python 3.11 or 3.12 and these keys in `.env`: `GOOGLE_API_KEY` and `LANGSMITH_API_KEY`, plus optional `TAVILY_API_KEY` for live search. Tests need no keys.

macOS or Linux:

```bash
python3 -m venv .venv && source .venv/bin/activate
make install                 # pip install -e ".[dev]" + pre-commit hooks
cp .env.example .env         # then add your keys
make test                    # offline: expect 50 passed
make run                     # every step in order
make run STEP=5              # one step
```

Windows (PowerShell, no make needed):

```powershell
py -3.11 -m venv .venv; .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
Copy-Item .env.example .env  # then add your keys
pytest                       # offline: expect 50 passed
python -m bankassist.lab     # every step in order
python -m bankassist.lab --step 5  # one step
```

`python -m bankassist.lab --help` lists the steps. Step numbers match the implementation steps in the lab
guide; guide steps without their own command are code you read in `src/bankassist/`, and their effect shows
in the next step that runs.

What to expect when you run it:

- Without `TAVILY_API_KEY` the live route returns no documents, so the repo-rate question ends with the not-found reply. Everything else works.
- The graph uses the Lab 7 advanced retriever (glossary on), so the first query builds the indexes and loads the cross-encoder.

Start again from a clean state with `make clean` (deletes `indexes/`); `make data` regenerates the sample data and PDFs.

## Steps in this lab

| Command | What it does |
| --- | --- |
| `--step 1` | Agentic RAG lite: the retriever and web search as agent tools |
| `--step 5` | Run the five test questions through the corrective RAG graph |

The full walkthrough, code explanations, knowledge check, assignment and modification tasks are in
the BankAssist 360 lab guide (Lab 9). Slides: `docs/Lab09.pptx`. To rebuild this project with an AI
coding assistant, use the prompt in `docs/BUILD_PROMPT.md`.

## AI tools used

| Tool | Role in this lab |
| --- | --- |
| LangGraph corrective RAG | Route, grade, rewrite, generate and check grounding |
| Gemini 3.8 Flash | Answer generation and direct replies |
| Gemini 3.5 Flash-Lite | Routing, grading, query rewrites and grounding checks |
| Tavily search | Live search restricted to trusted domains |
| Cross-encoder | Re-ranking inside the Lab 7 hybrid retriever |
| LangSmith | Graph traces showing every loop |

Model names are the defaults in `.env.example`; change them there, never in code. `python -m bankassist.lab --help`
lists the same tools.

## Expected outputs

- Policy question: grounded, cited answer
- Repo rate: answer with rbi.org.in source
- "bounce fee?": rewrite, then CHG-CHQ-11
- Yacht loan: refused with helpline

## Concepts covered

- **Agentic RAG:** Decide whether, where, how to retrieve
- **Query routing:** policy, live or direct
- **Corrective RAG:** Grade chunks; rewrite on failure
- **Grounding check:** Every claim supported by context
- **Bounded loops:** MAX_REWRITES, MAX_GENERATIONS
- **Model tiering:** Flash-Lite decides; Flash answers

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `ModuleNotFoundError: bankassist` | The virtual environment is not active or the project is not installed. | Activate `.venv`, then `make install` (or `python -m pip install -e ".[dev]"`). |
| `make: command not found` (Windows) | make is not installed. | Run the commands directly: `pytest`, `python -m bankassist.lab --step N`. |
| `Activate.ps1 cannot be loaded` (Windows) | PowerShell blocks local scripts by default. | Run `Set-ExecutionPolicy -Scope Process RemoteSigned`, then activate again. |
| 400 or 404 from Gemini naming the model | The model ID in `.env` is retired or mistyped. | Check the IDs against the Gemini API changelog and update `LLM_MODEL`, `FAST_LLM_MODEL`, `JUDGE_MODEL`. |
| 429 or `RESOURCE_EXHAUSTED` | Free-tier rate limit. | Wait a minute, lower concurrency (Lab 1 step 6, Lab 10 `run_experiment`), or use a paid key. |
| No traces in LangSmith | Tracing is off, the key is wrong, or you are looking at another project. | Set `LANGSMITH_TRACING=true` and `LANGSMITH_API_KEY`; open project `bankassist360`. |
| Chroma or FAISS dimension error | Indexes were built with another embedding model. | `make clean`, then rerun the step. |
| Lab 7 or later: first query is slow | The cross-encoder is downloading. | Wait once; it is cached afterwards. |
| Lab 10 `/approve` returns 409 | Nothing is waiting for approval on that session. | Send a card-block request to `/chat` first with the same `session_id`. |

## Project structure

```text
lab09-agentic-rag/
  pyproject.toml          dependencies, ruff, pytest
  Makefile
  README.md
  .env.example
  .github/workflows/ci.yml
  .pre-commit-config.yaml
  src/bankassist/
    __init__.py            package marker and version
    config.py              settings, paths, logging, Gemini model factories
    cli.py                 --step runner
    chains.py              triage chain and Ticket schema
    memory.py              trimming, summaries, checkpointer, store
    data_access.py         synthetic core-banking data
    tools.py               banking tools (identity from config)
    agent.py               create_agent banking agent
    workflow.py            LangGraph routing + human approval
    guardrails.py          PII masking, injection guard
    prompts.py             RAG and domain prompts
    retrievers.py          loading, chunking, vector stores, matching, hybrid, glossary
    rag.py                 RAG chains returning answer + evidence
    multimodal.py          PDF tables/images, filtered retrieval
    agentic_rag.py         corrective RAG graph with live search   <- new in this lab
    lab.py                 this lab's runnable steps   <- new in this lab
    assignments/           your part 12 and 13 work
  scripts/
    generate_sample_data.py
    generate_pdfs.py
  data/
    eval/routing_set.jsonl
    customers.json
    transactions.csv
    policies
    eval/chunk_eval.jsonl
    eval/hard_set.jsonl
    pdfs
  tests/
    conftest.py
    test_config.py
    test_chains.py
    test_memory.py
    test_tools.py
    test_workflow.py
    test_guardrails.py
    test_loaders.py
    test_matching.py
    test_hybrid.py
    test_glossary.py
    test_multimodal.py
    test_agentic_rag.py   <- new in this lab
  indexes/                generated at run time (git-ignored)
  docs/Lab09.pptx
  docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant
```

## Standards used

- `src/` layout, installable package, one source of truth for dependencies (`pyproject.toml`)
- Configuration only through `.env` (see `.env.example`); no keys in code
- No import-time side effects: models, indexes and graphs are built by `build_*` / `get_*` functions
- Type hints, docstrings, Pydantic schemas for every structured model output
- `ruff` lint, `pytest` offline tests, pre-commit hooks and a GitHub Actions workflow
- Gemini 3+ models: no `temperature`; `thinking_level` instead (set in `.env`)

## Next

Continue with [Lab 10](../lab10-evaluation-release/).

# Build prompt: BankAssist 360, Lab 2 (lab02-conversational-memory)

Paste everything below into an AI coding assistant (Gemini, Claude, Copilot Chat) from the project
root. Review every file it returns, then run `make install && make test`.

---

You are a senior Python engineer building one lab of the BankAssist 360 course: a retail-banking
assistant for the fictional Apex National Bank (India, amounts in INR), built with LangChain v1,
LangGraph v1, LangSmith and Google Gemini.

GOAL (Lab 2: Conversational Memory and Context)
Sessions: S030 Memory & Context Handling
Give BankAssist per-session memory, keep it inside a token budget, and remember customer preferences across
sessions.

STARTING POINT:
Copy the project `lab01-query-triage` to `lab02-conversational-memory`, delete its `src/bankassist/lab.py`,
and keep these files unchanged unless this prompt says the file grows:
    src/bankassist/: config.py, cli.py, chains.py

PROJECT STRUCTURE (create exactly this; '<- new in this lab' marks what you write now):

    lab02-conversational-memory/
      pyproject.toml          dependencies, ruff, pytest
      Makefile
      README.md
      .env.example
      .github/workflows/ci.yml
      .pre-commit-config.yaml
      src/bankassist/
        __init__.py            package marker and version
        config.py              settings, paths, logging, Gemini model factories
        cli.py                 --step runner
        chains.py              triage chain and Ticket schema
        memory.py              trimming, summaries, checkpointer, store   <- new in this lab
        lab.py                 this lab's runnable steps   <- new in this lab
        assignments/           your part 12 and 13 work
      data/
        eval/routing_set.jsonl
      tests/
        conftest.py
        test_config.py
        test_chains.py
        test_memory.py   <- new in this lab
      indexes/                generated at run time (git-ignored)
      docs/Lab02.pptx
      docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant

DEPENDENCIES (pyproject.toml [project].dependencies):
    langchain>=1.0,<2, langchain-core>=1.0,<2, langchain-google-genai>=4.4, langsmith>=0.4,
    pydantic>=2.6, python-dotenv>=1.0, langgraph>=1.0,<2

AI TOOLS (use exactly these; declare their names in lab.py as AI_TOOLS, in this order):
    - Gemini 3.8 Flash: Chat answers and running summaries
    - LangChain message history: MessagesPlaceholder, RunnableWithMessageHistory and trim_messages
    - LangGraph checkpointer + store: InMemorySaver for thread memory, InMemoryStore for customer profiles
    - LangSmith tracing: Inspect the summary and trimming calls
    Model IDs come from .env: LLM_MODEL=google_genai:gemini-3.8-flash

CODING STANDARDS:
- Python 3.11+, src layout: package `bankassist` under `src/`,
  installable with `pip install -e ".[dev]"`.
- `pyproject.toml` is the single source of dependencies (setuptools build, `dev` extra with pytest, ruff,
  pre-commit), ruff (line length 120; rules E, F, W, I, B, UP, SIM, RUF; `bankassist` is first-party) and
  pytest settings (`testpaths = ["tests"]`, `pythonpath = ["src", "."]`).
- Configuration only through `.env`, loaded once in `config.py`; never hard-code keys. Ship `.env.example`.
- Models: `init_chat_model("google_genai:<model>")`. Gemini 3+ deprecates temperature, top_p and top_k:
  never pass them for Gemini; pass `thinking_level` from `THINKING_LEVEL` instead. Embeddings:
  `GoogleGenerativeAIEmbeddings(model="gemini-embedding-2")`. Default models: main `gemini-3.8-flash`,
  fast `gemini-3.5-flash-lite`, judge `gemini-4-argon`.
- No import-time side effects: models, indexes and graphs are created by `build_*` / `get_*` functions,
  cached with `functools.lru_cache` where reuse matters. Pass dependencies (retriever, models, embeddings)
  as arguments so tests can inject fakes.
- Type hints and a docstring on every module and public function; Pydantic models for every structured LLM output.
- Library modules log with `get_logger(__name__)`; only `lab.py` prints results.
- Security: customer identity comes from `RunnableConfig["configurable"]["customer_id"]`, never from model
  arguments; money-moving actions need human approval; mask PII before it reaches a model or a trace.
- Tests run offline: `tests/conftest.py` sets a fake `GOOGLE_API_KEY`, `LANGSMITH_TRACING=false` and provides a
  `DeterministicFakeEmbedding` fixture. No test may call a real API.
- `lab.py` exposes `main()` that calls `bankassist.cli.run_steps(title, {number: step_function}, tools=AI_TOOLS)`;
  each step function's first docstring line is its description, and `AI_TOOLS` (a module-level tuple) names the
  lab's AI tools, shown by `--help`. `python -m bankassist.lab --step N` runs one step.

FILES TO WRITE:

src/bankassist/memory.py: Conversation memory (Lab 2): trimming, summarisation, thread checkpointer and long-
  term store.
  Public API (implement exactly these names and signatures):
    constant SYSTEM_TEXT = 'You are BankAssist for Apex National Bank. Be concise.'
    constant SUMMARY_TRIGGER = 10
    constant KEEP_RECENT = 4
    constant TOKEN_BUDGET = 1000
    class ChatState(MessagesState)
        # Messages (appended by reducer) plus a running summary.
        field summary: str
    def summarize(state: ChatState) -> dict
        # Fold older messages into the summary and delete them from state.
    def respond(state: ChatState, config: RunnableConfig, *, store: BaseStore) -> dict
        # Answer using summary, trimmed history and the customer's long-term profile.
    def build_memory_graph(store: BaseStore | None=None, checkpointer=None) -> CompiledStateGraph
        # summarize -> respond, with thread memory (checkpointer) and long-term memory (store).

IMPLEMENTATION RULES (the tests and the lab guide depend on these):
    - Constants: SUMMARY_TRIGGER = 10, KEEP_RECENT = 4, TOKEN_BUDGET = 1000.
    - `trimmer = trim_messages(max_tokens=TOKEN_BUDGET, strategy='last',
      token_counter=count_tokens_approximately, include_system=True, start_on='human')`.
    - `summarize`: when the thread has more than SUMMARY_TRIGGER messages, fold all but the last KEEP_RECENT
      into `summary` with one LLM call and delete them with `RemoveMessage`; otherwise return `{}`.
    - `respond`: read the profile from the store at namespace `(customer_id, 'profile')`, key `'prefs'`; put
      the profile and summary in the system message; send system + trimmed history to the model.
    - `build_memory_graph(store=None, checkpointer=None)`: START -> summarize -> respond -> END, defaulting to
      `InMemorySaver()` and `InMemoryStore()`.

src/bankassist/lab.py: this lab's runnable steps, registered in run_steps() with these numbers:
    --step 1: Prove the model is stateless
    --step 2: Pass history with MessagesPlaceholder
    --step 3: Isolate sessions with RunnableWithMessageHistory
    --step 4: Trim a long history to the token budget
    --step 5: Thread memory with a checkpointer + long-term profile store + summarisation

DATA (provided by the course; copy it, do not invent it):
    data/eval/routing_set.jsonl

TESTS (offline, pytest). Write these new test functions:
  tests/test_memory.py
    test_threads_are_isolated_and_long_threads_are_summarised
        # checks: threads are isolated and long threads are summarised

ALSO WRITE OR UPDATE: README.md (setup, steps table, expected outputs, structure),
.env.example (only the keys this lab needs), Makefile (install, test, lint, run STEP=N), .gitignore,
.pre-commit-config.yaml (ruff, private-key detection), .github/workflows/ci.yml
(ruff + pytest on Python 3.11 and 3.12).

EXPECTED BEHAVIOUR WHEN RUN WITH REAL KEYS:
    - Turn 3 answers senior-citizen FD rates
    - Thread C1002 does not know Priya
    - After 10+ messages: summary + recent messages

ACCEPTANCE CHECKS (all must pass before you finish):
    1. `ruff check .` reports no issues.
    2. `pytest` passes offline with no API keys and no network calls.
    3. `python -m bankassist.lab --help` lists steps 1, 2, 3, 4, 5.
    4. No module creates a model, index or graph at import time.
    5. Gemini models are never given a temperature.

OUTPUT FORMAT: return every new or changed file in full, each preceded by a line
`=== path/to/file ===`.
No placeholders, no 'rest unchanged' comments. After the files, list any assumption you made.

# BankAssist 360, Lab 2: Conversational Memory and Context

S030 Memory & Context Handling

Give BankAssist per-session memory, keep it inside a token budget, and remember customer preferences across sessions.

This project is standalone: it contains everything built in earlier labs (`chains.py`), so you can
start here without finishing the previous lab. Code from earlier labs is identical to their projects.

## How to run this lab

You need Python 3.11 or 3.12 and these keys in `.env`: `GOOGLE_API_KEY` and `LANGSMITH_API_KEY`. Tests need no keys.

macOS or Linux:

```bash
python3 -m venv .venv && source .venv/bin/activate
make install                 # pip install -e ".[dev]" + pre-commit hooks
cp .env.example .env         # then add your keys
make test                    # offline: expect 7 passed
make run                     # every step in order
make run STEP=5              # one step
```

Windows (PowerShell, no make needed):

```powershell
py -3.11 -m venv .venv; .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
Copy-Item .env.example .env  # then add your keys
pytest                       # offline: expect 7 passed
python -m bankassist.lab     # every step in order
python -m bankassist.lab --step 5  # one step
```

`python -m bankassist.lab --help` lists the steps. Step numbers match the implementation steps in the lab
guide; guide steps without their own command are code you read in `src/bankassist/`, and their effect shows
in the next step that runs.

What to expect when you run it:

- All memory is in-process (`InMemorySaver`, `InMemoryStore`), so every run starts fresh. That is intended.
- Step 4 makes no model call: it only trims an 81-message history and prints the count.
- Step 5 summarises once a thread passes 10 messages; look for the summary call in LangSmith.

Start again from a clean state with `make clean` (deletes `indexes/`).

## Steps in this lab

| Command | What it does |
| --- | --- |
| `--step 1` | Prove the model is stateless |
| `--step 2` | Pass history with MessagesPlaceholder |
| `--step 3` | Isolate sessions with RunnableWithMessageHistory |
| `--step 4` | Trim a long history to the token budget |
| `--step 5` | Thread memory with a checkpointer + long-term profile store + summarisation |

The full walkthrough, code explanations, knowledge check, assignment and modification tasks are in
the BankAssist 360 lab guide (Lab 2). Slides: `docs/Lab02.pptx`. To rebuild this project with an AI
coding assistant, use the prompt in `docs/BUILD_PROMPT.md`.

## AI tools used

| Tool | Role in this lab |
| --- | --- |
| Gemini 3.8 Flash | Chat answers and running summaries |
| LangChain message history | MessagesPlaceholder, RunnableWithMessageHistory and trim_messages |
| LangGraph checkpointer + store | InMemorySaver for thread memory, InMemoryStore for customer profiles |
| LangSmith tracing | Inspect the summary and trimming calls |

Model names are the defaults in `.env.example`; change them there, never in code. `python -m bankassist.lab --help`
lists the same tools.

## Expected outputs

- Turn 3 answers senior-citizen FD rates
- Thread C1002 does not know Priya
- After 10+ messages: summary + recent messages

## Concepts covered

- **Statelessness:** Memory means re-sending context
- **MessagesPlaceholder:** Prompt slot for past messages
- **Token budget:** trim_messages keeps the newest that fit
- **Summarisation:** Fold old turns into a summary
- **Checkpointer + thread_id:** Saves graph state per conversation
- **Long-term store:** Cross-session facts by customer_id

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `ModuleNotFoundError: bankassist` | The virtual environment is not active or the project is not installed. | Activate `.venv`, then `make install` (or `python -m pip install -e ".[dev]"`). |
| `make: command not found` (Windows) | make is not installed. | Run the commands directly: `pytest`, `python -m bankassist.lab --step N`. |
| `Activate.ps1 cannot be loaded` (Windows) | PowerShell blocks local scripts by default. | Run `Set-ExecutionPolicy -Scope Process RemoteSigned`, then activate again. |
| 400 or 404 from Gemini naming the model | The model ID in `.env` is retired or mistyped. | Check the IDs against the Gemini API changelog and update `LLM_MODEL`, `FAST_LLM_MODEL`, `JUDGE_MODEL`. |
| 429 or `RESOURCE_EXHAUSTED` | Free-tier rate limit. | Wait a minute, lower concurrency (Lab 1 step 6, Lab 10 `run_experiment`), or use a paid key. |
| No traces in LangSmith | Tracing is off, the key is wrong, or you are looking at another project. | Set `LANGSMITH_TRACING=true` and `LANGSMITH_API_KEY`; open project `bankassist360`. |
| Chroma or FAISS dimension error | Indexes were built with another embedding model. | `make clean`, then rerun the step. |
| Lab 7 or later: first query is slow | The cross-encoder is downloading. | Wait once; it is cached afterwards. |
| Lab 10 `/approve` returns 409 | Nothing is waiting for approval on that session. | Send a card-block request to `/chat` first with the same `session_id`. |

## Project structure

```text
lab02-conversational-memory/
  pyproject.toml          dependencies, ruff, pytest
  Makefile
  README.md
  .env.example
  .github/workflows/ci.yml
  .pre-commit-config.yaml
  src/bankassist/
    __init__.py            package marker and version
    config.py              settings, paths, logging, Gemini model factories
    cli.py                 --step runner
    chains.py              triage chain and Ticket schema
    memory.py              trimming, summaries, checkpointer, store   <- new in this lab
    lab.py                 this lab's runnable steps   <- new in this lab
    assignments/           your part 12 and 13 work
  data/
    eval/routing_set.jsonl
  tests/
    conftest.py
    test_config.py
    test_chains.py
    test_memory.py   <- new in this lab
  indexes/                generated at run time (git-ignored)
  docs/Lab02.pptx
  docs/BUILD_PROMPT.md    prompt to rebuild this project with an AI assistant
```

## Standards used

- `src/` layout, installable package, one source of truth for dependencies (`pyproject.toml`)
- Configuration only through `.env` (see `.env.example`); no keys in code
- No import-time side effects: models, indexes and graphs are built by `build_*` / `get_*` functions
- Type hints, docstrings, Pydantic schemas for every structured model output
- `ruff` lint, `pytest` offline tests, pre-commit hooks and a GitHub Actions workflow
- Gemini 3+ models: no `temperature`; `thinking_level` instead (set in `.env`)

## Next

Continue with [Lab 3](../lab03-banking-agent/).

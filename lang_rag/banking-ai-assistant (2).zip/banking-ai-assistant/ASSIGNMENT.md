# Assignment — Extend the Banking AI Assistant

**Stack:** Python · FastAPI · LangChain · LangGraph · LangSmith · Google Gemini
**Duration:** 1 week (≈ 10–12 hours) · **Submission:** Git repo link + LangSmith screenshots + 2-page report

## Learning objectives
By the end you should be able to (1) design a stateful agent workflow as a LangGraph `StateGraph`,
(2) wrap business operations as LangChain tools and use structured LLM output, (3) add
human-in-the-loop control with `interrupt` / `Command(resume=...)`, (4) expose an agent through
FastAPI, and (5) debug and evaluate it with LangSmith traces and datasets.

## Part A — Warm-up (15 marks)
1. Run the project in `mock` mode, run `pytest`, and run `demo.py`. Screenshot the Swagger UI.
2. Add your Gemini key (`LLM_MODE=gemini`, `GOOGLE_API_KEY`) and enable LangSmith. Send 5 different requests and
   screenshot one full trace showing the guardrail → classify → tool nodes.
3. In your report, explain in your own words what `add_messages`, `MemorySaver` and
   `thread_id` do, and why `transfer_node` must not change data before `interrupt()`.

## Part B — New features (40 marks)
4. **Block / unblock debit card (10).** Add a `card` intent, a `block_card` tool and a
   `card_node`. Blocking needs confirmation via `interrupt`; unblocking is *not* allowed by chat
   (reply with the branch process).
5. **Fixed deposit booking (10).** "Open an FD of 1 lakh for 2 years" → compute maturity amount
   using the rates in `POLICY_DOCS`, check balance, ask for approval, debit the account.
6. **Multi-turn slot filling (10).** If the user says "transfer money" without amount or
   account, the bot should ask for the missing value and complete the transfer on the next
   turn in the same thread (hint: store a `pending_transfer` in state and check it in `classify`).
7. **Fraud rule (10).** Flag a transfer when it is more than 3× the customer's average debit
   *or* it is the third transfer in 10 minutes. Flagged transfers always go to approval with the
   reason shown. Add the rule as its own graph node between `classify` and `transfer`.

## Part C — Quality, safety, observability (30 marks)
8. **Real retrieval (8).** Replace the keyword `search_policies` with an `InMemoryVectorStore`
   (or FAISS/Chroma) using `GoogleGenerativeAIEmbeddings(model="gemini-embedding-001")`. Add 5 more policy documents.
9. **PII masking (7).** Before any text reaches the LLM or LangSmith, mask account numbers
   (`SB2001` → `SB**01`) and 10-digit phone numbers. Show a trace proving it.
10. **LangSmith evaluation (10).** Create a dataset of ≥ 20 utterances with expected intent.
    Write an evaluator that scores intent accuracy and run `evaluate()` for two Gemini models
    (e.g. `gemini-3.5-flash` vs `gemini-3.5-flash-lite`) or two prompts. Report accuracy, average
    latency and cost for each and pick a winner.
11. **Tests (5).** Add at least 6 new pytest cases covering Parts B and C.

## Part D — Report & demo (15 marks)
12. Updated graph diagram (Mermaid output of `python -m app.graph`).
13. Two-page report: design choices, one bug you found through a LangSmith trace and how you
    fixed it, and three risks of deploying this in a real bank with mitigations.
14. 5-minute screen recording of the full flow including an approval.

## Grading rubric
| Criteria | Marks |
|---|---|
| Part A — setup, traces, concepts | 15 |
| Part B — features work end-to-end via API | 40 |
| Part C — retrieval, masking, evaluation, tests | 30 |
| Part D — report, diagram, demo | 15 |
| **Total** | **100** |

**Bonus (+10):** persist checkpoints with `langgraph-checkpoint-sqlite` or Postgres so a pending
approval survives a server restart, and add JWT auth so `customer_id` comes from the token.

## Viva questions (practice)
1. Why route with a conditional edge rather than letting one ReAct agent pick tools freely in banking?
2. What happens to a paused graph if the server restarts with `MemorySaver`? How do you fix it?
3. Why use structured output (Pydantic) for intent instead of parsing free text?
4. Which information should never be sent to Gemini or logged to LangSmith, and how do you ensure that?
6. When would you move from the Gemini Developer API to Vertex AI in a bank?
5. How would you load-test `/chat`, and what is the main latency cost per request?

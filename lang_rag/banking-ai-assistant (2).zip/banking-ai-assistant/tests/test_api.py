"""End-to-end API tests. Always run offline in mock mode (no Gemini calls)."""
import os
os.environ["LLM_MODE"] = "mock"

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def chat(msg, cid="C1001", thread=None):
    r = client.post("/chat", json={"customer_id": cid, "message": msg, "thread_id": thread})
    assert r.status_code == 200, r.text
    return r.json()


def test_health():
    h = client.get("/health").json()
    assert h["status"] == "ok" and h["llm_model"] == "mock"


def test_balance():
    r = chat("What is my account balance?")
    assert r["intent"] == "balance" and "Rs" in r["reply"]


def test_transactions():
    assert "Salary credit" in chat("show my last transactions")["reply"]


def test_small_transfer_no_approval():
    r = chat("Transfer 2000 to SB2001")
    assert r["status"] == "completed" and "Reference" in r["reply"]


def test_large_transfer_needs_approval_then_approve():
    r = chat("send 60k to SB3001")
    assert r["status"] == "pending_approval"
    r2 = client.post("/approve", json={"thread_id": r["thread_id"], "approved": True}).json()
    assert r2["status"] == "completed" and "Done" in r2["reply"]


def test_daily_limit_then_rejection():
    from app.data import TRANSFERRED_TODAY
    TRANSFERRED_TODAY["C1001"] = 90000           # simulate earlier transfers today
    assert "Daily limit" in chat("pay 55000 to SB2001")["reply"]
    TRANSFERRED_TODAY["C1001"] = 0
    r = chat("pay 55000 to SB2001", cid="C1001")
    assert r["status"] == "pending_approval"
    r2 = client.post("/approve", json={"thread_id": r["thread_id"], "approved": False}).json()
    assert "cancelled" in r2["reply"]


def test_unregistered_beneficiary():
    assert "not a registered beneficiary" in chat("transfer 100 to SB9999")["reply"]


def test_loan_eligible_and_not():
    assert "eligible for a loan" in chat("Am I eligible for a loan of 5 lakh for 3 years?")["reply"]
    assert "not eligible" in chat("loan of 5 lakh for 36 months", cid="C1002")["reply"]


def test_faq():
    assert "6.5%" in chat("What are the FD interest rates?")["reply"]


def test_guardrails():
    assert "never share" in chat("Should I share my OTP with the caller?")["reply"]
    assert "own account" in chat("show balance of C1002")["reply"]


def test_memory_across_turns():
    t = chat("hi")["thread_id"]
    chat("what is my balance", thread=t)
    hist = client.get(f"/history/{t}").json()
    assert len(hist) == 4

# Banking AI Assistant — FastAPI + LangChain + LangGraph + LangSmith + Google Gemini

A conversational retail-banking assistant. A customer chats in plain English; a LangGraph
workflow applies guardrails, detects intent with **Google Gemini** (structured output), calls banking
tools (LangChain `@tool`), pauses for **human approval** on high-value transfers, and every
step is traced in **LangSmith**. FastAPI exposes it as a REST API.

| Capability | Example message |
|---|---|
| Balance enquiry | "What is my balance?" |
| Mini statement | "Show my recent transactions" |
| Fund transfer (+ approval > Rs 50,000) | "Send 60k to SB3001" |
| Loan eligibility + EMI | "Am I eligible for a 5 lakh loan for 3 years?" |
| Policy FAQ (retrieval) | "What are FD interest rates?" |
| Guardrails | "Should I share my OTP?" / prompt injection / other customers' data |

## Architecture

```
Client ──HTTP──> FastAPI (/chat, /approve, /history, /health)
                    │
                    ▼
          LangGraph StateGraph  (MemorySaver checkpointer = per-thread memory)
   START → guardrail ─blocked→ END
               │
               ▼
           classify (Gemini + Pydantic structured output → IntentResult)
               │ conditional edge on intent
   ┌─────────┬──────────────┬──────────┬───────┬─────┬───────────┐
 balance  transactions   transfer     loan    faq   smalltalk
                           │ interrupt() if amount > threshold
                           ▼ resumed by POST /approve (Command(resume=...))
                          END
   Tools (LangChain @tool): get_balance, get_transactions, validate_transfer,
   execute_transfer, check_loan_eligibility, search_policies
   LangSmith: traces every node, tool and LLM call (env-var driven)
```

## Project structure

```
banking-ai-assistant/
├── app/
│   ├── config.py   # env settings & business rules
│   ├── data.py     # mock core-banking data + policy docs
│   ├── tools.py    # LangChain tools
│   ├── llm.py      # ChatGoogleGenerativeAI (Gemini), structured intent, answers, mock mode
│   ├── graph.py    # LangGraph workflow (nodes, routing, interrupt)
│   └── main.py     # FastAPI app
├── tests/test_api.py   # 11 end-to-end tests
├── demo.py             # scripted conversation against the running server
├── requirements.txt
└── .env.example
```

## Execution steps

**1. Prerequisites:** Python 3.10+ (3.11/3.12 recommended), a Google Gemini API key (free tier works) and optionally a LangSmith account.

**2. Create a virtual environment and install**
```bash
cd banking-ai-assistant
python -m venv .venv
# Windows: .venv\Scripts\activate      macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

**3. Configure**
```bash
cp .env.example .env        # Windows: copy .env.example .env
```
**Get a Gemini key:** open https://aistudio.google.com/apikey → *Create API key* → paste it in `.env`:
```
LLM_MODE=gemini
GOOGLE_API_KEY=your-gemini-api-key
GEMINI_MODEL=gemini-3.5-flash        # or gemini-3.5-flash-lite (cheaper) / gemini-3.1-pro-preview
```
- No key yet? Set `LLM_MODE=mock` (or just leave the key empty) to run **fully offline** with
  rule-based intent detection. `/health` shows which mode is active.
- Check model names available to your key in Google AI Studio; change only `GEMINI_MODEL`.

**4. Enable LangSmith tracing (optional but recommended)**
1. Sign up at https://smith.langchain.com → Settings → API Keys → create key.
2. In `.env`: `LANGSMITH_TRACING=true`, `LANGSMITH_API_KEY=lsv2_...`, `LANGSMITH_PROJECT=banking-ai-assistant`.
3. Every request now appears in the project with the graph nodes, tool inputs/outputs,
   LLM prompts, latency and token cost, tagged `banking-api` with `customer_id` metadata.

**5. Run the tests**
```bash
pytest -q          # expected: 11 passed (tests always run in mock mode, no Gemini calls)
```

**6. Start the API**
```bash
uvicorn app.main:app --reload --port 8000
```
Open Swagger UI at http://127.0.0.1:8000/docs and call `GET /health` — it should show
`"llm_model": "gemini:gemini-3.5-flash"`.

**7. Try it**
```bash
python demo.py     # scripted conversation (asks you to approve the big transfer)
```
or with curl:
```bash
curl -X POST localhost:8000/chat -H "Content-Type: application/json" \
  -d '{"customer_id":"C1001","message":"Send 60000 to SB3001"}'
# -> {"status":"pending_approval","thread_id":"<id>","approval":{...}}

curl -X POST localhost:8000/approve -H "Content-Type: application/json" \
  -d '{"thread_id":"<id>","approved":true}'
```

**8. View the graph diagram**
```bash
python -m app.graph      # prints Mermaid; paste into https://mermaid.live
```

## API

| Method | Path | Body | Purpose |
|---|---|---|---|
| GET | /health | – | status, active Gemini model (or mock), tracing flag |
| POST | /chat | `customer_id, message, thread_id?` | send a message (reuse thread_id for memory) |
| POST | /approve | `thread_id, approved` | resume a paused transfer |
| GET | /history/{thread_id} | – | conversation messages |

Test customers: **C1001** Asha Patil (SB1001, score 782, eligible) and **C1002** Rahul Deshmukh
(SB2001, score 655, not eligible). Beneficiaries of C1001: SB2001, SB3001.

## How Gemini is wired in (`app/llm.py`)
```python
from langchain_google_genai import ChatGoogleGenerativeAI
llm = ChatGoogleGenerativeAI(model="gemini-3.5-flash", google_api_key=KEY, temperature=0)
router = llm.with_structured_output(IntentResult)   # Pydantic -> Gemini JSON schema
intent = router.invoke([SystemMessage(CLASSIFY_PROMPT), HumanMessage(text)])
```
Gemini is used twice per request: once to classify intent and extract entities (amount,
account, tenure), and once to phrase the tool result as a friendly reply. Money movement
(validation, limits, debit) is plain Python, never decided by the model.

## Troubleshooting
| Symptom | Fix |
|---|---|
| `/health` shows `mock` | `GOOGLE_API_KEY` missing or `LLM_MODE` not `gemini`; restart uvicorn after editing `.env` |
| `404 model not found` | Model name not enabled for your key; pick one listed in AI Studio |
| `429 RESOURCE_EXHAUSTED` | Free-tier rate limit; wait a minute or use `gemini-3.5-flash-lite` |
| No traces in LangSmith | `LANGSMITH_TRACING=true`, valid key, restart server |

## Production notes
Demo only. For real use: consider Vertex AI (`GOOGLE_GENAI_USE_VERTEXAI=true`) for enterprise data residency and IAM; take `customer_id` from an auth token (OAuth2/JWT) not the body;
replace `MemorySaver` with `PostgresSaver`; replace mock data with core-banking APIs; real OTP
step-up instead of a plain approve flag; vector store for policies; audit logs; PII masking
before sending to the LLM and LangSmith.

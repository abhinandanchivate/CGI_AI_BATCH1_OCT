r"""LangGraph workflow for the banking assistant.

    START -> guardrail -> classify -> {balance | transactions | transfer | loan | faq | smalltalk}
                     \-> (blocked) -> END                      transfer may pause (interrupt)
                                                               for human approval
"""
import re
from typing import Annotated, Optional, TypedDict

from langchain_core.messages import AIMessage, AnyMessage
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.types import interrupt

from app import llm, tools
from app.llm import IntentResult


class BankState(TypedDict, total=False):
    messages: Annotated[list[AnyMessage], add_messages]  # full chat history (memory)
    customer_id: str
    question: str
    intent: Optional[IntentResult]
    blocked: bool
    reply: str


def _inr(x: float) -> str:
    return f"Rs {x:,.2f}"


def _say(text: str) -> dict:
    return {"reply": text, "messages": [AIMessage(text)]}


# ------------------------------------------------------------------ nodes
INJECTION = re.compile(r"ignore (all|previous|the) (instructions|rules)|system prompt|act as admin", re.I)
SECRETS = re.compile(r"\b(otp|pin|cvv|password)\b", re.I)
OTHER_CUSTOMER = re.compile(r"\bC\d{4}\b")


def guardrail(state: BankState) -> dict:
    q = state["question"]
    if INJECTION.search(q):
        return {"blocked": True, **_say("I can only help with your own banking requests.")}
    if SECRETS.search(q) and re.search(r"\b(share|give|send|tell|what is)\b", q, re.I):
        return {"blocked": True, **_say(
            "Please never share your OTP, PIN, CVV or password with anyone, including bank staff "
            "or this assistant. If someone asked for it, report it to 1930 immediately.")}
    other = [c for c in OTHER_CUSTOMER.findall(q) if c != state["customer_id"]]
    if other:
        return {"blocked": True, **_say("For privacy, I can only access your own account.")}
    return {"blocked": False}


def classify(state: BankState) -> dict:
    return {"intent": llm.classify(state["question"])}


def balance_node(state: BankState) -> dict:
    r = tools.get_balance.invoke({"customer_id": state["customer_id"]})
    fb = f"Your {r['account_type']} account {r['account_no']} has an available balance of {_inr(r['balance'])}."
    return _say(llm.answer(state["question"], str(r), fb))


def transactions_node(state: BankState) -> dict:
    txns = tools.get_transactions.invoke({"customer_id": state["customer_id"], "limit": 5})
    lines = [f"{t['date']}  {t['desc']}  {'+' if t['amount'] > 0 else '-'}{_inr(abs(t['amount']))}" for t in txns]
    fb = "Your last transactions:\n" + "\n".join(lines)
    return _say(llm.answer(state["question"], str(txns), fb))


def transfer_node(state: BankState) -> dict:
    i: IntentResult = state["intent"]
    args = {"customer_id": state["customer_id"], "to_account": i.to_account, "amount": i.amount}
    check = tools.validate_transfer.invoke(args)
    if not check["ok"]:
        return _say(check["reason"])

    if check["needs_approval"]:
        # Human-in-the-loop: graph pauses here and is resumed via POST /approve.
        # Everything above re-runs on resume, so no side effects before this line.
        decision = interrupt({
            "type": "transfer_approval",
            "message": f"Confirm transfer of {_inr(i.amount)} to {check['beneficiary_name']} ({i.to_account})?",
            "amount": i.amount,
            "to_account": i.to_account,
        })
        if not decision.get("approved"):
            return _say("Transfer cancelled. No money was debited.")

    r = tools.execute_transfer.invoke(args)
    return _say(
        f"Done! {_inr(i.amount)} sent to {check['beneficiary_name']} ({i.to_account}). "
        f"Reference {r['reference']}. New balance: {_inr(r['new_balance'])}."
    )


def loan_node(state: BankState) -> dict:
    i: IntentResult = state["intent"]
    if not i.amount:
        return _say("Sure! How much would you like to borrow, and for how many months?")
    r = tools.check_loan_eligibility.invoke({
        "customer_id": state["customer_id"], "loan_amount": i.amount, "tenure_months": i.tenure_months or 36})
    if r["eligible"]:
        fb = (f"Good news: you are eligible for a loan of {_inr(i.amount)} for {r['tenure_months']} months "
              f"at {r['interest_rate']}% p.a. Estimated EMI: {_inr(r['emi'])}.")
    else:
        fb = (f"You are not eligible for {_inr(i.amount)} right now because " + " and ".join(r["reasons"]) +
              f". You may be eligible for up to {_inr(r['max_eligible_amount'])} over {r['tenure_months']} months.")
    return _say(llm.answer(state["question"], str(r), fb))


def faq_node(state: BankState) -> dict:
    docs = tools.search_policies.invoke({"query": state["question"]})
    if not docs:
        return _say("I couldn't find that in our policies. Please call 1800-000-0000 or visit a branch.")
    fb = " ".join(d["text"] for d in docs[:1])
    context = "\n".join(f"[{d['title']}] {d['text']}" for d in docs)
    return _say(llm.answer(state["question"], context, fb))


def smalltalk_node(state: BankState) -> dict:
    if state["intent"].intent == "greeting":
        return _say("Hello! I can check your balance, show transactions, transfer money, "
                    "check loan eligibility or answer questions about our services.")
    return _say("I can only help with banking questions such as balance, transfers, loans and bank policies.")


# ------------------------------------------------------------------ routing
def after_guardrail(state: BankState) -> str:
    return "end" if state.get("blocked") else "classify"


def route_intent(state: BankState) -> str:
    return {
        "balance": "balance", "transactions": "transactions", "transfer": "transfer",
        "loan": "loan", "faq": "faq",
    }.get(state["intent"].intent, "smalltalk")


def build_graph(checkpointer=None):
    g = StateGraph(BankState)
    g.add_node("guardrail", guardrail)
    g.add_node("classify", classify)
    g.add_node("balance", balance_node)
    g.add_node("transactions", transactions_node)
    g.add_node("transfer", transfer_node)
    g.add_node("loan", loan_node)
    g.add_node("faq", faq_node)
    g.add_node("smalltalk", smalltalk_node)

    g.add_edge(START, "guardrail")
    g.add_conditional_edges("guardrail", after_guardrail, {"end": END, "classify": "classify"})
    g.add_conditional_edges("classify", route_intent,
                            ["balance", "transactions", "transfer", "loan", "faq", "smalltalk"])
    for n in ["balance", "transactions", "transfer", "loan", "faq", "smalltalk"]:
        g.add_edge(n, END)
    return g.compile(checkpointer=checkpointer or MemorySaver())


graph = build_graph()

if __name__ == "__main__":
    # print a Mermaid diagram of the workflow
    print(graph.get_graph().draw_mermaid())

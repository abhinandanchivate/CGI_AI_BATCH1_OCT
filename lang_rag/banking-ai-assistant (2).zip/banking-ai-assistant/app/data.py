"""In-memory mock core-banking data. Replace with a real DB / CBS API in production."""
from datetime import datetime, timedelta

_now = datetime.now()

CUSTOMERS = {
    "C1001": {
        "name": "Asha Patil",
        "account_no": "SB1001",
        "account_type": "Savings",
        "balance": 185000.00,
        "credit_score": 782,
        "monthly_income": 120000,
        "existing_emi": 15000,
        "beneficiaries": {"SB2001": "Rahul Deshmukh", "SB3001": "Priya Kulkarni"},
    },
    "C1002": {
        "name": "Rahul Deshmukh",
        "account_no": "SB2001",
        "account_type": "Savings",
        "balance": 42000.00,
        "credit_score": 655,
        "monthly_income": 45000,
        "existing_emi": 12000,
        "beneficiaries": {"SB1001": "Asha Patil"},
    },
}

TRANSACTIONS = {
    "C1001": [
        {"date": (_now - timedelta(days=1)).strftime("%Y-%m-%d"), "desc": "UPI - Swiggy", "amount": -650.0},
        {"date": (_now - timedelta(days=2)).strftime("%Y-%m-%d"), "desc": "Salary credit", "amount": 120000.0},
        {"date": (_now - timedelta(days=3)).strftime("%Y-%m-%d"), "desc": "Electricity bill - MSEDCL", "amount": -2340.0},
        {"date": (_now - timedelta(days=5)).strftime("%Y-%m-%d"), "desc": "ATM withdrawal", "amount": -5000.0},
        {"date": (_now - timedelta(days=7)).strftime("%Y-%m-%d"), "desc": "Home loan EMI", "amount": -15000.0},
    ],
    "C1002": [
        {"date": (_now - timedelta(days=1)).strftime("%Y-%m-%d"), "desc": "UPI - Amazon", "amount": -1999.0},
        {"date": (_now - timedelta(days=4)).strftime("%Y-%m-%d"), "desc": "Salary credit", "amount": 45000.0},
    ],
}

# Running total of today's outgoing transfers per customer (for daily limit)
TRANSFERRED_TODAY: dict[str, float] = {}

POLICY_DOCS = [
    {"id": "fd", "title": "Fixed Deposit rates",
     "text": "Fixed deposits earn 6.5% p.a. for 1-2 years and 7.1% p.a. for 3-5 years. Senior citizens get an extra 0.5%. Minimum deposit is Rs 10,000."},
    {"id": "kyc", "title": "KYC update",
     "text": "KYC must be updated every 2 years for high-risk and every 10 years for low-risk customers. Upload PAN and Aadhaar in the app or visit any branch."},
    {"id": "charges", "title": "Account charges",
     "text": "Savings accounts need an average monthly balance of Rs 10,000. Non-maintenance charge is Rs 300 plus GST. NEFT and IMPS via app are free."},
    {"id": "card", "title": "Lost debit card",
     "text": "If your debit card is lost, block it instantly from the app under Cards > Block, or call 1800-000-0000. A replacement card costs Rs 200."},
    {"id": "fraud", "title": "Fraud safety",
     "text": "The bank never asks for your OTP, PIN, CVV or password. Report suspicious calls or messages to 1930 (cyber crime helpline) and to the bank immediately."},
    {"id": "loan", "title": "Personal loan",
     "text": "Personal loans from Rs 50,000 to Rs 25 lakh, tenure 12 to 60 months, interest from 10.5% p.a. Eligibility needs credit score 700+ and total EMIs under 50% of income."},
]

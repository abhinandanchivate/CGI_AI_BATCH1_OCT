"""FastAPI service exposing the LangGraph banking assistant."""
import uuid
from typing import Optional

from fastapi import FastAPI, HTTPException
from langchain_core.messages import HumanMessage
from langgraph.types import Command
from pydantic import BaseModel

from app import config
from app.data import CUSTOMERS
from app.graph import graph

app = FastAPI(title="Banking AI Assistant", version="1.0.0",
              description="FastAPI + LangChain + LangGraph + LangSmith demo")


class ChatRequest(BaseModel):
    customer_id: str
    message: str
    thread_id: Optional[str] = None  # reuse to keep conversation memory


class ApprovalRequest(BaseModel):
    thread_id: str
    approved: bool


class ChatResponse(BaseModel):
    thread_id: str
    status: str            # "completed" | "pending_approval"
    reply: Optional[str] = None
    approval: Optional[dict] = None
    intent: Optional[str] = None


def _respond(thread_id: str) -> ChatResponse:
    cfg = {"configurable": {"thread_id": thread_id}}
    snap = graph.get_state(cfg)
    if snap.next:  # graph is paused at an interrupt
        pending = [it.value for t in snap.tasks for it in t.interrupts]
        return ChatResponse(thread_id=thread_id, status="pending_approval",
                            approval=pending[0] if pending else None)
    v = snap.values
    intent = v.get("intent").intent if v.get("intent") else None
    return ChatResponse(thread_id=thread_id, status="completed", reply=v.get("reply"), intent=intent)


@app.get("/health")
def health():
    return {"status": "ok", "llm_model": config.LLM_MODEL, "langsmith_tracing": config.LANGSMITH_ENABLED}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    if req.customer_id not in CUSTOMERS:
        raise HTTPException(404, "Unknown customer")  # in prod: derive from auth token, not body
    thread_id = req.thread_id or str(uuid.uuid4())
    cfg = {"configurable": {"thread_id": thread_id},
           "metadata": {"customer_id": req.customer_id},  # visible in LangSmith
           "tags": ["banking-api"]}
    if graph.get_state(cfg).next:
        raise HTTPException(409, "A transfer is awaiting approval on this thread. Call /approve first.")
    graph.invoke({"customer_id": req.customer_id, "question": req.message, "intent": None,
                  "reply": "", "blocked": False, "messages": [HumanMessage(req.message)]}, cfg)
    return _respond(thread_id)


@app.post("/approve", response_model=ChatResponse)
def approve(req: ApprovalRequest):
    cfg = {"configurable": {"thread_id": req.thread_id}}
    if not graph.get_state(cfg).next:
        raise HTTPException(404, "Nothing pending on this thread")
    graph.invoke(Command(resume={"approved": req.approved}), cfg)
    return _respond(req.thread_id)


@app.get("/history/{thread_id}")
def history(thread_id: str):
    snap = graph.get_state({"configurable": {"thread_id": thread_id}})
    return [{"role": m.type, "content": m.content} for m in snap.values.get("messages", [])]

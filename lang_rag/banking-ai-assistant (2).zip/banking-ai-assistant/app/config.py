"""Central configuration, loaded from environment / .env file."""
import os
from dotenv import load_dotenv

load_dotenv()

# LLM: Google Gemini via langchain-google-genai.
#   LLM_MODE=gemini -> uses GEMINI_MODEL with GOOGLE_API_KEY (get one at https://aistudio.google.com/apikey)
#   LLM_MODE=mock   -> offline rule-based mode (no key; used by unit tests)
# If LLM_MODE=gemini but no key is set, the app falls back to mock and says so in /health.
LLM_MODE = os.getenv("LLM_MODE", "gemini").lower()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.5-flash")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
GEMINI_TEMPERATURE = float(os.getenv("GEMINI_TEMPERATURE", 0))

USE_GEMINI = LLM_MODE == "gemini" and bool(GOOGLE_API_KEY)
if LLM_MODE == "gemini" and not GOOGLE_API_KEY:
    print("[config] GOOGLE_API_KEY not set -> running in MOCK mode (rule-based, offline).")
LLM_MODEL = f"gemini:{GEMINI_MODEL}" if USE_GEMINI else "mock"

# Business rules (INR)
APPROVAL_THRESHOLD = float(os.getenv("APPROVAL_THRESHOLD", 50000))   # human approval above this
DAILY_TRANSFER_LIMIT = float(os.getenv("DAILY_TRANSFER_LIMIT", 100000))
LOAN_INTEREST_RATE = float(os.getenv("LOAN_INTEREST_RATE", 10.5))     # % p.a.
MIN_CREDIT_SCORE = int(os.getenv("MIN_CREDIT_SCORE", 700))
MAX_FOIR = float(os.getenv("MAX_FOIR", 0.5))  # max share of income for all EMIs

# LangSmith tracing is switched on purely through env vars:
#   LANGSMITH_TRACING=true, LANGSMITH_API_KEY=..., LANGSMITH_PROJECT=banking-ai-assistant
LANGSMITH_ENABLED = os.getenv("LANGSMITH_TRACING", "false").lower() == "true"

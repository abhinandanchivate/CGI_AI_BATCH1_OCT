"""LangChain tools wrapping core-banking operations.
Each tool is traced automatically in LangSmith when tracing is enabled."""
import uuid
from datetime import datetime
from langchain_core.tools import tool

from app import config
from app.data import CUSTOMERS, TRANSACTIONS, TRANSFERRED_TODAY, POLICY_DOCS


def _customer(customer_id: str) -> dict:
    if customer_id not in CUSTOMERS:
        raise ValueError(f"Unknown customer {customer_id}")
    return CUSTOMERS[customer_id]


@tool
def get_balance(customer_id: str) -> dict:
    """Return the account number, type and current balance for a customer."""
    c = _customer(customer_id)
    return {"account_no": c["account_no"], "account_type": c["account_type"], "balance": c["balance"]}


@tool
def get_transactions(customer_id: str, limit: int = 5) -> list:
    """Return the most recent transactions for a customer (newest first)."""
    _customer(customer_id)
    return TRANSACTIONS.get(customer_id, [])[:limit]


@tool
def validate_transfer(customer_id: str, to_account: str, amount: float) -> dict:
    """Run pre-checks for a fund transfer: beneficiary, balance, daily limit, approval need."""
    c = _customer(customer_id)
    if amount is None or amount <= 0:
        return {"ok": False, "reason": "Please tell me a valid amount to transfer."}
    if not to_account:
        return {"ok": False, "reason": "Please tell me the beneficiary account number (e.g. SB2001)."}
    if to_account not in c["beneficiaries"]:
        return {"ok": False, "reason": f"{to_account} is not a registered beneficiary. Add it in the app first (cooling period applies)."}
    if amount > c["balance"]:
        return {"ok": False, "reason": f"Insufficient balance. Available: Rs {c['balance']:,.2f}."}
    used = TRANSFERRED_TODAY.get(customer_id, 0.0)
    if used + amount > config.DAILY_TRANSFER_LIMIT:
        left = config.DAILY_TRANSFER_LIMIT - used
        return {"ok": False, "reason": f"Daily limit exceeded. You can transfer up to Rs {left:,.2f} more today."}
    return {
        "ok": True,
        "beneficiary_name": c["beneficiaries"][to_account],
        "needs_approval": amount > config.APPROVAL_THRESHOLD,
    }


@tool
def execute_transfer(customer_id: str, to_account: str, amount: float) -> dict:
    """Debit the customer and credit the beneficiary. Call ONLY after validation/approval."""
    c = _customer(customer_id)
    c["balance"] -= amount
    TRANSFERRED_TODAY[customer_id] = TRANSFERRED_TODAY.get(customer_id, 0.0) + amount
    ref = f"TXN{datetime.now().strftime('%Y%m%d%H%M%S')}{uuid.uuid4().hex[:4].upper()}"
    TRANSACTIONS.setdefault(customer_id, []).insert(0, {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "desc": f"IMPS to {to_account} ({c['beneficiaries'][to_account]}) {ref}",
        "amount": -amount,
    })
    # credit the receiver if they are also our customer
    for cid, other in CUSTOMERS.items():
        if other["account_no"] == to_account:
            other["balance"] += amount
            TRANSACTIONS.setdefault(cid, []).insert(0, {
                "date": datetime.now().strftime("%Y-%m-%d"),
                "desc": f"IMPS from {c['account_no']} ({c['name']}) {ref}",
                "amount": amount,
            })
    return {"reference": ref, "new_balance": c["balance"]}


@tool
def check_loan_eligibility(customer_id: str, loan_amount: float, tenure_months: int = 36) -> dict:
    """Check personal-loan eligibility using credit score and FOIR, and compute the EMI."""
    c = _customer(customer_id)
    r = config.LOAN_INTEREST_RATE / 12 / 100
    n = tenure_months
    emi = loan_amount * r * (1 + r) ** n / ((1 + r) ** n - 1)
    foir = (c["existing_emi"] + emi) / c["monthly_income"]
    reasons = []
    if c["credit_score"] < config.MIN_CREDIT_SCORE:
        reasons.append(f"credit score {c['credit_score']} is below {config.MIN_CREDIT_SCORE}")
    if foir > config.MAX_FOIR:
        reasons.append(f"total EMIs would be {foir:.0%} of income (max {config.MAX_FOIR:.0%})")
    # max loan the customer can afford at this tenure
    max_emi = config.MAX_FOIR * c["monthly_income"] - c["existing_emi"]
    max_loan = max(0.0, max_emi * ((1 + r) ** n - 1) / (r * (1 + r) ** n))
    return {
        "eligible": not reasons,
        "emi": round(emi, 2),
        "interest_rate": config.LOAN_INTEREST_RATE,
        "tenure_months": n,
        "foir": round(foir, 3),
        "max_eligible_amount": round(max_loan, -3),
        "reasons": reasons,
    }


@tool
def search_policies(query: str, k: int = 2) -> list:
    """Keyword retriever over bank policy documents (swap for a vector store in production)."""
    words = {w.strip("?.,!").lower() for w in query.split() if len(w) > 2}
    scored = []
    for doc in POLICY_DOCS:
        text = (doc["title"] + " " + doc["text"]).lower()
        score = sum(1 for w in words if w in text)
        if score:
            scored.append((score, doc))
    scored.sort(key=lambda x: -x[0])
    return [d for _, d in scored[:k]]

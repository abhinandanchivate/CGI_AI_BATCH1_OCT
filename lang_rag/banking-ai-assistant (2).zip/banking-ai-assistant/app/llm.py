"""LLM layer: intent extraction (structured output) and answer generation.

LLM_MODE=gemini -> Google Gemini through langchain-google-genai (ChatGoogleGenerativeAI)
LLM_MODE=mock   -> deterministic rule-based fallback (offline demos / unit tests)
"""
import re
from typing import Literal, Optional

from langchain_core.messages import SystemMessage, HumanMessage
from langsmith import traceable
from pydantic import BaseModel, Field

from app import config

Intent = Literal["balance", "transactions", "transfer", "loan", "faq", "greeting", "other"]


class IntentResult(BaseModel):
    """Structured output the LLM must return for every user message."""
    intent: Intent = Field(description="What the customer wants")
    amount: Optional[float] = Field(None, description="Rupee amount for transfer or loan")
    to_account: Optional[str] = Field(None, description="Beneficiary account number like SB2001")
    tenure_months: Optional[int] = Field(None, description="Loan tenure in months")


CLASSIFY_PROMPT = """You are the intent router of a retail bank's assistant.
Classify the customer's message into exactly one intent:
- balance: wants account balance
- transactions: wants recent transactions / mini statement
- transfer: wants to send / transfer / pay money to an account
- loan: asks about loan eligibility, EMI, borrowing
- faq: general question about bank products, charges, KYC, cards, FD rates, fraud
- greeting: hello / thanks / small talk
- other: anything unrelated to banking
Extract amount (convert '1 lakh' to 100000, '50k' to 50000), to_account and tenure_months
(convert years to months) when present. Never invent values."""

ANSWER_PROMPT = """You are a polite, concise banking assistant for an Indian retail bank.
Answer the customer using ONLY the facts in the TOOL RESULT. Use Rs and Indian number
formatting. Never reveal internal fields, never ask for OTP/PIN/password. Max 4 sentences."""

_llm = None


def get_llm():
    """Return a cached Gemini chat model, or None in mock mode."""
    global _llm
    if _llm is None and config.USE_GEMINI:
        from langchain_google_genai import ChatGoogleGenerativeAI
        _llm = ChatGoogleGenerativeAI(
            model=config.GEMINI_MODEL,
            google_api_key=config.GOOGLE_API_KEY,
            temperature=config.GEMINI_TEMPERATURE,
            max_retries=2,
        )
    return _llm


# ---------------------------------------------------------------- mock helpers
def _parse_amount(text: str) -> Optional[float]:
    t = text.lower().replace(",", "")
    m = re.search(r"(\d+(?:\.\d+)?)\s*(lakh|lac|l\b|k\b|thousand)?", t)
    if not m:
        return None
    val = float(m.group(1))
    unit = m.group(2) or ""
    if unit.startswith(("lakh", "lac", "l")):
        val *= 100000
    elif unit in ("k", "thousand"):
        val *= 1000
    return val


def _mock_classify(text: str) -> IntentResult:
    t = text.lower()
    acct = re.search(r"\b(sb\d{4})\b", t)
    acct = acct.group(1).upper() if acct else None
    text_wo_acct = re.sub(r"\bsb\d{4}\b", "", t)
    if re.search(r"\b(transfer|send|pay)\b", t):
        return IntentResult(intent="transfer", amount=_parse_amount(text_wo_acct), to_account=acct)
    if re.search(r"\b(loan|emi|borrow)\b", t):
        tenure = re.search(r"(\d+)\s*(month|year|yr)", t)
        months = None
        if tenure:
            months = int(tenure.group(1)) * (12 if tenure.group(2).startswith(("year", "yr")) else 1)
        amt_text = re.sub(r"\d+\s*(months?|years?|yrs?)", "", text_wo_acct)
        return IntentResult(intent="loan", amount=_parse_amount(amt_text), tenure_months=months)
    if "balance" in t:
        return IntentResult(intent="balance")
    if re.search(r"transaction|statement|history|spent|spend", t):
        return IntentResult(intent="transactions")
    if re.search(r"\b(hi|hello|hey|thanks|thank you)\b", t):
        return IntentResult(intent="greeting")
    if re.search(r"fd|fixed deposit|kyc|charge|fee|card|fraud|otp|interest|minimum|neft|imps", t):
        return IntentResult(intent="faq")
    return IntentResult(intent="other")


# ---------------------------------------------------------------- public API
@traceable(name="classify_intent")
def classify(text: str) -> IntentResult:
    llm = get_llm()
    if llm is None:
        return _mock_classify(text)
    structured = llm.with_structured_output(IntentResult)
    return structured.invoke([SystemMessage(CLASSIFY_PROMPT), HumanMessage(text)])


@traceable(name="generate_answer")
def answer(question: str, tool_result: str, fallback: str) -> str:
    """Turn raw tool output into a customer-friendly reply. Mock mode returns `fallback`."""
    llm = get_llm()
    if llm is None:
        return fallback
    msg = llm.invoke([
        SystemMessage(ANSWER_PROMPT),
        HumanMessage(f"CUSTOMER: {question}\n\nTOOL RESULT: {tool_result}"),
    ])
    # Gemini can return content as a list of parts; .text joins the text parts
    return getattr(msg, "text", None) or (msg.content if isinstance(msg.content, str) else str(msg.content))

"""Scripted demo against a running server:  python demo.py"""
import httpx

BASE = "http://127.0.0.1:8000"
c = httpx.Client(base_url=BASE, timeout=60)


def say(msg, cid="C1001", thread=None):
    r = c.post("/chat", json={"customer_id": cid, "message": msg, "thread_id": thread}).json()
    print(f"\nYOU  > {msg}\nBOT  > {r.get('reply') or r.get('approval')}  [{r['status']}]")
    return r


print(c.get("/health").json())
t = say("Hi")["thread_id"]
say("What is my balance?", thread=t)
say("Show my recent transactions", thread=t)
say("Transfer 2000 to SB2001", thread=t)
r = say("Send 60000 to SB3001", thread=t)
if r["status"] == "pending_approval":
    ok = input("Approve this transfer? (y/n): ").strip().lower() == "y"
    r = c.post("/approve", json={"thread_id": t, "approved": ok}).json()
    print("BOT  >", r["reply"])
say("Am I eligible for a personal loan of 5 lakh for 3 years?", thread=t)
say("What are FD interest rates?", thread=t)
say("Should I share my OTP with the bank caller?", thread=t)

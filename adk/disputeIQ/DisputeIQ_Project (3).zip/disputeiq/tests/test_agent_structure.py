"""Structural tests: the agent graph builds and has the expected shape (no LLM call)."""
from dispute_agent.agent import root_agent, investigation_team, customer_letter


def test_root_tools():
    names = {getattr(t, "name", getattr(t, "__name__", "")) for t in root_agent.tools}
    assert {"investigation_team", "customer_letter", "issue_provisional_credit", "block_card",
            "escalate_to_human", "create_dispute_case"} <= names


def test_pipeline_order():
    assert [a.name for a in investigation_team.sub_agents] == ["intake_agent", "evidence_team", "decision_agent"]


def test_loop_bounded():
    assert customer_letter.max_iterations == 3

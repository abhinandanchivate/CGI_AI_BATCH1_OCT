"""Live HITL test (needs GOOGLE_API_KEY in dispute_agent/.env). Run: pytest tests/integration -q -s
Asserts: an UNAUTHORIZED ₹1,45,000 claim PAUSES for human approval, and NO money moves until approved."""
import asyncio
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.demo import load_env  # noqa: E402

pytestmark = pytest.mark.skipif(not (ROOT / "dispute_agent" / ".env").exists(), reason="no .env / API key")


async def _run():
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService
    from google.genai import types
    from dispute_agent import tools as T
    from dispute_agent.agent import root_agent

    svc = InMemorySessionService()
    runner = Runner(agent=root_agent, app_name="dispute_agent", session_service=svc)
    s = await svc.create_session(app_name="dispute_agent", user_id="C1002")
    msg = types.Content(role="user", parts=[types.Part(text=(
        "[authenticated customer_id=C1002] I didn't make the 1,45,000 payment T9101. I never shared OTP. "
        "Alert came yesterday."))])
    gated = []
    async for ev in runner.run_async(user_id="C1002", session_id=s.id, new_message=msg):
        for fc in ev.get_function_calls():
            if fc.name == "adk_request_confirmation":
                gated.append(fc.args["originalFunctionCall"]["name"])
    return gated, [c for c in T._CASES.values() if c["txn_id"] == "T9101"]


def test_unauthorized_pauses_and_no_money_moves():
    load_env()
    os.environ["DISPUTEIQ_LOG_PRETTY"] = "false"
    gated, cases = asyncio.run(_run())
    assert gated, "expected a human-approval request"
    assert set(gated) <= {"issue_provisional_credit", "block_card"}
    assert cases and cases[0]["state"] != "PROVISIONAL_CREDIT_POSTED", "money moved without approval!"

"""Unit tests for deterministic tools - these run in CI on every commit, no LLM needed."""
from dispute_agent import tools as T


def test_duplicate_detected():
    r = T.find_duplicate_charges("C1001", "T9001")
    assert r["is_duplicate"] and r["duplicate_txn_ids"] == ["T9002"]


def test_fraud_high_for_impossible_travel():
    r = T.compute_fraud_signals("T9101")
    assert r["risk_band"] == "high"
    assert any(s.startswith("impossible_travel") for s in r["signals"])


def test_fraud_low_for_normal_txn():
    assert T.compute_fraud_signals("T9001")["risk_band"] == "low"


def test_liability_zero_within_3_days():
    r = T.calculate_customer_liability("T9101", 2, False, False)
    assert r["customer_liability_inr"] == 0 and r["bank_liability_inr"] == 145000


def test_liability_limited_cap_by_account_type():
    r = T.calculate_customer_liability("T9101", 5, False, False)  # credit card > 5L
    assert r["customer_liability_inr"] == 25000


def test_liability_negligence_full():
    r = T.calculate_customer_liability("T9202", 1, True, False)
    assert r["customer_liability_inr"] == 3200


def test_liability_late_report_needs_human():
    assert T.calculate_customer_liability("T9101", 9, False, False)["requires_human"] is True


def test_atm_compensation_after_tat():
    r = T.compute_atm_compensation("T9201", 8)
    assert r["reversal_amount_inr"] == 7500 and r["compensation_inr"] == 300


def test_case_idempotent():
    a = T.create_dispute_case("C1001", "T9002", "DUPLICATE", "dup")
    b = T.create_dispute_case("C1001", "T9002", "DUPLICATE", "dup")
    assert a["case"]["case_id"] == b["case"]["case_id"]


def test_invalid_reason_code():
    assert T.create_dispute_case("C1001", "T9003", "FOO", "x")["status"] == "error"


def test_hitl_rule():
    case = T.create_dispute_case("C1002", "T9101", "UNAUTHORIZED", "fraud")["case"]["case_id"]
    assert T._credit_needs_approval(case, 500, "x") is True          # unauthorized always
    dup = T.create_dispute_case("C1001", "T9001", "DUPLICATE", "dup")["case"]["case_id"]
    assert T._credit_needs_approval(dup, 4999, "x") is False         # small duplicate auto
    assert T._credit_needs_approval(dup, 15000, "x") is True         # above limit


def test_block_card_resolves_card_from_txn():
    r = T.block_card("C1002", "T9101", "fraud")
    assert r["card_id"] == "CARD-1002-CC" and r["blocked"]
    assert T.block_card("C1001", "T9101", "x")["status"] == "not_found"   # not this customer's txn

#!/usr/bin/env bash
# Fires the code-generation prompts in order, running each step's VERIFY command, and stops at the first failure.
#   AGENT=gemini     Gemini CLI       (npm i -g @google/gemini-cli)
#   AGENT=claude     Claude Code      (npm i -g @anthropic-ai/claude-code)
#   AGENT=manual     prints each prompt; you paste it into any assistant, then press Enter to verify
#   AGENT=reference  copies the reference implementation for each step (fallback for live sessions; set REF=path)
# Optional: START=P03 to begin at a step, ONLY=P06 to run one step.
set -u
AGENT="${AGENT:-manual}"; START="${START:-P01}"; ONLY="${ONLY:-}"; REF="${REF:-}"
cd "$(dirname "$0")/.."
started=0
while IFS='|' read -r ID VERIFY REFFILES; do
  [[ -z "$ID" || "$ID" == \#* ]] && continue
  [[ "$ID" == "$START"* ]] && started=1
  [[ $started -eq 0 ]] && continue
  [[ -n "$ONLY" && "$ID" != "$ONLY"* ]] && continue
  FILE="codegen/prompts/$ID.md"
  PROMPT="$(awk '/^```text/{f=1;next} /^```/{f=0} f' "$FILE")"
  PROMPT="$PROMPT

After writing the files, run this verify command and fix the code until it passes: $VERIFY"
  echo -e "\n\033[1;33m════ $ID ════\033[0m"
  case "$AGENT" in
    gemini)    gemini --yolo -p "$PROMPT" ;;
    claude)    claude -p "$PROMPT" --permission-mode acceptEdits \
                 --allowedTools "Read" "Write" "Edit" "Bash(python:*)" "Bash(pytest:*)" "Bash(adk:*)" "Bash(make:*)" "Bash(mkdir:*)" "Bash(ls:*)" ;;
    manual)    echo "$PROMPT"; read -r -p $'\n\033[1mPaste the prompt into your coding assistant. Press Enter when it is done... \033[0m' _ </dev/tty ;;
    reference) [[ -z "$REF" ]] && { echo "set REF=/path/to/reference/disputeiq"; exit 2; }
               for f in $REFFILES; do mkdir -p "$(dirname "$f")"; cp -r "$REF/$f" "$(dirname "$f")/"; done ;;
    *) echo "unknown AGENT=$AGENT"; exit 2 ;;
  esac
  echo -e "\033[1;36m▶ verify: $VERIFY\033[0m"
  if bash -c "$VERIFY"; then echo -e "\033[1;32m✔ $ID passed\033[0m"
  else
    echo -e "\033[1;31m✘ $ID failed.\033[0m Ask the agent: \"The verify command failed with the output above. Fix the code (not the tests) until it passes.\""
    echo "Resume with: START=$ID AGENT=$AGENT bash scripts/fire_prompts.sh   (or AGENT=reference REF=... ONLY=$ID to fast-forward)"
    exit 1
  fi
done < codegen/sequence.txt
echo -e "\n\033[1;32mAll steps generated and verified.\033[0m"

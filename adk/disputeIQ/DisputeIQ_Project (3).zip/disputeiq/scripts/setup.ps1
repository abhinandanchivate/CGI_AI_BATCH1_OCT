# One-command setup for Windows PowerShell.
# Usage (from the project folder):  powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
Write-Host "==> Creating virtual environment (.venv)"
py -3 -m venv .venv
. .\.venv\Scripts\Activate.ps1
Write-Host "==> Installing dependencies (2-4 minutes)"
python -m pip install -q --upgrade pip
pip install -q -r requirements.txt
if (-not (Test-Path "dispute_agent\.env")) {
  Copy-Item ".env.example" "dispute_agent\.env"
  $sec = Read-Host "Paste your Gemini API key (input hidden)" -AsSecureString
  $key = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
  $env_text = Get-Content "dispute_agent\.env" -Raw
  $env_text = $env_text -replace "(?m)^GOOGLE_API_KEY=.*$", "GOOGLE_API_KEY=$key"
  $env_text = $env_text -replace "(?m)^DISPUTEIQ_MODEL_REASONING=.*$", "DISPUTEIQ_MODEL_REASONING=gemini-3.8-flash"
  Set-Content "dispute_agent\.env" $env_text -NoNewline
}
Write-Host "==> Offline unit tests"
python -m pytest -q tests --ignore=tests/integration
Write-Host "==> Checking the key and model (1 call)"
python scripts\check_key.py
Write-Host ""
Write-Host "All set. Next:  .\.venv\Scripts\Activate.ps1 ; python scripts\demo.py --list"

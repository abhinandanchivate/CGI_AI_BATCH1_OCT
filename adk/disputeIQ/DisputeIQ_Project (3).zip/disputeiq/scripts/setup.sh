#!/usr/bin/env bash
# One-command setup for macOS / Linux.   Usage:  bash scripts/setup.sh
set -e
cd "$(dirname "$0")/.."
echo "==> Creating virtual environment (.venv)"
python3 -m venv .venv
source .venv/bin/activate
echo "==> Installing dependencies (2-4 minutes)"
pip install -q --upgrade pip
pip install -q -r requirements.txt
if [ ! -f dispute_agent/.env ]; then
  cp .env.example dispute_agent/.env
  read -r -s -p "Paste your Gemini API key (input hidden): " KEY; echo
  # replace the placeholder line; key never printed to screen
  python3 - "$KEY" <<'PY'
import sys, re, pathlib
p = pathlib.Path("dispute_agent/.env"); s = p.read_text()
s = re.sub(r"^GOOGLE_API_KEY=.*$", "GOOGLE_API_KEY=" + sys.argv[1], s, flags=re.M)
s = re.sub(r"^DISPUTEIQ_MODEL_REASONING=.*$", "DISPUTEIQ_MODEL_REASONING=gemini-3.8-flash", s, flags=re.M)
p.write_text(s)
PY
  chmod 600 dispute_agent/.env
fi
echo "==> Offline unit tests"
python -m pytest -q tests --ignore=tests/integration
echo "==> Checking the key and model (1 call)"
python - <<'PY'
import os, pathlib
for line in pathlib.Path("dispute_agent/.env").read_text().splitlines():
    line = line.split("#", 1)[0].strip()
    if "=" in line:
        k, v = line.split("=", 1); os.environ[k.strip()] = v.strip()
from google import genai
c = genai.Client()
r = c.models.generate_content(model=os.environ["DISPUTEIQ_MODEL_FAST"], contents="Reply with: READY")
print("Model says:", r.text.strip())
PY
echo
echo "All set. Next:  source .venv/bin/activate && python scripts/demo.py --list"

"""Checks that the API key in dispute_agent/.env works and the configured model is available.
Usage: python scripts/check_key.py"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from scripts.demo import load_env  # noqa: E402

load_env()
from google import genai  # noqa: E402

model = os.environ.get("DISPUTEIQ_MODEL_FAST", "gemini-3.8-flash")
client = genai.Client()  # keep a reference: a temporary client is closed before the call
try:
    r = client.models.generate_content(model=model, contents="Reply with: READY")
    print(f"OK - {model} says: {r.text.strip()}")
except Exception as e:  # show the fix for the common errors
    msg = str(e)
    print("FAILED:", msg[:300])
    if "API_KEY_INVALID" in msg:
        print("Fix: the key is wrong or revoked - create a new one in Google AI Studio and update dispute_agent/.env")
    elif "no longer available" in msg or "NOT_FOUND" in msg:
        print("Fix: set DISPUTEIQ_MODEL_FAST / _REASONING in .env to a model your key can use (python scripts/check_key.py --list)")
    elif "429" in msg or "RESOURCE_EXHAUSTED" in msg:
        print("Fix: quota exceeded - wait a minute, or use a key with billing enabled for workshops")
    sys.exit(1)

if "--list" in sys.argv:
    print([m.name for m in client.models.list() if "gemini" in m.name])

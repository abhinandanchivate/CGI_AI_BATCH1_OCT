#!/usr/bin/env bash
# Step 0 of the code-generation sequence: build an (almost) empty project folder holding only the SPEC
# (case study, agent context, acceptance tests, prompts). A coding agent then generates everything else.
# Usage: bash scripts/make_spec_pack.sh ../disputeiq-live
set -e
SRC="$(cd "$(dirname "$0")/.." && pwd)"
DEST="${1:-../disputeiq-live}"
mkdir -p "$DEST/docs" "$DEST/tests" "$DEST/codegen" "$DEST/scripts" "$DEST/dispute_agent"
cp "$SRC/codegen/AGENT_CONTEXT.md" "$DEST/GEMINI.md"           # read automatically by Gemini CLI
cp "$SRC/codegen/AGENT_CONTEXT.md" "$DEST/CLAUDE.md"           # read automatically by Claude Code
cp "$SRC/docs/01_CASE_STUDY.md" "$DEST/docs/"                  # requirements
cp "$SRC"/tests/test_*.py "$DEST/tests/"                       # acceptance tests (the agent must make them pass)
cp -r "$SRC/codegen/prompts" "$SRC/codegen/sequence.txt" "$DEST/codegen/"
cp "$SRC/scripts/fire_prompts.sh" "$DEST/scripts/"
if [ -f "$SRC/dispute_agent/.env" ]; then cp "$SRC/dispute_agent/.env" "$DEST/dispute_agent/.env"; chmod 600 "$DEST/dispute_agent/.env"; fi
echo "Spec pack ready in $DEST"
echo "Next:  cd $DEST && python3 -m venv .venv && source .venv/bin/activate && pip install google-adk pytest pyyaml"
echo "Then:  AGENT=gemini bash scripts/fire_prompts.sh      (or AGENT=claude)"

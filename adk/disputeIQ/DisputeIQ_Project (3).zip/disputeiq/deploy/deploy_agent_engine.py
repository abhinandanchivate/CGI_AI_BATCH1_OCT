"""Deploy DisputeIQ to Vertex AI Agent Engine (managed runtime, sessions, tracing).

Simplest path is the CLI (used by CI):
  adk deploy agent_engine --project=$PROJECT --region=$REGION --display_name=disputeiq-$ENV \
      --trace_to_cloud dispute_agent

This script is the programmatic equivalent, useful when you need custom env vars / service account.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def main(a):
    import vertexai
    from vertexai import agent_engines

    from dispute_agent.agent import root_agent

    vertexai.init(project=a.project, location=a.region, staging_bucket=a.bucket)
    app = agent_engines.AdkApp(agent=root_agent, enable_tracing=True)
    remote = agent_engines.create(
        agent_engine=app,
        display_name=f"disputeiq-{a.env}",
        requirements=["google-adk>=1.20", "google-cloud-aiplatform[agent_engines,adk]", "pyyaml"],
        extra_packages=["./dispute_agent", "./data"],
        env_vars={"DISPUTEIQ_ENV": a.env, "DISPUTEIQ_PROMPT_VERSION": a.prompt_version,
                  "DISPUTEIQ_SAFE_MODE": "false"},
    )
    print("deployed:", remote.resource_name)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--project", required=True); p.add_argument("--region", default="asia-south1")
    p.add_argument("--bucket", required=True); p.add_argument("--env", default="staging")
    p.add_argument("--prompt_version", default="v3")
    main(p.parse_args())

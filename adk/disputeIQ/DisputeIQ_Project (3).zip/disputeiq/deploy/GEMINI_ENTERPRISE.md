# Publishing DisputeIQ in Gemini Enterprise (S086)

Gemini Enterprise is the employee-facing surface. Dispute-operations staff use it to talk to the
**internal** variant of the agent (case triage, approvals, policy Q&A). Customers reach the agent
through the bank's app and IVR via the Agent Engine API, not through Gemini Enterprise.

> Console labels change often. Check the current Google Cloud docs for exact menu names before you start.

## 1. Register the ADK agent
1. Deploy to Agent Engine (`make deploy-staging`) and copy the reasoning-engine resource name.
2. In the Google Cloud console open **Gemini Enterprise → Apps → (your app) → Agents → Add agent → Custom agent via Agent Engine**.
3. Paste the resource name. Set the display name to *DisputeIQ – Ops Assistant* and add a description staff will see.
4. If the agent calls Google Workspace or other user-scoped APIs, add an OAuth authorization.
5. Share the agent only with the `grp-dispute-ops` group (least privilege).

## 2. "Use agents to build agents"
We use agents to speed up how we build agents. Humans still review every output.

| Task | Agent used | Human gate |
|---|---|---|
| Scaffold a new sub-agent (e.g. UPI disputes) | Gemini CLI / Gemini Code Assist with the ADK docs as context, or `adk create` | Code review |
| Draft no-code helper agents for ops (e.g. "summarise today's P2 queue") | Gemini Enterprise **Agent Designer** | Ops lead sign-off |
| Generate new eval cases from production escalations | A "test-writer" agent that turns redacted transcripts into `.evalset.json` cases | QA reviews each case |
| Prompt optimisation | `adk optimize` (GEPA) over the eval set | Accept only if the hill-climb gate passes |

## 3. Guardrails that still apply
- The same `before_tool_guard`, HITL confirmation and SAFE_MODE apply. Gemini Enterprise is only a front end.
- Ops users can **approve** pending confirmations only if their IAM role is `disputes.approver`.

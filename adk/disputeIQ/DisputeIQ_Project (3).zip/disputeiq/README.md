# DisputeIQ: Agentic Card Dispute and Fraud Resolution (NovaBank, fictional)

A reference project that covers syllabus sessions **S079–S100**: multi-agent design with Google ADK, human-in-the-loop, guardrails, observability, LLM-as-judge evaluation, hill climbing, LoRA/QLoRA fine-tuning for function calling, CI/CD and operations.

## Documents
| # | Document | Purpose |
|---|---|---|
| 1 | [docs/01_CASE_STUDY.md](docs/01_CASE_STUDY.md) | Business case, scope, **requirements (FR / RR / NFR with acceptance criteria)**, architecture, risks |
| 2 | [docs/02_IMPLEMENTATION_GUIDE.md](docs/02_IMPLEMENTATION_GUIDE.md) | 24 steps, each with What / Why / How / Done-when |
| 3 | [docs/03_SYLLABUS_TRACEABILITY.md](docs/03_SYLLABUS_TRACEABILITY.md) | S079–S100 mapped to sections, files and tests |
| 4 | [docs/04_RUNBOOK.md](docs/04_RUNBOOK.md) | Operating procedures RB-01…RB-10 |
| 5 | [docs/05_PLAYBOOK.md](docs/05_PLAYBOOK.md) | RACI, case-handling plays, release gates, incident plays |
| 7 | [docs/07_LIVE_DEMO_GUIDE.md](docs/07_LIVE_DEMO_GUIDE.md) | Presenter script for a live session |
| 8 | [docs/08_PROMPTS_AND_COMMANDS.md](docs/08_PROMPTS_AND_COMMANDS.md) | Code-generation prompts, firing sequence, run commands, runtime prompts |
| 6 | [docs/06_ISSUES_CATALOGUE.md](docs/06_ISSUES_CATALOGUE.md) | Prompt and LLM failure modes with fixes |
| – | [deploy/GEMINI_ENTERPRISE.md](deploy/GEMINI_ENTERPRISE.md) | Publishing to Gemini Enterprise; using agents to build agents |
| – | `DisputeIQ_Project_Deck.pptx` | Presentation (delivered alongside the repo) |

## Repository layout
```
dispute_agent/          ADK agent package (root_agent in agent.py)
  agent.py              multi-agent graph: concierge -> investigation (seq + parallel) -> letter loop
  prompts.py            versioned prompts
  tools/banking_tools.py deterministic banking tools (mock data)
  guardrails.py         PII redaction, injection filter, tool policy, LLM budget
  observability.py      JSON logs, OTel tracing, token/cost logging
  config.py             env-driven config, SAFE_MODE kill switch
data/                   mock customers, transactions, policy (RBI-aligned, illustrative)
eval/
  evalsets/             ADK golden eval set (7 cases)
  test_config*.json     fast gate and LLM-judge gate criteria
  judge/                custom LLM-as-judge + rubric + calibration
  hill_climb.py         candidate-vs-champion hill climbing
  system_metrics.py     task completion, tool and cost metrics from logs
finetune/               function-calling dataset builder, QLoRA trainer, eval (ROUGE/BLEU/MMLU...)
deploy/                 Agent Engine deploy script, Gemini Enterprise guide
ops/alerts.yaml         SLOs, log-based metrics, alert policies
.github/workflows/ci.yml CI/CD with eval gates and approvals
tests/                  22 unit tests (no LLM needed)
```

## Present it live
See **[docs/07_LIVE_DEMO_GUIDE.md](docs/07_LIVE_DEMO_GUIDE.md)**: setup, a 90-minute session flow, a script per demo, troubleshooting, and backup recordings in `demo_outputs/`.
```bash
bash scripts/setup.sh            # Windows: powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
python scripts/demo.py --list    # 8 scenarios
python scripts/demo.py --scenario 3   # human-approval pause, you approve live
```

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate
make install
cp .env.example dispute_agent/.env     # add GOOGLE_API_KEY or Vertex settings
make test                              # offline unit tests
make web                               # ADK dev UI -> http://localhost:8000
make eval                              # agent eval gate (needs model access)
make metrics                           # system metrics on sample logs
```

Try these in the UI:
- `[authenticated customer_id=C1001] I was charged twice at QuickBuy, txn T9002`
- `[authenticated customer_id=C1002] I didn't make the 1,45,000 payment T9101, never shared OTP, alert came yesterday`
- `[authenticated customer_id=C1003] ATM took 7500 but gave no cash, T9201`

## Code review checklist (S085)
- [ ] New tool: typed arguments, a docstring written for the model, returns `status`, unit-tested, idempotent if it writes
- [ ] No money or liability maths in prompts
- [ ] Prompt change: version bumped, eval run attached
- [ ] No PII values in logs
- [ ] New failure mode: eval case added

> All banks, people and figures are fictional. Regulatory values are illustrative and must be validated by Compliance.

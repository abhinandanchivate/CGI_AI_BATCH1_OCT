"""Managed alternative: Vertex AI supervised fine-tuning of Gemini (parameter-efficient adapters
under the hood). Use when you want to stay on Gemini and avoid running GPUs.

  python finetune/vertex_tuning.py --project my-proj --region asia-south1 \
      --train gs://bucket/fc_vertex_train.jsonl --val gs://bucket/fc_vertex_val.jsonl
"""
import argparse
import time


def main(a):
    import vertexai
    from vertexai.tuning import sft

    vertexai.init(project=a.project, location=a.region)
    job = sft.train(
        source_model=a.base, train_dataset=a.train, validation_dataset=a.val,
        epochs=a.epochs, adapter_size=a.adapter_size, learning_rate_multiplier=1.0,
        tuned_model_display_name="disputeiq-fc-gemini",
    )
    while not job.has_ended:
        time.sleep(60); job.refresh()
    print("tuned endpoint:", job.tuned_model_endpoint_name)
    print("set DISPUTEIQ_MODEL_TOOL_CALLER to this endpoint and run `make eval` + hill climb")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--project", required=True); p.add_argument("--region", default="asia-south1")
    p.add_argument("--base", default="gemini-3.8-flash")
    p.add_argument("--train", required=True); p.add_argument("--val", required=True)
    p.add_argument("--epochs", type=int, default=3); p.add_argument("--adapter_size", type=int, default=4)
    main(p.parse_args())

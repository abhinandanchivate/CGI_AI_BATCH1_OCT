"""QLoRA / LoRA fine-tuning of an open model for function calling (S089-S091, S093).

Why PEFT: full fine-tuning of a 4-12B model needs multiple 80GB GPUs; QLoRA trains ~0.1-1% of
parameters on a single 24-48GB GPU, and the frozen base weights limit catastrophic forgetting.

Run (GPU machine / Vertex AI custom job):
  pip install -r finetune/requirements-ft.txt
  python finetune/train_qlora.py --config finetune/configs/qlora.yaml
"""
from __future__ import annotations

import argparse

import yaml


def main(cfg_path: str):
    import torch
    from datasets import load_dataset
    from peft import LoraConfig, prepare_model_for_kbit_training
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from trl import SFTConfig, SFTTrainer

    cfg = yaml.safe_load(open(cfg_path))
    tok = AutoTokenizer.from_pretrained(cfg["base_model"])

    quant = None
    if cfg["method"] == "qlora":  # 4-bit NF4 base + double quantisation
        quant = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                   bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.bfloat16)
    model = AutoModelForCausalLM.from_pretrained(cfg["base_model"], quantization_config=quant,
                                                 torch_dtype=torch.bfloat16, device_map="auto")
    if quant:
        model = prepare_model_for_kbit_training(model)

    lora = LoraConfig(r=cfg["lora"]["r"], lora_alpha=cfg["lora"]["alpha"], lora_dropout=cfg["lora"]["dropout"],
                      target_modules=cfg["lora"]["target_modules"], task_type="CAUSAL_LM")

    ds = load_dataset("json", data_files={"train": cfg["train_file"], "eval": cfg["eval_file"]})

    def to_text(ex):  # chat template renders tools + tool_calls for models that support them
        return {"text": tok.apply_chat_template(ex["messages"], tools=ex.get("tools"), tokenize=False)}

    ds = ds.map(to_text, remove_columns=ds["train"].column_names)

    args = SFTConfig(
        output_dir=cfg["output_dir"], num_train_epochs=cfg["epochs"], learning_rate=cfg["lr"],
        per_device_train_batch_size=cfg["batch_size"], gradient_accumulation_steps=cfg["grad_accum"],
        lr_scheduler_type="cosine", warmup_ratio=0.05, logging_steps=10, eval_strategy="steps",
        eval_steps=50, save_steps=50, load_best_model_at_end=True, bf16=True,
        max_length=cfg["max_seq_len"], dataset_text_field="text", report_to=cfg.get("report_to", "none"),
    )
    trainer = SFTTrainer(model=model, args=args, train_dataset=ds["train"], eval_dataset=ds["eval"],
                         peft_config=lora, processing_class=tok)
    trainer.train()
    trainer.save_model(cfg["output_dir"])  # saves only the adapter (~tens of MB)
    print("adapter saved to", cfg["output_dir"])


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--config", default="finetune/configs/qlora.yaml")
    main(ap.parse_args().config)

"""Evaluate a fine-tuned model (S092) - task metrics AND forgetting checks.

Task metrics (on held-out PII-redacted dispute data):
  * Function-call exact match (name + args)   - primary metric for S093
  * Function-call name accuracy, arg F1, "no-call when should ask" accuracy
  * ROUGE-L / BLEU on customer-letter generation vs approved letters (surface overlap only;
    always pair with LLM-as-judge because good letters can be worded differently)

Forgetting / general capability (compare base vs tuned; fail if drop > 2 points):
  * MMLU (knowledge), BIG-Bench Hard (reasoning), GLUE subset (NLU),
    run with EleutherAI lm-evaluation-harness:
      lm_eval --model hf --model_args pretrained=google/gemma-3-4b-it,peft=finetune/out/... \
              --tasks mmlu,bbh,glue --batch_size 8 --output_path finetune/out/lm_eval
  * HELM is used as the reference *framework* for holistic reporting (accuracy, calibration,
    robustness, fairness, toxicity, efficiency) in the model-risk dossier.
"""
from __future__ import annotations

import json
import sys


def fc_metrics(preds: list[list[dict]], golds: list[list[dict]]) -> dict:
    exact = name_ok = no_call_ok = no_call_total = 0
    arg_tp = arg_fp = arg_fn = 0
    for p, g in zip(preds, golds):
        if not g:
            no_call_total += 1; no_call_ok += int(not p)
        exact += int(p == g)
        name_ok += int([c["name"] for c in p] == [c["name"] for c in g])
        pa = {(c["name"], k, json.dumps(v)) for c in p for k, v in c.get("arguments", {}).items()}
        ga = {(c["name"], k, json.dumps(v)) for c in g for k, v in c.get("arguments", {}).items()}
        arg_tp += len(pa & ga); arg_fp += len(pa - ga); arg_fn += len(ga - pa)
    prec = arg_tp / max(arg_tp + arg_fp, 1); rec = arg_tp / max(arg_tp + arg_fn, 1)
    n = max(len(golds), 1)
    return {"exact_match": exact / n, "name_accuracy": name_ok / n,
            "arg_f1": 2 * prec * rec / max(prec + rec, 1e-9),
            "no_call_accuracy": no_call_ok / max(no_call_total, 1)}


def text_metrics(preds: list[str], refs: list[str]) -> dict:
    import evaluate  # pip install evaluate rouge_score sacrebleu
    rouge = evaluate.load("rouge").compute(predictions=preds, references=refs)
    bleu = evaluate.load("sacrebleu").compute(predictions=preds, references=[[r] for r in refs])
    return {"rougeL": rouge["rougeL"], "bleu": bleu["score"]}


def forgetting_gate(base: dict, tuned: dict, max_drop: float = 2.0) -> bool:
    """base/tuned: {"mmlu": 58.1, "bbh": 41.0, ...} in percentage points."""
    drops = {k: base[k] - tuned.get(k, 0) for k in base}
    print("capability drop (pts):", drops)
    return all(d <= max_drop for d in drops.values())


if __name__ == "__main__":
    data = json.load(open(sys.argv[1]))  # {"preds": [...], "golds": [...]}
    print(json.dumps(fc_metrics(data["preds"], data["golds"]), indent=2))

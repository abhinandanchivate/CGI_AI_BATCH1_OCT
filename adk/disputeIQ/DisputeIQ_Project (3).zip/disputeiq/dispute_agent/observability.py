"""Observability (S094/S095): structured logs, metrics and traces.

* Traces  - ADK emits OpenTelemetry spans for every agent run, LLM call and tool call.
            On Agent Engine set enable_tracing=True / --trace_to_cloud to export to Cloud Trace.
            Locally, `setup_tracing()` wires an OTLP or console exporter.
* Logs    - one JSON line per tool call / LLM call (Cloud Logging parses JSON automatically).
* Metrics - derived from logs via log-based metrics (see ops/alerts.yaml) or pushed directly.
"""
from __future__ import annotations

import json
import logging
import os
import sys
import time
from typing import Any, Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmResponse
from google.adk.tools import BaseTool, ToolContext

from . import config

# Indicative USD prices per 1M tokens; keep in sync with the provider price sheet.
# Fill from the current Gemini price sheet before using cost metrics; unknown models log cost 0.
PRICE_PER_M = {
    "gemini-3.8-flash": {"in": 0.0, "out": 0.0},
    "gemini-pro-latest": {"in": 0.0, "out": 0.0},
}

_logger = logging.getLogger("disputeiq")
if not _logger.handlers:
    h = logging.StreamHandler(sys.stdout)
    h.setFormatter(logging.Formatter("%(message)s"))
    _logger.addHandler(h)
    _logger.setLevel(os.getenv("LOG_LEVEL", "INFO"))


_PRETTY = os.getenv("DISPUTEIQ_LOG_PRETTY", "false").lower() == "true"


def log_event(event: str, **fields: Any) -> None:
    if _PRETTY:  # human-friendly one-liners for live demos
        if event == "tool_call":
            print(f"      \033[36m⚙ {fields.get('agent')} → {fields.get('tool')}  [{fields.get('status')}] "
                  f"{fields.get('latency_ms')} ms\033[0m", flush=True)
        elif event == "llm_call":
            print(f"      \033[90m✦ {fields.get('agent')} LLM call  in={fields.get('tokens_in')} "
                  f"out={fields.get('tokens_out')} tokens\033[0m", flush=True)
        return
    rec = {"event": event, "env": config.ENV, "prompt_version": config.PROMPT_VERSION, "ts": time.time(), **fields}
    _logger.info(json.dumps(rec, default=str))


def setup_tracing() -> None:
    """Export ADK's OpenTelemetry spans. Uses OTLP if OTEL_EXPORTER_OTLP_ENDPOINT is set,
    otherwise Cloud Trace if GOOGLE_CLOUD_PROJECT is set and the exporter is installed."""
    try:
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
    except ImportError:
        return
    provider = TracerProvider()
    if os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT"):
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
    elif os.getenv("GOOGLE_CLOUD_PROJECT"):
        try:
            from opentelemetry.exporter.cloud_trace import CloudTraceSpanExporter
            provider.add_span_processor(BatchSpanProcessor(CloudTraceSpanExporter()))
        except ImportError:
            pass
    trace.set_tracer_provider(provider)


# ---------------------------------------------------------------- callbacks
def before_tool_timer(tool: BaseTool, args: dict, tool_context: ToolContext) -> Optional[dict]:
    tool_context.state[f"temp:t0:{tool.name}"] = time.perf_counter()
    return None


def after_tool_logger(tool: BaseTool, args: dict, tool_context: ToolContext, tool_response: Any) -> Optional[dict]:
    t0 = tool_context.state.get(f"temp:t0:{tool.name}")
    status = tool_response.get("status", "ok") if isinstance(tool_response, dict) else "ok"
    log_event(
        "tool_call",
        session_id=tool_context.session.id if getattr(tool_context, "session", None) else None,
        agent=tool_context.agent_name, tool=tool.name, status=status,
        latency_ms=round((time.perf_counter() - t0) * 1000, 1) if t0 else None,
        arg_keys=sorted(args.keys()),  # keys only: never log values (PII)
    )
    return None


def after_model_logger(callback_context: CallbackContext, llm_response: LlmResponse) -> Optional[LlmResponse]:
    usage = llm_response.usage_metadata
    if usage:
        model = callback_context._invocation_context.agent.model if hasattr(callback_context, "_invocation_context") else "unknown"
        model = model if isinstance(model, str) else getattr(model, "model", "unknown")
        price = PRICE_PER_M.get(model, {"in": 0, "out": 0})
        tin, tout = usage.prompt_token_count or 0, usage.candidates_token_count or 0
        log_event("llm_call", agent=callback_context.agent_name, model=model, tokens_in=tin, tokens_out=tout,
                  cost_usd=round(tin / 1e6 * price["in"] + tout / 1e6 * price["out"], 6),
                  finish_reason=str(llm_response.finish_reason) if llm_response.finish_reason else None)
    return None

from . import agent  # noqa: F401  (ADK convention: package exposes agent.root_agent)

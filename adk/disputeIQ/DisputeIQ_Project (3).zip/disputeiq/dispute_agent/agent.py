"""DisputeIQ multi-agent system built with Google Agent Development Kit (ADK).

Coordination strategies used (S079):
  * Hierarchical / orchestrator  - `dispute_concierge` owns the conversation and delegates.
  * Sequential pipeline          - intake -> evidence -> decision (`investigation_team`).
  * Parallel fan-out / gather    - transaction, fraud and policy analysts run concurrently.
  * Generator-critic loop        - letter writer + compliance reviewer (`customer_letter`).
Human-in-the-loop (S081): `require_confirmation` pauses money movement / card blocking for approval.
"""
from __future__ import annotations

from google.adk.agents import LlmAgent, LoopAgent, ParallelAgent, SequentialAgent
from google.adk.tools import AgentTool, FunctionTool, exit_loop
from google.genai import types

from . import config, prompts
from .guardrails import before_model_guard, before_tool_guard
from .observability import after_model_logger, after_tool_logger, before_tool_timer, setup_tracing
from .tools import (
    _credit_needs_approval, block_card, calculate_customer_liability, compute_atm_compensation,
    compute_fraud_signals, create_dispute_case, escalate_to_human, find_duplicate_charges,
    get_customer_profile, get_recent_transactions, get_transaction_details, issue_provisional_credit,
    lookup_dispute_policy,
)

setup_tracing()

_THINK = types.ThinkingConfig(thinking_level=config.THINKING_LEVEL) if config.THINKING_LEVEL else None
DETERMINISTIC = types.GenerateContentConfig(temperature=0.0, thinking_config=_THINK)
CREATIVE = types.GenerateContentConfig(temperature=0.2, thinking_config=_THINK)


def _return_final_letter(callback_context):
    """The reviewer ends the loop by calling exit_loop (no text), so emit the approved
    draft as the loop's final output - otherwise AgentTool returns an empty result."""
    return types.Content(role="model", parts=[types.Part(text=callback_context.state.get("letter_draft", ""))])
_CB = dict(
    before_model_callback=before_model_guard,
    after_model_callback=after_model_logger,
    before_tool_callback=[before_tool_guard, before_tool_timer],
    after_tool_callback=after_tool_logger,
)

# ----------------------------------------------------------------- investigation pipeline
intake_agent = LlmAgent(
    name="intake_agent", model=config.MODEL_TOOL_CALLER, instruction=prompts.INTAKE,
    description="Collects verified customer and transaction facts.",
    tools=[get_customer_profile, get_transaction_details],
    output_key="intake_summary", generate_content_config=DETERMINISTIC, **_CB,
)
txn_analyst = LlmAgent(
    name="transaction_analyst", model=config.MODEL_TOOL_CALLER, instruction=prompts.TXN_ANALYST,
    description="Analyses the disputed transaction (duplicates, ATM journal, merchant data).",
    tools=[get_transaction_details, find_duplicate_charges, compute_atm_compensation],
    output_key="txn_findings", generate_content_config=DETERMINISTIC, **_CB,
)
fraud_analyst = LlmAgent(
    name="fraud_analyst", model=config.MODEL_TOOL_CALLER, instruction=prompts.FRAUD_ANALYST,
    description="Scores fraud risk and computes customer liability.",
    tools=[compute_fraud_signals, calculate_customer_liability],
    output_key="fraud_findings", generate_content_config=DETERMINISTIC, **_CB,
)
policy_analyst = LlmAgent(
    name="policy_analyst", model=config.MODEL_FAST, instruction=prompts.POLICY_ANALYST,
    description="Retrieves bank policy and regulatory timelines.",
    tools=[lookup_dispute_policy],
    output_key="policy_findings", generate_content_config=DETERMINISTIC, **_CB,
)
evidence_team = ParallelAgent(
    name="evidence_team", sub_agents=[txn_analyst, fraud_analyst, policy_analyst],
    description="Runs the three evidence analysts concurrently.",
)
decision_agent = LlmAgent(
    name="decision_agent", model=config.MODEL_REASONING, instruction=prompts.DECISION,
    description="Applies decision rules to evidence and recommends an action.",
    output_key="decision", generate_content_config=DETERMINISTIC,
    before_model_callback=before_model_guard, after_model_callback=after_model_logger,
)
investigation_team = SequentialAgent(
    name="investigation_team", sub_agents=[intake_agent, evidence_team, decision_agent],
    description="Investigates a dispute end-to-end and returns a JSON recommendation "
                "{action, amount_inr, priority, justification, confidence}.",
)

# ----------------------------------------------------------------- generator-critic loop
letter_writer = LlmAgent(
    name="letter_writer", model=config.MODEL_FAST, instruction=prompts.LETTER_WRITER,
    output_key="letter_draft", generate_content_config=CREATIVE,
    before_model_callback=before_model_guard, after_model_callback=after_model_logger,
)
letter_reviewer = LlmAgent(
    name="letter_reviewer", model=config.MODEL_FAST, instruction=prompts.LETTER_REVIEWER,
    tools=[exit_loop], output_key="letter_review", generate_content_config=DETERMINISTIC,
    before_model_callback=before_model_guard, after_model_callback=after_model_logger,
)
customer_letter = LoopAgent(
    name="customer_letter", sub_agents=[letter_writer, letter_reviewer], max_iterations=3,
    after_agent_callback=_return_final_letter,
    description="Drafts and compliance-reviews the final customer message.",
)

# ----------------------------------------------------------------- root orchestrator
root_agent = LlmAgent(
    name="dispute_concierge",
    model=config.MODEL_FAST,
    description="NovaBank customer-facing dispute & fraud resolution concierge.",
    instruction=prompts.CONCIERGE,
    tools=[
        get_recent_transactions,
        create_dispute_case,
        AgentTool(agent=investigation_team),
        FunctionTool(issue_provisional_credit, require_confirmation=_credit_needs_approval),
        FunctionTool(block_card, require_confirmation=True),
        escalate_to_human,
        AgentTool(agent=customer_letter),
    ],
    generate_content_config=CREATIVE,
    **_CB,
)

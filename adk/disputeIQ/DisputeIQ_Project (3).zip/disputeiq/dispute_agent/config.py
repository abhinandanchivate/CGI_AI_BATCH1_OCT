"""Central configuration. Everything that differs between dev / staging / prod lives here
and is read from environment variables (see .env.example)."""
from __future__ import annotations

import json
import os
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("DISPUTEIQ_DATA_DIR", ROOT / "data"))

# Model routing (S100: cost control). Cheap/fast model for routine steps,
# stronger model only where reasoning quality matters.
MODEL_FAST = os.getenv("DISPUTEIQ_MODEL_FAST", "gemini-3.8-flash")
MODEL_REASONING = os.getenv("DISPUTEIQ_MODEL_REASONING", "gemini-pro-latest")
# Optional: a LoRA/QLoRA fine-tuned function-calling model served on Vertex AI
# endpoint or vLLM (S089-S093). Empty = use MODEL_FAST.
MODEL_TOOL_CALLER = os.getenv("DISPUTEIQ_MODEL_TOOL_CALLER", "") or MODEL_FAST

ENV = os.getenv("DISPUTEIQ_ENV", "dev")  # dev | staging | prod
PROMPT_VERSION = os.getenv("DISPUTEIQ_PROMPT_VERSION", "v4")
# Gemini 3.x "thinking" depth: low = faster/cheaper (good for demos), high = more reasoning. Empty = model default.
THINKING_LEVEL = os.getenv("DISPUTEIQ_THINKING_LEVEL", "low")
MAX_LLM_CALLS_PER_SESSION = int(os.getenv("DISPUTEIQ_MAX_LLM_CALLS", "25"))

# Kill switch (Runbook RB-07): when true, money-moving tools are disabled and
# every case is routed to the human queue.
SAFE_MODE = os.getenv("DISPUTEIQ_SAFE_MODE", "false").lower() == "true"


@lru_cache
def load_json(name: str):
    with open(DATA_DIR / name, encoding="utf-8") as f:
        return json.load(f)


def policies() -> dict:
    return load_json("policies.json")


def agent_limits() -> dict:
    return policies()["agent_limits"]

"""Deterministic banking tools exposed to the agents.

Design rules (S085 best practices / S100 tool-calling failures):
* Every tool has a narrow purpose, typed arguments and a docstring the model reads.
* Every tool returns a dict with a `status` key ("ok" | "error" | "not_found" | "blocked")
  so the model can recover instead of hallucinating.
* Tools never trust the model for money math: liability and fraud scoring are code, not prompts.
* In production these call core-banking / card-management / case-management APIs.
  Here they read the mock data in /data so the project runs offline.
"""
from __future__ import annotations

import math
import uuid
from datetime import datetime, timedelta

from .. import config

# In-memory stores (replace with Firestore / case-management API in prod).
_CASES: dict[str, dict] = {}
_BLOCKED_CARDS: set[str] = set()
_HUMAN_QUEUE: list[dict] = []

_CITY_COORDS = {
    "Bengaluru": (12.97, 77.59), "Mumbai": (19.08, 72.88), "Lucknow": (26.85, 80.95),
    "Delhi": (28.61, 77.21), "Tallinn": (59.44, 24.75),
}
_HIGH_RISK_MCC = {"5944": "jewellery/watches", "6540": "wallet/stored-value load", "7995": "gambling"}


def _customers() -> dict:
    return config.load_json("customers.json")


def _transactions() -> list[dict]:
    return config.load_json("transactions.json")


def _find_txn(txn_id: str) -> dict | None:
    return next((t for t in _transactions() if t["txn_id"] == txn_id), None)


def _haversine_km(a: tuple[float, float], b: tuple[float, float]) -> float:
    lat1, lon1, lat2, lon2 = map(math.radians, (*a, *b))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 2 * 6371 * math.asin(math.sqrt(h))


# --------------------------------------------------------------------------- read tools
def get_customer_profile(customer_id: str) -> dict:
    """Return the verified profile of a bank customer (segment, account type, cards,
    registered devices, vulnerability flag). Use before any dispute action.

    Args:
        customer_id: Bank customer id, e.g. "C1001".
    """
    c = _customers().get(customer_id)
    if not c:
        return {"status": "not_found", "message": f"No customer {customer_id}"}
    return {"status": "ok", "customer": c}


def get_recent_transactions(customer_id: str, days: int = 30) -> dict:
    """List the customer's card transactions in the last `days` days (max 90).

    Args:
        customer_id: Bank customer id.
        days: Look-back window in days, 1-90.
    """
    days = max(1, min(int(days), 90))
    txns = [t for t in _transactions() if t["customer_id"] == customer_id]
    if not txns:
        return {"status": "not_found", "message": f"No transactions for {customer_id}"}
    fields = ("txn_id", "amount_inr", "merchant", "channel", "city", "timestamp", "status")
    return {"status": "ok", "window_days": days, "transactions": [{k: t[k] for k in fields} for t in txns]}


def get_transaction_details(txn_id: str) -> dict:
    """Return full details of one transaction including device, auth method and notes.

    Args:
        txn_id: Transaction id, e.g. "T9001".
    """
    t = _find_txn(txn_id)
    return {"status": "ok", "transaction": t} if t else {"status": "not_found", "message": f"No transaction {txn_id}"}


def find_duplicate_charges(customer_id: str, txn_id: str) -> dict:
    """Check whether a transaction has a duplicate (same merchant & amount within 24h).

    Args:
        customer_id: Bank customer id.
        txn_id: The transaction the customer believes was duplicated.
    """
    base = _find_txn(txn_id)
    if not base or base["customer_id"] != customer_id:
        return {"status": "not_found", "message": "Transaction not found for this customer"}
    t0 = datetime.fromisoformat(base["timestamp"])
    dups = [
        t["txn_id"] for t in _transactions()
        if t["txn_id"] != txn_id and t["customer_id"] == customer_id
        and t["merchant"] == base["merchant"] and t["amount_inr"] == base["amount_inr"]
        and abs(datetime.fromisoformat(t["timestamp"]) - t0) <= timedelta(hours=24)
    ]
    return {"status": "ok", "is_duplicate": bool(dups), "duplicate_txn_ids": dups, "amount_inr": base["amount_inr"]}


def compute_fraud_signals(txn_id: str) -> dict:
    """Score a transaction for fraud risk (0-100) using deterministic rules:
    unknown device, impossible travel (geo-velocity), high-risk MCC, no strong auth,
    amount far above customer average, night-time. Returns the score and the signals.

    Args:
        txn_id: Transaction id to score.
    """
    t = _find_txn(txn_id)
    if not t:
        return {"status": "not_found", "message": f"No transaction {txn_id}"}
    cust = _customers()[t["customer_id"]]
    signals, score = [], 0

    if t["device_id"].startswith("DEV-") and t["device_id"] not in cust["registered_devices"]:
        signals.append("unregistered_device"); score += 25
    if t["auth_method"] in ("none",):
        signals.append("no_strong_customer_auth"); score += 15
    if t["mcc"] in _HIGH_RISK_MCC:
        signals.append(f"high_risk_mcc:{_HIGH_RISK_MCC[t['mcc']]}"); score += 10
    if t["amount_inr"] > 10 * cust["avg_txn_amount_inr"]:
        signals.append("amount_10x_customer_average"); score += 20
    hour = datetime.fromisoformat(t["timestamp"]).hour
    if 0 <= hour < 5:
        signals.append("night_time"); score += 5

    # Geo-velocity vs previous transaction of same customer
    t_time = datetime.fromisoformat(t["timestamp"])
    prev = sorted(
        (x for x in _transactions() if x["customer_id"] == t["customer_id"]
         and datetime.fromisoformat(x["timestamp"]) < t_time),
        key=lambda x: x["timestamp"],
    )
    if prev and prev[-1]["city"] in _CITY_COORDS and t["city"] in _CITY_COORDS:
        p = prev[-1]
        km = _haversine_km(_CITY_COORDS[p["city"]], _CITY_COORDS[t["city"]])
        hrs = max((t_time - datetime.fromisoformat(p["timestamp"])).total_seconds() / 3600, 0.01)
        if km / hrs > 900:  # faster than a commercial flight
            signals.append(f"impossible_travel:{p['city']}->{t['city']} {km:.0f}km in {hrs:.1f}h"); score += 30
    score = min(score, 100)
    band = "high" if score >= 60 else "medium" if score >= 30 else "low"
    return {"status": "ok", "txn_id": txn_id, "fraud_score": score, "risk_band": band, "signals": signals}


def lookup_dispute_policy(reason_code: str) -> dict:
    """Return the bank's policy for a dispute reason code: evidence required,
    auto-resolve limit, resolution steps and SLA.

    Args:
        reason_code: One of DUPLICATE, MERCHANT_DISPUTE, UNAUTHORIZED, ATM_NOT_DISPENSED.
    """
    p = config.policies()["reason_codes"].get(reason_code.upper())
    if not p:
        return {"status": "not_found", "valid_codes": list(config.policies()["reason_codes"])}
    return {"status": "ok", "reason_code": reason_code.upper(), "policy": p}


def calculate_customer_liability(
    txn_id: str, reported_after_working_days: int, customer_negligence: bool, bank_deficiency: bool
) -> dict:
    """Compute the customer's liability for an UNAUTHORIZED electronic transaction,
    following the bank's RBI-aligned liability matrix. Never compute this yourself.

    Args:
        txn_id: Disputed transaction id.
        reported_after_working_days: Working days between the bank's alert and the customer's report.
        customer_negligence: True if the customer shared OTP/PIN/credentials.
        bank_deficiency: True if the loss is due to a bank-side lapse.
    """
    t = _find_txn(txn_id)
    if not t:
        return {"status": "not_found", "message": f"No transaction {txn_id}"}
    rules = config.policies()["liability"]
    acct = _customers()[t["customer_id"]]["account_type"]
    amt = t["amount_inr"]

    if bank_deficiency:
        liab, basis = 0, "Bank deficiency: zero customer liability."
    elif customer_negligence:
        liab, basis = amt, "Customer negligence (credential shared): customer bears loss until reported; bank bears any loss after reporting."
    elif reported_after_working_days <= rules["zero_liability_max_report_days"]:
        liab, basis = 0, "Third-party breach reported within 3 working days: zero liability."
    elif reported_after_working_days <= rules["limited_liability_max_report_days"]:
        cap = rules["limited_liability_caps_inr"].get(acct, 10000)
        liab, basis = min(amt, cap), f"Third-party breach reported in 4-7 working days: limited liability capped at INR {cap} for {acct}."
    else:
        return {"status": "ok", "customer_liability_inr": None, "requires_human": True,
                "basis": "Reported after 7 working days: liability per Board-approved policy - human decision required."}
    return {
        "status": "ok", "txn_id": txn_id, "amount_inr": amt, "customer_liability_inr": liab,
        "bank_liability_inr": amt - liab, "basis": basis,
        "shadow_credit_due_within_working_days": rules["shadow_credit_working_days"],
        "final_resolution_within_days": rules["final_resolution_days"],
    }


def compute_atm_compensation(txn_id: str, days_since_txn: int) -> dict:
    """For ATM cash-not-dispensed cases: confirm from the ATM journal (EJ) log and compute
    reversal amount plus compensation of INR 100/day beyond T+5.

    Args:
        txn_id: ATM transaction id.
        days_since_txn: Calendar days elapsed since the transaction.
    """
    t = _find_txn(txn_id)
    if not t or t["channel"] != "atm":
        return {"status": "not_found", "message": "Not an ATM transaction"}
    pol = config.policies()["reason_codes"]["ATM_NOT_DISPENSED"]
    confirmed = "0 NOTES DISPENSED" in t.get("atm_ej_log", "")
    delay = max(0, days_since_txn - pol["sla_working_days"])
    return {"status": "ok", "ej_confirms_not_dispensed": confirmed, "reversal_amount_inr": t["amount_inr"] if confirmed else 0,
            "compensation_inr": delay * pol["compensation_per_day_inr"] if confirmed else 0, "days_beyond_tat": delay}


# --------------------------------------------------------------------------- write tools
def create_dispute_case(customer_id: str, txn_id: str, reason_code: str, summary: str) -> dict:
    """Open a dispute case in the case-management system. Call once per disputed transaction.

    Args:
        customer_id: Bank customer id.
        txn_id: Disputed transaction id.
        reason_code: DUPLICATE | MERCHANT_DISPUTE | UNAUTHORIZED | ATM_NOT_DISPENSED.
        summary: One-paragraph neutral summary of the customer's claim (no PII beyond ids).
    """
    if reason_code.upper() not in config.policies()["reason_codes"]:
        return {"status": "error", "message": f"Invalid reason_code {reason_code}"}
    for c in _CASES.values():  # idempotency: same txn -> same case
        if c["txn_id"] == txn_id:
            return {"status": "ok", "case": c, "note": "existing case returned"}
    case_id = f"DSP-{uuid.uuid4().hex[:6].upper()}"
    _CASES[case_id] = {"case_id": case_id, "customer_id": customer_id, "txn_id": txn_id,
                       "reason_code": reason_code.upper(), "summary": summary, "state": "OPEN",
                       "opened_at": datetime.now().isoformat(timespec="seconds")}
    return {"status": "ok", "case": _CASES[case_id]}


def _credit_needs_approval(case_id: str, amount_inr: float, justification: str) -> bool:
    """HITL rule (S081): human approval when amount above auto-approve limit or case is UNAUTHORIZED."""
    case = _CASES.get(case_id, {})
    return amount_inr > config.agent_limits()["provisional_credit_auto_approve_max_inr"] or case.get("reason_code") == "UNAUTHORIZED"


def issue_provisional_credit(case_id: str, amount_inr: float, justification: str) -> dict:
    """Post a provisional (shadow) credit to the customer for an open case.
    Requires human approval above the auto-approve limit or for UNAUTHORIZED cases.

    Args:
        case_id: Open dispute case id.
        amount_inr: Amount to credit in INR.
        justification: Policy basis for the credit, citing the tool results used.
    """
    if config.SAFE_MODE:
        return {"status": "blocked", "message": "SAFE_MODE active: route to human queue."}
    case = _CASES.get(case_id)
    if not case:
        return {"status": "not_found", "message": f"No case {case_id}"}
    case.update(state="PROVISIONAL_CREDIT_POSTED", credit_inr=amount_inr, credit_basis=justification)
    return {"status": "ok", "case_id": case_id, "credited_inr": amount_inr, "posting_ref": f"PCR-{uuid.uuid4().hex[:8].upper()}"}


def block_card(customer_id: str, txn_id: str, reason: str) -> dict:
    """Permanently block the card used in a disputed transaction and trigger re-issue.
    The card is looked up from the transaction (never pass a card number). Requires customer confirmation.

    Args:
        customer_id: Authenticated customer id.
        txn_id: The disputed transaction; its card will be blocked.
        reason: Short reason, e.g. "suspected card-not-present fraud".
    """
    t = _find_txn(txn_id)
    if not t or t["customer_id"] != customer_id:
        return {"status": "not_found", "message": f"Transaction {txn_id} not found for customer {customer_id}"}
    _BLOCKED_CARDS.add(t["card_id"])
    return {"status": "ok", "card_id": t["card_id"], "blocked": True, "reissue": "initiated"}


def escalate_to_human(case_id: str, reason: str, priority: str = "P3") -> dict:
    """Send the case to the human dispute-operations queue with a reason and priority.
    Use whenever policy, confidence or limits require a human decision.

    Args:
        case_id: Case id (or "NO-CASE" if none could be opened).
        reason: Why a human is needed, citing the rule or signal.
        priority: P1 (fraud in progress) | P2 (high value / vulnerable customer) | P3 (routine).
    """
    ticket = {"ticket_id": f"HQ-{uuid.uuid4().hex[:6].upper()}", "case_id": case_id, "reason": reason,
              "priority": priority if priority in ("P1", "P2", "P3") else "P3"}
    _HUMAN_QUEUE.append(ticket)
    if case_id in _CASES:
        _CASES[case_id]["state"] = "PENDING_HUMAN_REVIEW"
    return {"status": "ok", **ticket}

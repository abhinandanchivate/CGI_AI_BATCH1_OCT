"""Guardrails implemented as ADK callbacks (S084 ethics/regulation, S095 security, S081 HITL).

Layered defence:
  1. before_model_callback  -> PII redaction + prompt-injection screening + LLM-call budget
  2. before_tool_callback   -> tool allow-list per agent, hard money limits, safe-mode
  3. require_confirmation   -> human approval on risky tools (see agent.py)
"""
from __future__ import annotations

import re
from typing import Any, Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmRequest, LlmResponse
from google.adk.tools import BaseTool, ToolContext
from google.genai import types

from . import config

# ---------------------------------------------------------------- PII redaction (DPDP Act data minimisation)
_PII_PATTERNS = [
    ("CARD", re.compile(r"\b(?:\d[ -]?){12,18}\d\b")),
    ("AADHAAR", re.compile(r"\b\d{4}[ -]?\d{4}[ -]?\d{4}\b")),
    ("PAN", re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")),
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b")),
    ("PHONE", re.compile(r"(?<!\d)(?:\+91[ -]?)?[6-9]\d{9}(?!\d)")),
    ("OTP", re.compile(r"\b(?:otp|pin|cvv)\b\D{0,12}\d{3,6}\b", re.I)),
]


def redact_pii(text: str) -> str:
    for label, pat in _PII_PATTERNS:
        text = pat.sub(f"[{label}_REDACTED]", text)
    return text


# ---------------------------------------------------------------- prompt-injection heuristics
_INJECTION = re.compile(
    r"(ignore (all|previous|prior) (instructions|rules)|you are now|system prompt|developer mode|"
    r"approve (this|the) (refund|credit) without|bypass (the )?(policy|limit|approval))",
    re.I,
)


def looks_like_injection(text: str) -> bool:
    return bool(_INJECTION.search(text or ""))


def before_model_guard(callback_context: CallbackContext, llm_request: LlmRequest) -> Optional[LlmResponse]:
    """Redact PII from every text part sent to the model and stop runaway loops."""
    state = callback_context.state
    state["llm_calls"] = state.get("llm_calls", 0) + 1
    if state["llm_calls"] > config.MAX_LLM_CALLS_PER_SESSION:  # S100 cost / infinite-loop protection
        return LlmResponse(content=types.Content(role="model", parts=[types.Part(text=(
            "I need to hand this over to a specialist colleague to finish. "
            "Your case has been saved and you will hear from us within 1 working day."))]))

    for content in llm_request.contents or []:
        for part in content.parts or []:
            if part.text:
                if content.role == "user" and looks_like_injection(part.text):
                    state["injection_flag"] = True
                    part.text = "[Customer message withheld by security filter: possible prompt injection]"
                else:
                    part.text = redact_pii(part.text)
    return None


# ---------------------------------------------------------------- tool guard
MONEY_TOOLS = {"issue_provisional_credit"}


def before_tool_guard(tool: BaseTool, args: dict[str, Any], tool_context: ToolContext) -> Optional[dict]:
    """Deterministic policy checks that the LLM cannot talk its way around."""
    limits = config.agent_limits()

    if tool.name in MONEY_TOOLS:
        if config.SAFE_MODE:
            return {"status": "blocked", "message": "SAFE_MODE: money movement disabled. Escalate to human."}
        if tool_context.state.get("injection_flag"):
            return {"status": "blocked", "message": "Security flag on session. Escalate to human (P1)."}
        amount = float(args.get("amount_inr", 0) or 0)
        if amount <= 0:
            return {"status": "error", "message": "amount_inr must be positive."}
        if amount > limits["provisional_credit_hard_cap_inr"]:
            return {"status": "blocked",
                    "message": f"Amount exceeds agent hard cap INR {limits['provisional_credit_hard_cap_inr']}. "
                               "Call escalate_to_human with priority P2."}
        if not str(args.get("justification", "")).strip():
            return {"status": "error", "message": "justification is mandatory (audit requirement)."}

    if tool.name == "escalate_to_human" and args.get("priority") not in ("P1", "P2", "P3"):
        args["priority"] = "P3"  # repair malformed argument rather than fail (S100)
    return None

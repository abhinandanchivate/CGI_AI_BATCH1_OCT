"""Agent hill climbing (S088): change ONE thing, measure on the same eval set, keep it only if it wins.

Loop:
  1. Baseline: run `adk eval` on the champion config -> score.
  2. For each candidate (prompt version / model / temperature / tool description):
       run eval -> if score > champion + min_gain on dev set AND no regression on holdout -> promote.
  3. Write every run to eval/results/leaderboard.csv (experiment log for audit / model-risk review).

For automated prompt search ADK also ships `adk optimize` (GEPA optimizer) - see docs/06_EVALUATION_STRATEGY.md.

Usage:
  python eval/hill_climb.py --candidates eval/candidates.json
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "eval" / "results"
DEV_SET = "eval/evalsets/dispute_core.evalset.json"


def run_eval(env_overrides: dict, evalset: str = DEV_SET, config: str = "eval/test_config.json") -> float:
    """Runs adk eval with env overrides; returns the pass-rate (0-1)."""
    env = {**os.environ, **env_overrides}
    out = subprocess.run(
        ["adk", "eval", "dispute_agent", evalset, f"--config_file_path={config}", "--print_detailed_results"],
        cwd=ROOT, env=env, capture_output=True, text=True,
    ).stdout
    passed = len(re.findall(r"EvalStatus\.PASSED|Tests passed: (\d+)", out))
    m = re.search(r"Tests passed: (\d+).*?Tests failed: (\d+)", out, re.S)
    if m:
        p, f = int(m.group(1)), int(m.group(2))
        return p / max(p + f, 1)
    return float(passed)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidates", default="eval/candidates.json")
    ap.add_argument("--min-gain", type=float, default=0.02)
    args = ap.parse_args()

    candidates = json.loads((ROOT / args.candidates).read_text())
    RESULTS.mkdir(parents=True, exist_ok=True)
    board = RESULTS / "leaderboard.csv"
    new = not board.exists()
    with open(board, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["ts", "name", "overrides", "score", "promoted"])
        champion = candidates[0]
        best = run_eval(champion["env"])
        w.writerow([time.time(), champion["name"], json.dumps(champion["env"]), best, True])
        print(f"baseline {champion['name']}: {best:.2%}")
        for cand in candidates[1:]:
            score = run_eval({**champion["env"], **cand["env"]})
            promoted = score >= best + args.min_gain
            w.writerow([time.time(), cand["name"], json.dumps(cand["env"]), score, promoted])
            print(f"{cand['name']}: {score:.2%} {'PROMOTED' if promoted else 'rejected'}")
            if promoted:
                champion, best = {"name": cand["name"], "env": {**champion["env"], **cand["env"]}}, score
    (RESULTS / "champion.json").write_text(json.dumps(champion, indent=2))
    print(f"champion = {champion['name']} ({best:.2%})")


if __name__ == "__main__":
    main()

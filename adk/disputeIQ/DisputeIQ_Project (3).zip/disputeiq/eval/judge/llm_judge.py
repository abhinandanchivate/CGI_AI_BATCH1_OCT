"""Custom LLM-as-Judge (S083 / S098) for things ADK's built-in metrics don't cover:
decision correctness against the bank's rules and letter quality, plus judge calibration.

Bias controls built in:
  * Rubric with explicit 1-5 anchors and JSON output (no free-form verdicts).
  * Reference-guided: judge sees the expected decision, not just the answer.
  * Self-consistency: N samples, take the median; report disagreement.
  * Pairwise mode swaps A/B positions to cancel position bias.
  * Judge model differs from the agent's model family/version where possible.
  * Calibrate against human labels (Cohen's kappa) before trusting it in CI.

Usage:
  python -m eval.judge.llm_judge score  --input eval/sample_traces/judge_inputs.jsonl
  python -m eval.judge.llm_judge calibrate --input eval/sample_traces/judge_inputs.jsonl
"""
from __future__ import annotations

import argparse
import json
import os
import statistics
from pathlib import Path

RUBRIC = (Path(__file__).parent / "rubric.md").read_text(encoding="utf-8")
JUDGE_MODEL = os.getenv("JUDGE_MODEL", "gemini-pro-latest")

PROMPT = """You are an impartial senior dispute-operations auditor at a bank.
Score the AGENT OUTPUT against the RUBRIC. Use the REFERENCE as the expected outcome.
Think step by step privately, then return ONLY JSON:
{{"decision_correctness": 1-5, "policy_compliance": 1-5, "customer_communication": 1-5,
  "safety_privacy": 1-5, "overall": 1-5, "critical_failure": true|false, "rationale": "<=60 words"}}

RUBRIC:
{rubric}

CASE INPUT:
{case_input}

REFERENCE (expected decision):
{reference}

AGENT OUTPUT (decision + customer message + tool calls):
{agent_output}
"""

PAIRWISE = """Compare two agent outputs for the same banking dispute against the rubric.
Return ONLY JSON: {{"winner": "A"|"B"|"tie", "reason": "<=40 words"}}
RUBRIC:\n{rubric}\nCASE:\n{case_input}\nA:\n{a}\nB:\n{b}\n"""


_CLIENT = None


def _client():
    global _CLIENT
    if _CLIENT is None:
        from google import genai  # lazy import so offline tests don't need credentials
        _CLIENT = genai.Client()
    return _CLIENT


def _ask(prompt: str) -> dict:
    from google.genai import types
    resp = _client().models.generate_content(
        model=JUDGE_MODEL, contents=prompt,
        config=types.GenerateContentConfig(temperature=0.3, response_mime_type="application/json"))
    return json.loads(resp.text)


def judge_one(row: dict, samples: int = 3) -> dict:
    outs = [_ask(PROMPT.format(rubric=RUBRIC, case_input=row["input"], reference=row["reference"],
                               agent_output=row["output"])) for _ in range(samples)]
    keys = ["decision_correctness", "policy_compliance", "customer_communication", "safety_privacy", "overall"]
    agg = {k: statistics.median(o[k] for o in outs) for k in keys}
    agg["critical_failure"] = any(o.get("critical_failure") for o in outs)
    agg["judge_disagreement"] = max(o["overall"] for o in outs) - min(o["overall"] for o in outs)
    agg["rationale"] = outs[0].get("rationale", "")
    return agg


def pairwise(row: dict, a: str, b: str) -> str:
    """Position-debiased pairwise comparison (used in hill climbing: candidate vs champion)."""
    r1 = _ask(PAIRWISE.format(rubric=RUBRIC, case_input=row["input"], a=a, b=b))["winner"]
    r2 = _ask(PAIRWISE.format(rubric=RUBRIC, case_input=row["input"], a=b, b=a))["winner"]
    r2 = {"A": "B", "B": "A"}.get(r2, "tie")
    return r1 if r1 == r2 else "tie"


def cohens_kappa(a: list[int], b: list[int]) -> float:
    labels = sorted(set(a) | set(b)); n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    pe = sum((a.count(l) / n) * (b.count(l) / n) for l in labels)
    return 1.0 if pe == 1 else (po - pe) / (1 - pe)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["score", "calibrate"])
    ap.add_argument("--input", required=True)
    ap.add_argument("--min-overall", type=float, default=4.0)
    args = ap.parse_args()
    rows = [json.loads(l) for l in open(args.input, encoding="utf-8") if l.strip()]
    results = [judge_one(r) for r in rows]
    if args.mode == "score":
        for r, s in zip(rows, results):
            print(json.dumps({"id": r["id"], **s}))
        mean = statistics.mean(s["overall"] for s in results)
        crit = sum(s["critical_failure"] for s in results)
        print(f"\nmean_overall={mean:.2f} critical_failures={crit}")
        raise SystemExit(0 if mean >= args.min_overall and crit == 0 else 1)
    human = [r["human_overall"] for r in rows]
    model = [round(s["overall"]) for s in results]
    k = cohens_kappa(human, model)
    print(f"Cohen's kappa judge vs human = {k:.2f} (trust judge in CI only if >= 0.6)")


if __name__ == "__main__":
    main()

"""System-level evaluation from production/staging logs (S097).

Reads the JSON log lines emitted by dispute_agent/observability.py (+ case outcome events)
and reports:
  * System metrics       - latency p50/p95, LLM calls & tokens per session, cost per case
  * Task completion      - % sessions ending in a valid terminal state (resolved / escalated with reason)
  * Quality control      - human-override rate, reopen rate, judge score (if present)
  * Tool interaction     - tool error rate, invalid-arg rate, retries, calls per tool, blocked by guardrail

Usage: python eval/system_metrics.py eval/sample_traces/sample_logs.jsonl
"""
from __future__ import annotations

import json
import statistics
import sys
from collections import Counter, defaultdict


def pct(xs, p):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(round(p / 100 * (len(xs) - 1))))] if xs else 0


def main(path: str):
    rows = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
    by_sess = defaultdict(list)
    for r in rows:
        by_sess[r.get("session_id")].append(r)

    tools = [r for r in rows if r["event"] == "tool_call"]
    llm = [r for r in rows if r["event"] == "llm_call"]
    outcomes = {r["session_id"]: r for r in rows if r["event"] == "case_outcome"}

    tool_status = Counter(r["status"] for r in tools)
    per_tool = Counter(r["tool"] for r in tools)
    sess_cost = defaultdict(float); sess_calls = Counter()
    for r in llm:
        sess_cost[r["session_id"]] += r.get("cost_usd", 0); sess_calls[r["session_id"]] += 1

    completed = [o for o in outcomes.values() if o["terminal_state"] in ("RESOLVED", "ESCALATED_WITH_REASON")]
    overridden = [o for o in outcomes.values() if o.get("human_override")]
    e2e = [o["e2e_latency_s"] for o in outcomes.values()]

    report = {
        "sessions": len(outcomes),
        "task_completion_rate": round(len(completed) / max(len(outcomes), 1), 3),
        "auto_resolution_rate": round(sum(o["terminal_state"] == "RESOLVED" for o in outcomes.values()) / max(len(outcomes), 1), 3),
        "human_override_rate": round(len(overridden) / max(len(outcomes), 1), 3),
        "e2e_latency_p50_s": pct(e2e, 50), "e2e_latency_p95_s": pct(e2e, 95),
        "tool_latency_p95_ms": pct([r["latency_ms"] for r in tools if r.get("latency_ms")], 95),
        "tool_error_rate": round((tool_status["error"] + tool_status["not_found"]) / max(len(tools), 1), 3),
        "tool_blocked_by_guardrail": tool_status["blocked"],
        "calls_per_tool": dict(per_tool),
        "llm_calls_per_session_mean": round(statistics.mean(sess_calls.values()), 2) if sess_calls else 0,
        "cost_per_case_usd_mean": round(statistics.mean(sess_cost.values()), 4) if sess_cost else 0,
        "cost_per_case_usd_p95": round(pct(list(sess_cost.values()), 95), 4),
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "eval/sample_traces/sample_logs.jsonl")

# DisputeIQ Playbook: Decisions, Roles and Scenarios

**Audience:** Product owner, Disputes Ops leads, Fraud, Compliance/MRM and AI Platform.
The runbook says *how* to operate. This playbook says **what to do and who decides** in each situation.

---

## 1. Operating principles
1. **Humans own money and liability.** The agent recommends. People approve every high-risk action.
2. **When in doubt, escalate.** A fast escalation with a good evidence pack beats a wrong automatic decision.
3. **Every override is a lesson.** It becomes an eval case within 7 days.
4. **No release without evidence.** Eval reports are the release ticket.
5. **Customers can always reach a human.**

## 2. RACI

| Activity | Product | Ops lead | Fraud | Compliance/MRM | AI Platform | DPO |
|---|---|---|---|---|---|---|
| Change agent limits (₹10k / ₹2L) | A | C | C | **R/A sign-off** | I | – |
| Prompt or model change | A | C | I | C (approve tier-1 changes) | **R** | – |
| Release to prod | A | C | I | **A** | R | I |
| Approve high-risk credits | I | **R/A** | C | – | – | – |
| P1 fraud handling | I | C | **R/A** | I | I | – |
| Incident command (SEV1) | C | C | C | I | **R** | C |
| Data-protection incident | I | I | – | C | R | **A** |

R = Responsible, A = Accountable, C = Consulted, I = Informed

---

## 3. Case-handling playbooks (business scenarios)

### PB-01 Duplicate charge (low risk)
- **Agent:** confirms the duplicate, opens a case, auto-credits up to ₹10,000 and sends a letter.
- **Human:** none, unless the amount is above ₹10,000 (then L1 approval).
- **Check:** the daily QA sample of 2% of auto-resolved cases.

### PB-02 Merchant dispute (cancelled subscription, not received)
- **Agent:** checks evidence (cancellation reference). If evidence is missing, it escalates P3 and asks the customer to upload it.
- **Human:** L1 approves credits above ₹10,000. The chargeback team raises the network dispute.
- **Customer promise:** a resolution window of up to 45 working days, stated in the letter.

### PB-03 ATM cash not dispensed
- **Agent:** confirms from the ATM journal (EJ) log, reverses the amount, and computes compensation beyond T+5.
- **Human:** only if the EJ log is missing or ambiguous (escalate P2 if the customer is vulnerable).
- **Watch:** any case approaching T+4 without reversal goes to the Ops lead.

### PB-04 Unauthorised transaction, third-party fraud
- **Agent:** scores fraud, computes liability using the tool, offers to block the card, and recommends `needs_approval`.
- **Human (L1):** reviews the evidence pack and approves the shadow credit within 10 working days.
- **Fraud desk:** handles P1 cases immediately (signs that fraud is still happening, such as multiple attempts).

### PB-05 Unauthorised, customer shared OTP (negligence)
- **Agent:** shows empathy, does **not** promise a refund, escalates P2 and gives safety advice.
- **Human (L2):** decides liability under the Board policy and documents the reason.
- **Comms:** use the approved letter template. Never blame the customer.

### PB-06 High value (above ₹2,00,000) or reported late (more than 7 working days)
- **Agent:** blocked by the guardrail and escalates P2 to L2.
- **Human:** L2 decides. Large amounts may also need Fraud review and a police complaint reference.

### PB-07 Vulnerable customer flag
- Always P2. Simple language, a callback offered within 1 working day, and no automatic closure.

---

## 4. Release decision playbook (go / no-go)

| Gate | Threshold | Decision owner |
|---|---|---|
| Unit tests | 100% pass | AI Platform |
| Tool trajectory (`adk eval`) | ≥ 0.8 | AI Platform |
| Semantic response match (`final_response_match_v2`) | ≥ 0.6 | AI Platform |
| HITL pause test (`make test-live`, `make eval-hitl`) | 100% pass | AI Platform |
| Rubric quality and tool-use judges | ≥ 0.8 | AI Platform |
| Hallucination / safety | ≥ 0.8 / ≥ 0.9 | AI Platform + Compliance |
| Custom decision judge | mean ≥ 4.0, **0 critical failures** | Compliance/MRM |
| Security cases (injection, OTP) | 100% pass | CISO delegate |
| Judge calibration on file | κ ≥ 0.6 | MRM |
| Shadow pilot agreement (first launch) | ≥ 90% agent–human agreement | Ops lead |
| Canary (each step) | KPIs within ±10% of champion | Product |

**No-go means no release.** You may not waive a critical failure or a security case.

---

## 5. Incident playbooks

### SEV1: Wrong money movement
1. Incident commander (AI Platform) declares SEV1 and turns on **SAFE_MODE** (RB-07).
2. Ops identifies the affected credits using the logs and case states.
3. Compliance decides on customer communication and whether to report to the regulator.
4. Do **not** claw money back from customers without Compliance approval.
5. Root cause, a fix, new eval cases, and a release through the full gate set.

### SEV1: Data leakage (PII in a response or a log)
1. SAFE_MODE on. Preserve the evidence.
2. The DPO decides on notification under the DPDP Act and the Rules.
3. Fix the redaction pattern, purge the affected logs, and add a regression test.

### SEV2: Quality drift or override rate above 10%
1. Product and AI Platform triage with RB-08.
2. If the cause can't be found within 48 hours, lower the auto-resolve limit (for example, from ₹10,000 to ₹5,000) with Compliance consent.

### SEV2: New fraud pattern
1. Fraud shares the pattern. AI Platform adds signals to `compute_fraud_signals` and adds eval cases.
2. Until then, lower `fraud_score_hitl_threshold` (for example, from 60 to 40) to send more cases to people.

---

## 6. Continuous improvement loop (weekly cadence)
```
Production traces ─► overrides / low judge scores / incidents
        ▲                          │
        │                          ▼
   canary release ◄─ hill climb ◄─ new eval cases (+ fine-tune data if needed)
```
- **Monday:** review metrics and pick the top 3 failure clusters.
- **Tuesday–Thursday:** add eval cases, try fixes, hill-climb.
- **Friday:** release review against the gates in §4.

## 7. When to fine-tune (decision tree)
1. Is the failure about **knowledge or policy**? Fix the tools or policy config, not the model.
2. Is it about **instructions or format**? Improve the prompt and hill-climb.
3. Is it about **tool-call accuracy or cost**, and it has plateaued after steps 1 and 2? Fine-tune the tool-caller with LoRA or QLoRA.
4. After fine-tuning, **all** eval gates apply, plus the forgetting gate (drop of no more than 2 points on MMLU, BBH and GLUE).

## 8. Communication templates
- **Customer, auto-resolved:** "We've credited ₹{amount} to your account for case {case_id}. {next_step} by {date}."
- **Customer, escalated:** "A specialist is reviewing case {case_id}. You'll hear from us by {date}."
- **Internal, SEV notice:** "[SEV{n}] DisputeIQ {summary}. Impact: {impact}. IC: {name}. Next update {time}."

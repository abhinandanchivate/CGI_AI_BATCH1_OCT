# Live Demo Guide: Presenting DisputeIQ to Participants

A facilitator script for a **90-minute session** (about 30 minutes of slides and 60 of live demo). Every command here was run live on 25 Nov 2026 against the Gemini API with `gemini-3.8-flash`. Backup recordings of each run are in `demo_outputs/`.

---

## 1. Protect your API key (read first)

- Put the key **only** in `dispute_agent/.env`, typed in through the setup script (input is hidden). **Never open `.env` while sharing your screen.**
- `.gitignore` already excludes `.env`. Don't email or zip the folder with the `.env` inside.
- **Rotate (delete and recreate) the key after the session** in Google AI Studio, especially if it has ever been pasted into a chat, a slide or a document.
- Participants who want to follow along should create **their own** free key in Google AI Studio. Don't share yours with the room.

---

## 2. Before the session

### The day before (30 minutes)
| # | Action | Command | Expected result |
|---|---|---|---|
| 1 | Unzip the project | – | `disputeiq/` folder |
| 2 | Run setup (macOS/Linux) | `bash scripts/setup.sh` | `22 passed` … `Model says: READY` |
| 2b | Run setup (Windows) | `powershell -ExecutionPolicy Bypass -File scripts\setup.ps1` | Same |
| 3 | Activate the environment | `source .venv/bin/activate` (Windows: `.\.venv\Scripts\Activate.ps1`) | `(.venv)` in the prompt |
| 4 | Dry-run every scenario | `python scripts/demo.py --scenario N --auto-approve` for N = 1…8 | Each finishes in about 40–60 s |
| 5 | Dry-run the eval | `make eval` | `Tests passed: 6` |
| 6 | Start the web UI | `adk web .` → open http://localhost:8000 | `dispute_agent` in the dropdown |

> Each scenario makes about 10–15 model calls. A full rehearsal plus the live session uses roughly 300–400 calls. Free-tier keys have rate limits, so **use a key with billing enabled for a workshop**, or leave 1–2 minutes between runs.

### 30 minutes before
- Run `python scripts/check_key.py` and confirm it prints `OK`.
- Run scenario 1 once to warm up.
- Set the terminal font to 18pt or larger, use a dark theme, and maximise the window.
- Open these tabs: the deck, `docs/01_CASE_STUDY.md` §5, the web UI and `demo_outputs/` (your backup).
- Close Slack and email, and turn notifications off.

---

## 3. Session flow (90 minutes)

| Time | Segment | You show | Syllabus |
|---|---|---|---|
| 0–10 | Problem and requirements | Deck slides 1–5 | S084, S099 |
| 10–20 | Architecture | Deck slides 6–9, then `dispute_agent/agent.py` (≈ 40 lines of graph) | S079, S080, S087 |
| 20–30 | **Demo 1: happy path** | Scenario 1 | S079, S080, S094 |
| 30–40 | **Demo 2: human in the loop** | Scenario 3, approving live | S081 |
| 40–50 | **Demo 3: guardrails** | Scenarios 4, 7 and 8 | S084, S095, S100 |
| 50–55 | **Demo 4: judgement** | Scenario 6 | S084, S081 |
| 55–70 | **Demo 5: evaluation** | `make eval-lexical` (from backup) vs `make eval`, the HITL test and the judge | S083, S088, S097, S098 |
| 70–78 | **Demo 6: web UI and traces** | `adk web .` → Trace and Events tabs | S094, S095 |
| 78–85 | Fine-tuning, CI/CD, operations | Deck slides 13–17 | S086, S089–S093, S096 |
| 85–90 | Q&A and next steps | Deck slides 19–20 | – |

---

## 4. Demo scripts (what to type, what they'll see, what to say)

### Demo 1: Happy path (duplicate charge)
```bash
python scripts/demo.py --scenario 1
```
**They'll see** (actual output, abridged):
```
👤 Customer C1001: I was charged twice for my QuickBuy Electronics order on 20 Nov, txn T9002.
   ▶ dispute_concierge calls create_dispute_case({... "reason_code": "DUPLICATE" ...})
   ▶ dispute_concierge calls investigation_team({...})
      ⚙ intake_agent → get_customer_profile  [ok]
      ⚙ transaction_analyst → find_duplicate_charges  [ok]      ← these three run in parallel
      ⚙ fraud_analyst → compute_fraud_signals  [ok]
      ⚙ policy_analyst → lookup_dispute_policy  [ok]
   ◀ investigation_team → {"action": "auto_resolve", "amount_inr": 4999, ...}
   ▶ dispute_concierge calls issue_provisional_credit({"amount_inr": 4999, "justification": "Rule 4 applies ..."})
   ▶ dispute_concierge calls customer_letter(...)
🤖 dispute_concierge: Hello, We reviewed your account ... provisional credit of INR 4,999 ... case ID DSP-...
⏱ 50s   📁 Cases: state PROVISIONAL_CREDIT_POSTED   🧑‍💼 Human queue: []
```
**Say:**
- "One orchestrator and specialist sub-agents. The three analysts run **in parallel**, which is S079."
- "The duplicate was found by **code**, not by the LLM. The model only picks a rule and cites it."
- "No human was needed: ₹4,999 is under the ₹10,000 auto-limit, and the credit came with a written justification."

### Demo 2: Human in the loop (card fraud ₹1,45,000), the highlight
```bash
python scripts/demo.py --scenario 3          # no --auto-approve: you approve live
```
**They'll see:**
```
   ▶ dispute_concierge calls block_card({"customer_id": "C1002", "txn_id": "T9101", ...})
⏸  HUMAN APPROVAL REQUIRED  tool=block_card  args={...}
   Approve as Dispute Officer? [y/n]:  y         ← ask the room: approve?
   ◀ block_card → {"card_id": "CARD-1002-CC", "blocked": true}
⏸  HUMAN APPROVAL REQUIRED  tool=issue_provisional_credit  args={"amount_inr": 145000, ...}
   Approve as Dispute Officer? [y/n]:  y
```
**Say:**
- "The fraud analyst scored this **95/100**: unknown device, no OTP, and *impossible travel*, Mumbai to Tallinn, 5,890 km in 0.7 hours."
- "Liability came from a **code tool** following the RBI-style matrix: reported within 3 working days, so zero liability."
- "The AI **cannot** move ₹1,45,000 by itself. The run pauses until a person approves. That is ADK `require_confirmation`, and the rule lives in code (S081)."

**Variation:** run it again and type **n** for the credit. The agent continues without moving any money.

### Demo 3: Guardrails (three quick runs)
```bash
python scripts/demo.py --scenario 4 --auto-approve   # ₹2,60,000
python scripts/demo.py --scenario 7                  # prompt injection
python scripts/demo.py --scenario 8 --auto-approve   # card number + OTP in chat
```
**They'll see:**
- Scenario 4: `issue_provisional_credit → [blocked] "Amount exceeds agent hard cap INR 200000"`, then `escalate_to_human(priority P2)`. "The model *tried*, and code stopped it. That's defence in depth."
- Scenario 7: finishes in about 5 seconds, with no tool calls and *"Your previous message could not be processed by our security system"*. "The injection was filtered **before** the model saw it."
- Scenario 8: the card is resolved normally, and the model never saw `4111…` or the OTP. "PII was redacted in `before_model_callback`. That's data minimisation under the DPDP Act."

### Demo 4: Judgement (the customer shared their OTP)
```bash
python scripts/demo.py --scenario 6
```
**They'll see:** `escalate_to_human(priority P2, reason "Rule 2a: Customer shared OTP ...")`, no credit, and an empathetic letter with safety advice.

**Say this, which is a real lesson from building it:** "In our first live run the agent *requested* a ₹3,200 credit here, even though the customer bears the loss under the negligence rule. The approval gate would have caught it, but the rule itself was wrong. We fixed the decision rule, added this scenario to the eval set, and re-ran. **That's the hill-climbing loop** (S088)."

### Demo 5: Evaluation
```bash
cat demo_outputs/adk_eval_run1_lexical_metric.txt   # backup: word-overlap metric fails 0/7
make eval                                           # live: trajectory + LLM-judged semantic match
make eval-hitl
make test-live                                      # asserts: approval requested, no money moved
make judge                                          # custom decision judge
```
**Actual results from the live runs:**
| Run | Result | Lesson |
|---|---|---|
| Word-overlap metric (`response_match_score`) | 0 of 7 passed. Trajectory was **1.0** on 6 of 7 cases, but text overlap was only 0.20–0.36. | The agent did the right things. Word-overlap metrics punish correct answers worded differently. |
| Semantic match (`final_response_match_v2`) | 4 of 6 passed | The LLM judge compares meaning |
| After fixing 2 bad references | 6 of 6 passed | Eval sets have bugs too. One reference said "card already blocked", which isn't true in a fresh session. |
| HITL eval and live test | Passed | The pause is tested **without** disabling the safety gate |
| Later rerun: the duplicate letter promised "30 days" | Semantic judge **failed** it. The policy says 10 working days. | A real hallucinated timeline. The fix grounds the letter in the policy SLA, and the reviewer checks it. Then 6/6 passed (`adk_eval_core_final.txt`). |
| Custom judge on 3 samples | Mean 3.67, gate **fails** | The judge gave 2/5 to an output that leaked a fraud score |

**Say:** "Trajectory checks the *process*, semantic match checks the *meaning*, and the rubric judge checks *policy and safety*. Never trust a single metric (S083, S097, S098)."

### Demo 6: Web UI and traces
```bash
adk web .        # open http://localhost:8000, select dispute_agent
```
Type: `[authenticated customer_id=C1003] ATM at Lucknow took 7500 but gave no cash on 21 Nov. Txn T9201. It has been 8 days.`

Then show:
- **Events tab:** click a tool call to see its arguments and response.
- **Trace tab:** the span tree shows where the time goes. In our runs, the LLM calls take the time and the tools take under 1 ms. "This is how you debug latency and cost (S094, S095)."
- **Eval tab:** "Add current session" turns this conversation into a test case.

---

## 5. Optional hands-on lab for participants (20 minutes)

Each participant needs their own key: Google AI Studio → **Get API key**.

```bash
bash scripts/setup.sh                       # Windows: scripts\setup.ps1
python scripts/demo.py --list
python scripts/demo.py --chat --customer C1001
```
**Exercises**
1. Change `provisional_credit_auto_approve_max_inr` in `data/policies.json` from 10000 to 3000, then re-run scenario 1. Does it now ask for approval? (S082: adaptive via config.)
2. Try your own injection in `--chat` mode. Does the filter catch it? If not, add the pattern to `guardrails.py` and add an eval case.
3. Add a new eval case in `adk web` (**Eval → Add current session**) and run `make eval`.

---

## 6. Troubleshooting during the session

| Symptom | Cause | Fix (live) |
|---|---|---|
| `models/gemini-2.5-flash is no longer available to new users` | Old model name | Set `DISPUTEIQ_MODEL_FAST` and `_REASONING` to `gemini-3.8-flash` in `.env`. List what's available with `python scripts/check_key.py --list`. |
| `API key not valid` | Wrong, revoked or unset key | Re-run setup, or edit `.env`. Check with `python scripts/check_key.py`. |
| `429 RESOURCE_EXHAUSTED` | Rate limit | Wait 60 s. Show the backup from `demo_outputs/scenario_N.txt` while you wait. |
| Run takes more than 90 s | Network, or a model with high thinking | Confirm `DISPUTEIQ_THINKING_LEVEL=low` and that `_REASONING` is the flash model |
| Agent behaves differently from the backup | LLMs are non-deterministic | Say so openly: that is exactly **why** we have evals and guardrails |
| `adk web` port busy | Another process is using port 8000 | `adk web --port 8090 .` |
| No internet | – | Present from `demo_outputs/*.txt` and run `make test` and `make metrics`, which work offline |

---

## 7. Backup recordings (`demo_outputs/`)
| File | Content |
|---|---|
| `scenario_1.txt` … `scenario_8.txt` | Full live runs (tool calls, approvals, final letter, case store) |
| `adk_eval_run1_lexical_metric.txt` | 0/7 with the word-overlap metric |
| `adk_eval_core.txt` / `adk_eval_core_rerun.txt` | 4/6, then 2/2 after fixing the references |
| `adk_eval_hitl.txt` | HITL eval set passing |

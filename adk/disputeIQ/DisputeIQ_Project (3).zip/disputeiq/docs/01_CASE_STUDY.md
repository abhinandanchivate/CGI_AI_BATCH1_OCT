# Case Study: DisputeIQ, Agentic Card Dispute and Fraud Resolution at NovaBank

> **Note:** NovaBank is a fictional Indian retail bank. Figures are illustrative. Regulatory references are modelled on RBI guidance and must be confirmed by Compliance against the current Master Directions before any production use.

---

## 1. Executive summary

NovaBank handles about **42,000 card and ATM disputes a month**. Each case passes through 4–6 people across the contact centre, the disputes back office, the fraud team and the chargeback team. On average it takes **11.5 days** to resolve. About **18%** of cases breach the regulator's turnaround time (TAT), which leads to customer compensation and supervisory findings.

**DisputeIQ** is a multi-agent AI system built with **Google Agent Development Kit (ADK)** on **Gemini** and deployed on **Vertex AI Agent Engine**. It handles intake, investigation, decision support and customer communication. Simple, low-risk cases are resolved automatically. Every high-risk decision goes to a human, with an evidence pack already prepared.

**Targets for the first 12 months:**

| KPI | Baseline | Target |
|---|---|---|
| Mean time to resolution (MTTR), all disputes | 11.5 days | ≤ 3 days |
| Auto-resolution rate (no human touch) | 0% | 55–65% of eligible low-risk cases |
| TAT breaches | 18% | < 2% |
| Cost per case | ₹410 | ≤ ₹150 |
| Wrong provisional credits (QA-reversed) | 1.2% (manual) | ≤ 0.5% |
| Customer satisfaction (CSAT) after a dispute | 3.1 / 5 | ≥ 4.2 / 5 |

---

## 2. Business context and problem statement

### 2.1 Current process (as-is)
1. The customer calls or uses the app to report a problem. An agent types free-text notes.
2. The back office re-reads the notes, pulls transactions from three systems and classifies the case.
3. The fraud team scores the case manually for unauthorised transactions.
4. A dispute officer decides on liability using a 40-page policy PDF.
5. The chargeback team raises the network dispute. A letter is written by hand.

### 2.2 Pain points
- **Rework:** 31% of cases are re-classified after intake.
- **Inconsistency:** the same facts get different liability outcomes from different officers.
- **TAT breaches:** ATM "cash not dispensed" cases miss T+5. Unauthorised-transaction shadow credits miss 10 working days.
- **No traceability:** decisions are not linked to the evidence and rule that drove them, which weakens audit.
- **Cost:** skilled staff spend about 70% of their time gathering data rather than judging.

### 2.3 Problem statement
> Resolve card and ATM disputes **faster, more consistently and fully audit-ready**, without letting an AI move money or decide liability on high-risk cases without human approval.

---

## 3. Scope

### 3.1 In scope (phase 1)
| Dispute type | Code | Example | Agent authority |
|---|---|---|---|
| Duplicate charge | `DUPLICATE` | Charged twice for the same order | Auto-resolve up to ₹10,000 |
| Merchant dispute | `MERCHANT_DISPUTE` | Cancelled subscription still billed | Auto-resolve up to ₹10,000 with evidence |
| ATM cash not dispensed | `ATM_NOT_DISPENSED` | Debited, no cash | Auto-reverse when the ATM journal confirms it, up to ₹20,000 |
| Unauthorised transaction | `UNAUTHORIZED` | Card-not-present fraud, OTP scam | **Never automatic.** Recommendation plus human approval |

### 3.2 Out of scope (phase 1)
UPI disputes, loans, insurance, corporate cards, and legal or ombudsman escalations. UPI is planned for phase 2 (see §12).

### 3.3 Channels
- **Customers:** mobile app chat and web chat. Voice/IVR comes in phase 2.
- **Staff:** Gemini Enterprise for the ops assistant, plus an approval queue.

---

## 4. Stakeholders and roles

| Role | Responsibility | Interaction with DisputeIQ |
|---|---|---|
| Customer | Raises the dispute | Chats with the Dispute Concierge |
| Dispute Officer (L1) | Approves or rejects agent recommendations up to ₹2,00,000 | Approval queue |
| Senior Dispute Officer (L2) | Above ₹2,00,000, late reports, negligence cases | Escalation queue |
| Fraud Analyst | P1 fraud-in-progress cases | P1 queue and card actions |
| Compliance / Model Risk (MRM) | Approves policy, prompts, models and eval results | Release sign-off, monthly review |
| AI Platform / SRE | Runs, monitors and deploys the system | Runbook owner |
| Product Owner | KPIs and roadmap | Playbook owner |
| Data Protection Officer | DPDP Act compliance | Data-flow and retention approval |

---

## 5. Requirements

Each requirement has an ID, a priority (**M**ust / **S**hould / **C**ould) and an acceptance criterion (AC) that can be tested.

### 5.1 Functional requirements

| ID | Requirement | Priority | Acceptance criterion |
|---|---|---|---|
| **FR-01** | The system shall accept a dispute only from an **authenticated** customer session. The customer ID comes from the channel, never from the chat text. | M | A request without an authenticated customer ID is rejected. Covered by an eval case. |
| **FR-02** | The system shall identify the disputed transaction. If it is ambiguous, it shall list recent transactions and ask the customer to confirm one. | M | ≥ 98% correct transaction identification on the eval set. |
| **FR-03** | The system shall classify each dispute into exactly one reason code: DUPLICATE, MERCHANT_DISPUTE, ATM_NOT_DISPENSED or UNAUTHORIZED. | M | ≥ 95% classification accuracy against human labels. |
| **FR-04** | The system shall open exactly **one** case per disputed transaction. Repeat calls return the existing case (idempotent). | M | Unit test `test_case_idempotent` passes. |
| **FR-05** | The system shall gather evidence **in parallel**: transaction analysis, fraud signals and policy lookup. | M | Trace shows the three analysts running concurrently. |
| **FR-06** | Fraud scoring, customer liability and ATM compensation shall be computed by **deterministic code tools**, never by the LLM. | M | No liability figure appears in a response unless it came from a tool result (hallucination metric ≥ 0.8). |
| **FR-07** | The system shall recommend one action, `auto_resolve`, `needs_approval` or `escalate`, using the ordered decision rules in §6.3, and shall cite the rule and evidence. | M | Decision correctness ≥ 4/5 from the LLM judge. Exact action match ≥ 95%. |
| **FR-08** | Provisional credits ≤ ₹10,000 for non-UNAUTHORIZED cases may be posted automatically. Larger amounts and **all** UNAUTHORIZED cases need human approval (HITL). | M | Unit test `test_hitl_rule` passes. Zero unapproved credits above the limit in production audit. |
| **FR-09** | The system shall never post a credit above ₹2,00,000. Such cases are escalated to L2. | M | Guardrail test `test_hard_cap_blocks` passes. |
| **FR-10** | The system shall offer to block the card when fraud is suspected, and block it only after the customer confirms. | M | `block_card` requires confirmation. Covered by an eval case. |
| **FR-11** | Every escalation shall carry a reason and a priority: P1 for fraud in progress, P2 for high value or a vulnerable customer, P3 for routine. | M | 100% of escalations have a non-empty reason (from logs). |
| **FR-12** | The final customer message shall go through a writer and compliance-reviewer loop (at most 3 iterations). It must include the case ID and the next-step timeline, and no internal scores or PII. | M | Rubric score ≥ 0.8 on `states_next_steps` and `no_internal_details`. |
| **FR-13** | The system shall respond in English or Hindi, matching the customer. | S | Hindi eval subset passes. |
| **FR-14** | Ops staff shall be able to ask the agent for case status and policy explanations through Gemini Enterprise. | S | UAT sign-off by the ops lead. |
| **FR-15** | The system shall record every tool call, decision and approval with timestamps for audit. | M | Audit query returns the full trail for 100% of sampled cases. |

### 5.2 Regulatory and compliance requirements

| ID | Requirement | Source (to be verified by Compliance) |
|---|---|---|
| **RR-01** | Customer liability for unauthorised electronic transactions follows the bank's matrix. Third-party breach reported within 3 working days means **zero** liability. Reported in 4–7 working days means **limited** liability capped by account type. Later than that, the Board-approved policy applies. | RBI circular on limiting customer liability in unauthorised electronic banking transactions (2017) |
| **RR-02** | Shadow-credit the customer within **10 working days** of notification where liability is zero or limited. Resolve within **90 days**. | Same as above |
| **RR-03** | ATM cash-not-dispensed: reverse proactively within **T+5**, and pay **₹100 per day** of delay after that. | RBI circular on TAT harmonisation for failed transactions (2019) |
| **RR-04** | Personal data shall be minimised and masked before it reaches the LLM. Purpose limitation and retention follow the DPDP Act 2023 and the Rules. | Digital Personal Data Protection Act, 2023 |
| **RR-05** | AI governance follows the bank's Board-approved AI policy, aligned with RBI's **FREE-AI** framework (Aug 2025): its 7 Sutras, a model inventory, incident reporting and human oversight. | RBI FREE-AI Committee Report |
| **RR-06** | Every model and prompt version is registered in the model inventory, with validation evidence from the eval reports. | Model Risk Management policy |
| **RR-07** | Customers shall be told they are interacting with an AI assistant and can always ask for a human. | Fair-practice / transparency principle |

### 5.3 Non-functional requirements

| ID | Category | Requirement |
|---|---|---|
| **NFR-01** | Latency | p95 end-to-end ≤ 60 s for a full investigation. First response to the customer ≤ 5 s. |
| **NFR-02** | Availability | 99.5% monthly. If the model is unavailable, cases go to the human queue automatically. |
| **NFR-03** | Cost | Mean LLM cost ≤ US$0.03 per case. Hard cap of 25 LLM calls per session. |
| **NFR-04** | Security | No secrets in code. Workload Identity. Least-privilege service accounts. VPC-SC perimeter. Data stays in an India region (asia-south1). |
| **NFR-05** | Privacy | Card number, Aadhaar, PAN, phone, email and OTP are redacted before every LLM call. Logs hold IDs and keys, never values. |
| **NFR-06** | Observability | 100% of sessions traced (OpenTelemetry → Cloud Trace). Structured JSON logs. Dashboards and alerts as in `ops/alerts.yaml`. |
| **NFR-07** | Quality gate | No release unless eval thresholds pass (§9). |
| **NFR-08** | Robustness | Prompt-injection attempts never cause money movement. Security eval cases pass 100%. |
| **NFR-09** | Explainability | Each decision includes the rule number, tool facts and a confidence score. |
| **NFR-10** | Kill switch | SAFE_MODE disables all money-moving tools within 15 minutes. |

### 5.4 Constraints and assumptions
- Core banking, card management and case management expose REST APIs. Phase 1 uses mocks in `/data`.
- Gemini models are reached through Vertex AI in an India region. The model names are configuration, not code.
- Human approvers are available 08:00–22:00 IST. P1 fraud cases are covered 24×7 by the fraud desk.

---

## 6. Solution overview

### 6.1 Architecture
```
Customer app / web ──► API gateway ──► Vertex AI Agent Engine
                                         │
                       ┌─────────────────┴───────────────────┐
                       │  dispute_concierge (root LlmAgent)   │  ◄── guardrails: PII redaction,
                       │  tools: create_case, credit*,        │      injection filter, tool policy,
                       │         block_card*, escalate        │      LLM-call budget
                       └──────┬──────────────────────┬────────┘      (*require human confirmation)
                              │ AgentTool            │ AgentTool
              ┌───────────────▼─────────────┐   ┌────▼──────────────────────┐
              │ investigation_team (Seq)     │   │ customer_letter (Loop ≤3) │
              │ 1 intake_agent               │   │  letter_writer ⇄ reviewer │
              │ 2 evidence_team (Parallel)   │   └───────────────────────────┘
              │    ├ transaction_analyst     │
              │    ├ fraud_analyst           │──► deterministic tools (core banking, card, policy)
              │    └ policy_analyst          │
              │ 3 decision_agent (Pro model) │
              └──────────────────────────────┘
Observability: OTel traces → Cloud Trace │ JSON logs → Cloud Logging → log metrics → alerts
Staff: Gemini Enterprise (ops assistant) │ approval queue (HITL)
```

### 6.2 Multi-agent coordination strategies (S079)
| Pattern | Where | Why |
|---|---|---|
| Hierarchical orchestrator | `dispute_concierge` | One owner of the conversation, with clear accountability |
| Sequential pipeline | intake → evidence → decision | Each step depends on the one before |
| Parallel fan-out and gather | three evidence analysts | Cuts latency by about 40%. The analysts are independent. |
| Generator–critic loop | letter writer ⇄ compliance reviewer | Raises letter quality with a bounded number of iterations |
| Shared state (blackboard) | `output_key` → session state | Agents pass structured JSON, not free text |

### 6.3 Decision rules (applied in order; the first match wins)
1. Evidence missing → **escalate** P3
2. UNAUTHORIZED → **needs_approval** if liability was computed, otherwise **escalate** P1 or P2
3. Fraud score ≥ 60 → **escalate** P1
4. Amount ≤ the policy auto limit and ≤ ₹10,000 → **auto_resolve**
5. Amount ≤ ₹2,00,000 → **needs_approval**
6. Otherwise → **escalate** P2

### 6.4 Human-in-the-loop design (S081)
- **Confirmation gates:** `issue_provisional_credit` (conditional) and `block_card` (always) use ADK `require_confirmation`. The run pauses until a human approves or rejects.
- **Escalation:** `escalate_to_human` puts the case in a queue with priority, reason and an evidence pack.
- **Override learning:** every human override is logged and becomes a new eval case (§9).

### 6.5 Adaptive behaviour (S082)
- Policy limits, thresholds and model routing are **configuration** (`policies.json`, env vars), so they can change without a code change.
- The agent adapts to downstream failures: it retries once, then escalates. SAFE_MODE degrades the service gracefully.
- Drift is handled through feedback loops: overrides, judge scores and new fraud patterns become eval cases, then hill climbing, then release.

---

## 7. Technology stack

| Layer | Choice |
|---|---|
| Agent framework | Google ADK (Python): LlmAgent, SequentialAgent, ParallelAgent, LoopAgent, AgentTool, callbacks, `require_confirmation` |
| Models | Gemini Flash (routing, tools, letters) and Gemini Pro (decision). Optional LoRA-tuned tool-caller. |
| Runtime | Vertex AI Agent Engine (managed sessions, scaling, tracing) |
| Staff UI | Gemini Enterprise (agent registration, Agent Designer) |
| Evaluation | `adk eval` (trajectory, response match, rubric judges, hallucination, safety), custom LLM judge, `adk optimize` |
| Fine-tuning | HF PEFT (LoRA/QLoRA) on Gemma, or Vertex AI supervised tuning for Gemini |
| Observability | OpenTelemetry, Cloud Trace, Cloud Logging, Cloud Monitoring |
| CI/CD | GitHub Actions with Workload Identity Federation, environments with required reviewers |

---

## 8. Ethics, risk and controls (S084)

| Risk | Control |
|---|---|
| AI moves money wrongly | Hard caps in code, HITL confirmation, SAFE_MODE, daily QA sample |
| Biased outcomes (for example, by region or segment) | Monthly fairness review of approval and escalation rates by segment. The rules use no protected attributes. |
| Privacy leakage | PII redaction before the LLM, no values in logs, India data residency |
| Prompt injection or social engineering | Injection filter, session security flag, and money tools blocked when the flag is set |
| Hallucinated policy | Policy only from the `lookup_dispute_policy` tool. Hallucination metric gate. |
| Vulnerable customers | Flag raises the case to P2, uses simpler language and offers a human |
| Accountability | A human approver is recorded for every high-risk decision. Model inventory entry. Incident reporting following FREE-AI. |

---

## 9. Evaluation strategy summary (S083, S088, S092, S097, S098)
- **Offline gate (every PR):** `adk eval` on the golden set. Tool trajectory ≥ 0.8 and semantic response match (LLM-judged `final_response_match_v2`) ≥ 0.6. Word-overlap matching was dropped after live testing showed it failing correct but reworded answers. Human-approval pauses are verified separately (a dedicated HITL eval set plus a live integration test).
- **Pre-prod gate:** rubric-based LLM judge ≥ 0.8, hallucination ≥ 0.8, safety ≥ 0.9, custom decision judge mean ≥ 4/5 with zero critical failures.
- **Judge calibration:** Cohen's κ ≥ 0.6 against 100 human-labelled cases before the judge can gate a release.
- **Online:** task-completion rate, auto-resolution rate, human-override rate, tool error rate, p95 latency, cost per case.
- **Hill climbing:** change one variable at a time, keep it only if it improves the dev set by ≥ 2 points with no regression on the holdout set.
- **Fine-tune evaluation:** function-call exact match and argument F1. ROUGE-L and BLEU for letters. MMLU, BBH and GLUE for forgetting, with a drop of no more than 2 points.

---

## 10. Expected benefits

| Benefit | Estimate (illustrative) |
|---|---|
| Staff hours saved | about 60% of data-gathering time, roughly 38 FTE redeployed to complex cases |
| Lower compensation payouts | TAT breaches cut from 18% to under 2% |
| Audit readiness | 100% of decisions traceable to evidence, rule and approver |
| Customer experience | Same-day resolution for most low-risk cases |

---

## 11. Delivery plan

| Phase | Weeks | Output |
|---|---|---|
| 0. Discovery and governance | 1–2 | Requirements sign-off, DPIA, model-risk tiering, eval set v0 |
| 1. Build MVP | 3–6 | Agents, tools, guardrails, unit tests, golden eval set |
| 2. Evaluate and harden | 7–9 | Judge calibration, hill climbing, red-team tests, observability |
| 3. Pilot (shadow mode) | 10–12 | Agent recommends, humans decide. Measure agreement (target ≥ 90%). |
| 4. Controlled go-live | 13–16 | Canary at 5%, then 25%, then 100% for low-risk codes, with HITL on |
| 5. Optimise | 17+ | Fine-tuned tool-caller, cost tuning, phase-2 scope |

---

## 12. Phase 2 roadmap
UPI disputes, voice channel, chargeback-network API integration, proactive fraud outreach, and multilingual support beyond Hindi.

## 13. Glossary
**HITL:** human in the loop. **TAT:** turnaround time. **Shadow credit:** a temporary credit while the investigation continues. **EJ log:** ATM electronic journal. **MCC:** merchant category code. **PEFT:** parameter-efficient fine-tuning. **LLM-as-judge:** using a model to grade another model's output against a rubric.

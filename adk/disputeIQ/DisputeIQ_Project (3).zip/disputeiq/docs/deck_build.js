const pptxgen = require('pptxgenjs');
const { applyTheme } = require(process.env.SK + "/scripts/apply_theme.js");
const THEME = { name: "DisputeIQ", headFontFace: "Cambria", bodyFontFace: "Calibri",
  colors: { dk1: "1B2A2F", lt1: "FFFFFF", dk2: "0B3D3A", lt2: "EEF4F2", accent1: "0B3D3A", accent2: "F2A541",
            accent3: "2E8B7A", accent4: "C0392B", accent5: "7A8C8A", accent6: "D9E7E3", hlink: "2E8B7A", folHlink: "7A8C8A" } };
const HX = THEME.colors;
const pres = new pptxgen(); pres.layout = "LAYOUT_WIDE";
pres.title = "DisputeIQ - Agentic Card Dispute Resolution"; pres.author = "NovaBank AI Platform";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;
const W = 13.333;

pres.defineSlideMaster({ title: "DARK", background: { color: C.text2 },
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.8, y: 2.3, w: 11.5, h: 1.6, fontSize: 44, bold: true, color: C.background1, fontFace: "Cambria", valign: "bottom", align: "left", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "body", type: "body", x: 0.8, y: 4.05, w: 11.5, h: 1.4, fontSize: 18, color: C.background2, valign: "top", margin: 0 }, text: "" } },
  ] });
pres.defineSlideMaster({ title: "CONTENT", background: { color: C.background1 },
  margin: [0.5, 0.6, 0.6, 0.6],
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.6, y: 0.4, w: 12.1, h: 0.85, fontSize: 32, bold: true, color: C.text2, fontFace: "Cambria", valign: "middle", align: "left", margin: 0 }, text: "" } },
    { text: { text: "DisputeIQ  |  NovaBank (fictional)  |  S079–S100 reference project", options: { x: 0.6, y: 7.0, w: 8, h: 0.3, fontSize: 10, color: C.accent5, margin: 0 } } },
  ],
  slideNumber: { x: 12.2, y: 7.0, w: 0.5, h: 0.3, fontSize: 10, color: C.accent5, align: "right" } });

let n = 0;
function content(title, section) { const s = pres.addSlide({ masterName: "CONTENT", sectionTitle: section }); s.addText(title, { placeholder: "title" }); return s; }
function badge(s, x, y, label, d = 0.55, fill = C.accent2, col = C.text2) {
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: fill }, line: { color: fill }, objectName: "badge" + (n++) });
  s.addText(label, { x, y, w: d, h: d, fontSize: d > 0.5 ? 16 : 12, bold: true, color: col, align: "center", valign: "middle", margin: 0, isTextBox: true });
}
function card(s, x, y, w, h, fill = C.background2) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: { color: fill }, objectName: "card" + (n++) });
}
function txt(s, t, o) { s.addText(t, Object.assign({ isTextBox: true, margin: 0, color: C.text1, fontSize: 14, valign: "top" }, o)); }
function bullets(s, items, o) { s.addText(items.map((t, i) => ({ text: t, options: { bullet: true, breakLine: i < items.length - 1 } })), Object.assign({ isTextBox: true, fontSize: 14, color: C.text1, paraSpaceAfter: 6, valign: "top", margin: 0 }, o)); }

// 1 Title
pres.addSection({ title: "Introduction" });
let s = pres.addSlide({ masterName: "DARK", sectionTitle: "Introduction" });
s.addText("DisputeIQ: agentic card dispute and fraud resolution", { placeholder: "title" });
s.addText("NovaBank case study  ·  Google ADK · Gemini · Vertex AI Agent Engine\nCovers syllabus sessions S079–S100", { placeholder: "body" });
badge(s, 0.8, 1.3, "AI", 0.8);
s.addNotes("NovaBank is fictional. The deck walks from the business problem to requirements, architecture, evaluation, fine-tuning, deployment and operations.");

// 2 Exec summary
s = content("Disputes are slow, costly and hard to audit today", "Introduction");
[["42k", "disputes per month"], ["11.5 days", "mean time to resolve"], ["18%", "breach regulatory TAT"], ["₹410", "cost per case"]].forEach((k, i) => {
  const x = 0.6 + i * 3.08; card(s, x, 1.55, 2.85, 1.75);
  txt(s, k[0], { x: x + 0.25, y: 1.7, w: 2.4, h: 0.9, fontSize: 40, bold: true, color: C.text2, fontFace: "Cambria", valign: "middle" });
  txt(s, k[1], { x: x + 0.25, y: 2.65, w: 2.4, h: 0.5, fontSize: 14, color: C.accent5 });
});
txt(s, "Goal: resolve low-risk disputes automatically, give humans a ready evidence pack for high-risk ones, and make every decision traceable.", { x: 0.6, y: 3.65, w: 5.6, h: 1.3, fontSize: 18, color: C.text2, italic: true });
s.addChart(pres.charts.BAR, [{ name: "Baseline", labels: ["MTTR (days)", "TAT breach %", "Cost/case (₹00)"], values: [11.5, 18, 4.1] },
                             { name: "Target", labels: ["MTTR (days)", "TAT breach %", "Cost/case (₹00)"], values: [3, 2, 1.5] }],
  { x: 6.6, y: 3.5, w: 6.1, h: 3.3, barDir: "bar", chartColors: [HX.accent5, HX.accent3], showValue: true, dataLabelPosition: "outEnd",
    dataLabelFontFace: "+mn-lt", dataLabelFontSize: 11, catAxisLabelFontFace: "+mn-lt", valAxisHidden: true, catAxisLabelColor: HX.dk1,
    valGridLine: { style: "none" }, catGridLine: { style: "none" }, showLegend: true, legendPos: "b", legendFontFace: "+mn-lt", legendFontSize: 11,
    showTitle: true, title: "Baseline vs 12-month target (illustrative)", titleFontFace: "+mn-lt", titleFontSize: 13, titleColor: HX.dk1 });

pres.addSection({ title: "Problem and scope" });
// 3 Problem
s = content("Five pain points drive the business case", "Problem and scope");
[["Rework", "31% of cases are re-classified after intake"], ["Inconsistency", "Same facts, different liability outcomes"], ["TAT breaches", "ATM T+5 and 10-day shadow credits missed"], ["No traceability", "Decisions not linked to evidence and rule"], ["Wasted skill", "~70% of officer time spent gathering data"]].forEach((p, i) => {
  const y = 1.5 + i * 1.0; badge(s, 0.6, y, String(i + 1));
  txt(s, p[0], { x: 1.35, y: y - 0.02, w: 3, h: 0.6, fontSize: 18, bold: true, color: C.text2, valign: "middle" });
  txt(s, p[1], { x: 4.0, y: y - 0.02, w: 4.2, h: 0.6, fontSize: 15, valign: "middle" });
});
card(s, 8.7, 1.5, 4.0, 4.6, C.text2);
txt(s, "Problem statement", { x: 9.0, y: 1.75, w: 3.4, h: 0.5, fontSize: 16, bold: true, color: C.accent2 });
txt(s, "Resolve card and ATM disputes faster, more consistently and audit-ready — without letting an AI move money or decide liability on high-risk cases without human approval.", { x: 9.0, y: 2.35, w: 3.4, h: 3.5, fontSize: 18, color: C.background1, fontFace: "Cambria" });

// 4 Scope
s = content("Four dispute types, each with a clear authority limit", "Problem and scope");
const hdr = (t) => ({ text: t, options: { bold: true, color: HX.lt1, fill: { color: HX.dk2 }, fontSize: 14 } });
s.addTable([[hdr("Reason code"), hdr("Example"), hdr("Agent authority")],
  ["DUPLICATE", "Charged twice for one order", "Auto-resolve ≤ ₹10,000"],
  ["MERCHANT_DISPUTE", "Cancelled subscription still billed", "Auto-resolve ≤ ₹10,000 with evidence"],
  ["ATM_NOT_DISPENSED", "Debited, no cash", "Auto-reverse when EJ log confirms (≤ ₹20,000)"],
  [{ text: "UNAUTHORIZED", options: { bold: true, color: HX.accent4 } }, "Card-not-present fraud, OTP scam", { text: "Never automatic — recommend + human approval", options: { bold: true } }]],
  { x: 0.6, y: 1.5, w: 12.1, colW: [3.0, 4.3, 4.8], fontSize: 14, fontFace: "Calibri", color: HX.dk1, border: { type: "solid", pt: 0.5, color: "D9E7E3" }, fill: { color: "FFFFFF" }, rowH: 0.6, valign: "middle" });
txt(s, "Out of scope (phase 1): UPI, loans, insurance, corporate cards, ombudsman cases.   Channels: app and web chat for customers; Gemini Enterprise for staff.", { x: 0.6, y: 5.0, w: 12.1, h: 0.8, fontSize: 14, color: C.accent5 });

// 5 Requirements
pres.addSection({ title: "Requirements" });
s = content("Requirements are numbered, owned and testable", "Requirements");
[["15", "Functional (FR)", ["Authenticated intake only", "One case per transaction (idempotent)", "Maths in code tools, never the LLM", "HITL above ₹10k and for all fraud", "Hard cap ₹2,00,000"]],
 ["7", "Regulatory (RR)", ["Liability matrix: 3 / 4–7 / >7 working days", "Shadow credit ≤ 10 working days", "ATM reversal T+5, ₹100/day after", "DPDP Act data minimisation", "RBI FREE-AI aligned governance"]],
 ["10", "Non-functional (NFR)", ["p95 latency ≤ 60 s", "99.5% availability", "≤ US$0.03 LLM cost per case", "100% sessions traced", "Kill switch within 15 min"]]].forEach((c, i) => {
  const x = 0.6 + i * 4.1; card(s, x, 1.5, 3.85, 5.1);
  txt(s, c[0], { x: x + 0.3, y: 1.65, w: 1.3, h: 0.9, fontSize: 44, bold: true, color: C.accent3, fontFace: "Cambria", valign: "middle" });
  txt(s, c[1], { x: x + 1.5, y: 1.65, w: 2.2, h: 0.9, fontSize: 18, bold: true, color: C.text2, valign: "middle" });
  bullets(s, c[2], { x: x + 0.3, y: 2.75, w: 3.3, h: 3.7, fontSize: 14 });
});
s.addNotes("Every requirement in the case study has an ID, priority and acceptance criterion. Regulatory values must be confirmed by Compliance against current RBI directions.");

// 6 Architecture
pres.addSection({ title: "Solution" });
s = content("Architecture: an orchestrator with specialist sub-agents", "Solution");
const box = (x, y, w, h, t, fill, col, fs = 13, b = true) => { card(s, x, y, w, h, fill); txt(s, t, { x: x + 0.1, y, w: w - 0.2, h, fontSize: fs, bold: b, color: col, align: "center", valign: "middle" }); };
box(0.6, 3.0, 1.9, 1.0, "Customer app / web", C.background2, C.text2);
box(3.0, 2.6, 2.9, 1.8, "dispute_concierge\n(root LlmAgent)\n+ guardrails", C.text2, C.background1, 14);
box(6.6, 1.45, 6.1, 0.55, "investigation_team  (SequentialAgent)", C.accent3, C.background1, 14);
box(6.6, 2.15, 1.8, 0.75, "1 · intake_agent", C.background2, C.text2, 12);
box(8.55, 2.15, 2.35, 0.75, "2 · evidence_team\n(ParallelAgent)", C.background2, C.text2, 12);
box(11.05, 2.15, 1.65, 0.75, "3 · decision\n(Pro model)", C.background2, C.text2, 12);
["txn", "fraud", "policy"].forEach((t, i) => box(8.55 + i * 0.8, 3.0, 0.75, 0.6, t, C.accent6, C.text2, 9));
box(6.6, 4.05, 6.1, 0.75, "customer_letter (LoopAgent ≤ 3): writer ⇄ compliance reviewer", C.accent2, C.text2, 13);
box(6.6, 5.0, 6.1, 0.75, "Deterministic tools: core banking · card mgmt · policy · case mgmt", C.background2, C.text2, 13);
box(0.6, 5.0, 5.3, 0.75, "HITL gates: credit (conditional) · block_card (always)", C.accent4, C.background1, 13);
s.addShape(pres.shapes.LINE, { x: 2.5, y: 3.5, w: 0.5, h: 0, line: { color: HX.accent5, width: 2, endArrowType: "triangle" } });
s.addShape(pres.shapes.LINE, { x: 5.9, y: 3.1, w: 0.7, h: -1.35, line: { color: HX.accent5, width: 2, endArrowType: "triangle" } });
s.addShape(pres.shapes.LINE, { x: 5.9, y: 3.9, w: 0.7, h: 0.5, line: { color: HX.accent5, width: 2, endArrowType: "triangle" } });
txt(s, "Runtime: Vertex AI Agent Engine (asia-south1) · Traces → Cloud Trace · JSON logs → Cloud Logging · Staff via Gemini Enterprise", { x: 0.6, y: 6.1, w: 12.1, h: 0.5, fontSize: 13, color: C.accent5 });

// 7 Coordination
s = content("Four coordination patterns, each chosen for a reason", "Solution");
[["Hierarchical orchestrator", "dispute_concierge owns the conversation and delegates through AgentTool.", "One accountable owner"],
 ["Sequential pipeline", "intake → evidence → decision; each step needs the one before.", "Predictable order"],
 ["Parallel fan-out", "Transaction, fraud and policy analysts run concurrently.", "~40% lower latency"],
 ["Generator–critic loop", "Letter writer and compliance reviewer iterate, max 3 rounds.", "Higher letter quality"]].forEach((p, i) => {
  const x = 0.6 + (i % 2) * 6.15, y = 1.5 + Math.floor(i / 2) * 2.55; card(s, x, y, 5.95, 2.3);
  badge(s, x + 0.3, y + 0.3, String.fromCharCode(65 + i));
  txt(s, p[0], { x: x + 1.05, y: y + 0.28, w: 4.6, h: 0.6, fontSize: 20, bold: true, color: C.text2, valign: "middle" });
  txt(s, p[1], { x: x + 1.05, y: y + 0.95, w: 4.6, h: 0.8, fontSize: 15 });
  txt(s, p[2], { x: x + 1.05, y: y + 1.75, w: 4.6, h: 0.4, fontSize: 14, italic: true, color: C.accent3 });
});
s.addNotes("Agents share structured JSON through output_key into session state (a blackboard). Analysts run at temperature 0.");

// 8 HITL + guardrails
s = content("Layered defence keeps humans in charge of money", "Solution");
[["Model input guard", "PII redaction (card, Aadhaar, PAN, phone, OTP) · prompt-injection filter · 25-call LLM budget"],
 ["Tool policy guard", "Hard cap ₹2,00,000 · justification mandatory · blocked when session flagged · SAFE_MODE"],
 ["Human confirmation", "ADK require_confirmation: credit > ₹10k or any UNAUTHORIZED case; card block always"],
 ["Escalation queue", "P1 fraud in progress · P2 high value or vulnerable · P3 routine — always with a reason"]].forEach((l, i) => {
  const y = 1.5 + i * 1.2, w = 12.1 - i * 0.6, x = 0.6 + i * 0.3;
  card(s, x, y, w, 1.0, i % 2 ? C.background2 : C.accent6);
  txt(s, l[0], { x: x + 0.3, y, w: 3.2, h: 1.0, fontSize: 17, bold: true, color: C.text2, valign: "middle" });
  txt(s, l[1], { x: x + 3.5, y, w: w - 3.8, h: 1.0, fontSize: 14, valign: "middle" });
});
txt(s, "Rules live in code, so the model cannot argue its way past them.", { x: 0.6, y: 6.35, w: 12.1, h: 0.45, fontSize: 16, italic: true, color: C.accent3 });

// 9 Decision rules
s = content("Ordered decision rules: the first match wins", "Solution");
[["Evidence missing", "escalate P3"], ["UNAUTHORIZED", "needs_approval / escalate"], ["Fraud score ≥ 60", "escalate P1"], ["≤ ₹10k & policy limit", "auto_resolve"], ["≤ ₹2,00,000", "needs_approval"], ["Otherwise", "escalate P2"]].forEach((r, i) => {
  const x = 0.6 + i * 2.05; badge(s, x + 0.65, 1.6, String(i + 1), 0.6);
  card(s, x, 2.45, 1.9, 1.3); txt(s, r[0], { x: x + 0.1, y: 2.45, w: 1.7, h: 1.3, fontSize: 15, bold: true, color: C.text2, align: "center", valign: "middle" });
  card(s, x, 3.9, 1.9, 0.9, i === 3 ? C.accent3 : C.text2); txt(s, r[1], { x: x + 0.1, y: 3.9, w: 1.7, h: 0.9, fontSize: 13, bold: true, color: C.background1, align: "center", valign: "middle" });
});
bullets(s, ["Fraud score, liability and ATM compensation come from deterministic tools", "The decision agent only selects a rule and cites the evidence and its confidence", "Thresholds live in policies.json, so Compliance can change them without code"], { x: 0.6, y: 5.2, w: 12.1, h: 1.6, fontSize: 15 });

// 10 Observability
pres.addSection({ title: "Quality and operations" });
s = content("Observability: logs, metrics and traces for every session", "Quality and operations");
[["Logs", "What happened", ["One JSON line per tool and LLM call", "Tool, status, latency, tokens, cost", "Argument keys only, never values"]],
 ["Metrics", "How much, how often", ["Completion and auto-resolution rate", "Tool error rate, guardrail blocks", "p95 latency, cost per case"]],
 ["Traces", "Where and why", ["ADK OpenTelemetry spans", "Agent → LLM → tool hierarchy", "Exported to Cloud Trace"]]].forEach((c, i) => {
  const x = 0.6 + i * 4.1; card(s, x, 1.5, 3.85, 3.4);
  txt(s, c[0], { x: x + 0.3, y: 1.65, w: 3.3, h: 0.6, fontSize: 24, bold: true, color: C.text2, fontFace: "Cambria" });
  txt(s, c[1], { x: x + 0.3, y: 2.25, w: 3.3, h: 0.4, fontSize: 14, italic: true, color: C.accent3 });
  bullets(s, c[2], { x: x + 0.3, y: 2.8, w: 3.3, h: 2.0, fontSize: 14 });
});
txt(s, "Alerts", { x: 0.6, y: 5.15, w: 2, h: 0.4, fontSize: 16, bold: true, color: C.text2 });
txt(s, "AL-01 tool errors > 5%  ·  AL-02 guardrail spike  ·  AL-03 cost burn  ·  AL-04 latency SLO  ·  AL-05 quality drift  ·  AL-06 model 5xx — each linked to a runbook procedure", { x: 0.6, y: 5.6, w: 12.1, h: 0.8, fontSize: 14 });

// 11 Evaluation
s = content("Evaluation gates: no release without evidence", "Quality and operations");
s.addTable([[hdr("Gate"), hdr("Metric"), hdr("Threshold"), hdr("When")],
  ["Unit tests", "22 deterministic tests", "100%", "Every commit"],
  ["Trajectory", "tool_trajectory_avg_score (in order)", "≥ 0.8", "Every PR"],
  ["Response", "Semantic match (LLM-judged)", "≥ 0.6", "Every PR"],
  ["LLM-as-judge", "Rubric quality + tool-use rubrics", "≥ 0.8", "Staging"],
  ["Grounding / safety", "hallucinations_v1 / safety_v1", "≥ 0.8 / ≥ 0.9", "Staging"],
  ["Decision judge", "Custom judge, 1–5 rubric", "≥ 4.0, 0 critical", "Staging"],
  ["Judge trust", "Cohen's κ vs 100 human labels", "≥ 0.6", "Before gating"]],
  { x: 0.6, y: 1.45, w: 7.6, colW: [1.7, 3.0, 1.5, 1.4], fontSize: 12, fontFace: "Calibri", color: HX.dk1, border: { type: "solid", pt: 0.5, color: "D9E7E3" }, rowH: 0.5, valign: "middle" });
card(s, 8.6, 1.45, 4.1, 4.1, C.background2);
txt(s, "Judge bias controls", { x: 8.9, y: 1.6, w: 3.6, h: 0.5, fontSize: 17, bold: true, color: C.text2 });
bullets(s, ["Anchored rubric, JSON output", "Reference-guided scoring", "Median of 3 samples", "Swap A/B order in pairwise", "Different judge model", "Calibrate against humans"], { x: 8.9, y: 2.2, w: 3.6, h: 3.2, fontSize: 14 });
txt(s, "System metrics from logs: task completion · auto-resolution · override rate · tool error rate · LLM calls per session · cost per case", { x: 0.6, y: 5.85, w: 12.1, h: 0.7, fontSize: 14, color: C.accent5 });

// 12 Hill climbing
s = content("Hill climbing: change one thing, keep only winners", "Quality and operations");
const steps = ["Baseline champion", "Propose one change", "Run same eval set", "Beats by ≥ 2 pts, no holdout regression?", "Promote + log to leaderboard"];
steps.forEach((t, i) => { const x = 0.6 + i * 2.48; card(s, x, 1.7, 2.2, 1.6, i === 3 ? C.accent2 : C.background2);
  txt(s, t, { x: x + 0.15, y: 1.7, w: 1.9, h: 1.6, fontSize: 15, bold: true, color: C.text2, align: "center", valign: "middle" });
  if (i < 4) s.addShape(pres.shapes.LINE, { x: x + 2.2, y: 2.5, w: 0.28, h: 0, line: { color: HX.accent5, width: 2, endArrowType: "triangle" } }); });
txt(s, "Candidates we test", { x: 0.6, y: 3.75, w: 5, h: 0.5, fontSize: 18, bold: true, color: C.text2 });
bullets(s, ["Prompt versions (v3 → v4)", "Decision step on Flash instead of Pro (cost)", "LoRA-tuned tool-caller model", "Lower LLM-call budget"], { x: 0.6, y: 4.3, w: 5.8, h: 2.2, fontSize: 15 });
card(s, 6.9, 3.75, 5.8, 2.6, C.text2);
txt(s, "Automate it", { x: 7.2, y: 3.95, w: 5.2, h: 0.5, fontSize: 18, bold: true, color: C.accent2 });
txt(s, "eval/hill_climb.py runs candidates against the champion and writes leaderboard.csv. adk optimize (GEPA) searches prompt space using the same eval set.", { x: 7.2, y: 4.5, w: 5.2, h: 1.7, fontSize: 15, color: C.background1 });

// 13 Fine-tuning
pres.addSection({ title: "Fine-tuning" });
s = content("Fine-tune only when prompts plateau", "Fine-tuning");
[["Instruction vs task-specific", "Start from an instruction-tuned base (FLAN-style). Add task-specific SFT on our tools and arguments."],
 ["PEFT: LoRA / QLoRA", "Gemma 3 4B, r=16, 4-bit NF4. Trains < 1% of weights on one GPU. Or Vertex AI tuning for Gemini."],
 ["Avoid forgetting", "Frozen base · 25% general replay · 2 epochs, LR 1e-4 · fail if MMLU/BBH/GLUE drop > 2 pts"],
 ["Function-calling data", "Schemas from ADK tools · exact args · 'ask, don't call' negatives · 15% safety refusals"]].forEach((p, i) => {
  const y = 1.5 + i * 1.22; badge(s, 0.6, y + 0.15, String(i + 1));
  txt(s, p[0], { x: 1.35, y, w: 3.4, h: 0.9, fontSize: 17, bold: true, color: C.text2, valign: "middle" });
  txt(s, p[1], { x: 4.8, y, w: 3.6, h: 0.9, fontSize: 13, valign: "middle" });
});
card(s, 8.8, 1.5, 3.9, 4.75, C.background2);
txt(s, "Metrics", { x: 9.1, y: 1.65, w: 3.3, h: 0.5, fontSize: 18, bold: true, color: C.text2 });
bullets(s, ["Function-call exact match, argument F1", "ROUGE-L / BLEU for letters (with judge)", "MMLU, BIG-Bench Hard, GLUE for forgetting", "HELM-style holistic report for model risk"], { x: 9.1, y: 2.25, w: 3.3, h: 3.9, fontSize: 14 });

// 14 CI/CD
pres.addSection({ title: "Delivery" });
s = content("CI/CD treats prompts and models like code", "Delivery");
["Lint + unit", "ADK eval gate", "Deploy staging", "Judge eval", "Approval (MRM)", "Prod canary 5→25→100%"].forEach((t, i) => {
  const x = 0.6 + i * 2.05; card(s, x, 1.8, 1.85, 1.3, i === 4 ? C.accent2 : C.text2);
  txt(s, t, { x: x + 0.1, y: 1.8, w: 1.65, h: 1.3, fontSize: 14, bold: true, color: i === 4 ? C.text2 : C.background1, align: "center", valign: "middle" });
  if (i < 5) s.addShape(pres.shapes.LINE, { x: x + 1.85, y: 2.45, w: 0.2, h: 0, line: { color: HX.accent5, width: 2, endArrowType: "triangle" } });
});
bullets(s, ["GitHub Actions with Workload Identity Federation — no service-account keys", "A PR that breaks a tool trajectory is blocked automatically", "Production environment requires named reviewers (AI Platform lead + model risk)", "adk deploy agent_engine --trace_to_cloud; previous version kept 7 days for rollback", "Gemini Enterprise: register the agent for ops staff; use Agent Designer and coding agents to build new agents"], { x: 0.6, y: 3.5, w: 12.1, h: 3.0, fontSize: 15 });

// 15 Roadmap
s = content("Delivery plan: 16 weeks to controlled go-live", "Delivery");
s.addShape(pres.shapes.LINE, { x: 0.6, y: 2.25, w: 12.1, h: 0, line: { color: HX.accent6, width: 3 } });
[["Wk 1–2", "Discovery and governance", "Requirements sign-off, DPIA, eval set v0"], ["Wk 3–6", "Build MVP", "Agents, tools, guardrails, tests"], ["Wk 7–9", "Evaluate and harden", "Judge calibration, hill climb, red team"], ["Wk 10–12", "Shadow pilot", "Agent recommends, humans decide (≥ 90% agreement)"], ["Wk 13–16", "Controlled go-live", "Canary for low-risk codes, HITL on"], ["Wk 17+", "Optimise", "Fine-tuned tool-caller, UPI scope"]].forEach((p, i) => {
  const x = 0.6 + i * 2.05;
  badge(s, x + 0.65, 1.97, String(i + 1));
  txt(s, p[0], { x, y: 2.75, w: 1.9, h: 0.4, fontSize: 14, bold: true, color: C.accent3, align: "center" });
  card(s, x, 3.25, 1.9, 2.8);
  txt(s, p[1], { x: x + 0.12, y: 3.4, w: 1.66, h: 0.8, fontSize: 15, bold: true, color: C.text2 });
  txt(s, p[2], { x: x + 0.12, y: 4.25, w: 1.66, h: 1.7, fontSize: 13 });
});

// 16 Runbook & playbook
s = content("Runbook says how to operate; playbook says who decides", "Delivery");
card(s, 0.6, 1.5, 5.95, 5.0); card(s, 6.75, 1.5, 5.95, 5.0, C.text2);
txt(s, "Runbook (SRE / AI Platform)", { x: 0.9, y: 1.7, w: 5.4, h: 0.5, fontSize: 18, bold: true, color: C.text2 });
bullets(s, ["Daily and weekly checks", "RB-01 model errors · RB-02 latency", "RB-03 release and canary", "RB-04 tool outages · RB-05 cost spikes", "RB-06 prompt injection / abuse", "RB-07 SAFE_MODE kill switch", "RB-08 quality drift · RB-09 rollback", "RB-10 DPDP data-subject requests"], { x: 0.9, y: 2.3, w: 5.4, h: 4.0, fontSize: 14 });
txt(s, "Playbook (business owners)", { x: 7.05, y: 1.7, w: 5.4, h: 0.5, fontSize: 18, bold: true, color: C.accent2 });
bullets(s, ["RACI for limits, releases, approvals", "PB-01…07 case-handling plays", "Go / no-go release gates", "SEV1: wrong money movement, data leak", "SEV2: drift, new fraud pattern", "Weekly improvement loop", "When-to-fine-tune decision tree"], { x: 7.05, y: 2.3, w: 5.4, h: 4.0, fontSize: 14, color: C.background1 });

// 17 Risk
s = content("Responsible AI: risks mapped to controls", "Delivery");
s.addTable([[hdr("Risk"), hdr("Control")],
  ["Wrong money movement", "Hard caps in code, HITL, SAFE_MODE, daily QA sample"],
  ["Privacy leakage", "PII redaction before the LLM, no values in logs, India data residency (DPDP)"],
  ["Prompt injection", "Input filter, session flag, money tools blocked, security eval cases at 100%"],
  ["Hallucinated policy", "Policy only from tools; hallucination metric gate"],
  ["Unfair outcomes", "No protected attributes; monthly approval-rate review by segment"],
  ["Accountability", "Named approver per decision, model inventory, FREE-AI-aligned incident reporting"]],
  { x: 0.6, y: 1.5, w: 12.1, colW: [3.3, 8.8], fontSize: 14, fontFace: "Calibri", color: HX.dk1, border: { type: "solid", pt: 0.5, color: "D9E7E3" }, rowH: 0.62, valign: "middle" });
txt(s, "Regulatory values are illustrative and must be validated by Compliance against current RBI Master Directions.", { x: 0.6, y: 6.2, w: 12.1, h: 0.4, fontSize: 12, italic: true, color: C.accent5 });

// 18 Syllabus coverage
s = content("Every syllabus session is implemented and tested", "Delivery");
const cov = [["S079–S082", "Coordination, workflows, HITL, adaptive agents", "agent.py, guardrails, policies.json"], ["S083–S085", "LLM judge, ethics and regulation, best practices", "judge configs, guardrails, checklist"], ["S086–S088", "Gemini Enterprise, ADK build/deploy, hill climbing", "deploy/, hill_climb.py"], ["S089–S093", "Fine-tuning, PEFT, forgetting, metrics, function calling", "finetune/"], ["S094–S096", "Observability, debugging, CI/CD", "observability.py, alerts.yaml, ci.yml"], ["S097–S100", "System metrics, judges, prompt and LLM issues", "system_metrics.py, issues catalogue"]];
cov.forEach((c, i) => { const x = 0.6 + (i % 3) * 4.1, y = 1.5 + Math.floor(i / 3) * 2.55; card(s, x, y, 3.85, 2.3);
  txt(s, c[0], { x: x + 0.3, y: y + 0.2, w: 3.3, h: 0.5, fontSize: 20, bold: true, color: C.accent3, fontFace: "Cambria" });
  txt(s, c[1], { x: x + 0.3, y: y + 0.75, w: 3.3, h: 0.8, fontSize: 14, bold: true, color: C.text2 });
  txt(s, c[2], { x: x + 0.3, y: y + 1.6, w: 3.3, h: 0.55, fontSize: 12, color: C.accent5 }); });

// 19 Close
pres.addSection({ title: "Close" });
// 18b Live demo
s = content("Live demo: eight scenarios, one command each", "Close");
s.addTable([[hdr("#"), hdr("Scenario"), hdr("What participants see"), hdr("Syllabus")],
  ["1", "Duplicate charge ₹4,999", "Parallel analysts → auto credit → letter", "S079, S080"],
  ["2", "Cancelled subscription", "Evidence check from customer's words", "S080"],
  ["3", "Card fraud ₹1,45,000", "Run PAUSES — presenter approves live", "S081"],
  ["4", "Fraud ₹2,60,000", "Guardrail blocks the hard cap → escalation", "S084, S095"],
  ["5", "ATM no cash", "EJ log check + ₹100/day compensation", "S080"],
  ["6", "OTP shared", "Negligence → senior officer, no credit", "S084"],
  ["7", "Prompt injection", "Filtered before the model sees it", "S095, S100"],
  ["8", "Card number in chat", "PII redacted before the LLM", "S084"]],
  { x: 0.6, y: 1.45, w: 12.1, colW: [0.6, 3.2, 5.9, 2.4], fontSize: 13, fontFace: "Calibri", color: HX.dk1, border: { type: "solid", pt: 0.5, color: "D9E7E3" }, rowH: 0.52, valign: "middle" });
txt(s, "python scripts/demo.py --scenario 3     ·     then: make eval  ·  adk web .", { x: 0.6, y: 6.35, w: 12.1, h: 0.4, fontSize: 14, bold: true, color: C.accent3, fontFace: "Courier New" });

s = pres.addSlide({ masterName: "DARK", sectionTitle: "Close" });
s.addText("Next steps", { placeholder: "title" });
s.addText("Four actions to start in the next 30 days", { placeholder: "body" });
["Sign off requirements and DPIA", "Run the MVP against the golden eval set", "Calibrate the judge on 100 labelled cases", "Start the shadow pilot with Disputes Ops"].forEach((t, i) => {
  const x = 0.8 + i * 2.95; card(s, x, 4.9, 2.75, 1.6, C.accent3);
  badge(s, x + 0.2, 5.05, String(i + 1), 0.5);
  txt(s, t, { x: x + 0.2, y: 5.6, w: 2.35, h: 0.85, fontSize: 14, bold: true, color: C.background1 });
});

(async () => { await pres.writeFile({ fileName: "DisputeIQ_Project_Deck.pptx" }); await applyTheme("DisputeIQ_Project_Deck.pptx", THEME); console.log("done"); })();

# Syllabus Traceability Matrix (S079–S100)

Each syllabus session maps to where it is covered in the case study, where it is implemented in code or config, and how it is verified.

| # | Topic | Case study § | Implementation (file) | Verified by |
|---|---|---|---|---|
| S079 | Multi-agent coordination strategies | 6.2 | `dispute_agent/agent.py` (orchestrator, Sequential, Parallel, Loop, shared state via `output_key`) | `tests/test_agent_structure.py`, trace view |
| S080 | Architecting AI workflows with autonomous agents | 6.1, 6.3 | `agent.py`, `prompts.py` decision rules, tools vs LLM split | Eval trajectories |
| S081 | Human-in-the-loop agentic systems | 6.4, FR-08/09/10 | `require_confirmation` on credit and block_card, `escalate_to_human`, approval queue | `test_hitl_rule`, eval case `unauthorized_high_value_hitl` |
| S082 | Adaptive agents for dynamic environments | 6.5 | Policy-as-config (`policies.json`), env model routing, SAFE_MODE, retry-then-escalate, feedback loop | Playbook §6, Runbook RB-08 |
| S083 | Evaluating and deploying agents: LLM as judge | 9 | `eval/test_config.judge.json`, `eval/judge/llm_judge.py`, CI gates | `make eval-judge`, `make judge` |
| S084 | Ethical and regulatory considerations | 5.2, 8 | `guardrails.py` (PII, injection), RBI-aligned liability tool, FREE-AI alignment, DPDP | `tests/test_guardrails.py`, Playbook §5 |
| S085 | Guidelines and best practices | Whole doc | Narrow tools, structured outputs, idempotency, config over code, least privilege | Code review checklist (README) |
| S086 | Gemini Enterprise: use agents to build agents | 3.3, 7 | `deploy/GEMINI_ENTERPRISE.md` (registration, Agent Designer, test-writer agent, `adk optimize`) | Ops UAT |
| S087 | Build and deploy agents with ADK | 7, 11 | `agent.py`, `adk web/run/eval`, `adk deploy agent_engine`, `deploy/deploy_agent_engine.py` | Staging smoke test (RB-03) |
| S088 | Agent evaluation and hill climbing | 9 | `eval/hill_climb.py`, `eval/candidates.json`, leaderboard, `adk optimize` | `eval/results/leaderboard.csv` |
| S089 | LLM fine-tuning: instruction vs task-specific | Guide step 16 | Instruction-tuned base (Gemma-it / Gemini) plus task-specific function-calling SFT | Playbook §7 decision tree |
| S090 | PEFT (LoRA, QLoRA, FLAN) | Guide step 18 | `finetune/train_qlora.py`, `configs/qlora.yaml`, FLAN-style replay mix | Adapter eval |
| S091 | Avoiding catastrophic forgetting | Guide steps 17–19 | Frozen base (PEFT), 25% replay, low LR and few epochs, forgetting gate | `forgetting_gate()` (≤ 2 point drop) |
| S092 | ROUGE, BLEU, MMLU, BIG-Bench, GLUE, HELM | 9 | `finetune/evaluate_finetune.py`, `lm-eval` commands, HELM-style report | Fine-tune eval report |
| S093 | Fine-tuning for function calling | Guide step 17 | `finetune/build_function_calling_dataset.py` (schemas from ADK FunctionTool, negatives, safety) | FC exact match / argument F1 |
| S094 | Observability: logs, metrics, traces | NFR-06 | `observability.py` (JSON logs, OTel), `ops/alerts.yaml` log metrics | Dashboard, Cloud Trace |
| S095 | Issue detection, debugging, optimisation, security/compliance | 8 | Alerts AL-01…06, Runbook RB-01…10, guardrail blocks, audit trail | Alert fire drills |
| S096 | CI/CD and developer workflows | 11 | `.github/workflows/ci.yml`, `Makefile`, WIF auth, environments with reviewers | PR blocked on regression |
| S097 | System metrics, task completion, quality control, tool-interaction metrics | 9 | `eval/system_metrics.py`, ADK `tool_trajectory_avg_score`, rubric tool-use judge | `make metrics` report |
| S098 | LLM / agents as judge | 9 | ADK rubric judges, custom judge with bias controls, κ calibration, pairwise swap | `llm_judge calibrate` |
| S099 | Development issues: poorly defined prompts | 2.2, Guide 5 | Prompt skeleton, versioning, numbered rules, JSON outputs; `06_ISSUES_CATALOGUE.md` | Eval before/after each prompt version |
| S100 | LLM issues: cost; planning, reasoning and tool-calling failures | NFR-03, 8 | Model routing, LLM-call budget, deterministic maths tools, arg repair, retry-then-escalate, cost logging | AL-03, `cost_per_case`, trajectory metric |

# DisputeIQ Operations Runbook

**Audience:** AI Platform / SRE on-call, plus the Disputes Ops lead.  **Owner:** AI Platform team.  **Review:** monthly and after every incident.

The runbook says **how to operate and fix** the system. The playbook (`05_PLAYBOOK.md`) says **what to decide** and who decides it.

---

## 0. Quick reference

| Item | Value |
|---|---|
| Prod runtime | Vertex AI Agent Engine `disputeiq-prod`, region asia-south1 |
| Staging | `disputeiq-staging` |
| Dashboards | Cloud Monitoring → "DisputeIQ Overview" (completion, latency, tool errors, cost, guardrail blocks) |
| Traces | Cloud Trace, filtered by `service.name=disputeiq` or a session ID |
| Logs | Cloud Logging, filter `jsonPayload.event=("tool_call" OR "llm_call")` |
| Kill switch | `DISPUTEIQ_SAFE_MODE=true` (RB-07) |
| Human queue | Case-management queue `DISPUTES-AI-ESC` (P1 → fraud desk 24×7) |
| Escalation chain | On-call SRE → AI Platform lead → Head of Disputes Ops → CISO/DPO (for security or privacy issues) |

### Severity levels
| Sev | Definition | Response | Update cadence |
|---|---|---|---|
| SEV1 | Wrong money movement, data leak, or the agent is down for all customers | 15 min | every 30 min |
| SEV2 | SLO breach, tool outage, a quality drop affecting more than 5% of cases | 30 min | hourly |
| SEV3 | Degradation with a workaround in place | next business day | daily |

---

## 1. Daily checks (09:00 IST, about 10 minutes)
1. Dashboard: task completion is at least 95%, p95 latency at most 60 s, tool error rate at most 2%, and cost per case is within budget.
2. Human queue: no P1 is older than 30 minutes and no P2 is older than 4 hours.
3. Guardrail blocks are within 3× the 7-day baseline.
4. Overnight judge job: mean overall score is at least 4.0 with zero critical failures.
5. Pending HITL confirmations older than 2 hours are pinged to the approver group.
6. Record the results in the ops log.

## 2. Weekly tasks
- Export human overrides, convert them to eval cases, and open a PR to `eval/evalsets/`.
- Run `make metrics` on the last 7 days and attach the report to the weekly review.
- Check model and API deprecation notices, and quota headroom (at least 30%).
- Rotate the on-call handover notes.

---

## 3. Standard procedures

### RB-01 Agent unavailable / model errors (alert AL-06)
**Symptoms:** 5xx errors from Agent Engine, LLM 429 or 5xx errors above 2%, or customers getting a "specialist will contact you" fallback.
1. Check the Google Cloud status page and the Vertex AI quota page (`gcloud alpha services quota list ...`).
2. **429 (quota):** request a quota increase. Meanwhile, set `DISPUTEIQ_MODEL_REASONING=gemini-2.5-flash` to shed load on Pro, and redeploy.
3. **5xx from the model:** confirm the region is affected. If the outage lasts more than 15 minutes, turn **SAFE_MODE on** (RB-07) so all cases go to humans.
4. **Agent Engine errors:** roll back to the previous engine version (RB-09).
5. Post an update to #disputeiq-incidents and inform the Disputes Ops lead about the extra manual volume.

### RB-02 Latency degradation (alert AL-04)
1. Open Cloud Trace and sort sessions by duration. Find the slow span: a model call, a tool, or the loop.
2. **Slow tool span:** this is a downstream API problem. Go to RB-04.
3. **Many LLM spans per session:** the agent is looping. Go to RB-05.
4. **Slow model span:** check the region's latency. Consider routing the decision step to Flash temporarily, using a hill-climb-approved config only.
5. Check whether the letter loop always hits 3 iterations. If so, the reviewer prompt has regressed. Roll back the prompt version.

### RB-03 Release and canary deployment
1. Make sure CI is green: unit tests, `adk eval` fast gate and judge gate on staging.
2. Staging smoke test: run the 7 golden scenarios in `adk web` against staging, or run `make eval` with staging env vars.
3. Get the production environment approval in GitHub (AI Platform lead and MRM delegate).
4. Deploy the prod engine. Route **5%** of traffic in the API gateway.
5. Watch for 2 hours. Completion rate, override rate, tool error rate, cost per case and judge score must stay within ±10% of the champion.
6. Move to 25% after 24 hours and to 100% after 72 hours if the criteria hold. Otherwise roll back (RB-09).
7. Update the model inventory with the version, prompt version, eval report link and approver.

### RB-04 Tool / downstream API failures (alert AL-01)
1. Find which tool is failing: log metric `disputeiq_tool_errors`, grouped by `tool`.
2. Check the health of the downstream system (core banking, card management, case management).
3. If the outage lasts more than 15 minutes and affects a **write** tool (credit or case), turn SAFE_MODE on.
4. Read tools that fail cause the agent to retry once and then escalate. Confirm that escalations are flowing to the queue.
5. After recovery, re-queue the sessions that escalated because of the outage, using a case-management bulk action.

### RB-05 Cost spike / runaway loops (alert AL-03)
1. Run the log query for top sessions by `sum(cost_usd)` in the last hour.
2. Open the trace of the top session. Look for repeated identical tool calls, or a loop that never calls `exit_loop`.
3. Immediate fix: lower `DISPUTEIQ_MAX_LLM_CALLS`, for example from 25 to 15, and redeploy. The guard ends the session gracefully.
4. If one customer or IP is causing it, rate-limit at the gateway. Treat it as possible abuse (RB-06).
5. Root cause: a prompt or tool-description regression. Add an eval case, fix it, hill-climb and release.

### RB-06 Suspected prompt injection / abuse (alert AL-02)
1. Filter logs for sessions with `injection_flag` and for `status="blocked"`.
2. Confirm that no money moved. Check `issue_provisional_credit` calls in those sessions. If any credit was posted, raise a **SEV1** and go to the SEV1 playbook.
3. Block the abusing customer or session at the channel level. Inform the Fraud and Security operations centre.
4. Add the attack pattern to the injection regex or classifier and to the security eval cases.
5. File an AI incident report using the indicative format from RBI FREE-AI Annexure VI, adapted to bank policy.

### RB-07 Kill switch (SAFE_MODE)
**When:** wrong money movement is suspected, a data leak, a model outage longer than 15 minutes, or a regulator or CISO instruction.
1. Set `DISPUTEIQ_SAFE_MODE=true` on the prod engine (update env vars and redeploy, or promote the pre-built SAFE_MODE revision).
2. Verify: run a test credit in prod-shadow. It must return `status: blocked`.
3. The agent keeps doing intake and investigation, and routes **every** case to the human queue.
4. Tell Disputes Ops to add staff to the queue.
5. Turning it off requires approval from the incident commander and the Head of Disputes Ops.

### RB-08 Quality drift (alert AL-05)
1. Compare judge scores by dimension against last week. Find which one dropped: decision, policy, communication or safety.
2. Sample 20 low-scoring sessions and read their traces.
3. Common causes and fixes:
   - Policy changed but the eval set didn't. Update `policies.json` and the evals.
   - A new fraud pattern appeared. Add signals to `compute_fraud_signals` and add eval cases.
   - The model version changed upstream. Pin the version and re-run hill climbing.
   - A prompt regression. Roll back the prompt version.
4. Run `make eval-judge` before and after the fix. Release through RB-03.

### RB-09 Rollback
1. Agent Engine: point the gateway back to the previous engine resource (keep N-1 deployed for 7 days).
2. Prompt or config-only change: redeploy the previous Git tag.
3. Confirm with the smoke test and a dashboard check.
4. Open a post-incident review within 2 business days.

### RB-10 Data-subject request (DPDP)
1. The DPO's ticket gives the customer ID.
2. Export the case records, approval records, and logs keyed by session ID. Logs hold no values by design.
3. Delete or anonymise according to the retention policy. Agent Engine sessions follow the configured TTL.
4. Record completion in the DPO tracker.

---

## 4. Useful queries

```text
# Tool errors by tool (last 1h)
jsonPayload.event="tool_call" AND jsonPayload.status=("error" OR "not_found")

# Guardrail blocks
jsonPayload.event="tool_call" AND jsonPayload.status="blocked"

# Expensive sessions
jsonPayload.event="llm_call" | group by jsonPayload.session_id | sum(jsonPayload.cost_usd)
```

## 5. Post-incident review template
Summary · Impact (customers, ₹, duration) · Timeline · Root cause (5 whys) · What went well and what didn't · Action items (owner, date) · **New eval cases added** · Regulatory reporting needed? (Y/N)

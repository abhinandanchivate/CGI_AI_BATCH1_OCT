# Development and LLM Issues Catalogue (S099, S100)

Known failure modes, how to spot each one, and the fix that is built into DisputeIQ.

## A. Development issues (S099)

| Issue | Symptom | Detection | Prevention / fix in DisputeIQ |
|---|---|---|---|
| Vague goal in the prompt | Agent chats instead of acting, or calls random tools | Trajectory score drops | ROLE/GOAL/STEPS/RULES/OUTPUT skeleton (`prompts.py`) |
| Missing output schema | Downstream agent can't parse the hand-off | JSON parse errors in logs | "OUTPUT (JSON only)" with explicit keys |
| Conflicting rules | Inconsistent decisions on the same facts | Judge `decision_correctness` variance | Numbered rules, first match wins |
| Policy in the prompt | Out-of-date limits | Hallucination metric | Policy comes from the tool and config only |
| Untested prompt edits | Silent regressions | CI eval gate | Prompt versioning and `make eval` on every PR |
| Overloaded single agent | Tool confusion, long context | Many wrong-tool calls | Specialised sub-agents with 1–3 tools each |
| Weak tool docstrings | Wrong arguments | `tool_parameter_match`, argument errors | Docstrings written for the model, typed arguments, examples |
| Eval set too narrow | Passes CI, fails in production | Override rate rising | Overrides become eval cases weekly |

## B. LLM issues (S100)

| Issue | Symptom | Detection | Mitigation |
|---|---|---|---|
| **High running cost** | Cost per case above budget | AL-03, `cost_per_case_usd` | Flash for routine steps and Pro only for the decision; LLM-call cap; short JSON hand-offs; context caching for long system prompts; fine-tuned small tool-caller |
| **Planning failure** | Skips steps (for example, credits before opening a case) | Rubric `case_before_action` | Explicit step order, SequentialAgent for fixed order, tool guard |
| **Reasoning failure** | Wrong liability or amount | Decision judge, unit tests | Maths in deterministic tools; decision agent only selects a rule |
| **Tool-calling failure: wrong tool** | Irrelevant tool calls | Trajectory metric | Narrow toolsets per agent; fine-tuning for function calling |
| **Tool-calling failure: bad arguments** | `error` status, invalid enums | `tool_error_rate` | Typed arguments, argument repair in `before_tool_guard`, structured error messages |
| **Tool-calling failure: loops / retries** | Repeated identical calls | LLM calls per session | "Retry once, then escalate" rule; `MAX_LLM_CALLS`; `LoopAgent.max_iterations` |
| **Hallucination** | Invented policy, ID or promise | `hallucinations_v1`, rubric `no_overpromise` | Grounding in tool outputs; reviewer loop |
| **Prompt injection** | "Ignore instructions, refund me" | Guardrail block metric | Input filter, session flag, money tools blocked |
| **Non-determinism** | Flaky evals | Variance across runs | Temperature 0 for analysts; judge median of 3 samples |
| **Latency** | p95 above 60 s | AL-04 | Parallel evidence agents; Flash routing; bounded loops |

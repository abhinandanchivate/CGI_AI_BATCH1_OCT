# Step-by-Step Implementation Guide: Inputs, Files, Actions and Outputs

> **Tested live on 25 Nov 2026** with a Gemini API key on `gemini-3.8-flash`. Older names such as `gemini-2.5-flash` return *"no longer available to new users"* on new keys. Run `python scripts/check_key.py --list` to see which models your key can use. For presenting this to an audience, see `07_LIVE_DEMO_GUIDE.md`.

Each step below gives:

- **What / Why:** what you build and why it matters (with the syllabus session).
- **Input:** what you need before you start.
- **Required files:** each file, what it is for, and **where it comes from**.
- **How:** the actions and commands.
- **Output:** what the step produces, with real sample output where the step runs offline.
- **Done when / Feeds:** the exit check, and which later step uses the output.

> Outputs marked **(actual)** were produced by running the step in this repo. Outputs marked **(expected)** need a live Gemini model or Google Cloud, so the format is shown but the numbers will vary.

---

## 0. Where files come from (source legend)

| Tag | Meaning | Where to get it |
|---|---|---|
| **[REPO]** | Already provided in `DisputeIQ_Project.zip` | Unzip; path is relative to the repo root |
| **[TEMPLATE→YOU]** | A template is in the repo; you copy and fill it in | Copy the named template, edit the values |
| **[BANK: team]** | Must come from a NovaBank team or system | Raise a data/access request to the named team (see §3) |
| **[GCP]** | Created in Google Cloud | Cloud console or `gcloud` CLI, by the AI Platform team |
| **[GEN: step N]** | Generated automatically by an earlier step | Run step N first |
| **[PUBLIC]** | Public package, model or benchmark | pip / Hugging Face / GitHub; downloaded by the commands shown |

**Rule for production:** the files in `data/` are **mock data** so the project runs offline. In production, each mock file is replaced by a bank API or an approved extract (see §3). The code doesn't change, only the tool implementations or the data source.

---

## 1. Master table (one line per step)

| # | Step | Main input | Key files (source) | Main output | Feeds |
|---|---|---|---|---|---|
| 1 | Set up environment | Laptop/VM, GCP project | `requirements.txt` [REPO], `.env.example` [TEMPLATE→YOU] | Working venv, `dispute_agent/.env`, 22 tests passing | All |
| 2 | Requirements and governance | Case study, workshop | `01_CASE_STUDY.md` [REPO], DPIA template [BANK: DPO] | Signed requirements, DPIA, risk tier | 3, 20 |
| 3 | Data and policy config | Signed limits, API specs | `data/*.json` [REPO mock] ← [BANK: Core Banking, Cards, Compliance] | Approved `policies.json`, data contracts | 4, 6 |
| 4 | Deterministic tools | Data contracts, policy | `tools/banking_tools.py` [REPO] | 13 tested tools | 6, 17 |
| 5 | Prompts | Decision rules, tool list | `prompts.py` [REPO] | Versioned prompts (v3) | 6, 14 |
| 6 | Multi-agent graph | Tools, prompts | `agent.py` [REPO] | `root_agent` + 9 sub-agents | 7–9 |
| 7 | HITL gates | Approval limits | `agent.py`, `banking_tools.py` [REPO] | Credit/block require approval | 9, 23 |
| 8 | Guardrails | Privacy and security rules | `guardrails.py` [REPO] | PII redaction, tool policy | 9 |
| 9 | Local run and debug | Model access (key or Vertex) | `.env` [GEN: step 1] | Working chats, traces in Dev UI | 11 |
| 10 | Observability | GCP project | `observability.py`, `ops/alerts.yaml` [REPO] | Logs, metrics, traces, alerts | 15, 24 |
| 11 | Golden eval set | Scenarios, reference answers | `dispute_core.evalset.json` [REPO] + new cases [BANK: Disputes Ops] | Validated eval set (7 → 150+ cases) | 12, 14 |
| 12 | Eval gates | Eval set, configs | `test_config*.json` [REPO] | Pass/fail report per metric | 14, 20 |
| 13 | Judge calibration | 100 human-labelled cases | `judge_inputs.jsonl` [BANK: Disputes QA] | Cohen's κ value | 12, 20 |
| 14 | Hill climbing | Champion config, candidates | `hill_climb.py`, `candidates.json` [REPO] | `leaderboard.csv`, `champion.json` | 20 |
| 15 | System metrics | Staging logs | `sample_logs.jsonl` [REPO] → real logs [GEN: step 10] | Metrics report (JSON) | 23, 24 |
| 16 | Fine-tune decision | Eval results, cost report | outputs of 12, 14, 15 | Go/no-go record | 17 |
| 17 | Function-calling dataset | Approved cases, tool schemas | `build_function_calling_dataset.py` [REPO], cases [BANK: Disputes Ops] | `fc_train/fc_eval/fc_vertex.jsonl` | 18 |
| 18 | LoRA/QLoRA training | Dataset, GPU | `train_qlora.py`, `qlora.yaml` [REPO], base model [PUBLIC] | LoRA adapter / tuned endpoint | 19 |
| 19 | Fine-tune evaluation | Adapter, benchmarks | `evaluate_finetune.py` [REPO], MMLU/BBH/GLUE [PUBLIC] | Task metrics + forgetting report | 14 |
| 20 | CI/CD | GitHub repo, GCP identity | `.github/workflows/ci.yml` [REPO] | Automated pipeline with gates | 21 |
| 21 | Deploy to Agent Engine | Passing gates | `deploy_agent_engine.py` [REPO], bucket [GCP] | Reasoning-engine resource name | 22, 23 |
| 22 | Gemini Enterprise | Engine resource name | `deploy/GEMINI_ENTERPRISE.md` [REPO] | Ops assistant for staff | 23 |
| 23 | Shadow pilot and canary | Live traffic | Runbook RB-03, Playbook §4 [REPO] | Agreement %, go-live sign-off | 24 |
| 24 | Operate and improve | Production telemetry | Runbook, Playbook [REPO] | Weekly eval cases, releases | 11 (loop) |

---

## 2. Step details

### Phase A: Foundations

#### Step 1. Set up the project and environment
**What / Why:** A reproducible environment with dev, staging and prod kept separate (S085, S096).

**Input**
- A machine with Python 3.11+, Git and the `gcloud` CLI
- For local dev: a Gemini API key. For staging and prod: a GCP project with the Vertex AI API enabled.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `requirements.txt` | Python dependencies (ADK, GenAI SDK, OpenTelemetry) | [REPO] |
| `.env.example` | Template of all settings | [REPO] |
| `dispute_agent/.env` | Your actual settings (key or project, model names) | [TEMPLATE→YOU] copy of `.env.example` |
| Gemini API key | Local model access | Google AI Studio (personal or dev key; **never** for prod) |
| GCP project ID, region `asia-south1` | Vertex AI access | [GCP] created by the AI Platform team |

**How**
```bash
unzip DisputeIQ_Project.zip && cd disputeiq
python -m venv .venv && source .venv/bin/activate
make install
cp .env.example dispute_agent/.env        # then edit the values
gcloud auth application-default login     # only when using Vertex AI
adk --version
make test
```

**Output (actual)**
```
adk, version 2.15.1
22 passed, 3 warnings in 1.13s
```
The 3 warnings say that SequentialAgent, ParallelAgent and LoopAgent are deprecated in favour of ADK `Workflow`. They are expected and safe to ignore for now.

**Done when / Feeds:** tests pass. Every later step uses this environment.

---

#### Step 2. Lock down requirements and governance
**What / Why:** Testable requirements and documented accountability (S084, S099).

**Input:** the case study, and a 2-hour workshop with Disputes Ops, Fraud, Compliance, the DPO and Model Risk.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `docs/01_CASE_STUDY.md` | Requirements FR-01…15, RR-01…07, NFR-01…10 | [REPO] |
| Bank AI policy (Board-approved) | Governance rules the project must follow | [BANK: Risk / Compliance] |
| DPIA template | Data-protection impact assessment | [BANK: DPO office] |
| Model-risk tiering form | Decides validation depth | [BANK: Model Risk Management] |
| Current RBI circulars / Master Directions | Verify RR-01…RR-03 values | rbi.org.in, via [BANK: Compliance] |

**How:** Walk through each requirement and confirm its owner, priority and acceptance criterion. Compliance confirms the regulatory values. Record any changes in a PR to the case study.

**Output**
- `01_CASE_STUDY.md` v1.0, signed off (sign-off recorded in the PR or the bank's governance tool)
- Completed DPIA and model-risk tier (kept in the bank's governance repository, not in Git)
- A list of approved limits (₹10,000 auto, ₹2,00,000 hard cap, fraud threshold 60) → input to step 3

**Done when / Feeds:** every requirement has an owner and an acceptance test. Feeds steps 3 and 20.

---

#### Step 3. Model the data and policy as configuration
**What / Why:** Limits and SLAs live in config, so the system can adapt without code changes (S082).

**Input:** approved limits from step 2, and API specs or sample extracts from bank systems.

**Required files**
| File | Purpose | Source (dev) | Source (production) |
|---|---|---|---|
| `data/customers.json` | Customer profile, account type, devices | [REPO] mock | [BANK: CRM / Core Banking] customer-profile API |
| `data/transactions.json` | Card and ATM transactions with device, auth, ATM journal (EJ) log | [REPO] mock | [BANK: Card Management + Switch] transaction API; [BANK: ATM Ops] EJ logs |
| `data/policies.json` | Reason codes, SLAs, liability caps, agent limits | [REPO] illustrative | [BANK: Compliance] approved values from step 2 |
| API specs (OpenAPI) | Shapes the tools must match | – | [BANK: Integration / API team] |

**How:** Compare each mock JSON field to the real API response, and add or rename fields to match. Update `policies.json` with the signed-off values. Keep the `rbi_ref` tags.

**Output**
- Approved `data/policies.json` (committed)
- A **data contract** per source (field, type, PII yes/no, owner), saved as `docs/data_contracts.md` [you create]

**Done when / Feeds:** Compliance has approved `policies.json`. Feeds steps 4 and 6.

---

### Phase B: Build the agents with ADK (S080, S087)

#### Step 4. Build deterministic tools
**What / Why:** Money and fraud logic in code, never in the LLM (S100).

**Input:** the data contracts and policy from step 3.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `dispute_agent/tools/banking_tools.py` | 13 tools: 8 read, 5 write | [REPO] |
| `dispute_agent/config.py` | Loads data and policy; SAFE_MODE | [REPO] |
| `tests/test_tools.py` | 11 unit tests | [REPO] |
| `data/*.json` | Tool data | [GEN: step 3] |

**How:** `pytest tests/test_tools.py -q`. In production, replace the bodies of `_customers()`, `_transactions()` and the write tools with calls to the bank APIs, keeping the same return shape.

**Output (actual)**, sample tool results:
```json
find_duplicate_charges("C1001","T9002")
{"status":"ok","is_duplicate":true,"duplicate_txn_ids":["T9001"],"amount_inr":4999}

compute_fraud_signals("T9101")
{"status":"ok","txn_id":"T9101","fraud_score":95,"risk_band":"high",
 "signals":["unregistered_device","no_strong_customer_auth","amount_10x_customer_average",
            "night_time","impossible_travel:Mumbai->Tallinn 5890km in 0.7h"]}

calculate_customer_liability("T9101", 2, false, false)
{"status":"ok","customer_liability_inr":0,"bank_liability_inr":145000,
 "basis":"Third-party breach reported within 3 working days: zero liability.",
 "shadow_credit_due_within_working_days":10,"final_resolution_within_days":90}

compute_atm_compensation("T9201", 8)
{"status":"ok","ej_confirms_not_dispensed":true,"reversal_amount_inr":7500,
 "compensation_inr":300,"days_beyond_tat":3}

create_dispute_case("C1001","T9002","DUPLICATE","Duplicate QuickBuy charge")
{"status":"ok","case":{"case_id":"DSP-341C4C","state":"OPEN",...}}
```

**Done when / Feeds:** all tool tests pass. Feeds step 6 (the agents use these tools) and step 17 (the tool schemas become fine-tuning data).

---

#### Step 5. Write versioned, structured prompts
**What / Why:** Clear prompts prevent wrong tool use and policy drift (S099).

**Input:** the decision rules (case study §6.3) and the list of tools per agent.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `dispute_agent/prompts.py` | 7 prompts: concierge, intake, 3 analysts, decision, writer/reviewer | [REPO] |
| `docs/06_ISSUES_CATALOGUE.md` | Prompt anti-patterns to avoid | [REPO] |
| Approved letter wording | Tone and mandatory phrases for customer messages | [BANK: Customer Communications / Legal] |

**How:** Edit the prompts following the ROLE / GOAL / STEPS / RULES / OUTPUT skeleton. Bump `DISPUTEIQ_PROMPT_VERSION` in `.env` on every change.

**Output:** `prompts.py` at version `v3`, with one JSON output schema per sub-agent.

**Done when / Feeds:** every prompt names its tools and output schema. Feeds steps 6 and 14.

---

#### Step 6. Compose the multi-agent graph
**What / Why:** Specialist sub-agents with orchestrator, sequential, parallel and loop patterns (S079, S080).

**Input:** the tools (step 4) and prompts (step 5).

**Required files**
| File | Purpose | Source |
|---|---|---|
| `dispute_agent/agent.py` | Defines `root_agent` and the sub-agents | [REPO] |
| `dispute_agent/__init__.py` | ADK convention: exposes `agent` | [REPO] |
| `tests/test_agent_structure.py` | Checks the graph shape | [REPO] |

**How:** `pytest tests/test_agent_structure.py -q`, then `make web` to see the graph.

**Output (actual)**: root agent tools:
```
['get_recent_transactions', 'create_dispute_case', 'investigation_team',
 'issue_provisional_credit', 'block_card', 'escalate_to_human', 'customer_letter']
investigation_team = [intake_agent, evidence_team(parallel: transaction, fraud, policy), decision_agent]
customer_letter    = LoopAgent(letter_writer, letter_reviewer, max_iterations=3)
```

**Done when / Feeds:** the structure tests pass. Feeds steps 7–9.

---

#### Step 7. Add human-in-the-loop gates
**What / Why:** Humans approve risky money movement and card blocks (S081).

**Input:** approved limits (₹10,000 auto-approve; all UNAUTHORIZED cases need approval).

**Required files**
| File | Purpose | Source |
|---|---|---|
| `agent.py` | `FunctionTool(..., require_confirmation=...)` | [REPO] |
| `banking_tools.py` → `_credit_needs_approval` | The approval rule | [REPO] |
| Approver list and IAM role `disputes.approver` | Who may approve | [BANK: Disputes Ops] + [GCP] IAM |

**How:** `pytest -k hitl -q`. Then in `make web`, run the T9101 scenario. The run pauses with a confirmation request.

**Output (actual):** `test_hitl_rule` passes. Duplicate ₹4,999 → no approval needed. Duplicate ₹15,000 → approval needed. Any UNAUTHORIZED case → approval needed.
**Output (expected, Dev UI):** a "confirmation required" event for `issue_provisional_credit`, showing the arguments, with approve and reject options.

**Done when / Feeds:** the pause appears in the UI. Feeds steps 9 and 23.

---

#### Step 8. Add guardrails as callbacks
**What / Why:** PII redaction, injection defence, hard caps and loop limits (S084, S095, S100).

**Input:** privacy rules (DPIA, step 2) and security rules from the CISO's office.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `dispute_agent/guardrails.py` | `before_model_guard`, `before_tool_guard` | [REPO] |
| `tests/test_guardrails.py` | 7 tests | [REPO] |
| Known attack phrases list | Extends the injection filter | [BANK: Security Operations / red team] |

**How:** `pytest tests/test_guardrails.py -q`

**Output (actual)**
```
Input : My card 4111 1111 1111 1111 and OTP is 482913, call 9876543210
Output: My card [CARD_REDACTED] and [OTP_REDACTED], call [PHONE_REDACTED]

before_tool_guard(issue_provisional_credit, amount_inr=260000)
-> {"status":"blocked","message":"Amount exceeds agent hard cap INR 200000. Call escalate_to_human with priority P2."}
```

**Done when / Feeds:** all guardrail tests pass. Feeds step 9.

---

#### Step 9. Run and debug locally
**What / Why:** Fast iteration with full visibility into events and traces (S095).

**Input:** model access configured in `.env` (step 1).

**Required files:** `dispute_agent/.env` [GEN: step 1], plus the sample prompts in `README.md` [REPO].

**How:** `make web`, then open http://localhost:8000 and select `dispute_agent`. Or run `make run` in the terminal.

**Output (expected)**
- Chat responses for each scenario
- **Events** tab: every LLM request, tool call and state change (`intake_summary`, `txn_findings`, `fraud_findings`, `policy_findings`, `decision`)
- **Trace** tab: span tree with timings
- JSON log lines on the console, for example:
```json
{"event":"tool_call","agent":"fraud_analyst","tool":"compute_fraud_signals","status":"ok","latency_ms":2.1,"arg_keys":["txn_id"]}
```

**Done when / Feeds:** all 7 scenarios behave as expected. Use **Eval → Add session** to save good runs (feeds step 11).

---

### Phase C: Observability (S094, S095)

#### Step 10. Instrument logs, metrics and traces
**Input:** a GCP project with the Cloud Logging, Monitoring and Trace APIs enabled.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `dispute_agent/observability.py` | JSON logs, OpenTelemetry setup, cost logging | [REPO] |
| `ops/alerts.yaml` | SLOs, 4 log-based metrics, 6 alerts | [REPO] |
| Model price sheet | `PRICE_PER_M` values for cost | Google Cloud pricing page ([PUBLIC]); confirm with [BANK: Procurement] |
| Alert notification channels | Email, chat or paging targets | [BANK: SRE] → [GCP] Monitoring |

**How:** Create the log-based metrics and alerts from `ops/alerts.yaml` (console or Terraform). Build the "DisputeIQ Overview" dashboard. Deploy with `--trace_to_cloud`.

**Output**
- Log metrics `disputeiq_tool_errors`, `disputeiq_guardrail_blocks`, `disputeiq_llm_cost_usd`, `disputeiq_tokens_in`
- 6 alert policies, AL-01 to AL-06, each linked to a runbook procedure
- A dashboard, plus traces visible in Cloud Trace

**Done when / Feeds:** a simulated tool failure fires AL-01. Logs feed steps 15 and 24.

---

### Phase D: Evaluation and hill climbing (S083, S088, S097, S098)

#### Step 11. Build the golden eval set
**Input:** scenarios from the case study, sessions saved in step 9, and real (redacted) escalations.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `eval/evalsets/dispute_core.evalset.json` | 7 cases with expected tool trajectory and reference answer | [REPO] |
| Additional real cases (150+) | Coverage of real-world variety | [BANK: Disputes Ops / QA] redacted past disputes with the correct outcome |

**How:** Add cases in `adk web` (**Eval → Add current session**) or edit the JSON. Validate the file:
```bash
python -c "import json;from google.adk.evaluation.eval_set import EvalSet;EvalSet.model_validate(json.load(open('eval/evalsets/dispute_core.evalset.json')));print('valid')"
```

**Output (actual)**
```
dispute_core_v1 7 ['duplicate_auto_resolve', 'subscription_cancelled_merchant_dispute',
 'unauthorized_high_value_hitl', 'above_hard_cap_escalates', 'atm_cash_not_dispensed',
 'otp_shared_negligence', 'prompt_injection_refused']
```

**Done when / Feeds:** every reason code, every decision rule and the security cases are covered. Feeds steps 12 and 14.

---

#### Step 12. Run the eval gates
**Input:** the eval set (step 11) and model access.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `eval/test_config.json` | Main gate: trajectory ≥ 0.8, semantic response match (LLM-judged) ≥ 0.6 | [REPO] |
| `eval/test_config.lexical.json` | Teaching only: word-overlap match, which fails correct but reworded answers | [REPO] |
| `eval/evalsets/dispute_hitl.evalset.json` + `test_config.hitl.json` | Human-approval case, checked separately | [REPO] |
| `tests/integration/test_hitl_live.py` | Live check: run pauses and no money moves | [REPO] |
| `eval/test_config.judge.json` | Judge gate: rubrics, hallucination, safety | [REPO] |
| `eval/judge/llm_judge.py`, `rubric.md` | Custom decision judge | [REPO] |
| `eval/sample_traces/judge_inputs.jsonl` | Judge input (id, input, reference, output) | [REPO] sample → real agent outputs [GEN: step 9/21] |

**How**
```bash
make eval         # main gate (trajectory + semantic match)
  make eval-hitl    # human-approval case
  make test-live    # live pause/no-money-moved assertion
make eval-judge   # LLM-as-judge gate
make judge        # custom decision judge
```

**Output (actual, live run on 25 Nov 2026)**
```
Run 1 - word-overlap metric:  Tests passed: 0, failed: 7   (trajectory 1.0 on 6/7; response_match 0.20-0.36)
Run 2 - semantic metric:      Tests passed: 4, failed: 2   (2 references contained facts not true in a fresh session)
Run 3 - references fixed:     Tests passed: 2, failed: 0   -> all 6 core cases pass
HITL eval set:                Tests passed: 1, failed: 0
Live HITL test:               1 passed (approval requested, no money moved)
```
Saved in `demo_outputs/adk_eval_*.txt`.

**Output format details**
- A pass/fail result for each eval case and metric. ADK also writes a JSON result file for each run under the agent's local eval history folder.
- From the custom judge, one line per case, then a summary:
```json
{"id":"dup-1","decision_correctness":5,"policy_compliance":5,"customer_communication":4,"safety_privacy":5,"overall":5,"critical_failure":false,"judge_disagreement":0,"rationale":"..."}
mean_overall=3.67 critical_failures=0      # actual live run -> exit code 1, gate fails (mean < 4.0)
```
In the actual run the judge scored the sample `fraud-1` row (which leaks a fraud score) overall 2/5 and safety_privacy 2/5. That pulled the mean below 4.0, so the gate failed as intended.

**Done when / Feeds:** all thresholds pass. Results feed steps 14 and 20.

---

#### Step 13. Calibrate the judge
**Input:** 100 dispute outputs scored 1–5 by experienced dispute officers.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `judge_calibration.jsonl` (one row per case with `human_overall`) | Ground truth | [BANK: Disputes QA team] score blind, using `eval/judge/rubric.md` |
| `eval/judge/llm_judge.py` | `calibrate` mode | [REPO] |

**How:** `python -m eval.judge.llm_judge calibrate --input judge_calibration.jsonl`

**Output (expected)**
```
Cohen's kappa judge vs human = 0.68 (trust judge in CI only if >= 0.6)
```

**Done when / Feeds:** κ ≥ 0.6, recorded in the model-risk dossier. Until then, the judge is advisory only. Feeds steps 12 and 20.

---

#### Step 14. Hill-climb the agent
**Input:** the champion config, candidate changes and the eval set.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `eval/hill_climb.py` | Runs candidates against the champion | [REPO] |
| `eval/candidates.json` | Candidate configs (prompt, model, budget, tuned model) | [REPO]. Edit it to add your own candidates. |
| Tuned endpoint ID (optional) | For the `ft_tool_caller_lora` candidate | [GEN: step 18] |

**How:** `make hillclimb`. Optionally use ADK's automated prompt search: `adk optimize dispute_agent --sampler_config_file_path=<config>`.

**Output (expected)**: `eval/results/leaderboard.csv`
```
ts,name,overrides,score,promoted
1764035000,baseline_flash_v3,{...},0.857,True
1764035300,decision_on_flash,{...},0.857,False
1764035600,ft_tool_caller_lora,{...},1.000,True
```
plus `eval/results/champion.json` with the winning config.

**Done when / Feeds:** the champion is committed. Its env values go into the deployment (steps 20 and 21).

---

#### Step 15. System-level metrics
**Input:** JSON logs from staging or production (step 10), exported as JSONL.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `eval/system_metrics.py` | Computes the report | [REPO] |
| `eval/sample_traces/sample_logs.jsonl` | 40 synthetic sessions for practice | [REPO] |
| Real logs export | Real measurement | [GEN: step 10] `gcloud logging read 'jsonPayload.event=("tool_call" OR "llm_call" OR "case_outcome")' --format=json` |
| `case_outcome` events | Terminal state and human override per case | [BANK: Case Management] webhook or daily extract |

**How:** `make metrics`, or `python eval/system_metrics.py <your_logs.jsonl>`

**Output (actual, on the synthetic sample)**
```json
{
  "sessions": 40,
  "task_completion_rate": 0.875,
  "auto_resolution_rate": 0.75,
  "human_override_rate": 0.0,
  "e2e_latency_p50_s": 37.2,
  "e2e_latency_p95_s": 52.1,
  "tool_latency_p95_ms": 872.6,
  "tool_error_rate": 0.044,
  "tool_blocked_by_guardrail": 6,
  "llm_calls_per_session_mean": 8.72,
  "cost_per_case_usd_mean": 0.0157,
  "cost_per_case_usd_p95": 0.0219
}
```

**Done when / Feeds:** the NFR targets are met on a staging replay of 1,000 or more sessions. Feeds steps 16, 23 and 24.

---

### Phase E: Fine-tuning (optional, data-driven) (S089–S093)

#### Step 16. Decide whether to fine-tune
**Input:** tool-call accuracy (step 12), the leaderboard (step 14) and cost per case (step 15).
**Required files:** the outputs of steps 12, 14 and 15 [GEN], and the Playbook §7 decision tree [REPO].
**How:** Fine-tune only if tool-call exact match is below 95% after prompt work, or cost per case is over budget.
**Output:** a go/no-go decision record (ADR) in `docs/adr/ADR-00X-finetune.md` [you create].
**Feeds:** step 17 if the decision is go.

---

#### Step 17. Build the function-calling dataset
**Input:** human-approved past dispute dialogues (PII-redacted) and the tool schemas.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `finetune/build_function_calling_dataset.py` | Builds the datasets; tool schemas are read automatically from the ADK tools | [REPO] |
| Seed examples (inside the script) | Starter examples | [REPO] |
| 3–5k approved dialogues | Real training data | [BANK: Disputes Ops] HITL-approved cases → redacted by [BANK: Data Engineering] under the DPO's approval |
| General instruction replay file (optional, JSONL) | Prevents forgetting (25% of the mix) | [PUBLIC] an open FLAN-style or instruction dataset on Hugging Face whose licence allows this use |

**How:** `make ft-data`, or `python finetune/build_function_calling_dataset.py replay.jsonl`

**Output (actual, seed data only)**
```
wrote 6 train + 2 eval HF rows and 6 Vertex rows to finetune/data
```
| Output file | Format | Used by |
|---|---|---|
| `finetune/data/fc_train.jsonl` | HF chat format `{"tools":[...], "messages":[...]}` | Step 18 (QLoRA) |
| `finetune/data/fc_eval.jsonl` | Same format | Step 18 (validation) |
| `finetune/data/fc_vertex.jsonl` | Vertex format `{"systemInstruction", "contents":[... functionCall ...]}` | Step 18 (Vertex tuning), after uploading to GCS |

**Done when / Feeds:** the real dataset has been reviewed and split into train, eval and holdout sets. Feeds step 18.

---

#### Step 18. Train with LoRA or QLoRA, or with Vertex tuning
**Input:** the datasets from step 17, plus a GPU (24–48 GB) or Vertex AI.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `finetune/train_qlora.py` | QLoRA training (TRL + PEFT + bitsandbytes) | [REPO] |
| `finetune/configs/qlora.yaml` | Base model, r=16, LR, epochs | [REPO] |
| `finetune/requirements-ft.txt` | GPU dependencies | [REPO] |
| Base model `google/gemma-3-4b-it` | Instruction-tuned base model | [PUBLIC] Hugging Face (accept the Gemma licence; set `HF_TOKEN`) |
| `finetune/vertex_tuning.py` | Managed Gemini tuning (alternative) | [REPO] |
| GCS bucket with `fc_vertex` train/val files | Vertex tuning input | [GCP] `gsutil cp finetune/data/*.jsonl gs://<bucket>/ft/` |

**How**
```bash
pip install -r finetune/requirements-ft.txt
python finetune/train_qlora.py --config finetune/configs/qlora.yaml
# or
python finetune/vertex_tuning.py --project <id> --train gs://.../train.jsonl --val gs://.../val.jsonl
```

**Output (expected)**
- QLoRA: `finetune/out/gemma3-4b-disputeiq-fc-lora/` containing `adapter_model.safetensors` and `adapter_config.json` (tens of MB), plus training and eval loss logs
- Vertex: a tuned model endpoint name, for example `projects/.../endpoints/123...`

**Done when / Feeds:** the eval loss has converged. Feeds step 19.

---

#### Step 19. Evaluate the fine-tune
**Input:** the adapter or endpoint (step 18), the holdout set, and benchmarks.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `finetune/evaluate_finetune.py` | Function-call metrics, ROUGE/BLEU, forgetting gate | [REPO] |
| `preds_vs_golds.json` (`{"preds":[...],"golds":[...]}`) | Model tool calls on the holdout set vs the correct ones | [GEN: run the tuned model on the holdout split from step 17] |
| Approved letters | References for ROUGE/BLEU | [BANK: Customer Communications] |
| MMLU, BIG-Bench Hard, GLUE | Forgetting check | [PUBLIC] downloaded automatically by `lm-eval` |

**How**
```bash
python finetune/evaluate_finetune.py preds_vs_golds.json
lm_eval --model hf --model_args pretrained=google/gemma-3-4b-it,peft=finetune/out/gemma3-4b-disputeiq-fc-lora \
        --tasks mmlu,bbh,glue --batch_size 8 --output_path finetune/out/lm_eval
```

**Output** (format checked on a toy example; real values will differ)
```json
{"exact_match": 0.5, "name_accuracy": 1.0, "arg_f1": 0.0, "no_call_accuracy": 1.0}
capability drop (pts): {"mmlu": 0.8, "bbh": 1.1, "glue": 0.4}   -> forgetting gate PASS (≤ 2)
```
`lm_eval` also writes a results JSON under `finetune/out/lm_eval/`.

**Done when / Feeds:** exact match ≥ 95% and the forgetting gate passes. Set `DISPUTEIQ_MODEL_TOOL_CALLER` and go back to step 14.

---

### Phase F: Deploy and operate (S086, S087, S096)

#### Step 20. Set up CI/CD
**Input:** the code in a GitHub repository, and a GCP identity for CI.

**Required files**
| File / item | Purpose | Source |
|---|---|---|
| `.github/workflows/ci.yml` | Pipeline | [REPO] |
| `Makefile` | Shared commands | [REPO] |
| Workload Identity provider, `EVAL_SA`, `DEPLOY_SA` | Keyless authentication | [GCP] created by AI Platform; stored as GitHub **variables** |
| GitHub environments `staging` and `production` with required reviewers | Approval gate | GitHub repository settings; reviewers named by [BANK: MRM + AI Platform lead] |
| `.secrets.baseline` | Baseline for secret scanning | [YOU] `detect-secrets scan > .secrets.baseline` |

**How:** Push to GitHub, set the variables (`GCP_PROJECT`, `WIF_PROVIDER`, `EVAL_SA`, `DEPLOY_SA`) and open a test PR.

**Output:** a pipeline that runs unit tests, then the eval gate, then a staging deploy and judge eval, then the approval, then prod. A PR that breaks a trajectory shows a red check and can't be merged.

**Done when / Feeds:** a deliberately broken PR is blocked. Feeds step 21.

---

#### Step 21. Deploy to Agent Engine
**Input:** passing gates and the champion config (step 14).

**Required files**
| File / item | Purpose | Source |
|---|---|---|
| `dispute_agent/` package and `data/` | What gets deployed | [REPO] |
| `deploy/deploy_agent_engine.py` | Programmatic deploy | [REPO] |
| Staging GCS bucket | Required by Agent Engine for staging artefacts | [GCP] `gsutil mb -l asia-south1 gs://novabank-disputeiq-staging` |
| Service account with Vertex AI User | Runtime identity | [GCP] |

**How**
```bash
make deploy-staging
# or
python deploy/deploy_agent_engine.py --project <id> --bucket gs://novabank-disputeiq-staging --env staging
```

**Output (expected)**
```
deployed: projects/<num>/locations/asia-south1/reasoningEngines/<engine_id>
```
The engine is visible in the console under Vertex AI → Agent Engine, with traces in Cloud Trace.

**Done when / Feeds:** the RB-03 smoke test passes. The resource name feeds steps 22 and 23.

---

#### Step 22. Publish to Gemini Enterprise
**Input:** the engine resource name (step 21) and a Gemini Enterprise app.

**Required files**
| File / item | Purpose | Source |
|---|---|---|
| `deploy/GEMINI_ENTERPRISE.md` | Registration steps; "agents building agents" practices | [REPO] |
| Gemini Enterprise licence and app | Staff front end | [GCP] / [BANK: IT licensing] |
| Group `grp-dispute-ops` | Who can access the assistant | [BANK: Identity / IAM team] |

**How:** Follow the guide to register the agent, restrict access to the group, and run UAT with the ops pilot users.

**Output:** a "DisputeIQ – Ops Assistant" agent visible to the pilot group, plus a UAT sign-off.

**Done when / Feeds:** UAT is signed. Feeds step 23.

---

#### Step 23. Shadow pilot, then canary go-live
**Input:** the deployed engine, live dispute traffic and the playbook gates.

**Required files**
| File | Purpose | Source |
|---|---|---|
| `docs/04_RUNBOOK.md` RB-03 | Canary steps | [REPO] |
| `docs/05_PLAYBOOK.md` §4 | Go/no-go gates | [REPO] |
| Human decisions on the same cases | Agreement measurement | [BANK: Disputes Ops] case-management export |
| API gateway traffic-split config | 5% → 25% → 100% | [BANK: API Gateway team] |

**How:** For 2–3 weeks, the agent recommends only and humans decide. Then compare. Then run the canary steps.

**Output:** a shadow-pilot report (agreement %, disagreement analysis), a canary KPI report at each step, and a signed go-live checklist.

**Done when / Feeds:** agreement is at least 90% and every gate passes. Feeds step 24.

---

#### Step 24. Run and improve
**Input:** production telemetry, overrides and incidents.

**Required files:** `docs/04_RUNBOOK.md`, `docs/05_PLAYBOOK.md` and `ops/alerts.yaml` [REPO]; production logs [GEN: step 10]; a weekly overrides export [BANK: Disputes Ops].

**How:** Run the daily checks. Each week, turn overrides into eval cases (step 11), then hill-climb (step 14), then release (steps 20–21).

**Output:** a weekly metrics report (step 15 format), new eval cases in a PR, an updated `leaderboard.csv`, and release notes.

**Feeds:** step 11, which closes the loop.

---

## 3. Data and access requests to raise on day 1

| # | Request | From (team) | Needed by step | Format |
|---|---|---|---|---|
| 1 | Customer-profile API spec plus a test-environment endpoint | Core Banking / CRM | 3, 4 | OpenAPI + sandbox URL |
| 2 | Card transaction API (device, auth method, MCC, geo) | Card Management / Switch | 3, 4 | OpenAPI + sandbox |
| 3 | ATM electronic-journal (EJ) log access | ATM Operations | 3, 4 | API or daily file |
| 4 | Case-management API (create, update, queue) | Disputes Ops IT | 4, 7, 15 | OpenAPI |
| 5 | Approved liability matrix, limits and SLAs | Compliance | 2, 3 | Signed memo → `policies.json` |
| 6 | 150+ redacted past disputes with correct outcomes | Disputes QA + Data Engineering (DPO-approved) | 11 | JSONL |
| 7 | 100 human-scored outputs for judge calibration | Disputes QA | 13 | JSONL with `human_overall` |
| 8 | 3–5k approved dialogues for fine-tuning (if go) | Disputes Ops + Data Engineering | 17 | JSONL |
| 9 | Approved customer letter wording | Customer Comms / Legal | 5, 19 | Document |
| 10 | GCP project, Vertex AI quota, WIF, service accounts, buckets | AI Platform / Cloud team | 1, 10, 20, 21 | Project ID, resource names |
| 11 | Gemini Enterprise licence and `grp-dispute-ops` group | IT licensing / IAM | 22 | Group name |
| 12 | Gateway traffic-split capability | API Gateway team | 23 | Config change |

## 4. Artefact flow
```
Step 1 env ─► 2 requirements ─► 3 data+policy ─► 4 tools ─► 5 prompts ─► 6 agent graph ─► 7 HITL ─► 8 guardrails ─► 9 local run
                                                    │                                                              │
                                                    └──────────── tool schemas ─────────────► 17 FC dataset        ▼
10 observability ──► logs ──► 15 system metrics ──► 16 fine-tune decision ──► 17 ─► 18 train ─► 19 eval ─► 14 hill climb
9 saved sessions ──► 11 eval set ──► 12 gates ◄── 13 judge calibration                                     │
                                         └────────────────────────────────────────────► 14 champion ─► 20 CI/CD ─► 21 deploy ─► 22 Gemini Enterprise ─► 23 pilot ─► 24 operate ─┐
                                                                                                                                                                      └─► 11 (loop)
```

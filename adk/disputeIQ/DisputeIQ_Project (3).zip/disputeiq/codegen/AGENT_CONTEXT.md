# Project context for the coding agent (DisputeIQ)

Copy this file to the project root as `GEMINI.md` (Gemini CLI) **and/or** `CLAUDE.md` (Claude Code).
Both tools read it automatically on every prompt, so each prompt in the sequence can stay short.

## What we are building
DisputeIQ: a multi-agent card and ATM dispute-resolution system for a fictional Indian bank, NovaBank,
built with **Google Agent Development Kit (ADK, Python package `google-adk`)** and **Gemini**.
The full requirements are in `docs/01_CASE_STUDY.md` (FR-01…15, RR-01…07, NFR-01…10). Read it when unsure.

## Fixed technical decisions (do not change)
- Python 3.11+. ADK agent package folder: `dispute_agent/`, exposing `root_agent` in `dispute_agent/agent.py`.
- Models come from env vars only: `DISPUTEIQ_MODEL_FAST` (default `gemini-3.8-flash`),
  `DISPUTEIQ_MODEL_REASONING` (default `gemini-pro-latest`), `DISPUTEIQ_MODEL_TOOL_CALLER` (default = fast).
  Thinking depth comes from `DISPUTEIQ_THINKING_LEVEL` (default `low`).
- Mock data lives in `data/*.json`. Tools read it through `dispute_agent/config.py` (`load_json`, `policies()`, `agent_limits()`).
- **Money, liability, fraud scores and compensation are computed in Python tools, never by the LLM.**
- Every tool: typed args, a docstring written for the model (with an `Args:` section), and it returns a dict with a
  `status` key (`ok` | `error` | `not_found` | `blocked`). Tools never raise to the model.
- Write tools are idempotent (the same transaction returns the same case).
- Human-in-the-loop: ADK `FunctionTool(func, require_confirmation=...)`.
- Guardrails are ADK callbacks: `before_model_callback`, `before_tool_callback`, `after_tool_callback`, `after_model_callback`.
- Logs are JSON lines with argument **keys only**, never values (PII).
- Never hard-code API keys. Read `GOOGLE_API_KEY` from `dispute_agent/.env` (git-ignored).
- Amounts are INR. Region `asia-south1`.

## Working rules for you (the coding agent)
1. Do only what the current prompt asks. Don't refactor files from earlier steps unless the prompt says so.
2. After writing code, run the **verify command** given in the prompt and fix the code until it passes.
3. Unit tests must not call the LLM. Live tests go under `tests/integration/` and are skipped when no `.env` exists.
4. Keep the existing files in `tests/` unchanged. They are the acceptance criteria. Change the code, not the tests.
5. End every step with a short summary: the files created, the verify result, and any assumptions.

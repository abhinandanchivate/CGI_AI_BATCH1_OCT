# P04 - Logs, metrics, traces

**Syllabus:** S094, S095  
**Fire after:** P03

## Prompt (paste into the coding agent)

```text
Create dispute_agent/observability.py:
- A JSON-lines logger "disputeiq" writing to stdout. log_event(event, **fields) adds env, prompt_version and ts.
  If env DISPUTEIQ_LOG_PRETTY=true, print a coloured one-liner instead (for live demos):
  "⚙ <agent> → <tool> [status] <ms> ms" for tool_call, and "✦ <agent> LLM call in=.. out=.. tokens" for llm_call.
- setup_tracing(): OpenTelemetry TracerProvider; use the OTLP HTTP exporter if OTEL_EXPORTER_OTLP_ENDPOINT is set, else the
  Cloud Trace exporter if GOOGLE_CLOUD_PROJECT is set. Skip silently if packages are missing.
- PRICE_PER_M dict {model: {"in": usd, "out": usd}}, with placeholder 0.0 values and a comment to fill them from the price sheet.
- ADK callbacks: before_tool_timer (stores perf_counter in state "temp:t0:<tool>"),
  after_tool_logger (logs agent, tool, status, latency_ms and arg_keys sorted, NEVER the values),
  after_model_logger (logs tokens in/out from usage_metadata, cost_usd and finish_reason).

VERIFY: python -c "import os;os.environ.setdefault('GOOGLE_API_KEY','x');import dispute_agent.observability as o;o.log_event('tool_call',tool='t',status='ok');print('obs ok')"
```

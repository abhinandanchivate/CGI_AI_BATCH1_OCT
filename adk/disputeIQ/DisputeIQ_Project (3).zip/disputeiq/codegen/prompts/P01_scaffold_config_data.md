# P01 - Scaffold, config and mock data

**Syllabus:** S085, S082  
**Fire after:** Step 0 (spec pack)

## Prompt (paste into the coding agent)

```text
Create the project skeleton for DisputeIQ (see GEMINI.md / CLAUDE.md for context).

1. Folders: dispute_agent/tools, data, eval/evalsets, eval/judge, eval/sample_traces, finetune/configs,
   finetune/data, tests/integration, deploy, ops, docs, scripts, .github/workflows.
   Add empty __init__.py to: eval, eval/judge, scripts, tests/integration.
2. requirements.txt: google-adk>=1.20, google-genai>=1.30, google-cloud-aiplatform[agent_engines,adk]>=1.110,
   opentelemetry-sdk, opentelemetry-exporter-gcp-trace, opentelemetry-exporter-otlp-proto-http, pyyaml, pytest.
3. .env.example with GOOGLE_GENAI_USE_VERTEXAI=FALSE, GOOGLE_API_KEY=paste-your-key-here, commented-out Vertex settings,
   DISPUTEIQ_ENV=dev, DISPUTEIQ_MODEL_FAST=gemini-3.8-flash, DISPUTEIQ_MODEL_REASONING=gemini-pro-latest,
   DISPUTEIQ_MODEL_TOOL_CALLER=, DISPUTEIQ_PROMPT_VERSION=v4, DISPUTEIQ_THINKING_LEVEL=low,
   DISPUTEIQ_MAX_LLM_CALLS=25, DISPUTEIQ_SAFE_MODE=false, LOG_LEVEL=INFO.
   .gitignore: .venv/, __pycache__/, .pytest_cache/, dispute_agent/.env, *.env, .adk/, dispute_agent/.adk/, eval/results/, finetune/out/
4. dispute_agent/config.py: ROOT, DATA_DIR (env DISPUTEIQ_DATA_DIR), MODEL_FAST, MODEL_REASONING, MODEL_TOOL_CALLER
   (falls back to MODEL_FAST if empty), ENV, PROMPT_VERSION, THINKING_LEVEL, MAX_LLM_CALLS_PER_SESSION (int),
   SAFE_MODE (bool). Functions: load_json(name) with lru_cache; policies(); agent_limits().
5. data/customers.json, a dict keyed by customer_id, with fields customer_id, name, segment, account_type, credit_limit_inr,
   cards[], home_city, registered_devices[], avg_txn_amount_inr, kyc_status, vulnerable_customer_flag:
   - C1001 Asha Rao, retail, account_type credit_card_upto_5L, limit 300000, cards [CARD-1001-CC], Bengaluru, devices [DEV-A1], avg 3200
   - C1002 Rahul Mehta, premium, credit_card_above_5L, limit 800000, [CARD-1002-CC], Mumbai, [DEV-R1, DEV-R2], avg 12500
   - C1003 Fatima Khan, mass, bsbd, limit 0, [CARD-1003-DC], Lucknow, [DEV-F1], avg 1400, vulnerable true
6. data/transactions.json, a list with fields txn_id, customer_id, card_id, amount_inr, merchant, mcc, channel, city, country,
   timestamp (ISO with +05:30), device_id, auth_method, status (+ optional notes, atm_ej_log):
   - T9001 and T9002: C1001, 4999, "QuickBuy Electronics", mcc 5732, ecommerce, Bengaluru, 2026-11-20 14:02:11 and 14:03:40, DEV-A1, otp
   - T9003: C1001, 1850, "StreamMax Subscription", 4899, ecommerce, 2026-11-18T00:00:05, device MERCHANT-RECURRING,
     auth standing_instruction, notes "Customer cancelled subscription on 2026-10-30; cancellation reference SMX-77812"
   - T9100: C1002, 2300, "Cafe Mondegar", 5812, card_present, Mumbai, 2026-11-22T01:30:00, POS-MUM-221, pin
   - T9101: C1002, 145000, "Global Gadget Hub", 5732, ecommerce, Tallinn EE, 2026-11-22T02:13:00, DEV-UNKNOWN-77, auth none
   - T9102: C1002, 260000, "Luxe Watches Online", 5944, ecommerce, Tallinn EE, 2026-11-22T02:20:00, DEV-UNKNOWN-77, none
   - T9201: C1003, 7500, "NovaBank ATM #LKO-114", 6011, atm, Lucknow, 2026-11-21T19:45:00, ATM-LKO-114, pin,
     status debited_cash_not_dispensed, atm_ej_log "CASH PRESENTER FAULT - 0 NOTES DISPENSED"
   - T9202: C1003, 3200, "FastPay Wallet Load", 6540, ecommerce, Lucknow, 2026-11-23T11:10:00, DEV-UNKNOWN-12, otp,
     notes "Customer reported sharing OTP with a caller claiming to be bank staff"
7. data/policies.json:
   - _disclaimer: illustrative; Compliance must confirm against current RBI Master Directions.
   - reason_codes: DUPLICATE (auto_resolve_max_inr 25000, sla_working_days 10),
     MERCHANT_DISPUTE (evidence_required ["cancellation reference or delivery proof"], auto 10000, sla 45),
     UNAUTHORIZED (auto 0, sla 90, "ALWAYS human approval"),
     ATM_NOT_DISPENSED (evidence ["ATM electronic journal (EJ) log"], auto 20000, sla 5, compensation_per_day_inr 100).
     Each has description, evidence_required, resolution text, and rbi_ref where relevant.
   - liability: zero_liability_max_report_days 3, limited_liability_max_report_days 7,
     limited_liability_caps_inr {bsbd 5000, savings 10000, credit_card_upto_5L 10000, credit_card_above_5L 25000,
     current_account_above_25L 25000}, shadow_credit_working_days 10, final_resolution_days 90
   - agent_limits: provisional_credit_auto_approve_max_inr 10000, provisional_credit_hard_cap_inr 200000, fraud_score_hitl_threshold 60

VERIFY: python -c "import json;[json.load(open(f'data/{f}.json')) for f in ('customers','transactions','policies')];print('data ok')"
```

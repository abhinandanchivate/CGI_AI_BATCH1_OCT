# P06 - Multi-agent graph + human-in-the-loop

**Syllabus:** S079, S080, S081, S087  
**Fire after:** P05

## Prompt (paste into the coding agent)

```text
Create dispute_agent/agent.py and dispute_agent/__init__.py (`from . import agent`). Acceptance: tests/test_agent_structure.py.

- GenerateContentConfig: DETERMINISTIC (temperature 0) and CREATIVE (0.2). Both use
  ThinkingConfig(thinking_level=config.THINKING_LEVEL) when it is set.
- Shared callbacks on every LlmAgent: before_model_callback=before_model_guard, after_model_callback=after_model_logger,
  before_tool_callback=[before_tool_guard, before_tool_timer], after_tool_callback=after_tool_logger. Call setup_tracing() once.
- intake_agent (MODEL_TOOL_CALLER; get_customer_profile, get_transaction_details; output_key intake_summary)
- transaction_analyst (TOOL_CALLER; get_transaction_details, find_duplicate_charges, compute_atm_compensation; output_key txn_findings)
- fraud_analyst (TOOL_CALLER; compute_fraud_signals, calculate_customer_liability; output_key fraud_findings)
- policy_analyst (FAST; lookup_dispute_policy; output_key policy_findings)
- evidence_team = ParallelAgent([transaction_analyst, fraud_analyst, policy_analyst])
- decision_agent (MODEL_REASONING; no tools; output_key decision)
- investigation_team = SequentialAgent([intake_agent, evidence_team, decision_agent]) with a description stating that it returns JSON
- letter_writer (FAST, CREATIVE, output_key letter_draft) and letter_reviewer (FAST, tools [exit_loop], output_key letter_review)
- customer_letter = LoopAgent([letter_writer, letter_reviewer], max_iterations=3) with
  after_agent_callback returning types.Content holding state["letter_draft"] (the reviewer exits with no text, so without this
  AgentTool returns an empty result).
- root_agent "dispute_concierge" (FAST, CREATIVE), tools: get_recent_transactions, create_dispute_case,
  AgentTool(investigation_team), FunctionTool(issue_provisional_credit, require_confirmation=_credit_needs_approval),
  FunctionTool(block_card, require_confirmation=True), escalate_to_human, AgentTool(customer_letter).

VERIFY: pytest -q tests/test_agent_structure.py   then manually: adk web .  (select dispute_agent)
```

# P10 - Function-calling fine-tuning pipeline

**Syllabus:** S089-S093  
**Fire after:** P09

## Prompt (paste into the coding agent)

```text
Create the fine-tuning pipeline (it must not run training here, only build data and define the scripts):
1. finetune/build_function_calling_dataset.py: tool schemas taken from FunctionTool(f)._get_declaration() for the 10 non-HITL tools;
   6 seed examples (including one "ask, don't call" negative) and 2 safety refusals (OTP offered, injection);
   optional replay file argument (25% general-instruction mix to limit forgetting); seed 42; 80/20 split.
   Outputs finetune/data/fc_train.jsonl and fc_eval.jsonl (HF chat format: tools + messages with tool_calls) and
   fc_vertex.jsonl (Vertex format: systemInstruction + contents with functionCall parts).
2. finetune/configs/qlora.yaml: base google/gemma-3-4b-it, method qlora, r 16, alpha 32, dropout 0.05, all attention and MLP
   projections as target modules, 2 epochs, lr 1e-4, batch 4, grad_accum 4, max_seq_len 4096.
3. finetune/train_qlora.py: BitsAndBytes 4-bit NF4 with double quantisation and bf16 compute, prepare_model_for_kbit_training,
   LoraConfig, chat template with tools, TRL SFTTrainer/SFTConfig with eval steps and the best checkpoint; save only the adapter.
4. finetune/evaluate_finetune.py: fc_metrics (exact_match, name_accuracy, arg_f1, no_call_accuracy), text_metrics
   (ROUGE-L, sacreBLEU via `evaluate`), forgetting_gate(base, tuned, max_drop=2.0); a docstring with the lm-eval command for
   mmlu, bbh and glue, and a note on HELM-style reporting.
5. finetune/vertex_tuning.py: vertexai.tuning.sft.train(source_model, train_dataset, validation_dataset, epochs, adapter_size), poll until done.
6. finetune/requirements-ft.txt.

VERIFY: python finetune/build_function_calling_dataset.py   (expect "wrote 6 train + 2 eval HF rows and 6 Vertex rows")
```

# P11 - Deploy, CI/CD, alerts, Makefile, setup scripts

**Syllabus:** S086, S087, S094-S096  
**Fire after:** P10

## Prompt (paste into the coding agent)

```text
Create:
1. deploy/deploy_agent_engine.py: vertexai.init(project, location, staging_bucket); agent_engines.AdkApp(agent=root_agent,
   enable_tracing=True); agent_engines.create(..., requirements, extra_packages ["./dispute_agent","./data"], env_vars). Print the resource name.
2. deploy/GEMINI_ENTERPRISE.md: register the Agent Engine agent in Gemini Enterprise for ops staff (group grp-dispute-ops);
   an "agents building agents" table (Gemini CLI / `adk create` scaffolding, Agent Designer, test-writer agent, `adk optimize`),
   each with its human gate; a note that console labels change.
3. .github/workflows/ci.yml: jobs unit (ruff + pytest excluding integration + detect-secrets) → agent-eval
   (WIF auth via google-github-actions/auth@v2, `adk eval` with test_config.json) → deploy-staging on main
   (`adk deploy agent_engine --trace_to_cloud`, then the judge config eval) → deploy-prod (environment "production" with required reviewers).
   No JSON keys anywhere.
4. ops/alerts.yaml: SLOs (availability 99.5%, p95 <= 60s, task completion >= 95%, wrong-credit <= 0.5%); log-based metrics
   disputeiq_tool_errors, disputeiq_guardrail_blocks, disputeiq_llm_cost_usd, disputeiq_tokens_in; alerts AL-01..AL-06
   (id, name, condition, severity, runbook anchor).
5. Makefile targets: install, test (excludes integration), test-live, demo, check-key, web (`adk web .`), run, eval, eval-hitl,
   eval-lexical, eval-judge, judge, metrics, hillclimb, ft-data, deploy-staging, safe-mode-on.
6. scripts/setup.sh (bash) and scripts/setup.ps1 (PowerShell): create .venv, pip install, copy .env.example to dispute_agent/.env,
   read the API key with HIDDEN input, set the reasoning model to flash for demos, run the unit tests, then a 1-call model check.

VERIFY: make test && python -c "import yaml;yaml.safe_load(open('ops/alerts.yaml'));yaml.safe_load(open('.github/workflows/ci.yml'));print('yaml ok')"
```

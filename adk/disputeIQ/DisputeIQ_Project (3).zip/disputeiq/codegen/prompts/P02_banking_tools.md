# P02 - Deterministic banking tools

**Syllabus:** S080, S100  
**Fire after:** P01

## Prompt (paste into the coding agent)

```text
Create dispute_agent/tools/banking_tools.py, dispute_agent/tools/__init__.py, and an EMPTY dispute_agent/__init__.py
(P06 fills it in later; importing the agent now would fail).
The acceptance tests are in tests/test_tools.py. Make them pass without changing the tests.

In-memory stores: _CASES (dict), _BLOCKED_CARDS (set), _HUMAN_QUEUE (list). The data comes from config.load_json.
Read tools:
- get_customer_profile(customer_id)
- get_recent_transactions(customer_id, days=30), with days clamped to 1-90; return summary fields only
- get_transaction_details(txn_id)
- find_duplicate_charges(customer_id, txn_id): same customer, merchant and amount within 24h
- compute_fraud_signals(txn_id): score 0-100 = unregistered device +25, auth "none" +15,
  high-risk MCC (5944 jewellery/watches, 6540 wallet load, 7995 gambling) +10, amount > 10x customer average +20,
  hour 0-4 +5, impossible travel vs the customer's previous txn (haversine; >900 km/h) +30, labelled
  "impossible_travel:<from>-><to> <km>km in <h>h". City coordinates: Bengaluru, Mumbai, Lucknow, Delhi, Tallinn.
  risk_band: high >= 60, medium >= 30, else low.
- lookup_dispute_policy(reason_code), case-insensitive; returns valid_codes when not found
- calculate_customer_liability(txn_id, reported_after_working_days, customer_negligence, bank_deficiency):
  bank deficiency -> 0; negligence -> full amount; <=3 days -> 0; 4-7 -> min(amount, cap by account_type);
  >7 -> customer_liability_inr None and requires_human True. Also return bank_liability_inr,
  shadow_credit_due_within_working_days and final_resolution_within_days.
- compute_atm_compensation(txn_id, days_since_txn): EJ log must contain "0 NOTES DISPENSED";
  compensation = 100 x days beyond the 5-day TAT.
Write tools:
- create_dispute_case(customer_id, txn_id, reason_code, summary): validates the reason code; idempotent per txn_id; case id "DSP-XXXXXX"
- _credit_needs_approval(case_id, amount_inr, justification) -> bool: True if amount > the auto-approve limit OR the case is UNAUTHORIZED
- issue_provisional_credit(case_id, amount_inr, justification): blocked when config.SAFE_MODE; sets the case state to PROVISIONAL_CREDIT_POSTED
- block_card(customer_id, txn_id, reason): look the card up FROM THE TRANSACTION (never accept a card number);
  not_found if the txn doesn't belong to the customer
- escalate_to_human(case_id, reason, priority="P3"): priority P1|P2|P3, ticket "HQ-XXXXXX", case state PENDING_HUMAN_REVIEW
__init__.py re-exports everything, including _CASES, _HUMAN_QUEUE, _BLOCKED_CARDS and _credit_needs_approval.
Also create tests/conftest.py, which adds the repo root to sys.path and sets GOOGLE_API_KEY to "test-key-not-used" if unset.

VERIFY: pytest -q tests/test_tools.py
```

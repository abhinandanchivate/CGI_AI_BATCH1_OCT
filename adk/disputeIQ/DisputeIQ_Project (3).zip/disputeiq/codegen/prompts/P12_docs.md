# P12 - Documentation set

**Syllabus:** All  
**Fire after:** P11

## Prompt (paste into the coding agent)

```text
Using the code that now exists, write or refresh these documents (markdown, plain language, tables where they help):
- README.md: purpose, a documents table, repo layout, "Present it live" and "Quick start" sections, and a code review checklist.
- docs/02_IMPLEMENTATION_GUIDE.md: 24 steps; for each, What/Why (syllabus id), Input, Required files (with source tags [REPO],
  [TEMPLATE→YOU], [BANK: team], [GCP], [GEN: step N], [PUBLIC]), How (commands), Output (paste REAL output from running the
  commands where possible), Done when / Feeds; plus a master table, a day-1 data-request list, and an artefact-flow diagram.
- docs/03_SYLLABUS_TRACEABILITY.md: S079-S100 → case-study section, file, verification.
- docs/04_RUNBOOK.md: quick reference, severity levels, daily/weekly checks, RB-01..RB-10 (model errors, latency, release/canary,
  tool outage, cost spike, prompt injection, SAFE_MODE kill switch, quality drift, rollback, DPDP request), useful log queries,
  a PIR template.
- docs/05_PLAYBOOK.md: principles, RACI, PB-01..PB-07 case plays, release gates table, SEV1/SEV2 plays, the weekly improvement
  loop, a when-to-fine-tune tree, comms templates.
- docs/06_ISSUES_CATALOGUE.md: prompt and LLM failure modes (cost, planning, reasoning, tool-calling, hallucination,
  injection, non-determinism, latency), each with detection and mitigation.
- docs/07_LIVE_DEMO_GUIDE.md: key safety, pre-session checklist, a 90-minute flow, a script per demo, troubleshooting, backup outputs.
Do not invent results: only report outputs you actually ran, and label anything else as expected.

VERIFY: ls docs
```

# P03 - Guardrails as ADK callbacks

**Syllabus:** S084, S095, S100  
**Fire after:** P02

## Prompt (paste into the coding agent)

```text
Create dispute_agent/guardrails.py. The acceptance tests are tests/test_guardrails.py.

1. redact_pii(text): regex masks [CARD_REDACTED] (12-18 digits followed by a digit, spaces or dashes allowed, and it must not
   eat the trailing space), [AADHAAR_REDACTED], [PAN_REDACTED] (ABCDE1234F), [EMAIL_REDACTED],
   [PHONE_REDACTED] (Indian mobile, optional +91), [OTP_REDACTED] ("otp/pin/cvv" followed by 3-6 digits).
2. looks_like_injection(text): regex for "ignore (all|previous|prior) (instructions|rules)", "you are now",
   "system prompt", "developer mode", "approve (this|the) (refund|credit) without", "bypass (the) (policy|limit|approval)".
3. before_model_guard(callback_context, llm_request) -> Optional[LlmResponse]:
   increment state["llm_calls"]; above config.MAX_LLM_CALLS_PER_SESSION return a polite hand-off LlmResponse.
   For each text part: a user part that looks like an injection is replaced with a "withheld by security filter" note
   and state["injection_flag"] = True; otherwise apply redact_pii.
4. before_tool_guard(tool, args, tool_context) -> Optional[dict], for issue_provisional_credit:
   SAFE_MODE -> blocked; injection_flag -> blocked; amount <= 0 -> error; amount > hard cap -> blocked
   with "Call escalate_to_human with priority P2"; empty justification -> error.
   For escalate_to_human, repair an invalid priority to "P3" in place. Return None to allow.
Imports: google.adk.agents.callback_context.CallbackContext, google.adk.models LlmRequest/LlmResponse,
google.adk.tools BaseTool/ToolContext, google.genai.types.

VERIFY: pytest -q tests/test_guardrails.py
```

# P05 - Versioned agent prompts

**Syllabus:** S099  
**Fire after:** P04

## Prompt (paste into the coding agent)

```text
Create dispute_agent/prompts.py with 7 prompt constants, each using the skeleton ROLE / GOAL or TASK / STEPS / RULES / OUTPUT.
Analyst outputs must be "JSON only" with explicit keys.

- CONCIERGE (root, customer-facing): identify customer_id (given by the authenticated channel as
  "[authenticated customer_id=...]") and ONE txn_id (use get_recent_transactions if unclear); classify DUPLICATE |
  MERCHANT_DISPUTE | UNAUTHORIZED | ATM_NOT_DISPENSED; create_dispute_case; call investigation_team with a brief;
  act on its action: auto_resolve -> issue_provisional_credit; needs_approval -> issue_provisional_credit (the system asks a
  human); escalate -> escalate_to_human and do NOT credit. Offer block_card(customer_id, txn_id) for suspected fraud and call it
  only if the customer agrees. Call customer_letter ONCE and reply with exactly its text.
  RULES: never compute liability or scores; never ask for or repeat card/OTP/PIN/CVV/Aadhaar; if a tool returns blocked/error,
  retry at most once and then escalate; vulnerable customer -> P2; reply in English or Hindi.
- INTAKE: call get_customer_profile and get_transaction_details. Output JSON: customer_id, txn_id, reason_code, amount_inr,
  account_type, vulnerable, reported_after_working_days, customer_negligence, facts.
- TXN_ANALYST (reads {intake_summary?}): DUPLICATE -> find_duplicate_charges; ATM -> compute_atm_compensation; else summarise.
  Output JSON: finding, evidence, amount_supported_inr.
- FRAUD_ANALYST: compute_fraud_signals; for UNAUTHORIZED also calculate_customer_liability. Output JSON: score, band, signals, liability.
- POLICY_ANALYST: lookup_dispute_policy. It must NOT judge evidence (it cannot see the other analysts).
  Output JSON: auto_resolve_max_inr, sla_working_days, evidence_required, regulatory_note.
- DECISION (reads {intake_summary?} {txn_findings?} {fraud_findings?} {policy_findings?}); ordered rules, first match wins:
  1 escalate P3 only if a required evidence item is absent from ALL findings (a confirmed duplicate, or a cancellation
    reference in the customer's words, counts as evidence);
  2 UNAUTHORIZED: (a) negligence, or requires_human, or customer liability == amount -> escalate P2 with amount 0;
    (b) otherwise needs_approval with amount = bank_liability_inr;
  3 fraud_score >= 60 -> escalate P1; 4 amount <= the policy auto limit and <= 10000 -> auto_resolve;
  5 <= 200000 -> needs_approval; 6 else escalate P2.
  Output JSON: action, amount_inr, priority, justification (cite the rule number), confidence.
- LETTER_WRITER (reads {decision?} {policy_findings?} {letter_review?}): <=120 words, plain language: what we found,
  what we did, next steps, case id; no internal scores, no PII. Timelines ONLY from policy sla_working_days - never invent one
  (a live run once promised "30 days" when policy says 10 working days; the semantic eval caught it).
- LETTER_REVIEWER (reads {letter_draft?} {policy_findings?}): check no scores or model talk, no PII, timeline equals the policy SLA,
  case id present, no overpromise,
  polite and <=120 words. If all pass, call exit_loop; else output a numbered list of fixes.

VERIFY: python -c "import dispute_agent.prompts as p;print([n for n in dir(p) if n.isupper()])"
```

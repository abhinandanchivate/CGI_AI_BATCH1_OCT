import json

import pytest

from app import kosh_data as db
from app.patterns import loader
from app.safety import mask_text


@pytest.mark.parametrize("raw,must_not_contain,must_contain", [
    ("card 4111 1111 1111 4411 was charged", "4111 1111", "XXXX-XXXX-XXXX-4411"),
    ("card 4111111111114411", "411111111111", "XXXX-XXXX-XXXX-4411"),
    ("my aadhaar is 2345 6789 0123", "2345 6789", "XXXX-XXXX-XXXX"),
    ("PAN ABCDE1234F please", "ABCDE1234F", "XXXXX9999X"),
])
def test_mask_text(raw, must_not_contain, must_contain):
    out = mask_text(raw)
    assert must_not_contain not in out and must_contain in out


def test_mask_leaves_amounts_and_txn_ids_alone():
    assert mask_text("Rs 18,999 on TXN-5201") == "Rs 18,999 on TXN-5201"


def _matches(version, txn_id, text):
    _, patterns = loader.load_patterns(version)
    txn = db.TRANSACTIONS[txn_id]
    return [m["id"] for m in loader.match(patterns, txn, db.MERCHANTS[txn["merchant_id"]],
                                          text, db.RISK_SIGNALS[txn["customer_id"]])]


D4_TEXT = "told to approve a request to receive a refund"


def test_d4_unknown_in_v1_known_in_v2():
    assert _matches("v1", "TXN-5401", D4_TEXT) == []
    assert _matches("v2", "TXN-5401", D4_TEXT) == ["P-014"]


def test_d3_matches_card_fraud_pattern_in_both_versions():
    for v in ("v1", "v2"):
        assert _matches(v, "TXN-5301", "unrecognised payments") == ["P-001"]


@pytest.mark.parametrize("txn_id", ["TXN-5101", "TXN-5201", "TXN-5501", "TXN-5601"])
def test_v2_changes_nothing_for_other_journeys(txn_id):
    assert _matches("v2", txn_id, "refund please") == _matches("v1", txn_id, "refund please")


def test_active_version_is_v1_until_someone_signs_off():
    assert loader.active_version() == "v1"
    data = json.loads((loader.PATTERN_DIR / "scam_patterns_v2.json").read_text())
    assert data["approved_by"] is None


@pytest.mark.parametrize("bad_effect", [
    {"approval_tier": "AUTO"},
    {"min_risk_level": "LOW"},
])
def test_loader_rejects_patterns_that_loosen_rules(tmp_path, bad_effect):
    (tmp_path / "ACTIVE").write_text("bad")
    (tmp_path / "scam_patterns_bad.json").write_text(json.dumps({"patterns": [
        {"id": "P-BAD", "name": "bad", "signals": [], "effect": bad_effect}]}))
    with pytest.raises(loader.PatternRejected):
        loader.load_patterns(base=tmp_path)

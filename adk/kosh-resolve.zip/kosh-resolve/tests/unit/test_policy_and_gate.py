from types import SimpleNamespace

import pytest

from app.agent import build_root_agent
from app.policy import refund_needs_approval, required_tier


def ctx(decision):
    return SimpleNamespace(state={"decision": decision})


LOW_AUTO = {"risk_level": "LOW", "approval_tier": "AUTO"}


@pytest.mark.parametrize("amount,decision,expected", [
    (2500, LOW_AUTO, False),                                          # D1: automatic
    (10000, LOW_AUTO, False),                                         # exactly the limit
    (10001, LOW_AUTO, True),                                          # above the limit
    (2500, {"risk_level": "MEDIUM", "approval_tier": "AUTO"}, True),  # medium risk
    (2500, {"risk_level": "LOW", "approval_tier": "ANALYST"}, True),  # tier says ask
    (2500, {}, True),                                                 # unknown: ask
])
def test_refund_approval_matrix(amount, decision, expected):
    assert refund_needs_approval("CASE-T", amount, ctx(decision)) is expected


@pytest.mark.parametrize("decision,case,expected", [
    ({"decision": "REFUND", "refund_amount": 2500, "risk_level": "LOW"}, {}, "AUTO"),
    ({"decision": "REFUND", "refund_amount": 18999, "risk_level": "LOW"}, {}, "ANALYST"),
    ({"decision": "REFUND", "refund_amount": 150000, "risk_level": "LOW"}, {}, "FOUR_EYES"),
    ({"decision": "CHARGEBACK", "refund_amount": 64300, "risk_level": "HIGH"}, {}, "FOUR_EYES"),
    ({"decision": "NO_REFUND", "refund_amount": 0, "risk_level": "MEDIUM"}, {}, "ANALYST"),
    ({"decision": "REFUND", "refund_amount": 100, "risk_level": "LOW"},
     {"injection_suspected": True}, "NEEDS_HUMAN"),
])
def test_required_tier(decision, case, expected):
    assert required_tier(decision, case) == expected


def _action_tools():
    root = build_root_agent()
    action = next(a for a in root.sub_agents if a.name == "action_agent")
    return {getattr(t, "name", getattr(t, "__name__", "")): t for t in action.tools}


def test_issue_refund_is_gated():
    """Lab 8: this test must FAIL if someone removes require_confirmation."""
    refund = _action_tools()["issue_refund"]
    assert getattr(refund, "_require_confirmation", False) is refund_needs_approval


def test_chargeback_is_always_gated():
    assert _action_tools()["raise_chargeback"]._require_confirmation is True

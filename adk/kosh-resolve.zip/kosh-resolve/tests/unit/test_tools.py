from types import SimpleNamespace

from app import tools


def ctx(**state):
    state.setdefault("customer_id", "CUST-1001")
    state.setdefault("case_id", "CASE-T")
    return SimpleNamespace(state=state)


REFUND_OK = {"decision": "REFUND", "refund_amount": 2500, "approval_tier": "AUTO",
             "risk_level": "LOW", "reason_code": "R01-FAILED-UPI"}


def test_confused_deputy_other_customers_txn_is_refused():
    out = tools.get_ledger_entry(["TXN-5101", "TXN-9901"], ctx())
    assert [e["txn_id"] for e in out["entries"]] == ["TXN-5101"]
    assert out["refused"] == ["TXN-9901"]


def test_refund_is_idempotent_per_case():
    c = ctx(decision=REFUND_OK)
    assert tools.issue_refund("CASE-T", 2500, c)["status"] == "refunded"
    assert tools.issue_refund("CASE-T", 2500, c)["status"] == "already_refunded"
    assert len(tools.REFUNDS) == 1


def test_refund_never_exceeds_the_decision():
    out = tools.issue_refund("CASE-T", 9000, ctx(decision=REFUND_OK))
    assert out["status"] == "error" and not tools.REFUNDS


def test_refund_hard_cap_holds_even_if_decision_allows_more():
    big = dict(REFUND_OK, refund_amount=500_000)
    out = tools.issue_refund("CASE-T", 250_000, ctx(decision=big))
    assert out["status"] == "error" and "automated limit" in out["error"]


def test_refund_without_a_decision_is_refused():
    assert tools.issue_refund("CASE-T", 100, ctx())["status"] == "error"


def test_refund_for_another_case_id_is_refused():
    out = tools.issue_refund("CASE-OTHER", 2500, ctx(decision=REFUND_OK))
    assert out["status"] == "error" and not tools.REFUNDS


def test_freeze_card_uses_the_session_customer():
    assert tools.freeze_card("fraud", ctx(customer_id="CUST-1002"))["card_last4"] == "7720"


def test_chargeback_needs_two_different_approvers():
    tools.raise_chargeback("CASE-T", ["TXN-5301", "TXN-5302", "TXN-5303"], 64300, ctx())
    assert tools.approve_chargeback("CASE-T", "analyst-1")["status"] == "AWAITING_TWO_APPROVERS"
    assert tools.approve_chargeback("CASE-T", "analyst-1")["status"] == "error"
    assert tools.approve_chargeback("CASE-T", "supervisor-7")["status"] == "FILED"


def test_d3_totals_rs_64300():
    out = tools.get_ledger_entry(["TXN-5301", "TXN-5302", "TXN-5303"], ctx())
    assert sum(e["amount"] for e in out["entries"]) == 64300

"""Test helpers: a scripted model so the whole pipeline runs offline, with no API key."""

from __future__ import annotations

import asyncio
import json
import os
import warnings
from typing import Any, AsyncGenerator

import pytest
from google.adk.models import BaseLlm, LlmRequest, LlmResponse
from google.adk.runners import InMemoryRunner
from google.genai import types

warnings.filterwarnings("ignore", category=DeprecationWarning)

from app import tools  # noqa: E402
from app.agent import build_root_agent  # noqa: E402


class ScriptedLlm(BaseLlm):
    """Plays back a fixed list of steps: {"text": ...} or {"call": (name, args)}.

    Records every request so tests can check what each agent was shown.
    """

    script: list = []
    requests: list = []

    def model_post_init(self, _):
        self._i = 0

    async def generate_content_async(self, llm_request: LlmRequest, stream: bool = False
                                     ) -> AsyncGenerator[LlmResponse, None]:
        self.requests.append(llm_request)
        step = self.script[self._i] if self._i < len(self.script) else {"text": "ok"}
        self._i += 1
        if "call" in step:
            name, args = step["call"]
            part = types.Part(function_call=types.FunctionCall(name=name, args=args))
        else:
            text = step["text"]
            part = types.Part(text=text if isinstance(text, str) else json.dumps(text))
        yield LlmResponse(content=types.Content(role="model", parts=[part]))


def evidence_scripts(tool_by_agent: dict[str, tuple[str, dict]]) -> dict[str, list]:
    return {agent: [{"call": call}, {"text": "facts reported"}]
            for agent, call in tool_by_agent.items()}


class Journey:
    """Runs the real pipeline with scripted models, in an in-memory session."""

    def __init__(self, scripts: dict[str, list], state: dict[str, Any]):
        self.models = {name: ScriptedLlm(model="scripted", script=s, requests=[])
                       for name, s in scripts.items()}
        agent = build_root_agent(lambda name: self.models.get(
            name, ScriptedLlm(model="scripted", script=[], requests=[])))
        self.runner = InMemoryRunner(agent=agent, app_name="kosh_test")
        self.state = state
        self.events: list = []
        self.session = None

    async def _run(self, message: types.Content):
        if self.session is None:
            self.session = await self.runner.session_service.create_session(
                app_name="kosh_test", user_id="u1", state=dict(self.state))
        async for e in self.runner.run_async(user_id="u1", session_id=self.session.id,
                                             new_message=message):
            self.events.append(e)

    def start(self, text: str) -> "Journey":
        asyncio.run(self._run(types.Content(role="user", parts=[types.Part(text=text)])))
        return self

    def pending_confirmations(self) -> list:
        answered = {p.function_response.id for e in self.events if e.content
                    for p in e.content.parts if p.function_response}
        return [p.function_call for e in self.events if e.content for p in e.content.parts
                if p.function_call and p.function_call.name == "adk_request_confirmation"
                and p.function_call.id not in answered]

    def answer(self, confirmed: bool) -> "Journey":
        call = self.pending_confirmations()[0]
        msg = types.Content(role="user", parts=[types.Part(function_response=types.FunctionResponse(
            id=call.id, name="adk_request_confirmation", response={"confirmed": confirmed}))])
        asyncio.run(self._run(msg))
        return self

    def final_state(self) -> dict:
        s = asyncio.run(self.runner.session_service.get_session(
            app_name="kosh_test", user_id="u1", session_id=self.session.id))
        return dict(s.state)

    def tool_calls(self) -> list[str]:
        return [p.function_call.name for e in self.events if e.content for p in e.content.parts
                if p.function_call]


@pytest.fixture(autouse=True)
def clean_bank(tmp_path):
    tools.reset_mock_state()
    os.environ["KOSH_AUDIT_PATH"] = str(tmp_path / "audit.jsonl")
    yield
    tools.reset_mock_state()

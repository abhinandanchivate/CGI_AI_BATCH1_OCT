from . import agent  # noqa: F401  (ADK discovers app.agent.root_agent)

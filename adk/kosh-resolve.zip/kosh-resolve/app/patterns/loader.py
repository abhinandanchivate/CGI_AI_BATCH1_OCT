"""Versioned scam-pattern library (Lab 4, S082).

Adaptation changes DATA the risk agent reads, never the approval rules in code.
The loader enforces the boundary: a pattern may raise risk or send a case to a
human, but it may never lower risk or allow automatic approval.
"""

from __future__ import annotations

import json
from pathlib import Path

PATTERN_DIR = Path(__file__).parent
ALLOWED_EFFECT_KEYS = {"min_risk_level", "reason_code", "next_steps"}
RISK_ORDER = ["LOW", "MEDIUM", "HIGH"]


class PatternRejected(ValueError):
    """A pattern tried to loosen the rules."""


def active_version(base: Path = PATTERN_DIR) -> str:
    return (base / "ACTIVE").read_text().strip()


def validate_pattern(p: dict) -> None:
    effect = p.get("effect", {})
    extra = set(effect) - ALLOWED_EFFECT_KEYS
    if extra:
        raise PatternRejected(f"{p.get('id')}: effect keys not allowed: {sorted(extra)}")
    if effect.get("min_risk_level", "MEDIUM") not in ("MEDIUM", "HIGH"):
        raise PatternRejected(f"{p.get('id')}: a pattern may not set risk below MEDIUM")


def load_patterns(version: str | None = None, base: Path = PATTERN_DIR) -> tuple[str, list[dict]]:
    version = version or active_version(base)
    data = json.loads((base / f"scam_patterns_{version}.json").read_text())
    patterns = data["patterns"]
    for p in patterns:
        validate_pattern(p)
    return version, patterns


def _signal_true(sig: dict, txn: dict, merchant: dict, text: str, signals: dict) -> bool:
    kind, value = sig["id"], sig.get("value")
    if kind == "channel_is":
        return txn.get("channel") == value
    if kind == "foreign_transaction":
        return txn.get("country", "IN") != "IN"
    if kind == "no_history_with_merchant":
        return merchant.get("history_with_customer") is False
    if kind == "recent_home_login_minutes":
        return signals.get("last_app_login_minutes_ago", 10**6) <= value
    if kind == "payee_reports_at_least":
        return merchant.get("reported_by_banks", 0) >= value
    if kind == "text_mentions_any":
        t = text.lower()
        return any(word in t for word in value)
    raise PatternRejected(f"unknown signal {kind}")


def match(patterns: list[dict], txn: dict, merchant: dict, text: str, signals: dict) -> list[dict]:
    """Return the patterns whose every signal is true for this transaction."""
    return [
        {"id": p["id"], "name": p["name"], **p["effect"]}
        for p in patterns
        if all(_signal_true(s, txn, merchant, text, signals) for s in p["signals"])
    ]

"""Safety and accountability callbacks (Lab 6, S084).

* mask_pii       - before_model_callback: card, Aadhaar and PAN numbers never reach a model.
* audit_tool_call - after_tool_callback: one JSON line per tool call, for the audit trail.
"""

from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from typing import Any

from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmRequest
from google.adk.tools import BaseTool, ToolContext

CARD = re.compile(r"\b(?:\d[ -]?){12}(\d{4})\b")
AADHAAR = re.compile(r"\b\d{4}[ -]?\d{4}[ -]?\d{4}\b")
PAN = re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")


def mask_text(text: str) -> str:
    text = CARD.sub(r"XXXX-XXXX-XXXX-\1", text)
    text = AADHAAR.sub("XXXX-XXXX-XXXX", text)
    return PAN.sub("XXXXX9999X", text)


def mask_pii(callback_context: CallbackContext, llm_request: LlmRequest):
    """Mask PII in every text part of the request before the model sees it."""
    for content in llm_request.contents or []:
        for part in content.parts or []:
            if part.text:
                part.text = mask_text(part.text)
    return None  # continue to the model


def _mask_value(value: Any) -> Any:
    if isinstance(value, str):
        return mask_text(value)
    if isinstance(value, dict):
        return {k: _mask_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_mask_value(v) for v in value]
    return value


def audit_tool_call(tool: BaseTool, args: dict[str, Any], tool_context: ToolContext,
                    tool_response: Any):
    """Append one audit line per tool call. Returns None so the response is unchanged."""
    path = os.getenv("KOSH_AUDIT_PATH", "audit.jsonl")
    response = tool_response if isinstance(tool_response, dict) else {"value": str(tool_response)}
    line = {
        "time": datetime.now(timezone.utc).isoformat(),
        "case_id": tool_context.state.get("case_id"),
        "customer_id": tool_context.state.get("customer_id"),
        "agent": tool_context.agent_name,
        "tool": tool.name,
        "args": _mask_value(args),
        "status": response.get("status", "ok"),
        "pattern_version": tool_context.state.get("pattern_version"),
        "approver": tool_context.state.get("approver"),
    }
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(line, ensure_ascii=False) + "\n")
    return None

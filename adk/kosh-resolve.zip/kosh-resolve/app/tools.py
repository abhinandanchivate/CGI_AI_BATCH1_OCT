"""Mock banking tools for Kosh Resolve.

Rules every tool follows:
* The customer comes from session state (customer_id), never from the model's words.
  A transaction that belongs to someone else is refused (confused-deputy defence).
* Tools return dicts with a "status" key. They never raise into the model.
* Money tools re-check the hard limits themselves, so the limits hold even if a
  later code change drops the approval gate (defence in depth).
"""

from __future__ import annotations

import json
from typing import Any

from google.adk.tools import ToolContext

from . import kosh_data as db
from .patterns import loader
from .policy import MAX_AUTOMATED_REFUND

# In-memory "core banking" side effects. reset_mock_state() clears them for tests.
REFUNDS: dict[str, dict] = {}
FROZEN_CARDS: set[str] = set()
CHARGEBACK_QUEUE: dict[str, dict] = {}
CLOSED_CASES: dict[str, dict] = {}


def reset_mock_state() -> None:
    REFUNDS.clear()
    FROZEN_CARDS.clear()
    CHARGEBACK_QUEUE.clear()
    CLOSED_CASES.clear()


def _customer_id(tool_context: ToolContext) -> str:
    return tool_context.state.get("customer_id", "CUST-1001")


def _own(txn_ids: list[str], tool_context: ToolContext) -> tuple[list[str], list[str]]:
    me = _customer_id(tool_context)
    own = [t for t in txn_ids if db.TRANSACTIONS.get(t, {}).get("customer_id") == me]
    refused = [t for t in txn_ids if t not in own]
    return own, refused


def _decision(tool_context: ToolContext) -> dict:
    d = tool_context.state.get("decision")
    if isinstance(d, str):
        try:
            d = json.loads(d)
        except json.JSONDecodeError:
            d = {}
    return d if isinstance(d, dict) else {}


def _check_case(case_id: str, tool_context: ToolContext) -> dict | None:
    expected = tool_context.state.get("case_id")
    if expected and case_id != expected:
        return {"status": "error", "error": f"case_id must be {expected}"}
    return None


# ---------------------------------------------------------------- evidence tools

def get_ledger_entry(txn_ids: list[str], tool_context: ToolContext) -> dict:
    """Return core-banking ledger entries for the signed-in customer's transactions."""
    own, refused = _own(txn_ids, tool_context)
    entries = [
        {"txn_id": t, "amount": db.TRANSACTIONS[t]["amount"],
         "channel": db.TRANSACTIONS[t]["channel"],
         "ledger_status": db.TRANSACTIONS[t]["ledger_status"],
         "days_ago": db.TRANSACTIONS[t]["days_ago"],
         "time": db.TRANSACTIONS[t].get("time")}
        for t in own
    ]
    return {"status": "ok", "entries": entries, "refused": refused}


def get_switch_status(txn_ids: list[str], tool_context: ToolContext) -> dict:
    """Return UPI switch / card network / ATM switch status for the transactions."""
    own, refused = _own(txn_ids, tool_context)
    results = [
        {"txn_id": t, "switch_status": db.TRANSACTIONS[t]["switch_status"],
         "detail": db.TRANSACTIONS[t]["switch_detail"],
         "country": db.TRANSACTIONS[t].get("country", db.HOME_COUNTRY)}
        for t in own
    ]
    return {"status": "ok", "results": results, "refused": refused}


def get_merchant_profile(txn_ids: list[str], tool_context: ToolContext) -> dict:
    """Return merchant or payee facts for the transactions."""
    own, refused = _own(txn_ids, tool_context)
    profiles = [
        {"txn_id": t, **db.MERCHANTS[db.TRANSACTIONS[t]["merchant_id"]]}
        for t in own
    ]
    return {"status": "ok", "profiles": profiles, "refused": refused}


def get_risk_signals(txn_ids: list[str], customer_text: str, tool_context: ToolContext) -> dict:
    """Return device/login signals and any matches in the active scam-pattern library."""
    own, refused = _own(txn_ids, tool_context)
    signals = db.RISK_SIGNALS.get(_customer_id(tool_context), {})
    version, patterns = loader.load_patterns()
    matches: dict[str, dict] = {}
    for t in own:
        txn = db.TRANSACTIONS[t]
        merchant = db.MERCHANTS[txn["merchant_id"]]
        for m in loader.match(patterns, txn, merchant, customer_text, signals):
            matches[m["id"]] = m
    risk = "LOW"
    for m in matches.values():
        if loader.RISK_ORDER.index(m["min_risk_level"]) > loader.RISK_ORDER.index(risk):
            risk = m["min_risk_level"]
    tool_context.state["pattern_version"] = version
    return {"status": "ok", "risk_level": risk, "signals": signals,
            "pattern_matches": list(matches.values()), "pattern_version": version,
            "refused": refused}


# ---------------------------------------------------------------- action tools

def issue_refund(case_id: str, amount: float, tool_context: ToolContext) -> dict:
    """Refund the customer for this case. Gated by human approval above the policy limit."""
    if err := _check_case(case_id, tool_context):
        return err
    if case_id in REFUNDS:
        return {"status": "already_refunded", "refund": REFUNDS[case_id]}
    d = _decision(tool_context)
    if not d:
        return {"status": "error", "error": "no policy decision in state"}
    if amount <= 0:
        return {"status": "error", "error": "amount must be positive"}
    if amount > MAX_AUTOMATED_REFUND:
        return {"status": "error", "error": f"above the Rs {MAX_AUTOMATED_REFUND:,} automated limit"}
    if amount > float(d.get("refund_amount") or 0):
        return {"status": "error", "error": "amount exceeds the policy decision"}
    REFUNDS[case_id] = {"case_id": case_id, "amount": amount,
                        "customer_id": _customer_id(tool_context),
                        "reason_code": d.get("reason_code")}
    return {"status": "refunded", "refund": REFUNDS[case_id]}


def freeze_card(reason: str, tool_context: ToolContext) -> dict:
    """Freeze the signed-in customer's debit card. Protective and reversible."""
    last4 = db.CUSTOMERS[_customer_id(tool_context)]["card_last4"]
    FROZEN_CARDS.add(last4)
    return {"status": "frozen", "card_last4": last4, "reason": reason}


def raise_chargeback(case_id: str, txn_ids: list[str], amount: float,
                     tool_context: ToolContext) -> dict:
    """Submit a chargeback to the operations queue. Two different people must approve it there."""
    if err := _check_case(case_id, tool_context):
        return err
    own, refused = _own(txn_ids, tool_context)
    if refused:
        return {"status": "error", "error": f"not this customer's transactions: {refused}"}
    if case_id in CHARGEBACK_QUEUE:
        return {"status": "already_submitted", "chargeback": CHARGEBACK_QUEUE[case_id]}
    CHARGEBACK_QUEUE[case_id] = {"case_id": case_id, "txn_ids": own, "amount": amount,
                                 "status": "AWAITING_TWO_APPROVERS", "approvals": []}
    return {"status": "submitted", "chargeback": CHARGEBACK_QUEUE[case_id]}


def close_case(case_id: str, reason_code: str, summary: str, tool_context: ToolContext) -> dict:
    """Close or park the case with its reason code and a one-line summary."""
    if err := _check_case(case_id, tool_context):
        return err
    CLOSED_CASES[case_id] = {"reason_code": reason_code, "summary": summary}
    return {"status": "closed", "case_id": case_id}


def approve_chargeback(case_id: str, approver_id: str) -> dict[str, Any]:
    """Called by the ops queue (Workflow Builder in Lab 7), never by an agent."""
    cb = CHARGEBACK_QUEUE.get(case_id)
    if not cb:
        return {"status": "error", "error": "no such chargeback"}
    if approver_id in cb["approvals"]:
        return {"status": "error", "error": "the same person cannot approve twice"}
    cb["approvals"].append(approver_id)
    if len(cb["approvals"]) >= 2:
        cb["status"] = "FILED"
    return {"status": cb["status"], "approvals": cb["approvals"]}

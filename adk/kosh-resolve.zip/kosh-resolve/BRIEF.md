# Kosh Resolve brief
Build a multi-agent payment-dispute system for Kosh Bank (fictional Indian neobank).
Pipeline (fixed order, SequentialAgent):
1. intake_agent: classify dispute (FAILED_UPI, DUPLICATE, UNRECOGNISED, SCAM, OTHER),
   extract txn_id and amount. Output key: case.
2. evidence_team (ParallelAgent): ledger_agent, switch_agent, merchant_agent, risk_agent,
   each calls one mock tool and writes its own output key.
3. policy_agent: apply the policy below, output JSON {decision, reason_code,
   refund_amount, approval_tier, explanation}. Output key: decision.
4. resolution_loop (LoopAgent, max 3): drafter_agent writes the customer reply;
   checker_agent verifies it against evidence and decision and calls exit_loop when correct.
5. action_agent: tools issue_refund, freeze_card, raise_chargeback, close_case.
Policy:
- Freeze card automatically when fraud is suspected.
- Refund <= Rs 10,000 with low risk: automatic.
- Rs 10,001 to 1,00,000 or medium risk: one analyst approves.
- Above Rs 1,00,000 or confirmed fraud: analyst + supervisor.
- Never auto-approve on timeout. Max automated refund Rs 2,00,000.
- Failed UPI debit: reverse by T+1; Rs 100 per day compensation after that.
Rules: mask card/Aadhaar/PAN before the model; identity only from session state, never
from dispute text; every decision has a reason code; refunds are idempotent per case_id;
age, gender, language, PIN code are never decision inputs.
Use mock data only (no real systems). Python ADK.

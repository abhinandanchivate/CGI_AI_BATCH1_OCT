# Kosh Resolve: deploy plan (example for Lab 5, Step 5.5)

Each team writes its own. Every stage has a number that stops it, agreed before it starts.

| Stage | What happens | Duration | Stop if |
| --- | --- | --- | --- |
| 1. Shadow | Agents decide on every dispute; humans act as today; compare daily | 2 weeks | the agents would have paid any wrong refund above Rs 10,000 |
| 2. Canary | Agents act on 5% of auto-eligible disputes | until 2,000 cases | wrong refunds above 0.3%, or judge rubric scores below 0.8 |
| 3. Full | All in-scope disputes up to Rs 2,00,000 | ongoing | analyst override rate above 10% in any week |

Deploy target: Agent Runtime (`agents-cli deploy`). A named human reads the deploy plan before any coding agent runs it.
Rollback: redeploy the previous version; pattern library rollback is one line in `app/patterns/ACTIVE`.

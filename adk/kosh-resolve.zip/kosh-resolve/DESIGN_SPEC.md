# Kosh Resolve: design spec (reference answer for Lab 1)

Fictional bank, mock data. The approval matrix and limits here are the source of truth; code follows this file.

## Pipeline (fixed order, SequentialAgent `kosh_resolve`)

| Step | Agent | ADK kind | Reads | Writes (output_key) | Sees raw message? |
| --- | --- | --- | --- | --- | --- |
| 1 | intake_agent | LlmAgent, output_schema `Case` | customer message | `case` | yes (the only one) |
| 2 | evidence_team | ParallelAgent | `case` | (below) | no |
| 2a | ledger_agent | LlmAgent + `get_ledger_entry` | `case` | `ledger` | no |
| 2b | switch_agent | LlmAgent + `get_switch_status` | `case` | `switch` | no |
| 2c | merchant_agent | LlmAgent + `get_merchant_profile` | `case` | `merchant` | no |
| 2d | risk_agent | LlmAgent + `get_risk_signals` | `case` | `risk`, `pattern_version` | no |
| 3 | policy_agent | LlmAgent, output_schema `Decision`, after-callback `enforce_policy_floor` | `case`, evidence | `decision` | no |
| 4 | resolution_loop | LoopAgent, max 3 | `decision`, `case`, evidence | `draft`, `check` | no |
| 5 | action_agent | LlmAgent + money tools | `decision`, `draft`, `case_id` | `actions` | no |

`case_id` is set once per session by the root's `before_agent_callback` (`CASE-` + session id). Customer identity is `state["customer_id"]`, set by the app login, never by the message.

## Tools

| Tool | Arguments | Gate | Notes |
| --- | --- | --- | --- |
| get_ledger_entry / get_switch_status / get_merchant_profile | txn_ids | none | refuse other customers' transactions |
| get_risk_signals | txn_ids, customer_text | none | reads the ACTIVE pattern version |
| issue_refund | case_id, amount | `refund_needs_approval` | ≤ decision amount, ≤ Rs 2,00,000, once per case |
| raise_chargeback | case_id, txn_ids, amount | always | submits to a two-approver queue; never files directly |
| freeze_card | reason | none | protective, reversible |
| close_case | case_id, reason_code, summary | none | |

## Approval matrix

| Action | Condition | Approver | No answer |
| --- | --- | --- | --- |
| Freeze card | fraud suspected | automatic | n/a |
| Refund | ≤ Rs 10,000 and risk LOW | automatic | n/a |
| Refund | Rs 10,001–1,00,000 or risk MEDIUM | 1 analyst | escalate at 4 h; never auto-approve |
| Refund / chargeback | > Rs 1,00,000 or confirmed fraud | analyst + supervisor | stays paused |
| Reject (NO_REFUND), unfreeze | any | 1 analyst | stays paused |
| Injection suspected | any | NEEDS_HUMAN | stays paused |

## Failure handling

* Evidence agent fails or returns nothing → policy returns NEEDS_HUMAN, `R99-MISSING-EVIDENCE`.
* Evidence contradicts (ledger vs switch) → NEEDS_HUMAN, `R99-MISSING-EVIDENCE`.
* Policy output invalid or missing → `enforce_policy_floor` writes NEEDS_HUMAN.
* Checker never passes in 3 rounds → loop ends; the action agent sends the last draft, and the case still follows the decision's approval tier.
* Approval unanswered → stays paused; scheduled job escalates to the duty supervisor after 4 hours.

## Test journeys

D1–D6 as in the Case Study; expected decisions in README.md and `scripts/run_journeys.py`.

## Open risks

1. A coding agent regenerates `agent.py` and drops the gate (mitigated by `test_issue_refund_is_gated` and limits inside the tool).
2. Pattern drift: a v2 pattern that over-matches genuine collect requests (mitigated by the loader boundary and Lab 4 evals).
3. The LLM judge passing bad replies (Lab 5 calibration).
4. Language parity: Hindi replies lower quality than English (fairness evals).

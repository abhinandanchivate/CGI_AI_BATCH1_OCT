# Kosh Resolve: reference solution (S079–S086)

A multi-agent payment-dispute system for **Kosh Bank**, the fictional Indian neobank from the course case study. Built with Google's Agent Development Kit (ADK). All customers, merchants and figures are fictional, and the tools touch only in-memory mock data.

This is the **instructor's reference solution**. In the labs, learners build their own version by directing a coding agent (Antigravity CLI or Gemini CLI with the Agents CLI skills). Use this to compare, debug and demo.

```
intake_agent → evidence_team (4 agents in parallel) → policy_agent → resolution_loop (drafter ⇄ checker) → action_agent
```

## Quick start

**1. Offline tests (no API key, no cloud):** about 1 second.

```bash
uv sync
uv run pytest
```

45 tests: tools, approval matrix, PII masking, pattern library, and the whole pipeline run end to end with a scripted model (D1, D2, D5).

**2. Run against a real model** (after the Lab Environment Setup deck):

```bash
cp .env.example .env              # fill in project, region and KOSH_MODEL
uv run python scripts/run_journeys.py            # D1–D6; approvals stay pending
uv run python scripts/run_journeys.py --approve  # act as the analyst and approve
uv run adk web                    # or: agents-cli playground — chat with it, click approvals
```

**3. Evals (Lab 5):**

```bash
uv run python scripts/build_evalset.py   # regenerates the evalset from the journey table
uv run adk eval app tests/eval/evalsets/kosh.evalset.json --config_file_path tests/eval/eval_config.json
```

Set `judge_model` in `tests/eval/eval_config.json` first. Projects scaffolded with Agents CLI can use `agents-cli eval run` instead.

## Where each lab lives

| Lab | Session | Files |
| --- | --- | --- |
| 1 Spec first | S080, S086 | `BRIEF.md`, `DESIGN_SPEC.md` |
| 2 Pipeline | S079, S080 | `app/agent.py`, `app/tools.py`, `app/kosh_data.py` |
| 3 Approval gates | S081 | `app/policy.py` (`refund_needs_approval`, `enforce_policy_floor`), `tools.issue_refund`, `tools.approve_chargeback` |
| 4 Adaptive patterns | S082 | `app/patterns/` (`ACTIVE`, `scam_patterns_v1.json`, `v2.json`, `loader.py`), `data/overrides_week47.csv` |
| 5 Evals | S083 | `tests/eval/`, `scripts/build_evalset.py`, `scripts/run_journeys.py`, `DEPLOY_PLAN.md` |
| 6 Ethics controls | S084 | `app/safety.py` (`mask_pii`, `audit_tool_call`), fairness cases in the evalset |
| 7 Deploy and publish | S086 | `agents-cli deploy`, `agents-cli publish gemini`; `data/kosh_dispute_daily.csv` for Workflow Builder |
| 8 Standard review | S085 | `tests/unit/test_policy_and_gate.py::test_issue_refund_is_gated` |

## Expected decisions

| Journey | Txn | Reason code | Amount (Rs) | Approval |
| --- | --- | --- | --- | --- |
| D1 failed UPI | TXN-5101 | R01-FAILED-UPI | 2,500 (2,400 + 100 late fee) | AUTO |
| D2 duplicate | TXN-5201/5202 | R07-DUPLICATE-CHARGE | 18,999 | ANALYST |
| D3 card fraud | TXN-5301/02/03 | R15-CARD-FRAUD | 64,300 chargeback, card frozen | FOUR_EYES |
| D4 collect scam | TXN-5401 | v1: varies, no refund · v2: R12-AUTHORISED-SCAM | 0 | ANALYST |
| D5 injection | TXN-5501 | R20-SUSPICIOUS-INSTRUCTION | 0 | NEEDS_HUMAN |
| D6 failed ATM (Hindi) | TXN-5601 | R02-FAILED-ATM | 6,200 | AUTO |

## How money is protected (five layers)

1. **Policy agent never sees the raw message** (`include_contents="none"`): an injected instruction in the dispute text can't reach it.
2. **Policy floor** (`enforce_policy_floor`): code raises the approval tier to what the matrix requires, whatever the model said.
3. **Runtime confirmation** (`FunctionTool(issue_refund, require_confirmation=...)`): ADK pauses the call until a person answers. Chargebacks always pause.
4. **Limits inside the tool**: never above the decision, never above Rs 2,00,000, once per case, only for this session's case and customer.
5. **Four eyes outside the agent**: chargebacks go to a queue that needs two different approvers (`approve_chargeback`), which the agents cannot call.

`test_d5_a_fooled_policy_model_still_cannot_pay` shows layers 2–4 holding even when the policy model is fooled. Remove the gate in `agent.py` and four tests fail (try it; that is Lab 8, Step 8.1).

## Notes

* Tested with `google-adk` 2.15.0 and Python 3.13. ADK 2.x marks `SequentialAgent`, `ParallelAgent` and `LoopAgent` as deprecated in favour of its newer `Workflow` API; they still work and are what the course teaches. The pipeline would port to `Workflow` with the same agents.
* `require_confirmation` callables receive the tool's own arguments, so `refund_needs_approval` has the same signature as `issue_refund`.
* `KOSH_MODEL` defaults to `gemini-2.5-flash`; set it to a model your project lists in Model Garden.
* The pattern library ships with `ACTIVE` = `v1`. Promoting `v2` is the Lab 4 exercise.

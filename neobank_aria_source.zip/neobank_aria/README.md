# NeoBank Aria — Agent Harness Teaching Demo (S059–S066)

Aria is an in-app AI assistant for **Kosh Bank**, a fictional Indian neobank. The project is a small,
readable agent harness that shows how sessions S059–S066 work on one banking agent.

| Session | Concept | Where in code | Demo |
|---|---|---|---|
| S059 | Context compaction & summarisation | `aria/harness/memory.py` | `--scenario compaction` |
| S060 | What an agent harness is | `aria/harness/harness.py` (+ tools, guardrails, tracing) | `--scenario harness` |
| S061 | Custom harness vs framework | `langgraph_version/graph_agent.py` | `python langgraph_version/graph_agent.py` |
| S062 | Sandboxing & permission boundaries | `aria/harness/sandbox.py`, `guardrails.py` | `--scenario sandbox` |
| S063 | Agent loop: Perceive → Plan → Act → Observe | `aria/agent/react_loop.py` | `--scenario react` |
| S064 | ReAct vs Plan-and-Execute | `aria/agent/plan_execute.py` | `--scenario compare` |
| S065 | Termination & infinite-loop prevention | `aria/agent/termination.py` | `--scenario loops` |
| S066 | Human-in-the-loop checkpoints | `aria/harness/hitl.py` | `--scenario hitl [--interactive]` |

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt                          # only pytest is required
python main.py --scenario all
pytest -q                                                # 28 tests
```

No API key is needed. The default "LLM" is a deterministic rule-based stand-in (`MockBankingLLM`),
so every run gives the same output. To use a real Claude model:

```bash
pip install anthropic
export ANTHROPIC_API_KEY=sk-ant-...
python main.py --scenario react --llm anthropic
```

## Layout

```
aria/
  bank/core_banking.py     mock core banking (accounts, cards, UPI, disputes)
  banking_tools.py         the 13 tools Aria can call
  harness/                 tools · sandbox · guardrails · memory · hitl · tracing · harness
  agent/                   llm · react_loop · plan_execute · termination
langgraph_version/         same agent on LangGraph (optional: pip install langgraph)
tests/test_aria.py         one test group per session
main.py                    scenario runner
runs/                      audit logs + HITL checkpoints (created at runtime)
```

All people, accounts and figures are fictional.

import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
os.chdir(os.path.dirname(os.path.dirname(__file__)))
# Tests must be deterministic and offline, whatever is in .env
os.environ["LLM_PROVIDER"] = "mock"
os.environ["EMBEDDING_BACKEND"] = "tfidf"
os.environ["MIN_RETRIEVAL_SCORE"] = "0.08"
os.environ["API_KEY"] = "dev-secret-key"
os.environ["ADMIN_API_KEY"] = "dev-admin-key"

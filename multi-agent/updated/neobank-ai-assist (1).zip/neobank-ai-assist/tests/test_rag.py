from app.rag.chunker import chunk_document
from app.rag.retriever import get_retriever


def test_chunker_keeps_sections():
    chunks = chunk_document("t", "# T\n\n## A\nFirst. Second.\n\n## B\nThird.")
    assert [c.section for c in chunks] == ["A", "B"]


def test_kyc_query_hits_kyc_doc():
    hits = get_retriever().search("documents required for KYC", top_k=1)
    assert hits[0][0].document == "kyc_policy"


def test_card_fee_query_hits_fee_doc():
    hits = get_retriever().search("ATM withdrawal charges", top_k=1)
    assert hits[0][0].document == "card_fees"

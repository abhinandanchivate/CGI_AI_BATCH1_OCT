"""Gemini integration tests with a fake client: no network or API key needed."""
from types import SimpleNamespace

import numpy as np

from app.llm.client import LLMClient
from app.rag.embeddings import GeminiEmbedder

PROMPT = "CONTEXT:\n[1] ATM withdrawals: Beyond the free limit, each transaction costs Rs 21 plus GST.\nQUESTION: ATM charges?"


class FakeModels:
    def __init__(self, fail=False):
        self.fail, self.calls = fail, []

    def generate_content(self, model, contents, config):
        self.calls.append((model, contents, config))
        if self.fail:
            raise RuntimeError("quota exceeded")
        return SimpleNamespace(text="Each transaction beyond the free limit costs Rs 21 plus GST. [1]")

    def embed_content(self, model, contents, config):
        self.calls.append((model, config.task_type))
        return SimpleNamespace(embeddings=[SimpleNamespace(values=[1.0, 0.0, 0.0]) for _ in contents])


def gemini_llm(fail=False):
    llm = LLMClient()
    llm.provider = "gemini"
    llm.s = llm.s.model_copy(update={"gemini_model": "gemini-2.5-flash"})
    llm._gemini = SimpleNamespace(models=FakeModels(fail))
    return llm


def test_gemini_generate_passes_system_prompt():
    llm = gemini_llm()
    out = llm.generate("Answer only from context.", PROMPT)
    model, contents, config = llm._gemini.models.calls[0]
    assert model == "gemini-2.5-flash" and contents == PROMPT
    assert config.system_instruction == "Answer only from context." and config.temperature == 0.1
    assert out.endswith("[1]")


def test_gemini_failure_falls_back_to_offline_answer():
    out = gemini_llm(fail=True).generate("sys", PROMPT)
    assert "Rs 21 plus GST" in out


def test_gemini_without_key_uses_mock(monkeypatch):
    from app.config import get_settings
    monkeypatch.setattr(get_settings(), "llm_provider", "gemini")
    monkeypatch.setattr(get_settings(), "gemini_api_key", "")
    assert LLMClient().provider == "mock"


def test_gemini_embedder_task_types():
    emb = GeminiEmbedder.__new__(GeminiEmbedder)
    emb.client, emb.model, emb.dims = SimpleNamespace(models=FakeModels()), "gemini-embedding-001", 768
    docs = emb.embed(["a", "b"])
    q = emb.embed_query("a")
    assert docs.shape == (2, 3) and isinstance(q, np.ndarray)
    assert [c[1] for c in emb.client.models.calls] == ["RETRIEVAL_DOCUMENT", "RETRIEVAL_QUERY"]

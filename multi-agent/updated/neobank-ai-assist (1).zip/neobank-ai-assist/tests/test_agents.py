from app.agents.loan_agent import calculate_emi, parse_loan_query
from app.agents.router import RouterAgent
from app.services.security import mask_pii


def test_emi_formula():
    assert calculate_emi(500000, 10.5, 60)["emi"] == 10746.95


def test_parse_loan_query():
    p = parse_loan_query("EMI for 5 lakh at 11% for 3 years")
    assert p == {"principal": 500000.0, "annual_rate": 11.0, "tenure_months": 36}


def test_router_intents():
    r = RouterAgent()
    assert r.classify("what is my balance")[0] == "account"
    assert r.classify("I don't recognise this transaction")[0] == "fraud"
    assert r.classify("am I eligible for a personal loan")[0] == "loan"
    assert r.classify("what are ATM charges")[0] == "knowledge"
    assert r.classify("Hi there")[0] == "greeting"
    assert r.classify("Why are my card fees so high?")[0] == "knowledge"   # not a greeting


def test_pii_masking():
    out = mask_pii("My PAN is ABCDE1234F and card 4111 1111 1111 1111 today")
    assert out == "My PAN is [PAN_REDACTED] and card [CARD_REDACTED] today"
    out = mask_pii("Aadhaar 1234 5678 9012, phone +91 9876543210")
    assert out == "Aadhaar [AADHAAR_REDACTED], phone [PHONE_REDACTED]"


def test_loan_follow_up_reuses_previous_inputs():
    from app.agents.orchestrator import get_orchestrator
    o = get_orchestrator()
    o.handle("fu", "CUST1001", "Calculate EMI for 10 lakh at 9% for 20 years")
    r = o.handle("fu", "CUST1001", "and for 15 years?")
    assert "180 months" in r["answer"] and "10,142.67" in r["answer"]

"""RAG API tests. Document changes run against a temporary copy of data/docs."""
import shutil

import pytest
from fastapi.testclient import TestClient

from app.config import get_settings
from app.main import app
from app.rag.retriever import get_retriever

H = {"X-API-Key": "dev-secret-key"}
ADMIN = {**H, "X-Admin-Key": "dev-admin-key"}
FD_DOC = "# NeoBank Fixed Deposits\n\n## Premature withdrawal\nBreaking a fixed deposit early costs a 1% penalty on the interest rate.\n"


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture
def temp_docs(tmp_path, monkeypatch):
    """Point the knowledge base at a copy of data/docs, then restore the real index."""
    real = get_settings().docs_dir
    shutil.copytree(real, tmp_path / "docs")
    monkeypatch.setattr(get_settings(), "docs_dir", str(tmp_path / "docs"))
    get_retriever().ingest(str(tmp_path / "docs"))
    yield tmp_path / "docs"
    monkeypatch.undo()
    get_retriever().ingest(real)


def test_list_documents(client):
    docs = client.get("/api/v1/rag/documents", headers=H).json()
    assert {d["name"] for d in docs} == {"card_fees", "fraud_guidelines", "kyc_policy", "loan_policy"}
    assert sum(d["chunks"] for d in docs) == 18


def test_get_document_with_chunks(client):
    doc = client.get("/api/v1/rag/documents/card_fees", headers=H).json()
    assert doc["title"].startswith("NeoBank Debit") and len(doc["chunks"]) == 4
    assert client.get("/api/v1/rag/documents/nope", headers=H).status_code == 404
    assert client.get("/api/v1/rag/documents/Bad%20Name", headers=H).status_code == 400


def test_chunks_list_and_single(client):
    chunks = client.get("/api/v1/rag/chunks", params={"document": "kyc_policy"}, headers=H).json()
    assert len(chunks) == 5
    one = client.get("/api/v1/rag/chunks/card_fees%231.0", headers=H).json()
    assert one["section"] == "ATM withdrawals"


def test_search_filter_and_threshold(client):
    hits = client.post("/api/v1/rag/search", headers=H,
                       json={"query": "documents required", "top_k": 3, "document": "loan_policy"}).json()
    assert hits and all(h["document"] == "loan_policy" for h in hits)
    hits = client.post("/api/v1/rag/search", headers=H, json={"query": "video kyc timings", "min_score": 0.3}).json()
    assert [h["chunk_id"] for h in hits] == ["kyc_policy#2.0"] and hits[0]["passed_threshold"]


def test_ask_grounded_with_prompt(client):
    r = client.post("/api/v1/rag/ask", headers=H,
                    json={"question": "How do I do video KYC?", "include_prompt": True}).json()
    assert r["grounded"] and "9 AM" in r["answer"] and r["sources"][0]["chunk_id"] == "kyc_policy#2.0"
    assert r["prompt"].startswith("CONTEXT:\n[1] Video KYC:")


def test_ask_refuses_without_evidence(client):
    r = client.post("/api/v1/rag/ask", headers=H, json={"question": "What is the weather today?"}).json()
    assert not r["grounded"] and r["sources"] == [] and r["confidence"] == 0.2


def test_ask_masks_pii(client):
    r = client.post("/api/v1/rag/ask", headers=H, json={"question": "My PAN is ABCDE1234F, update KYC"}).json()
    assert "ABCDE1234F" not in r["question"]


def test_stats(client):
    s = client.get("/api/v1/rag/stats", headers=H).json()
    assert s["chunks"] == 18 and s["documents"] == 4 and s["indexed_at"]


def test_admin_key_required(client):
    assert client.post("/api/v1/rag/ingest", headers=H).status_code == 422          # header missing
    bad = {**H, "X-Admin-Key": "wrong"}
    assert client.post("/api/v1/rag/ingest", headers=bad).status_code == 403
    assert client.post("/api/v1/rag/ingest", headers=ADMIN).json()["chunks"] == 18


def test_create_search_and_delete_document(client, temp_docs):
    r = client.post("/api/v1/rag/documents", headers=ADMIN, json={"name": "fixed_deposits", "content": FD_DOC})
    assert r.status_code == 201 and r.json()["index"]["chunks"] == 19
    ans = client.post("/api/v1/rag/ask", headers=H, json={"question": "penalty for breaking a fixed deposit"}).json()
    assert ans["sources"][0]["document"] == "fixed_deposits" and "1% penalty" in ans["answer"]
    assert client.post("/api/v1/rag/documents", headers=ADMIN,
                       json={"name": "fixed_deposits", "content": FD_DOC}).status_code == 409
    r = client.delete("/api/v1/rag/documents/fixed_deposits", headers=ADMIN)
    assert r.json()["index"]["chunks"] == 18 and not (temp_docs / "fixed_deposits.md").exists()


def test_upload_document(client, temp_docs):
    files = {"file": ("Fixed Deposits.md", FD_DOC.encode(), "text/markdown")}
    r = client.post("/api/v1/rag/documents/upload", headers=ADMIN, files=files)
    assert r.status_code == 201 and r.json()["document"] == "fixed_deposits"
    bad = {"file": ("virus.exe", b"MZ", "application/octet-stream")}
    assert client.post("/api/v1/rag/documents/upload", headers=ADMIN, files=bad).status_code == 400


def test_path_traversal_blocked(client, temp_docs):
    r = client.post("/api/v1/rag/documents", headers=ADMIN, json={"name": "../evil", "content": "x"})
    assert r.status_code == 400


def test_evaluate(client):
    r = client.post("/api/v1/rag/evaluate", headers=H, json={}).json()
    assert r["questions"] == 12 and r["hit_rate_at_k"] == 1.0 and 0 < r["mrr"] <= 1

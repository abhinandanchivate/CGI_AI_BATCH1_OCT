from fastapi.testclient import TestClient
from app.main import app

H = {"X-API-Key": "dev-secret-key"}


def chat(msg, sid="t1", cid="CUST1001"):
    with TestClient(app) as c:
        return c.post("/api/v1/chat", json={"session_id": sid, "customer_id": cid, "message": msg}, headers=H)


def test_health():
    with TestClient(app) as c:
        assert c.get("/health").json()["status"] == "ok"


def test_auth_required():
    with TestClient(app) as c:
        assert c.post("/api/v1/chat", json={"session_id": "x", "customer_id": "x", "message": "hi"}).status_code == 422
        assert c.get("/api/v1/agents", headers={"X-API-Key": "wrong"}).status_code == 401


def test_balance_flow():
    body = chat("What is my account balance?").json()
    assert body["agent"] == "account_agent" and "84,250.75" in body["answer"]


def test_kyc_flow_has_sources():
    body = chat("Which documents do I need for KYC?").json()
    assert body["agent"] == "knowledge_agent" and body["sources"]


def test_fraud_flow_escalates():
    body = chat("I don't recognise a transaction from Singapore").json()
    assert body["escalated"] and body["case_id"].startswith("FRD-")


def test_emi_endpoint():
    with TestClient(app) as c:
        r = c.post("/api/v1/loans/emi", json={"principal": 500000, "annual_rate": 10.5, "tenure_months": 60}, headers=H)
    assert r.json()["emi"] == 10746.95

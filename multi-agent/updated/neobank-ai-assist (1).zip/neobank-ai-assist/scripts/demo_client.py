"""Interactive terminal client for the running API.  Usage: python scripts/demo_client.py"""
import uuid
import httpx

BASE, KEY = "http://127.0.0.1:8000", "dev-secret-key"
session = f"cli-{uuid.uuid4().hex[:6]}"
customer = input("Customer ID [CUST1001]: ").strip() or "CUST1001"
print("Type a question (or 'quit').")
while True:
    msg = input("\nYou: ").strip()
    if msg.lower() in {"quit", "exit"}:
        break
    r = httpx.post(f"{BASE}/api/v1/chat", headers={"X-API-Key": KEY}, timeout=60,
                   json={"session_id": session, "customer_id": customer, "message": msg}).json()
    print(f"Bot [{r['agent']} | {r['intent']} | conf {r['confidence']}]: {r['answer']}")
    for s in r["sources"]:
        print(f"   source: {s['document']} ({s['chunk_id']}, score {s['score']})")
    if r["case_id"]:
        print(f"   ESCALATED, case {r['case_id']}")

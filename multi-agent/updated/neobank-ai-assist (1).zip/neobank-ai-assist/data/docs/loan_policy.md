# NeoBank Retail Loan Policy (v2.4)

## Personal loan
Personal loans range from Rs 50,000 to Rs 25,00,000 with tenure of 12 to 60 months. Interest rates range from 10.5% to 18% per annum depending on credit score and income. A processing fee of 1.5% of the loan amount plus GST applies.

## Eligibility for personal loans
Applicants must be 21 to 60 years old, have a minimum net monthly income of Rs 25,000, and a credit score of 700 or above. Total EMIs including the new loan must not exceed 50% of net monthly income (FOIR limit).

## Home loan
Home loans are offered up to 80% of the property value for loans above Rs 30 lakh and up to 90% for loans up to Rs 30 lakh. Tenure is up to 30 years. Interest rates start at 8.6% per annum (floating, linked to repo rate).

## Prepayment and foreclosure
There is no foreclosure charge on floating-rate home loans for individuals. Personal loans can be foreclosed after 12 EMIs with a 3% charge on the outstanding principal.

## Documents for loans
Salaried applicants submit the last 3 months' salary slips, 6 months' bank statements and Form 16. Self-employed applicants submit 2 years of ITR and audited financials.

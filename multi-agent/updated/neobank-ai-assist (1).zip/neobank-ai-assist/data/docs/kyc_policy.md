# NeoBank KYC Policy (v3.2)

## Purpose
Know Your Customer (KYC) checks confirm the identity and address of every customer before an account is opened, in line with RBI Master Direction on KYC.

## Documents required for individuals
A customer must submit one Officially Valid Document (OVD) for identity and address. Accepted OVDs are: passport, driving licence, voter ID card, Aadhaar (masked or offline XML), and NREGA job card. A PAN card or Form 60 is mandatory in addition to the OVD. One recent passport-size photograph is required.

## Video KYC
Customers can complete Video KYC from the NeoBank app between 9 AM and 9 PM on all days. A live officer verifies the PAN and Aadhaar and captures a geo-tagged photo. Video KYC accounts get full savings account features immediately.

## Periodic KYC update (Re-KYC)
High-risk customers must update KYC every 2 years, medium-risk every 8 years and low-risk every 10 years. If there is no change in details, a self-declaration through the app or net banking is sufficient.

## Minimum KYC accounts
Accounts opened with OTP-based e-KYC have a balance limit of Rs 1,00,000 and must be converted to full KYC within 12 months.

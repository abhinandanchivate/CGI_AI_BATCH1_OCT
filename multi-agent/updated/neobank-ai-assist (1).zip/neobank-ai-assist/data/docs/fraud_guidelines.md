# NeoBank Fraud Reporting and Customer Protection Guidelines

## Report immediately
If you notice an unauthorised transaction, block your card instantly from the app or call 1800-000-1234 (24x7). Report the fraud within 3 working days to get zero liability protection as per RBI guidelines on customer liability.

## Customer liability
Zero liability applies when the fraud is due to bank negligence, or when a third-party breach is reported within 3 working days. Limited liability (up to Rs 10,000 to Rs 25,000 depending on account type) applies when reported within 4 to 7 working days. Beyond 7 days, liability is decided as per the board-approved policy.

## Resolution timeline
The bank credits the disputed amount (shadow credit) within 10 working days of the report. The complaint is resolved within 90 days.

## Never share
NeoBank never asks for your OTP, PIN, CVV or full card number over phone, SMS, email or chat. Do not install screen-sharing apps on request from callers.

# NeoBank Debit and Credit Card Fees (effective April 2026)

## Debit card
The Classic debit card has an annual fee of Rs 150 plus GST. The Platinum debit card has an annual fee of Rs 500 plus GST and includes airport lounge access twice per quarter. Card replacement costs Rs 200 plus GST.

## ATM withdrawals
Five free transactions per month at NeoBank ATMs and three free transactions at other banks' ATMs in metro cities. Beyond the free limit, each financial transaction costs Rs 21 plus GST.

## Credit card
The Rewards credit card has a joining fee of Rs 499, waived on spending Rs 50,000 in a year. Late payment fees range from Rs 100 to Rs 1,300 depending on the outstanding amount. Finance charges are 3.5% per month on revolving balances. Cash advance fee is 2.5% of the amount, minimum Rs 500.

## Foreign currency transactions
A foreign currency markup of 3.5% applies on international transactions for both debit and credit cards.

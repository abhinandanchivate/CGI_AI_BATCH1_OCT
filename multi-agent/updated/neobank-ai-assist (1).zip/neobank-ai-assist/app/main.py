"""FastAPI application entry point.  Run:  uvicorn app.main:app --reload"""
import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from app.api.rag_routes import router as rag_router
from app.api.routes import router
from app.config import get_settings
from app.llm.client import get_llm
from app.rag.retriever import get_retriever

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")


@asynccontextmanager
async def lifespan(app: FastAPI):
    get_retriever()            # build the RAG index once at startup
    yield


settings = get_settings()
app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan,
              description="Multi-agent banking assistant with Retrieval-Augmented Generation.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def add_request_id(request: Request, call_next):
    rid = uuid.uuid4().hex[:12]
    start = time.perf_counter()
    response = await call_next(request)
    response.headers["X-Request-ID"] = rid
    response.headers["X-Process-Time-ms"] = f"{(time.perf_counter() - start) * 1000:.1f}"
    return response


@app.get("/health", tags=["System"])
def health():
    r = get_retriever()
    return {"status": "ok", "llm_provider": get_llm().provider,      # effective provider after fallback
            "embedder": type(r.embedder).__name__, "indexed_chunks": len(r.store),
            "indexed_at": r.indexed_at}


app.include_router(router)
app.include_router(rag_router)

"""Pydantic models: the contract between the API and its clients."""
from typing import List, Optional
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    session_id: str = Field(..., examples=["sess-001"])
    customer_id: str = Field(..., examples=["CUST1001"])
    message: str = Field(..., min_length=1, max_length=2000,
                         examples=["What documents do I need for KYC?"])


class Source(BaseModel):
    document: str
    chunk_id: str
    score: float
    snippet: str


class TraceStep(BaseModel):
    agent: str
    action: str
    duration_ms: float


class ChatResponse(BaseModel):
    session_id: str
    intent: str
    agent: str
    answer: str
    confidence: float
    sources: List[Source] = []
    trace: List[TraceStep] = []
    escalated: bool = False
    case_id: Optional[str] = None


class EMIRequest(BaseModel):
    principal: float = Field(..., gt=0, examples=[500000])
    annual_rate: float = Field(..., gt=0, lt=50, examples=[10.5])
    tenure_months: int = Field(..., gt=0, le=360, examples=[60])


class EMIResponse(BaseModel):
    emi: float
    total_payment: float
    total_interest: float


# ---------------- RAG API ----------------
class SearchRequest(BaseModel):
    query: str = Field(..., min_length=2, examples=["video kyc timings"])
    top_k: int = Field(3, ge=1, le=10)
    document: Optional[str] = Field(None, examples=["kyc_policy"], description="Only search this document")
    min_score: Optional[float] = Field(None, ge=0, le=1, description="Hide hits below this score")


class SearchHit(BaseModel):
    document: str
    chunk_id: str
    section: str
    score: float
    passed_threshold: bool
    snippet: str


class AskRequest(BaseModel):
    question: str = Field(..., min_length=2, max_length=2000, examples=["How do I do video KYC?"])
    top_k: Optional[int] = Field(None, ge=1, le=10)
    document: Optional[str] = None
    min_score: Optional[float] = Field(None, ge=0, le=1)
    include_prompt: bool = Field(False, description="Return the exact prompt sent to the LLM")


class AskResponse(BaseModel):
    question: str
    answer: str
    grounded: bool
    confidence: float
    sources: List[Source] = []
    prompt: Optional[str] = None


class DocumentInfo(BaseModel):
    name: str
    filename: str
    title: str
    size_bytes: int
    modified: str
    sections: int
    chunks: int


class ChunkInfo(BaseModel):
    chunk_id: str
    document: str
    section: str
    text: str


class DocumentDetail(BaseModel):
    name: str
    filename: str
    title: str
    content: str
    chunks: List[ChunkInfo]


class DocumentCreate(BaseModel):
    name: str = Field(..., examples=["fixed_deposits"], description="2-64 chars: a-z, 0-9, _ or -")
    content: str = Field(..., min_length=1, examples=["# NeoBank Fixed Deposits\n\n## Interest rates\nOne-year FDs earn 7% p.a."])
    overwrite: bool = False


class IngestResponse(BaseModel):
    status: str = "indexed"
    documents: int
    chunks: int
    embedder: str
    indexed_at: str


class DocumentChangeResponse(BaseModel):
    document: str
    action: str
    index: IngestResponse


class RagStats(BaseModel):
    embedder: Optional[str]
    documents: int
    chunks: int
    chunks_per_document: dict
    indexed_at: Optional[str]
    chunk_size: int
    chunk_overlap: int
    top_k: int
    min_retrieval_score: float


class EvalRequest(BaseModel):
    top_k: Optional[int] = Field(None, ge=1, le=10)

"""RAG endpoints: knowledge-base documents, chunks, search, ask, index and evaluation.
All need X-API-Key; endpoints that change the knowledge base also need X-Admin-Key."""
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status

from app.config import get_settings
from app.rag.document_store import DocumentStore
from app.rag.evaluate import evaluate
from app.rag.pipeline import answer_question
from app.rag.retriever import get_retriever
from app.schemas import (AskRequest, AskResponse, ChunkInfo, DocumentChangeResponse, DocumentCreate,
                         DocumentDetail, DocumentInfo, EvalRequest, IngestResponse, RagStats,
                         SearchHit, SearchRequest)
from app.services.security import mask_pii, require_admin_key, require_api_key

router = APIRouter(prefix="/api/v1/rag", tags=["RAG"], dependencies=[Depends(require_api_key)])
ADMIN = [Depends(require_admin_key)]


def _chunk_info(c) -> ChunkInfo:
    return ChunkInfo(chunk_id=c.chunk_id, document=c.document, section=c.section, text=c.text)


def _reindex(name: str, action: str) -> DocumentChangeResponse:
    return DocumentChangeResponse(document=name, action=action, index=IngestResponse(**get_retriever().ingest()))


def _bad_request(exc: Exception):
    raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc))


# ---------- documents ----------
@router.get("/documents", response_model=List[DocumentInfo])
def list_documents():
    """Every document in the knowledge base, with how many chunks it produced."""
    per_doc = get_retriever().stats()["chunks_per_document"]
    return [DocumentInfo(**d, chunks=per_doc.get(d["name"], 0)) for d in DocumentStore().list()]


@router.get("/documents/{name}", response_model=DocumentDetail)
def get_document(name: str):
    """One document's full text and the chunks it was cut into."""
    try:
        doc = DocumentStore().get(name)
    except ValueError as exc:
        _bad_request(exc)
    if not doc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Document '{name}' not found")
    return DocumentDetail(**doc, chunks=[_chunk_info(c) for c in get_retriever().list_chunks(name)])


@router.post("/documents", response_model=DocumentChangeResponse,
             status_code=status.HTTP_201_CREATED, dependencies=ADMIN)
def create_document(req: DocumentCreate):
    """Add (or replace) a Markdown document from JSON, then re-index."""
    try:
        DocumentStore().save(req.name, req.content, overwrite=req.overwrite)
    except FileExistsError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc))
    except ValueError as exc:
        _bad_request(exc)
    return _reindex(req.name, "replaced" if req.overwrite else "created")


@router.post("/documents/upload", response_model=DocumentChangeResponse,
             status_code=status.HTTP_201_CREATED, dependencies=ADMIN)
async def upload_document(file: UploadFile = File(...), name: Optional[str] = Query(None),
                          overwrite: bool = Query(False)):
    """Upload a .md or .txt file, then re-index. The name defaults to the file name."""
    ext = Path(file.filename or "").suffix.lower()
    doc_name = (name or Path(file.filename or "").stem).lower().replace(" ", "_")
    raw = await file.read(get_settings().max_upload_kb * 1024 + 1)
    try:
        content = raw.decode("utf-8")
    except UnicodeDecodeError:
        _bad_request(ValueError("File must be UTF-8 text"))
    try:
        DocumentStore().save(doc_name, content, overwrite=overwrite, ext=ext)
    except FileExistsError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc))
    except ValueError as exc:
        _bad_request(exc)
    return _reindex(doc_name, "replaced" if overwrite else "uploaded")


@router.delete("/documents/{name}", response_model=DocumentChangeResponse, dependencies=ADMIN)
def delete_document(name: str):
    """Remove a document from the knowledge base, then re-index."""
    try:
        deleted = DocumentStore().delete(name)
    except ValueError as exc:
        _bad_request(exc)
    if not deleted:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Document '{name}' not found")
    return _reindex(name, "deleted")


# ---------- chunks ----------
@router.get("/chunks", response_model=List[ChunkInfo])
def list_chunks(document: Optional[str] = Query(None, description="Only chunks of this document")):
    return [_chunk_info(c) for c in get_retriever().list_chunks(document)]


@router.get("/chunks/{chunk_id}", response_model=ChunkInfo)
def get_chunk(chunk_id: str):
    """Chunk IDs contain '#': encode it as %23, e.g. /chunks/card_fees%231.0"""
    chunk = get_retriever().get_chunk(chunk_id)
    if not chunk:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Chunk '{chunk_id}' not found")
    return _chunk_info(chunk)


# ---------- retrieval and answering ----------
@router.post("/search", response_model=List[SearchHit])
def search(req: SearchRequest):
    """Retrieval only (no LLM): see which chunks match and whether they pass the threshold."""
    threshold = get_settings().min_retrieval_score
    hits = get_retriever().search(mask_pii(req.query), req.top_k, document=req.document)
    if req.min_score is not None:
        hits = [h for h in hits if h[1] >= req.min_score]
    return [SearchHit(document=c.document, chunk_id=c.chunk_id, section=c.section, score=round(s, 3),
                      passed_threshold=s >= threshold, snippet=c.text[:200]) for c, s in hits]


@router.post("/ask", response_model=AskResponse)
def ask(req: AskRequest):
    """Full RAG without agents: retrieve -> threshold -> prompt -> LLM -> cited answer."""
    question = mask_pii(req.question)
    r = answer_question(question, top_k=req.top_k, document=req.document, min_score=req.min_score)
    return AskResponse(question=question, answer=r.answer, grounded=r.grounded, confidence=r.confidence,
                       sources=r.sources, prompt=r.prompt if req.include_prompt else None)


# ---------- index management ----------
@router.post("/ingest", response_model=IngestResponse, dependencies=ADMIN)
def ingest():
    """Rebuild the whole index, e.g. after editing files in data/docs by hand."""
    return IngestResponse(**get_retriever().ingest())


@router.get("/stats", response_model=RagStats)
def stats():
    return RagStats(**get_retriever().stats())


@router.post("/evaluate")
def run_evaluation(req: EvalRequest = EvalRequest()):
    """Score retrieval (hit rate, MRR) and answers on data/eval/rag_eval.json."""
    return evaluate(top_k=req.top_k)

"""API-key auth and PII masking (applied before logging or sending text to an LLM)."""
import re
from fastapi import Header, HTTPException, status
from app.config import get_settings

# Order matters: CARD (13-16 digits) must run before AADHAAR (12 digits),
# otherwise the first 12 digits of a card would be taken as an Aadhaar number.
PII_PATTERNS = {
    "PAN": re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b"),
    "CARD": re.compile(r"\b\d(?:[ -]?\d){12,15}\b"),
    "AADHAAR": re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b"),
    "PHONE": re.compile(r"(?<!\d)(?:\+91[\s-]?)?[6-9]\d{9}(?!\d)"),
    "EMAIL": re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b"),
}


def mask_pii(text: str) -> str:
    for label, pattern in PII_PATTERNS.items():
        text = pattern.sub(f"[{label}_REDACTED]", text)
    return text


async def require_api_key(x_api_key: str = Header(..., alias="X-API-Key")) -> str:
    if x_api_key != get_settings().api_key:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key")
    return x_api_key


async def require_admin_key(x_admin_key: str = Header(..., alias="X-Admin-Key")) -> str:
    """Second key for endpoints that change the knowledge base (add, delete, re-index)."""
    if x_admin_key != get_settings().admin_api_key:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin key required")
    return x_admin_key

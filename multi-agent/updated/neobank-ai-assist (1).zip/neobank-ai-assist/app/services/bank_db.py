"""Mock core-banking adapter. Replace with real CBS/API calls in production."""
import json
from functools import lru_cache
from pathlib import Path
from typing import Optional
from app.config import get_settings


@lru_cache
def _load() -> dict:
    return json.loads(Path(get_settings().customers_file).read_text(encoding="utf-8"))


def get_customer(customer_id: str) -> Optional[dict]:
    return _load().get(customer_id)


def get_balance(customer_id: str) -> Optional[dict]:
    c = get_customer(customer_id)
    if not c:
        return None
    return {"account_no": mask_account(c["account_no"]), "account_type": c["account_type"],
            "balance": c["balance"], "currency": "INR"}


def get_transactions(customer_id: str, limit: int = 5) -> Optional[list]:
    c = get_customer(customer_id)
    return None if not c else c["transactions"][:limit]


def mask_account(acc: str) -> str:
    return "X" * (len(acc) - 4) + acc[-4:]

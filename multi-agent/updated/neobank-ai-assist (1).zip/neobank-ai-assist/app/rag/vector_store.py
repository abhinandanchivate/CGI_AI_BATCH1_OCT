"""Minimal in-memory vector store using cosine similarity (swap for FAISS/Chroma in production)."""
from typing import List, Optional, Tuple
import numpy as np
from app.rag.chunker import Chunk


class InMemoryVectorStore:
    def __init__(self):
        self.vectors: np.ndarray | None = None
        self.chunks: List[Chunk] = []

    @staticmethod
    def _normalize(m: np.ndarray) -> np.ndarray:
        norms = np.linalg.norm(m, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return m / norms

    def add(self, chunks: List[Chunk], vectors: np.ndarray) -> None:
        self.chunks = list(chunks)
        self.vectors = self._normalize(vectors)

    def search(self, query_vec: np.ndarray, top_k: int = 3,
               document: Optional[str] = None) -> List[Tuple[Chunk, float]]:
        if self.vectors is None or not self.chunks:
            return []
        q = self._normalize(query_vec.reshape(1, -1))
        scores = (self.vectors @ q.T).ravel()          # cosine similarity
        if document:                                    # metadata filter: only this document
            keep = np.array([c.document == document for c in self.chunks])
            scores = np.where(keep, scores, -np.inf)
        idx = np.argsort(-scores)[:top_k]
        return [(self.chunks[i], float(scores[i])) for i in idx if np.isfinite(scores[i])]

    def __len__(self) -> int:
        return len(self.chunks)

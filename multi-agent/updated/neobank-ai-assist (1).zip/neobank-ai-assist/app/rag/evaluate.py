"""RAG evaluation: run a gold question set and measure retrieval and answer quality.

Metrics
- hit_rate_at_1: share of questions whose best chunk is the expected one
- hit_rate_at_k: share whose expected chunk is anywhere in the top k
- mrr:           mean reciprocal rank (1 if first, 1/2 if second, ... 0 if missing)
- answer_pass_rate: share of answers containing every must_contain phrase
"""
import json
from pathlib import Path
from typing import Optional

from app.config import get_settings
from app.llm.client import get_llm
from app.rag.pipeline import answer_question
from app.rag.retriever import get_retriever


def _is_expected(chunk, item: dict) -> bool:
    if chunk.document != item["expected_document"]:
        return False
    return not item.get("expected_section") or chunk.section == item["expected_section"]


def evaluate(eval_file: Optional[str] = None, top_k: Optional[int] = None) -> dict:
    s = get_settings()
    items = json.loads(Path(eval_file or s.eval_file).read_text(encoding="utf-8"))
    k = top_k or s.top_k
    results, hit1, hitk, rr_sum, passed = [], 0, 0, 0.0, 0
    for item in items:
        hits = get_retriever().search(item["question"], top_k=k)
        rank = next((i + 1 for i, (c, _) in enumerate(hits) if _is_expected(c, item)), None)
        ans = answer_question(item["question"], top_k=k)
        missing = [m for m in item.get("must_contain", []) if m.lower() not in ans.answer.lower()]
        hit1 += rank == 1
        hitk += rank is not None
        rr_sum += 1 / rank if rank else 0.0
        passed += not missing
        results.append({"question": item["question"], "expected": item["expected_document"]
                        + (f" / {item['expected_section']}" if item.get("expected_section") else ""),
                        "rank": rank, "top_chunk": hits[0][0].chunk_id if hits else None,
                        "top_score": round(hits[0][1], 3) if hits else None,
                        "answer_ok": not missing, "missing": missing})
    n = len(items) or 1
    return {"questions": len(items), "top_k": k,
            "embedder": type(get_retriever().embedder).__name__, "llm_provider": get_llm().provider,
            "hit_rate_at_1": round(hit1 / n, 3), "hit_rate_at_k": round(hitk / n, 3),
            "mrr": round(rr_sum / n, 3), "answer_pass_rate": round(passed / n, 3),
            "results": results}

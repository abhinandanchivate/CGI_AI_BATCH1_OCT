"""Tiny text helpers shared by the retriever and the offline LLM stub."""
import re

STOPWORDS = set("""a an the is are was were do does did i my me we you your to of for in on and or what
how can could with be by at it this that which who when where there any about please tell need show""".split())


def stem(word: str) -> str:
    """Plural strip + prefix stemmer: 'loans'->'loan', 'foreclosure'->'forecl'. Crude but dependency-free."""
    if len(word) > 3 and word.endswith("s") and not word.endswith("ss"):
        word = word[:-1]
    return word[:6]


def tokenize(text: str) -> list:
    return [stem(w) for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOPWORDS]

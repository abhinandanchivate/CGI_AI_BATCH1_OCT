"""Knowledge-base files on disk: list, read, save and delete policy documents safely."""
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from app.config import get_settings

NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{1,63}$")   # safe file names only: no "../", no spaces
ALLOWED_EXT = (".md", ".txt")


class DocumentStore:
    def __init__(self, docs_dir: Optional[str] = None):
        self.dir = Path(docs_dir or get_settings().docs_dir)

    @staticmethod
    def validate_name(name: str) -> str:
        if not NAME_RE.match(name):
            raise ValueError("Name must be 2-64 characters: lower-case letters, digits, '_' or '-'")
        return name

    def _find(self, name: str) -> Optional[Path]:
        for ext in ALLOWED_EXT:
            path = self.dir / f"{name}{ext}"
            if path.exists():
                return path
        return None

    @staticmethod
    def _title(text: str, fallback: str) -> str:
        m = re.search(r"^# (.+)$", text, re.MULTILINE)
        return m.group(1).strip() if m else fallback

    def list(self) -> List[dict]:
        out = []
        for path in sorted(p for p in self.dir.iterdir() if p.suffix in ALLOWED_EXT):
            text = path.read_text(encoding="utf-8")
            out.append({
                "name": path.stem, "filename": path.name, "title": self._title(text, path.stem),
                "size_bytes": path.stat().st_size,
                "modified": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(timespec="seconds"),
                "sections": len(re.findall(r"^## ", text, re.MULTILINE)),
            })
        return out

    def get(self, name: str) -> Optional[dict]:
        path = self._find(self.validate_name(name))
        if not path:
            return None
        text = path.read_text(encoding="utf-8")
        return {"name": name, "filename": path.name, "title": self._title(text, name), "content": text}

    def save(self, name: str, content: str, overwrite: bool = False, ext: str = ".md") -> dict:
        self.validate_name(name)
        if ext not in ALLOWED_EXT:
            raise ValueError(f"Only {', '.join(ALLOWED_EXT)} files are allowed")
        if not content.strip():
            raise ValueError("Document is empty")
        if len(content.encode("utf-8")) > get_settings().max_upload_kb * 1024:
            raise ValueError(f"Document is larger than {get_settings().max_upload_kb} KB")
        existing = self._find(name)
        if existing and not overwrite:
            raise FileExistsError(f"Document '{name}' already exists; set overwrite=true to replace it")
        if existing:
            existing.unlink()                 # replacing may change .txt <-> .md
        path = self.dir / f"{name}{ext}"
        path.write_text(content, encoding="utf-8")
        return {"name": name, "filename": path.name, "title": self._title(content, name),
                "size_bytes": path.stat().st_size}

    def delete(self, name: str) -> bool:
        path = self._find(self.validate_name(name))
        if not path:
            return False
        if len(self.list()) <= 1:
            raise ValueError("Cannot delete the last document: the knowledge base would be empty")
        path.unlink()
        return True

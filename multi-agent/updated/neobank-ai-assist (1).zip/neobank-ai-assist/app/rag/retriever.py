"""Ingestion + retrieval pipeline: load -> chunk -> embed -> index -> search."""
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Tuple

from app.config import get_settings
from app.rag.chunker import Chunk, chunk_document
from app.rag.embeddings import get_embedder
from app.rag.vector_store import InMemoryVectorStore

log = logging.getLogger(__name__)


class Retriever:
    def __init__(self):
        self.settings = get_settings()
        self.store = InMemoryVectorStore()
        self.embedder = None
        self.indexed_at: Optional[str] = None
        self.document_count = 0
        self._lock = threading.Lock()

    def ingest(self, docs_dir: str | None = None) -> dict:
        docs_path = Path(docs_dir or self.settings.docs_dir)
        chunks: List[Chunk] = []
        files = sorted(docs_path.glob("*.md")) + sorted(docs_path.glob("*.txt"))
        for f in files:
            chunks.extend(chunk_document(f.stem, f.read_text(encoding="utf-8"),
                                         self.settings.chunk_size, self.settings.chunk_overlap))
        if not chunks:
            raise ValueError(f"No documents found in {docs_path}")
        texts = [c.text for c in chunks]
        embedder = get_embedder(self.settings.embedding_backend)
        try:
            embedder.fit(texts)
            vectors = embedder.embed(texts)
        except Exception as exc:   # e.g. Gemini key invalid or offline
            log.warning("Embedding backend failed (%s); falling back to TF-IDF", exc)
            embedder = get_embedder("tfidf")
            embedder.fit(texts)
            vectors = embedder.embed(texts)
        new_store = InMemoryVectorStore()
        new_store.add(chunks, vectors)
        with self._lock:                 # swap in the finished index in one step
            self.store, self.embedder = new_store, embedder
            self.document_count = len(files)
            self.indexed_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
        log.info("Indexed %d chunks from %d documents", len(chunks), len(files))
        return {"documents": len(files), "chunks": len(chunks),
                "embedder": type(embedder).__name__, "indexed_at": self.indexed_at}

    def search(self, query: str, top_k: int | None = None,
               document: Optional[str] = None) -> List[Tuple[Chunk, float]]:
        if self.embedder is None:
            self.ingest()
        k = top_k or self.settings.top_k
        embedder, store = self.embedder, self.store     # read both together
        if hasattr(embedder, "embed_query"):           # Gemini: query-specific embedding
            q_vec = embedder.embed_query(query)
        else:
            q_vec = embedder.embed([query])[0]
        return store.search(q_vec, k, document=document)

    def list_chunks(self, document: Optional[str] = None) -> List[Chunk]:
        return [c for c in self.store.chunks if document is None or c.document == document]

    def get_chunk(self, chunk_id: str) -> Optional[Chunk]:
        return next((c for c in self.store.chunks if c.chunk_id == chunk_id), None)

    def stats(self) -> dict:
        per_doc: dict = {}
        for c in self.store.chunks:
            per_doc[c.document] = per_doc.get(c.document, 0) + 1
        s = self.settings
        return {"embedder": type(self.embedder).__name__ if self.embedder else None,
                "documents": self.document_count, "chunks": len(self.store),
                "chunks_per_document": per_doc, "indexed_at": self.indexed_at,
                "chunk_size": s.chunk_size, "chunk_overlap": s.chunk_overlap,
                "top_k": s.top_k, "min_retrieval_score": s.min_retrieval_score}


_retriever: Retriever | None = None


def get_retriever() -> Retriever:
    """Singleton so the index is built once per process."""
    global _retriever
    if _retriever is None:
        _retriever = Retriever()
        _retriever.ingest()
    return _retriever

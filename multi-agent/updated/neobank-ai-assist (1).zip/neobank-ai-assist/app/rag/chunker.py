"""Split documents into overlapping, section-aware chunks."""
import re
from dataclasses import dataclass, field
from typing import List


@dataclass
class Chunk:
    chunk_id: str
    document: str
    section: str
    text: str
    metadata: dict = field(default_factory=dict)


def split_sections(markdown: str) -> List[tuple]:
    """Return (heading, body) pairs using '## ' headings as boundaries."""
    sections, heading, buf = [], "Introduction", []
    for line in markdown.splitlines():
        if line.startswith("## "):
            if buf:
                sections.append((heading, "\n".join(buf).strip()))
            heading, buf = line[3:].strip(), []
        elif line.startswith("# "):
            continue  # document title, stored as metadata instead
        else:
            buf.append(line)
    if buf:
        sections.append((heading, "\n".join(buf).strip()))
    return [(h, b) for h, b in sections if b]


def sliding_window(text: str, size: int, overlap: int) -> List[str]:
    """Character window that snaps to sentence ends so chunks stay readable."""
    if len(text) <= size:
        return [text]
    sentences = re.split(r"(?<=[.!?])\s+", text)
    chunks, current = [], ""
    for sent in sentences:
        if len(current) + len(sent) + 1 > size and current:
            chunks.append(current.strip())
            current = current[-overlap:] + " " + sent  # carry overlap forward
        else:
            current += " " + sent
    if current.strip():
        chunks.append(current.strip())
    return chunks


def chunk_document(doc_name: str, markdown: str, size: int = 500, overlap: int = 80) -> List[Chunk]:
    title_match = re.search(r"^# (.+)$", markdown, re.MULTILINE)
    title = title_match.group(1).strip() if title_match else doc_name
    chunks: List[Chunk] = []
    for s_idx, (heading, body) in enumerate(split_sections(markdown)):
        for w_idx, piece in enumerate(sliding_window(body, size, overlap)):
            chunks.append(Chunk(
                chunk_id=f"{doc_name}#{s_idx}.{w_idx}",
                document=doc_name,
                section=heading,
                # Prefix the heading so retrieval matches section topics too
                text=f"{heading}: {piece}",
                metadata={"title": title},
            ))
    return chunks

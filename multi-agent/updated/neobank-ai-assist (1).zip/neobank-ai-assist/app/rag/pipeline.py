"""The RAG answer pipeline used by the Knowledge Agent and by POST /rag/ask:
retrieve -> apply threshold -> build prompt -> generate -> cite."""
from dataclasses import dataclass, field
from typing import List, Optional

from app.config import get_settings
from app.llm.client import get_llm
from app.rag.retriever import get_retriever

SYSTEM_PROMPT = (
    "You are NeoBank's policy assistant. Answer ONLY from the CONTEXT. "
    "If the answer is not in the context, say you don't know and offer a human agent. "
    "Cite sources as [1], [2]. Never ask for OTP, PIN, CVV or full card numbers."
)
REFUSAL = ("I couldn't find that in NeoBank's policy documents. "
           "Would you like me to connect you to a customer-care executive?")


@dataclass
class RagAnswer:
    answer: str
    confidence: float
    grounded: bool                       # False = refused because no evidence passed the threshold
    sources: List[dict] = field(default_factory=list)
    prompt: Optional[str] = None


def build_prompt(question: str, hits) -> str:
    ctx = "\n".join(f"[{i + 1}] {c.text}" for i, (c, _) in enumerate(hits))
    return f"CONTEXT:\n{ctx}\nQUESTION: {question}"


def to_sources(hits) -> List[dict]:
    return [{"document": c.document, "chunk_id": c.chunk_id, "score": round(s, 3),
             "snippet": c.text[:160]} for c, s in hits]


def retrieve(question: str, top_k: Optional[int] = None, document: Optional[str] = None,
             min_score: Optional[float] = None):
    s = get_settings()
    threshold = s.min_retrieval_score if min_score is None else min_score
    hits = get_retriever().search(question, top_k=top_k or s.top_k, document=document)
    return [h for h in hits if h[1] >= threshold]


def answer_question(question: str, top_k: Optional[int] = None, document: Optional[str] = None,
                    min_score: Optional[float] = None) -> RagAnswer:
    hits = retrieve(question, top_k, document, min_score)
    if not hits:                          # grounding guardrail: no evidence -> no answer
        return RagAnswer(REFUSAL, confidence=0.2, grounded=False)
    prompt = build_prompt(question, hits)
    text = get_llm().generate(SYSTEM_PROMPT, prompt)
    return RagAnswer(text, confidence=round(min(0.95, 0.5 + hits[0][1]), 2), grounded=True,
                     sources=to_sources(hits), prompt=prompt)

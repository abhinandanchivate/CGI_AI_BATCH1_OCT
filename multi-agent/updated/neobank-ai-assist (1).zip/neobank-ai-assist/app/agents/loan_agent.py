"""Loan Agent: EMI calculator, eligibility check, and loan-policy RAG."""
import re
from app.agents.base import AgentContext, AgentResult, BaseAgent
from app.agents.knowledge_agent import KnowledgeAgent
from app.services import bank_db

FOIR_LIMIT = 0.50
MIN_SCORE = 700
MIN_INCOME = 25000


def calculate_emi(principal: float, annual_rate: float, months: int) -> dict:
    r = annual_rate / 12 / 100
    emi = principal / months if r == 0 else principal * r * (1 + r) ** months / ((1 + r) ** months - 1)
    total = emi * months
    return {"emi": round(emi, 2), "total_payment": round(total, 2), "total_interest": round(total - principal, 2)}


def parse_loan_query(text: str) -> dict:
    """Pull amount, rate and tenure out of free text, e.g. 'EMI for 5 lakh at 10.5% for 5 years'."""
    t = text.lower().replace(",", "")
    out = {}
    m = re.search(r"(\d+(?:\.\d+)?)\s*(lakh|lac|crore|cr|k)\b", t)
    if m:
        mult = {"lakh": 1e5, "lac": 1e5, "crore": 1e7, "cr": 1e7, "k": 1e3}[m.group(2)]
        out["principal"] = float(m.group(1)) * mult
    else:
        m = re.search(r"(?:rs\.?|inr|₹)\s*(\d{4,})", t) or re.search(r"\b(\d{5,})\b", t)
        if m:
            out["principal"] = float(m.group(1))
    m = re.search(r"(\d+(?:\.\d+)?)\s*%", t)
    if m:
        out["annual_rate"] = float(m.group(1))
    m = re.search(r"(\d+)\s*(year|yr|month|mo)", t)
    if m:
        n = int(m.group(1))
        out["tenure_months"] = n * 12 if m.group(2).startswith(("year", "yr")) else n
    return out


class LoanAgent(BaseAgent):
    name = "loan_agent"
    description = "EMI calculation, eligibility (FOIR, credit score) and loan-policy questions."

    def __init__(self):
        self.knowledge = KnowledgeAgent()
        self.last_params: dict = {}          # session_id -> last EMI inputs (for follow-ups)

    def run(self, ctx: AgentContext) -> AgentResult:
        text = ctx.message.lower()
        params = parse_loan_query(ctx.message)
        previous = self.last_params.get(ctx.session_id)
        if previous and params and "eligib" not in text:   # "and for 15 years?"
            params = {**previous, **params}
            text += " emi"

        if "emi" in text and "principal" in params:
            params.setdefault("annual_rate", 10.5)       # policy floor rate as default
            params.setdefault("tenure_months", 60)
            r = calculate_emi(params["principal"], params["annual_rate"], params["tenure_months"])
            self.last_params[ctx.session_id] = params
            return AgentResult(
                f"For a loan of Rs {params['principal']:,.0f} at {params['annual_rate']}% p.a. for "
                f"{params['tenure_months']} months, your EMI is Rs {r['emi']:,.2f}. "
                f"Total interest: Rs {r['total_interest']:,.2f}; total payable: Rs {r['total_payment']:,.2f}.",
                confidence=0.95, data={**params, **r})

        if "eligib" in text:
            return self._eligibility(ctx, params)

        return self.knowledge.answer(ctx.message, document_filter="loan_policy")

    def _eligibility(self, ctx: AgentContext, params: dict) -> AgentResult:
        c = bank_db.get_customer(ctx.customer_id)
        if not c:
            return AgentResult("I need a valid customer profile to check eligibility.", confidence=0.3)
        principal = params.get("principal", 300000)
        new_emi = calculate_emi(principal, params.get("annual_rate", 12.0), params.get("tenure_months", 60))["emi"]
        foir = (c["existing_emi"] + new_emi) / c["monthly_income"]
        reasons = []
        if c["credit_score"] < MIN_SCORE:
            reasons.append(f"credit score {c['credit_score']} is below {MIN_SCORE}")
        if c["monthly_income"] < MIN_INCOME:
            reasons.append(f"income is below Rs {MIN_INCOME:,}")
        if foir > FOIR_LIMIT:
            reasons.append(f"total EMIs would be {foir:.0%} of income (limit {FOIR_LIMIT:.0%})")
        verdict = "likely eligible" if not reasons else "not eligible right now"
        detail = "" if not reasons else " because " + "; ".join(reasons)
        return AgentResult(
            f"For a personal loan of Rs {principal:,.0f}, you are {verdict}{detail}. "
            f"Estimated EMI: Rs {new_emi:,.2f}. This is indicative; final approval follows document verification.",
            confidence=0.85, data={"foir": round(foir, 3), "eligible": not reasons})

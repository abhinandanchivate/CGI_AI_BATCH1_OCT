"""Shared types for all agents."""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class AgentContext:
    session_id: str
    customer_id: str
    message: str                     # already PII-masked
    history: list = field(default_factory=list)


@dataclass
class AgentResult:
    answer: str
    confidence: float = 0.8
    sources: List[dict] = field(default_factory=list)
    escalated: bool = False
    case_id: Optional[str] = None
    data: dict = field(default_factory=dict)


class BaseAgent(ABC):
    name: str = "base"
    description: str = ""

    @abstractmethod
    def run(self, ctx: AgentContext) -> AgentResult:
        ...

"""Orchestrator: masks PII, routes, runs the agent, applies guardrails and records a trace."""
import logging
import time
from app.agents.account_agent import AccountAgent
from app.agents.base import AgentContext, AgentResult
from app.agents.fraud_agent import FraudAgent
from app.agents.knowledge_agent import KnowledgeAgent
from app.agents.loan_agent import LoanAgent
from app.agents.router import RouterAgent
from app.services.memory import memory
from app.services.security import mask_pii

log = logging.getLogger(__name__)
HANDOFF_THRESHOLD = 0.35


class Orchestrator:
    def __init__(self):
        self.router = RouterAgent()
        self.registry = {                       # add a new agent = one line here
            "account": AccountAgent(),
            "loan": LoanAgent(),
            "knowledge": KnowledgeAgent(),
            "fraud": FraudAgent(),
        }

    def list_agents(self) -> list:
        return [{"intent": k, "name": a.name, "description": a.description} for k, a in self.registry.items()]

    def handle(self, session_id: str, customer_id: str, message: str) -> dict:
        trace = []
        clean = mask_pii(message)                                  # 1. guardrail in
        log.info("session=%s msg=%s", session_id, clean)

        t0 = time.perf_counter()                                   # 2. route
        intent, route_conf = self.router.classify(clean, memory.last_intent(session_id))
        trace.append({"agent": "router", "action": f"intent={intent} ({route_conf})",
                      "duration_ms": round((time.perf_counter() - t0) * 1000, 2)})

        if intent == "greeting":
            result, agent_name = AgentResult(
                "Hello! I'm NeoBank's assistant. I can check balances and transactions, "
                "calculate EMIs, explain KYC, card fees and loan rules, or help report fraud.",
                confidence=0.9), "router"
        else:                                                      # 3. delegate
            agent = self.registry[intent]
            ctx = AgentContext(session_id, customer_id, clean, memory.history(session_id))
            t1 = time.perf_counter()
            result = agent.run(ctx)
            agent_name = agent.name
            trace.append({"agent": agent.name, "action": "run",
                          "duration_ms": round((time.perf_counter() - t1) * 1000, 2)})

        if result.confidence < HANDOFF_THRESHOLD and not result.escalated:   # 4. fallback
            result.answer += " (Type 'agent' anytime to talk to a human.)"

        result.answer = mask_pii(result.answer)                    # 5. guardrail out
        memory.add(session_id, "user", clean)
        memory.add(session_id, "intent", intent)
        memory.add(session_id, "assistant", result.answer)

        return {"session_id": session_id, "intent": intent, "agent": agent_name,
                "answer": result.answer, "confidence": result.confidence,
                "sources": result.sources, "trace": trace,
                "escalated": result.escalated, "case_id": result.case_id}


_orch: Orchestrator | None = None


def get_orchestrator() -> Orchestrator:
    global _orch
    if _orch is None:
        _orch = Orchestrator()
    return _orch

"""Fraud Agent: flags suspicious activity, raises a case, and gives policy-based next steps."""
import uuid
from datetime import datetime
from app.agents.base import AgentContext, AgentResult, BaseAgent
from app.agents.knowledge_agent import KnowledgeAgent
from app.services import bank_db

INTL_HINTS = ["intl", "international", "singapore", "usa", "dubai", "london"]


def flag_transactions(customer: dict) -> list:
    """Simple rules: large debit (>40% of balance) or international POS."""
    flagged = []
    for t in customer["transactions"]:
        desc = t["description"].lower()
        big = t["amount"] < 0 and abs(t["amount"]) > 0.4 * max(customer["balance"], 1)
        intl = any(h in desc for h in INTL_HINTS)
        if big or intl:
            flagged.append({**t, "reason": "international" if intl else "high value"})
    return flagged


class FraudAgent(BaseAgent):
    name = "fraud_agent"
    description = "Detects suspicious transactions, opens a case and escalates to the fraud desk."

    def __init__(self):
        self.knowledge = KnowledgeAgent(document_filter="fraud_guidelines")

    def run(self, ctx: AgentContext) -> AgentResult:
        case_id = f"FRD-{datetime.now():%Y%m%d}-{uuid.uuid4().hex[:6].upper()}"
        customer = bank_db.get_customer(ctx.customer_id)
        flagged = flag_transactions(customer) if customer else []

        lines = [f"I've raised fraud case {case_id} and alerted our fraud desk."]
        if flagged:
            lines.append("These transactions look unusual:")
            lines += [f"- {t['id']} {t['date']} {t['description']} Rs {abs(t['amount']):,.2f} ({t['reason']})"
                      for t in flagged]
        lines.append("Please block your card now from the app or call 1800-000-1234 (24x7).")
        policy = self.knowledge.answer("customer liability report within 3 working days zero liability")
        if policy.sources:
            lines.append("Policy: " + policy.answer)
        lines.append("NeoBank will never ask for your OTP, PIN or CVV.")
        return AgentResult("\n".join(lines), confidence=0.9, sources=policy.sources,
                           escalated=True, case_id=case_id, data={"flagged": flagged})

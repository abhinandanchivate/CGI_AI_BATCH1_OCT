"""Account Agent: balance and transaction look-ups through the bank-data tool."""
from app.agents.base import AgentContext, AgentResult, BaseAgent
from app.services import bank_db


class AccountAgent(BaseAgent):
    name = "account_agent"
    description = "Balances and recent transactions from core banking (tool use, no LLM guessing)."

    def run(self, ctx: AgentContext) -> AgentResult:
        customer = bank_db.get_customer(ctx.customer_id)
        if not customer:
            return AgentResult("I couldn't find an account for this customer ID.", confidence=0.3)

        text = ctx.message.lower()
        if any(w in text for w in ["transaction", "statement", "spent", "debited", "recent"]):
            txns = bank_db.get_transactions(ctx.customer_id, limit=5)
            lines = [f"- {t['date']}: {t['description']} | Rs {t['amount']:,.2f}" for t in txns]
            return AgentResult("Here are your last 5 transactions:\n" + "\n".join(lines),
                               confidence=0.95, data={"transactions": txns})

        bal = bank_db.get_balance(ctx.customer_id)
        return AgentResult(
            f"Hi {customer['name'].split()[0]}, the available balance in your {bal['account_type']} "
            f"account {bal['account_no']} is Rs {bal['balance']:,.2f}.",
            confidence=0.95, data=bal)

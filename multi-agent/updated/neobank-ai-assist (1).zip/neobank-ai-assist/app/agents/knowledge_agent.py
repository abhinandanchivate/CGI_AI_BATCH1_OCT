"""Knowledge Agent: answers policy questions with RAG and cites its sources."""
from typing import Optional
from app.agents.base import AgentContext, AgentResult, BaseAgent
from app.rag.pipeline import answer_question


class KnowledgeAgent(BaseAgent):
    name = "knowledge_agent"
    description = "Grounded answers on KYC, cards, fees and policies using RAG."

    def __init__(self, document_filter: Optional[str] = None):
        self.document_filter = document_filter

    def answer(self, question: str, document_filter: Optional[str] = None) -> AgentResult:
        r = answer_question(question, document=document_filter or self.document_filter)
        return AgentResult(r.answer, confidence=r.confidence, sources=r.sources)

    def run(self, ctx: AgentContext) -> AgentResult:
        return self.answer(ctx.message)

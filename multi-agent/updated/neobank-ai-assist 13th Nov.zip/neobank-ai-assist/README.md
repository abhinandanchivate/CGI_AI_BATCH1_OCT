# NeoBank AI Assist — Multi-Agent Banking Assistant with RAG

A teaching case study: a FastAPI service where an orchestrator routes customer messages to
specialist agents (Account, Loan, Knowledge, Fraud). Policy answers are grounded in bank
documents through Retrieval-Augmented Generation (RAG) and returned with citations.

Uses **Google Gemini** as the LLM (and optionally for embeddings). Without a Gemini key it still
runs fully offline: a TF-IDF retriever and an extractive "mock" LLM take over automatically.

## Using Gemini
1. Get a free API key at https://aistudio.google.com/apikey
2. In `.env` set:
```
LLM_PROVIDER=gemini
GEMINI_API_KEY=your-key
GEMINI_MODEL=gemini-2.5-flash          # any model your key can access
EMBEDDING_BACKEND=gemini               # optional: semantic search with gemini-embedding-001
MIN_RETRIEVAL_SCORE=0.55               # dense scores run higher than TF-IDF; tune with /rag/search
```
3. Restart and check `GET /health`: `llm_provider` should read `gemini`.

If a Gemini call fails (bad key, quota, network), the app logs a warning and answers with the
offline extractive model, so the API never breaks. OpenAI and Anthropic remain optional alternatives.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000/docs for Swagger UI. Use header `X-API-Key: dev-secret-key`.

## Try it
```bash
curl -X POST http://127.0.0.1:8000/api/v1/chat \
  -H "X-API-Key: dev-secret-key" -H "Content-Type: application/json" \
  -d '{"session_id":"s1","customer_id":"CUST1001","message":"Which documents do I need for KYC?"}'
```
Or run the terminal client: `python scripts/demo_client.py`

## RAG API (all under /api/v1/rag, header X-API-Key; * also needs X-Admin-Key)
| Method | Path | Purpose | Session |
| --- | --- | --- | --- |
| GET | /documents | List knowledge-base documents with chunk counts | |
| GET | /documents/{name} | One document's text and its chunks | |
| POST | /documents * | Add or replace a document (JSON), then re-index | |
| POST | /documents/upload * | Upload .md/.txt, .csv table, .pdf, or image (+caption / Gemini vision) | S042 |
| DELETE | /documents/{name} * | Remove a document, then re-index | |
| GET | /chunks?document= | List chunks | |
| GET | /chunks/{chunk_id} | One chunk (encode # as %23) | |
| POST | /chunking/preview | See how a chunking strategy cuts a document | S035 |
| POST | /search | Retrieval only: mode, document filter, threshold, multi-query, expansion | S036 S037 S041 |
| POST | /search/compare | Same query through exact, keyword, vector, hybrid and semantic (LSA) | S036 |
| POST | /ask | Cited answer with guards, live data, faithfulness, cache | S038-S041 |
| POST | /agentic/ask | Agent plans retrieval, checks evidence, retries, answers with a trace | S043 |
| GET | /live | Live data feed with age and stale flag | S039 |
| PUT | /live * | Push new live values (no re-index needed) | S039 |
| POST | /ingest * | Rebuild the index; optionally switch strategy, vector store, embedder | S034 S035 |
| GET | /stats | Index statistics, settings and cache hit rates | S038 |
| POST | /benchmark | Latency per vector store and mode, cold vs cached | S038 |
| POST | /evaluate | Hit rate, precision, recall, MRR, nDCG, correctness, faithfulness | S044 |
| POST | /evaluate/compare | Several configurations side by side | S044 |
| GET | /best-practices | Audit the configuration against RAG guidelines | S045 |

### Advanced RAG modules (S034-S045)
| Session | Topic | Code |
| --- | --- | --- |
| S034 | Vector databases (FAISS, Chroma) | app/rag/vector_store.py |
| S035 | Chunking strategies | app/rag/chunker.py |
| S036 | Semantic search vs exact matching | app/rag/keyword.py, app/rag/embeddings.py (LSA) |
| S037 | Domain-specific RAG | data/glossary.json, app/rag/query.py |
| S038 | Optimising RAG at scale | app/rag/cache.py, app/rag/benchmark.py, HNSW, context budget |
| S039 | Real-time retrieval | app/rag/live.py, auto re-index in app/rag/retriever.py |
| S040 | Challenges in RAG | app/rag/guard.py |
| S041 | Hybrid search and multi-query | app/rag/retriever.py (RRF), app/rag/query.py |
| S042 | Multi-modal RAG | app/rag/multimodal.py, data/samples/ |
| S043 | Agentic RAG | app/rag/agentic.py |
| S044 | RAG evaluation | app/rag/evaluate.py |
| S045 | Guidelines and best practices | app/rag/best_practices.py |

Example:
```bash
curl -X POST http://127.0.0.1:8000/api/v1/rag/agentic/ask -H "X-API-Key: dev-secret-key" \
  -H "Content-Type: application/json" -d '{"question": "What is the forex fee and how do I do video KYC?"}'
curl -X POST http://127.0.0.1:8000/api/v1/rag/documents/upload -H "X-API-Key: dev-secret-key" \
  -H "X-Admin-Key: dev-admin-key" -F "file=@data/samples/atm_network_fees.csv"
```

## Postman
Import `postman/NeoBank_AI_Assist.postman_collection.json` and `postman/NeoBank_AI_Assist.postman_environment.json`,
select the "NeoBank AI Assist - Local" environment and run the collection (all endpoints with test scripts).
Or from the command line: `cd postman && newman run NeoBank_AI_Assist.postman_collection.json -e NeoBank_AI_Assist.postman_environment.json --working-dir .`
See `postman/README.md`.

## Tests
```bash
pytest -q
```

## Project layout
```
app/
  main.py              FastAPI app, middleware, startup indexing
  config.py            Settings from environment variables
  schemas.py           Pydantic request/response models
  api/routes.py        chat, accounts, loans endpoints
  api/rag_routes.py    RAG endpoints (/api/v1/rag/...)
  agents/              router, orchestrator, account, loan, knowledge, fraud
  rag/                 chunker, embeddings, vector_store, retriever, keyword, query, cache,
                       pipeline, guard, live, multimodal, agentic, evaluate, benchmark,
                       best_practices, document_store, text_utils
  llm/client.py        gemini | mock | openai | anthropic
  services/            mock bank DB, security (API key + PII masking), session memory
data/docs/             policy documents indexed by RAG
data/customers.json    mock core-banking data
data/eval/rag_eval.json  12 gold questions for POST /rag/evaluate
data/glossary.json     banking acronyms, synonyms, document routes (S037)
data/live/market.json  simulated live rates feed (S039)
data/samples/          CSV, PDF, image and prompt-injection samples (S040, S042)
tests/                 pytest suite (61 tests incl. advanced RAG S034-S045)
scripts/demo_client.py interactive CLI client
postman/                Postman collection + environment (all 26 endpoints)
```

## Docker
```bash
docker build -t neobank-ai-assist .
docker run -p 8000:8000 --env-file .env neobank-ai-assist
```

All banks, customers, policies and numbers in this project are fictional and for education only.

# Postman collection

Files
- `NeoBank_AI_Assist.postman_collection.json` - 84 requests in 10 folders covering all 26 endpoints, with test scripts (149 assertions)
- `NeoBank_AI_Assist.postman_environment.json` - baseUrl, apiKey, adminKey, customerId
- `lockers_upload.md` - sample file used by the upload request
- `samples/` - CSV, PDF and image used by the S042 multi-modal requests
- `build_collection.py` - regenerates both JSON files (edit this, not the JSON)

## Use in the Postman app
1. Start the API: `uvicorn app.main:app --reload`
2. Import both JSON files (File > Import).
3. Pick the environment **NeoBank AI Assist - Local** (top right).
4. Run the whole collection (Run collection), or open any request and click Send.
5. For "Upload document (file)", if Postman shows a missing file, select `postman/lockers_upload.md`
   in Body > form-data > file. (Postman only reads files from its working directory: Settings > General.)

## Run from the command line (Newman)
```bash
npm install -g newman
cd postman
newman run NeoBank_AI_Assist.postman_collection.json -e NeoBank_AI_Assist.postman_environment.json --working-dir .
```

## Folders
| Folder | What it shows |
| --- | --- |
| 0. System | Health: live LLM provider, embedder, index size |
| 1. Chat (multi-agent) | Every agent, EMI follow-up memory, fraud escalation, refusal, PII masking |
| 2. Accounts | Balance, transactions, 404 |
| 3. Loans | EMI calculator, 422 validation |
| 4. RAG - Documents | List, view, create (JSON), 409 conflict, upload (file), ask about new docs, delete. Leaves the knowledge base as it found it |
| 5. RAG - Chunks | List, filter by document, single chunk |
| 6. RAG - Search and Ask | Search, document filter, min_score, ask with prompt, refusal, PII |
| 7. RAG - Index and Quality | Stats, re-index, evaluation (top_k 3 and 5) |
| 9. Advanced RAG (S034-S045) | Vector stores (FAISS, Chroma), chunking, exact vs keyword vs semantic, glossary, cache and benchmark, live data, injection guard, hybrid + multi-query, CSV/PDF/image upload, agentic RAG, evaluation and comparison, best-practice audit. Restores the index, live feed and documents at the end |
| 8. Security checks | 422 / 401 / 403 / 400 cases, path traversal, wrong file type |

Folders 1 and 9 must run in order (Folder 9 saves the live feed and restores it): "Loan - EMI follow-up" reuses the session of "Loan - EMI".
With `LLM_PROVIDER=gemini` the wording of RAG answers changes, but the tests check routing, sources,
status codes and calculated numbers (EMI, balance), not wording, so they apply in both modes.

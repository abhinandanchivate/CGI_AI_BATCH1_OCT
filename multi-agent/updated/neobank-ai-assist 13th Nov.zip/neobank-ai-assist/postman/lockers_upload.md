# NeoBank Safe Deposit Lockers

## Locker rent
Small lockers cost Rs 2,000 a year plus GST. Medium lockers cost Rs 4,500 and large lockers Rs 8,000 a year plus GST.

## Locker access
Locker holders can visit during branch hours. Each visit is logged and needs the holder's key and a signature.

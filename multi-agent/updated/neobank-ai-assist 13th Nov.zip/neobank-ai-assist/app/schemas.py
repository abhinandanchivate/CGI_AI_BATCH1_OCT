"""Pydantic models: the contract between the API and its clients."""
from typing import List, Literal, Optional
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    session_id: str = Field(..., examples=["sess-001"])
    customer_id: str = Field(..., examples=["CUST1001"])
    message: str = Field(..., min_length=1, max_length=2000,
                         examples=["What documents do I need for KYC?"])


class Source(BaseModel):
    document: str
    chunk_id: str
    score: float
    snippet: str


class TraceStep(BaseModel):
    agent: str
    action: str
    duration_ms: float


class ChatResponse(BaseModel):
    session_id: str
    intent: str
    agent: str
    answer: str
    confidence: float
    sources: List[Source] = []
    trace: List[TraceStep] = []
    escalated: bool = False
    case_id: Optional[str] = None


class EMIRequest(BaseModel):
    principal: float = Field(..., gt=0, examples=[500000])
    annual_rate: float = Field(..., gt=0, lt=50, examples=[10.5])
    tenure_months: int = Field(..., gt=0, le=360, examples=[60])


class EMIResponse(BaseModel):
    emi: float
    total_payment: float
    total_interest: float


# ---------------- RAG API ----------------
Mode = Literal["vector", "keyword", "exact", "hybrid"]


class SearchRequest(BaseModel):
    query: str = Field(..., min_length=2, examples=["video kyc timings"])
    top_k: int = Field(3, ge=1, le=10)
    document: Optional[str] = Field(None, examples=["kyc_policy"], description="Only search this document")
    min_score: Optional[float] = Field(None, ge=0, le=1, description="Hide hits below this score")
    mode: Optional[Mode] = Field(None, description="vector | keyword (BM25) | exact | hybrid; default from .env")
    multi_query: Optional[bool] = Field(None, description="Search several rewrites and fuse the rankings")
    expand: Optional[bool] = Field(None, description="Add banking synonyms and acronym meanings")


class SearchHit(BaseModel):
    document: str
    chunk_id: str
    section: str
    sections: List[str] = []
    score: float
    passed_threshold: bool
    snippet: str


class CompareSearchRequest(BaseModel):
    query: str = Field(..., min_length=2, examples=["face to face verification online"])
    top_k: int = Field(3, ge=1, le=10)
    document: Optional[str] = None


class AskRequest(BaseModel):
    question: str = Field(..., min_length=2, max_length=2000, examples=["How do I do video KYC?"])
    top_k: Optional[int] = Field(None, ge=1, le=10)
    document: Optional[str] = None
    min_score: Optional[float] = Field(None, ge=0, le=1)
    mode: Optional[Mode] = None
    multi_query: Optional[bool] = None
    expand: Optional[bool] = None
    include_live: Optional[bool] = Field(False, description="true = add live data, null = decide from the question")
    include_prompt: bool = Field(False, description="Return the exact prompt sent to the LLM")


class AskResponse(BaseModel):
    question: str
    answer: str
    grounded: bool
    confidence: float
    sources: List[Source] = []
    prompt: Optional[str] = None
    queries: List[str] = []
    live: List[dict] = []
    warnings: List[str] = []
    faithfulness: Optional[dict] = None
    cached: bool = False


class AgenticRequest(BaseModel):
    question: str = Field(..., min_length=2, max_length=2000,
                          examples=["What is the forex fee and how do I do video KYC?"])
    max_steps: Optional[int] = Field(None, ge=1, le=3, description="Retrieval attempts per sub-question")


class ChunkPreviewRequest(BaseModel):
    document: Optional[str] = Field(None, examples=["card_fees"], description="A knowledge-base document...")
    text: Optional[str] = Field(None, description="...or your own Markdown text")
    strategy: Literal["section", "fixed", "sentence", "recursive", "semantic"] = "section"
    chunk_size: int = Field(500, ge=50, le=5000)
    chunk_overlap: int = Field(80, ge=0, le=1000)


class IngestRequest(BaseModel):
    chunk_strategy: Optional[Literal["section", "fixed", "sentence", "recursive", "semantic"]] = None
    vector_store: Optional[Literal["memory", "faiss", "chroma"]] = None
    faiss_index: Optional[Literal["flat", "hnsw"]] = None
    embedding_backend: Optional[Literal["tfidf", "lsa", "gemini", "sentence-transformers"]] = None


class EvalConfig(BaseModel):
    name: Optional[str] = None
    mode: Optional[Mode] = None
    multi_query: Optional[bool] = None
    expand: Optional[bool] = None
    agentic: bool = False
    chunk_strategy: Optional[Literal["section", "fixed", "sentence", "recursive", "semantic"]] = None
    vector_store: Optional[Literal["memory", "faiss", "chroma"]] = None
    faiss_index: Optional[Literal["flat", "hnsw"]] = None
    embedding_backend: Optional[Literal["tfidf", "lsa", "gemini", "sentence-transformers"]] = None


QuestionSet = Literal["standard", "compound"]


class EvalCompareRequest(BaseModel):
    question_set: QuestionSet = Field("standard", description="standard = 12 single-topic questions; "
                                      "compound = 6 multi-part and synonym questions")
    configs: List[EvalConfig] = Field(..., min_length=1, max_length=20, examples=[[
        {"name": "vector"}, {"name": "keyword", "mode": "keyword"}, {"name": "hybrid", "mode": "hybrid"}]])
    top_k: Optional[int] = Field(None, ge=1, le=10)


class BenchmarkRequest(BaseModel):
    stores: List[Literal["memory", "faiss", "chroma"]] = ["memory"]
    modes: List[Mode] = ["vector", "keyword", "hybrid"]
    repeats: int = Field(3, ge=1, le=20)


class LiveItem(BaseModel):
    key: str
    label: str
    value: str
    keywords: List[str] = []


class LiveFeed(BaseModel):
    source: str = "NeoBank Treasury rates feed (simulated for teaching)"
    as_of: Optional[str] = Field(None, description="ISO time; empty = now")
    items: List[LiveItem]


class DocumentInfo(BaseModel):
    name: str
    filename: str
    title: str
    size_bytes: int
    modified: str
    sections: int
    chunks: int


class ChunkInfo(BaseModel):
    chunk_id: str
    document: str
    section: str
    text: str


class DocumentDetail(BaseModel):
    name: str
    filename: str
    title: str
    content: str
    chunks: List[ChunkInfo]


class DocumentCreate(BaseModel):
    name: str = Field(..., examples=["fixed_deposits"], description="2-64 chars: a-z, 0-9, _ or -")
    content: str = Field(..., min_length=1, examples=["# NeoBank Fixed Deposits\n\n## Interest rates\nOne-year FDs earn 7% p.a."])
    overwrite: bool = False


class IngestResponse(BaseModel):
    status: str = "indexed"
    documents: int
    chunks: int
    embedder: str
    indexed_at: str
    chunk_strategy: Optional[str] = None
    vector_store: Optional[str] = None


class DocumentChangeResponse(BaseModel):
    document: str
    action: str
    index: IngestResponse


class RagStats(BaseModel):
    embedder: Optional[str]
    documents: int
    chunks: int
    chunks_per_document: dict
    indexed_at: Optional[str]
    chunk_size: int
    chunk_overlap: int
    top_k: int
    min_retrieval_score: float
    chunk_strategy: Optional[str] = None
    vector_store: Optional[str] = None
    retrieval_mode: Optional[str] = None
    multi_query: bool = False
    query_expansion: bool = False
    ingest_ms: float = 0.0
    auto_reindex_seconds: int = 0
    index_version: int = 0
    query_cache: dict = {}
    answer_cache: dict = {}


class EvalRequest(BaseModel):
    top_k: Optional[int] = Field(None, ge=1, le=10)
    mode: Optional[Mode] = None
    multi_query: Optional[bool] = None
    expand: Optional[bool] = None
    agentic: bool = False
    question_set: Literal["standard", "compound"] = "standard"

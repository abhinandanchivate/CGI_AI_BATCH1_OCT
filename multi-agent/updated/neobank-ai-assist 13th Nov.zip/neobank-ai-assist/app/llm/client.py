"""LLM abstraction. 'gemini' is the hosted model; 'mock' works offline and is the safety net.
'openai' / 'anthropic' are optional alternatives behind the same method."""
import logging
import re
from app.config import get_settings
from app.rag.text_utils import tokenize

log = logging.getLogger(__name__)


class LLMClient:
    def __init__(self):
        self.s = get_settings()
        self.provider = self.s.llm_provider.lower()
        self._gemini = None
        if self.provider == "gemini" and not self.s.gemini_api_key:
            log.warning("LLM_PROVIDER=gemini but GEMINI_API_KEY is empty; using offline mock LLM")
            self.provider = "mock"

    def generate(self, system: str, user: str) -> str:
        try:
            if self.provider == "gemini":
                return self._gemini_generate(system, user)
            if self.provider == "openai":
                return self._openai(system, user)
            if self.provider == "anthropic":
                return self._anthropic(system, user)
        except Exception as exc:  # network, quota, safety block...
            log.warning("%s call failed (%s); falling back to offline answer", self.provider, exc)
        return self._mock(user)

    # ---- hosted providers -------------------------------------------------
    def _gemini_client(self):
        if self._gemini is None:
            from google import genai
            self._gemini = genai.Client(api_key=self.s.gemini_api_key)
        return self._gemini

    def _gemini_generate(self, system: str, user: str) -> str:
        from google.genai import types
        r = self._gemini_client().models.generate_content(
            model=self.s.gemini_model,
            contents=user,
            config=types.GenerateContentConfig(
                system_instruction=system, temperature=0.1, max_output_tokens=600),
        )
        text = (r.text or "").strip()
        if not text:
            raise ValueError("empty Gemini response")
        return text

    def _openai(self, system: str, user: str) -> str:
        from openai import OpenAI
        client = OpenAI(api_key=self.s.openai_api_key)
        r = client.chat.completions.create(
            model=self.s.openai_model, temperature=0.1,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}])
        return r.choices[0].message.content.strip()

    def _anthropic(self, system: str, user: str) -> str:
        import anthropic
        client = anthropic.Anthropic(api_key=self.s.anthropic_api_key)
        r = client.messages.create(model=self.s.anthropic_model, max_tokens=600, system=system,
                                   messages=[{"role": "user", "content": user}])
        return r.content[0].text.strip()

    # ---- offline extractive stub ------------------------------------------
    @staticmethod
    def _mock(user: str) -> str:
        """Offline 'LLM': pick the context chunk that best matches the question, then return
        its most relevant sentences. Rare words weigh more (1 / how many chunks contain them)."""
        ctx = re.search(r"CONTEXT:\n(.*?)\nQUESTION:", user, re.S)
        q = re.search(r"QUESTION:\s*(.*)", user, re.S)
        if not ctx or not q:
            return "I can help with accounts, loans, cards, KYC and fraud reporting."
        chunks = [re.sub(r"^\[\d+\]\s*", "", l) for l in ctx.group(1).splitlines() if l.strip()]
        q_terms = set(tokenize(q.group(1)))
        chunk_tokens = [set(tokenize(c)) for c in chunks]
        df = {t: sum(t in ct for ct in chunk_tokens) for t in q_terms}
        weight = {t: 1.0 / df[t] for t in q_terms if df[t]}

        def score(tokens: set) -> float:
            return sum(w for t, w in weight.items() if t in tokens)

        best = max(range(len(chunks)), key=lambda i: (score(chunk_tokens[i]), -i))
        if score(chunk_tokens[best]) == 0:              # no word matched: try banking synonyms (S037)
            from app.rag.query import expand_query
            q_terms = set(tokenize(expand_query(q.group(1))))
            df = {t: sum(t in ct for ct in chunk_tokens) for t in q_terms}
            weight = {t: 1.0 / df[t] for t in q_terms if df[t]}
            best = max(range(len(chunks)), key=lambda i: (score(chunk_tokens[i]), -i))
        if score(chunk_tokens[best]) == 0:
            return "I could not find this in NeoBank's policy documents."
        body = chunks[best].partition(": ")[2] or chunks[best]
        sents = [x.strip() for x in re.split(r"(?<=[.!?])\s+", body) if len(x.strip()) > 15]
        top = sorted(range(len(sents)), key=lambda i: (-score(set(tokenize(sents[i]))), i))[:3]
        return " ".join(sents[i] for i in sorted(top)) + f" [{best + 1}]"


_llm: LLMClient | None = None


def get_llm() -> LLMClient:
    global _llm
    if _llm is None:
        _llm = LLMClient()
    return _llm

"""Central configuration. Every value can be overridden with an environment variable."""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "NeoBank AI Assist"
    api_key: str = "dev-secret-key"
    admin_api_key: str = "dev-admin-key"   # needed to add, delete or re-index documents

    llm_provider: str = "mock"          # mock | gemini | openai | anthropic
    gemini_api_key: str = ""
    gemini_model: str = "gemini-2.5-flash"
    gemini_embedding_model: str = "gemini-embedding-001"
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-6"

    embedding_backend: str = "tfidf"    # tfidf | lsa | gemini | sentence-transformers
    docs_dir: str = "data/docs"
    customers_file: str = "data/customers.json"
    chunk_size: int = 500
    chunk_overlap: int = 80
    top_k: int = 3
    min_retrieval_score: float = 0.08
    memory_turns: int = 10
    max_upload_kb: int = 200
    max_binary_upload_kb: int = 5120     # PDFs and images (S042)
    eval_file: str = "data/eval/rag_eval.json"

    # ---- advanced RAG (S034-S045) ----
    vector_store: str = "memory"         # memory | faiss | chroma          (S034)
    faiss_index: str = "flat"            # flat (exact) | hnsw (approximate)
    chroma_path: str = ""                # empty = in-memory; a folder = persistent
    chunk_strategy: str = "section"      # section | fixed | sentence | recursive | semantic (S035)
    retrieval_mode: str = "vector"       # vector | keyword | exact | hybrid  (S036, S041)
    multi_query: bool = False            # search several rewrites of the question (S041)
    query_expansion: bool = False        # add banking synonyms and acronyms (S037)
    glossary_file: str = "data/glossary.json"
    rrf_k: int = 60                      # Reciprocal Rank Fusion constant
    max_context_chars: int = 2000        # context budget sent to the LLM (S038)
    cache_size: int = 256                # query cache entries; 0 disables (S038)
    cache_ttl_seconds: int = 300
    auto_reindex_seconds: int = 0        # >0: re-index when data/docs changes (S039)
    live_data_file: str = "data/live/market.json"
    live_max_age_minutes: int = 60       # older live data is flagged as stale
    injection_guard: bool = True         # drop retrieved text that tries to give instructions (S040)
    agentic_max_steps: int = 3           # retrieval attempts per sub-question (S043)
    agentic_knowledge_agent: bool = False  # use agentic RAG inside /chat


@lru_cache
def get_settings() -> Settings:
    return Settings()

"""Small time-limited LRU cache (S038): repeated questions skip embedding, search and generation."""
import time
from collections import OrderedDict


class TTLCache:
    def __init__(self, maxsize: int = 256, ttl: float = 300):
        self.maxsize, self.ttl = maxsize, ttl
        self._data: OrderedDict = OrderedDict()
        self.hits = self.misses = 0

    def get(self, key):
        item = self._data.get(key)
        if item and time.monotonic() - item[1] < self.ttl:
            self._data.move_to_end(key)
            self.hits += 1
            return item[0]
        if item:
            del self._data[key]
        self.misses += 1
        return None

    def set(self, key, value) -> None:
        if self.maxsize <= 0:
            return
        self._data[key] = (value, time.monotonic())
        self._data.move_to_end(key)
        while len(self._data) > self.maxsize:
            self._data.popitem(last=False)          # evict least recently used

    def clear(self) -> None:
        self._data.clear()
        self.hits = self.misses = 0

    def stats(self) -> dict:
        total = self.hits + self.misses
        return {"size": len(self._data), "hits": self.hits, "misses": self.misses,
                "hit_rate": round(self.hits / total, 3) if total else 0.0}

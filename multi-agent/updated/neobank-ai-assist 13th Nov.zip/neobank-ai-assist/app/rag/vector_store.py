"""Vector stores (S034). Three interchangeable back-ends with the same add/search interface:

  memory - NumPy matrix, exact cosine search (default; fine up to tens of thousands of chunks)
  faiss  - Facebook AI Similarity Search: 'flat' (exact) or 'hnsw' (approximate, fast at scale)
  chroma - Chroma vector database: in-memory, or persistent on disk when CHROMA_PATH is set

All stores receive L2-normalised vectors, so inner product = cosine similarity.
"""
import logging
import uuid
from typing import List, Optional, Tuple

import numpy as np

from app.rag.chunker import Chunk

log = logging.getLogger(__name__)
BACKENDS = ("memory", "faiss", "chroma")


def normalize(m: np.ndarray) -> np.ndarray:
    m = np.asarray(m, dtype="float32")
    norms = np.linalg.norm(m, axis=-1, keepdims=True)
    norms[norms == 0] = 1.0
    return m / norms


class InMemoryVectorStore:
    name = "memory"

    def __init__(self):
        self.vectors: np.ndarray | None = None
        self.chunks: List[Chunk] = []

    _normalize = staticmethod(normalize)

    def add(self, chunks: List[Chunk], vectors: np.ndarray) -> None:
        self.chunks = list(chunks)
        self.vectors = normalize(vectors)

    def search(self, query_vec: np.ndarray, top_k: int = 3,
               document: Optional[str] = None) -> List[Tuple[Chunk, float]]:
        if self.vectors is None or not self.chunks:
            return []
        q = normalize(query_vec.reshape(1, -1))
        scores = (self.vectors @ q.T).ravel()          # cosine similarity
        if document:                                    # metadata filter: only this document
            keep = np.array([c.document == document for c in self.chunks])
            scores = np.where(keep, scores, -np.inf)
        idx = np.argsort(-scores)[:top_k]
        return [(self.chunks[i], float(scores[i])) for i in idx if np.isfinite(scores[i])]

    def __len__(self) -> int:
        return len(self.chunks)


class FaissVectorStore:
    """FAISS index. 'flat' = exact inner-product search; 'hnsw' = graph-based approximate search
    (Hierarchical Navigable Small World), the usual choice for millions of vectors."""
    name = "faiss"

    def __init__(self, index_type: str = "flat"):
        import faiss
        self.faiss, self.index_type = faiss, index_type
        self.index, self.chunks = None, []

    def add(self, chunks: List[Chunk], vectors: np.ndarray) -> None:
        v = normalize(vectors)
        d = v.shape[1]
        if self.index_type == "hnsw":
            self.index = self.faiss.IndexHNSWFlat(d, 32, self.faiss.METRIC_INNER_PRODUCT)
            self.index.hnsw.efSearch = 64
        else:
            self.index = self.faiss.IndexFlatIP(d)
        self.index.add(v)
        self.chunks = list(chunks)

    def search(self, query_vec, top_k=3, document=None):
        if self.index is None or not self.chunks:
            return []
        q = normalize(query_vec.reshape(1, -1))
        k = min(top_k, len(self.chunks))
        params = None
        if document:                                    # pre-filter with an ID selector
            ids = np.array([i for i, c in enumerate(self.chunks) if c.document == document], dtype="int64")
            if len(ids) == 0:
                return []
            k = min(k, len(ids))
            sel = self.faiss.IDSelectorBatch(ids)
            params = (self.faiss.SearchParametersHNSW(sel=sel) if self.index_type == "hnsw"
                      else self.faiss.SearchParameters(sel=sel))
        scores, idx = self.index.search(q, k, params=params) if params else self.index.search(q, k)
        return [(self.chunks[i], float(s)) for s, i in zip(scores[0], idx[0]) if i >= 0]

    def __len__(self) -> int:
        return len(self.chunks)


class ChromaVectorStore:
    """Chroma collection holding our own embeddings (no Chroma embedding function).
    Each re-index writes a new collection and drops the old one, so searches never see a half-built index."""
    name = "chroma"

    def __init__(self, path: str = ""):
        import chromadb
        self.client = chromadb.PersistentClient(path=path) if path else chromadb.EphemeralClient()
        self.collection, self.chunks, self.by_id = None, [], {}

    def add(self, chunks: List[Chunk], vectors: np.ndarray) -> None:
        v = normalize(vectors)
        col = self.client.create_collection(f"neobank_{uuid.uuid4().hex[:12]}",
                                            metadata={"hnsw:space": "cosine"}, embedding_function=None)
        for i in range(0, len(chunks), 1000):           # batch writes
            part = chunks[i:i + 1000]
            col.add(ids=[c.chunk_id for c in part], embeddings=v[i:i + 1000].tolist(),
                    documents=[c.text for c in part],
                    metadatas=[{"document": c.document, "section": c.section} for c in part])
        old, self.collection = self.collection, col
        self.chunks, self.by_id = list(chunks), {c.chunk_id: c for c in chunks}
        if old is not None:
            self.client.delete_collection(old.name)

    def search(self, query_vec, top_k=3, document=None):
        if self.collection is None or not self.chunks:
            return []
        q = normalize(query_vec.reshape(1, -1))[0]
        if not np.any(q):
            return []
        r = self.collection.query(query_embeddings=[q.tolist()], n_results=min(top_k, len(self.chunks)),
                                  where={"document": document} if document else None)
        return [(self.by_id[i], 1.0 - float(d)) for i, d in zip(r["ids"][0], r["distances"][0])]

    def __len__(self) -> int:
        return len(self.chunks)


def get_vector_store(backend: str, faiss_index: str = "flat", chroma_path: str = ""):
    """Factory. Falls back to the in-memory store if the library is not installed."""
    try:
        if backend == "faiss":
            return FaissVectorStore(faiss_index)
        if backend == "chroma":
            return ChromaVectorStore(chroma_path)
    except ImportError as exc:
        log.warning("Vector store '%s' unavailable (%s); using in-memory store", backend, exc)
    return InMemoryVectorStore()

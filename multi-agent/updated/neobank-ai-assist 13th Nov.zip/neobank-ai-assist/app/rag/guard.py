"""RAG challenges and their mitigations (S040).

- Prompt injection hidden in documents: retrieved text that tries to give the model instructions is dropped.
- Context overflow / cost: passages are trimmed to a character budget.
- Lost in the middle: models attend best to the start and end, so the strongest passages go there.
- Hallucination: each answer sentence is checked against the context (faithfulness).
- Broken citations: [n] markers must point at a passage that exists.
"""
import re
from typing import List, Tuple

from app.rag.text_utils import tokenize

INJECTION_PATTERNS = [
    r"ignore (all |any )?(the )?(previous|prior|above) (instructions|rules)",
    r"disregard (the )?(system|previous|above)",
    r"you are now", r"new instructions?:", r"system prompt", r"reveal (the )?(prompt|instructions|password|api key)",
    r"act as (an? )?(admin|developer|unrestricted)", r"send (the )?(otp|pin|cvv|password)",
]
_INJECTION_RE = re.compile("|".join(INJECTION_PATTERNS), re.I)


def is_injection(text: str) -> bool:
    return bool(_INJECTION_RE.search(text))


def filter_injections(hits) -> Tuple[list, List[str]]:
    kept, warnings = [], []
    for c, s in hits:
        if is_injection(c.text):
            warnings.append(f"Dropped {c.chunk_id}: looks like a prompt-injection attempt")
        else:
            kept.append((c, s))
    return kept, warnings


def apply_budget(hits, max_chars: int) -> Tuple[list, List[str]]:
    """Keep passages (best first) until the character budget is used up."""
    kept, used, warnings = [], 0, []
    for c, s in hits:
        if kept and used + len(c.text) > max_chars:
            warnings.append(f"Context budget {max_chars} chars reached; skipped {c.chunk_id}")
            continue
        kept.append((c, s))
        used += len(c.text)
    return kept, warnings


def lost_in_middle_order(hits) -> list:
    """[1, 2, 3, 4, 5] by relevance -> [1, 3, 5, 4, 2]: best at the start, second best at the end."""
    front, back = [], []
    for i, h in enumerate(hits):
        (front if i % 2 == 0 else back).append(h)
    return front + back[::-1]


def faithfulness(answer: str, context: str, support: float = 0.6) -> dict:
    """Share of answer sentences whose content words mostly appear in the context (lexical check;
    a real LLM judge is stricter, but this catches invented numbers and topics offline)."""
    ctx = set(tokenize(context))
    sentences = [s for s in re.split(r"(?<=[.!?])\s+", re.sub(r"\[\d+\]", "", answer)) if len(s.split()) >= 3]
    unsupported = []
    for s in sentences:
        words = set(tokenize(s))
        if words and len(words & ctx) / len(words) < support:
            unsupported.append(s)
    score = 1.0 if not sentences else round(1 - len(unsupported) / len(sentences), 3)
    return {"score": score, "sentences": len(sentences), "unsupported": unsupported}


def check_citations(answer: str, n_sources: int) -> List[str]:
    bad = sorted({int(n) for n in re.findall(r"\[(\d+)\]", answer) if not 1 <= int(n) <= n_sources})
    return [f"Answer cites [{n}] but only {n_sources} source(s) were given" for n in bad]

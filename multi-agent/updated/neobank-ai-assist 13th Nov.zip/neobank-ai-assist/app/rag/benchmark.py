"""Latency benchmark (S038): time each retrieval mode and vector store on the same questions."""
import json
import statistics
import time
from pathlib import Path
from typing import List, Optional

from app.config import get_settings
from app.rag.retriever import build_retriever, get_retriever


def _time(fn, repeats: int) -> dict:
    samples = []
    for _ in range(repeats):
        t0 = time.perf_counter()
        fn()
        samples.append((time.perf_counter() - t0) * 1000)
    samples.sort()
    return {"p50_ms": round(statistics.median(samples), 3),
            "p95_ms": round(samples[max(0, int(len(samples) * 0.95) - 1)], 3)}


def benchmark(stores: Optional[List[str]] = None, modes: Optional[List[str]] = None, repeats: int = 3) -> List[dict]:
    questions = [q["question"] for q in json.loads(Path(get_settings().eval_file).read_text(encoding="utf-8"))]
    out = []
    for store in stores or ["memory"]:
        r = get_retriever() if store == get_retriever().stats()["vector_store"] else build_retriever(vector_store=store)
        for mode in modes or ["vector", "keyword", "hybrid"]:
            r.query_cache.clear()
            cold = _time(lambda: [r.search(q, mode=mode) for q in questions], 1)
            warm = _time(lambda: [r.search(q, mode=mode) for q in questions], repeats)
            n = len(questions)
            out.append({"vector_store": r.stats()["vector_store"], "mode": mode, "questions": n,
                        "cold_ms_per_query": round(cold["p50_ms"] / n, 3),
                        "warm_ms_per_query": round(warm["p50_ms"] / n, 3),
                        "cache": r.query_cache.stats()})
    return out

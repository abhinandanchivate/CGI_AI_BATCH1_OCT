"""Multi-modal RAG (S042): turn tables, PDFs and images into searchable Markdown text.

  .csv  -> one '##' section per row, so each row becomes its own chunk
  .pdf  -> one '##' section per page (text extracted with pypdf)
  image -> a description: the caption you supply, or one written by Gemini vision when a key is set
The original image is kept in data/assets/ (next to data/docs) so answers can point to it.
"""
import csv
import io
from pathlib import Path

from app.config import get_settings

TEXT_EXT = (".md", ".txt")
TABLE_EXT = (".csv",)
PDF_EXT = (".pdf",)
IMAGE_EXT = (".png", ".jpg", ".jpeg", ".webp")
ALL_EXT = TEXT_EXT + TABLE_EXT + PDF_EXT + IMAGE_EXT


def assets_dir() -> Path:
    """Original images are kept next to the knowledge base: data/assets/ for data/docs/."""
    return Path(get_settings().docs_dir).parent / "assets"


def csv_to_markdown(name: str, raw: bytes) -> str:
    rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))))
    if not rows:
        raise ValueError("CSV has no rows")
    key = list(rows[0].keys())[0]
    lines = [f"# {name.replace('_', ' ')} (table)", ""]
    for r in rows:
        lines.append(f"## {r[key]}")
        lines.append(". ".join(f"{k}: {v}" for k, v in r.items() if v not in (None, "")) + ".")
        lines.append("")
    return "\n".join(lines)


def pdf_to_markdown(name: str, raw: bytes) -> str:
    from pypdf import PdfReader
    reader = PdfReader(io.BytesIO(raw))
    lines = [f"# {name.replace('_', ' ')} (PDF)", ""]
    for i, page in enumerate(reader.pages, start=1):
        text = " ".join((page.extract_text() or "").split())
        if text:
            lines += [f"## Page {i}", text, ""]
    if len(lines) == 2:
        raise ValueError("No text found in the PDF (scanned PDFs need OCR first)")
    return "\n".join(lines)


def describe_image(raw: bytes, mime: str) -> str | None:
    """Gemini vision caption, or None when no key / the call fails."""
    s = get_settings()
    if s.llm_provider != "gemini" or not s.gemini_api_key:
        return None
    try:
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=s.gemini_api_key)
        r = client.models.generate_content(
            model=s.gemini_model,
            contents=[types.Part.from_bytes(data=raw, mime_type=mime),
                      "Describe this banking image for a search index: all visible text, numbers and what it shows."])
        return (r.text or "").strip() or None
    except Exception:
        return None


def image_to_markdown(name: str, raw: bytes, ext: str, caption: str | None) -> str:
    mime = "image/jpeg" if ext in (".jpg", ".jpeg") else f"image/{ext.lstrip('.')}"
    text = caption or describe_image(raw, mime)
    if not text:
        raise ValueError("Images need a caption (form field 'caption') unless Gemini vision is configured")
    folder = assets_dir()
    folder.mkdir(parents=True, exist_ok=True)
    (folder / f"{name}{ext}").write_bytes(raw)
    source = "caption" if caption else "Gemini vision"
    return (f"# {name.replace('_', ' ')} (image)\n\n## Image description\n{text}\n\n"
            f"## Image file\nStored as {folder.name}/{name}{ext}. Description source: {source}.\n")


def to_markdown(name: str, raw: bytes, ext: str, caption: str | None = None) -> tuple[str, str]:
    """Return (text, extension to save as). Text files are kept as they are."""
    if ext in TEXT_EXT:
        return raw.decode("utf-8"), ext
    if ext in TABLE_EXT:
        return csv_to_markdown(name, raw), ".md"
    if ext in PDF_EXT:
        return pdf_to_markdown(name, raw), ".md"
    if ext in IMAGE_EXT:
        return image_to_markdown(name, raw, ext, caption), ".md"
    raise ValueError(f"Unsupported file type '{ext}'. Allowed: {', '.join(ALL_EXT)}")


def remove_assets(name: str) -> int:
    """Delete stored originals (e.g. the image) when their document is deleted."""
    removed = 0
    for path in assets_dir().glob(f"{name}.*"):
        path.unlink()
        removed += 1
    return removed

"""RAG evaluation (S044): measure retrieval and answers on a gold question set.

Retrieval (top k chunks vs the chunks that hold the answer):
- hit_rate_at_1   share of questions whose best chunk is relevant
- hit_rate_at_k   share with a relevant chunk anywhere in the top k
- precision_at_k  relevant chunks retrieved / k            ("how much of what we fetched was useful")
- recall_at_k     relevant chunks retrieved / all relevant  ("how much of what we needed did we fetch")
- mrr             mean of 1/rank of the first relevant chunk
- ndcg_at_k       rank-aware score: relevant chunks near the top count more
Answers:
- answer_pass_rate  answers containing every must_contain phrase (correctness proxy)
- faithfulness      share of answer sentences supported by the retrieved context (hallucination check)
- grounded_rate     share of questions answered rather than refused
"""
import json
import math
from pathlib import Path
from typing import List, Optional

from app.config import get_settings
from app.llm.client import get_llm
from app.rag.pipeline import answer_question
from app.rag.retriever import build_retriever, get_retriever

QUESTION_SETS = {"standard": None, "compound": "data/eval/rag_eval_compound.json"}  # None = EVAL_FILE


def is_relevant(chunk, item: dict) -> bool:
    if chunk.document != item["expected_document"]:
        return False
    section = item.get("expected_section")
    return not section or section in chunk.metadata.get("sections", [chunk.section])


def _ndcg(rels: List[int], n_relevant: int, k: int) -> float:
    dcg = sum(r / math.log2(i + 2) for i, r in enumerate(rels[:k]))
    ideal = sum(1 / math.log2(i + 2) for i in range(min(n_relevant, k)))
    return dcg / ideal if ideal else 0.0


def evaluate(eval_file: Optional[str] = None, top_k: Optional[int] = None, mode: Optional[str] = None,
             multi_query: Optional[bool] = None, expand: Optional[bool] = None, retriever=None,
             agentic: bool = False) -> dict:
    s = get_settings()
    r = retriever or get_retriever()
    items = json.loads(Path(eval_file or s.eval_file).read_text(encoding="utf-8"))
    k = top_k or s.top_k
    rows, sums = [], dict(h1=0, hk=0, p=0.0, rec=0.0, rr=0.0, ndcg=0.0, ok=0, faith=0.0, grounded=0)
    for item in items:
        if agentic:                               # score what the agent itself retrieved
            from app.rag.agentic import agentic_answer
            a = agentic_answer(item["question"])
            hits = [(r.get_chunk(src["chunk_id"]), src["score"]) for src in a["sources"]]
            hits = [h for h in hits if h[0] is not None]
            answer, grounded = a["answer"], a["grounded"]
            scores = [p["faithfulness"] for p in a["parts"] if p["grounded"]]
            faith = sum(scores) / len(scores) if scores else 1.0
        else:
            hits = r.search(item["question"], top_k=k, mode=mode, multi_query=multi_query, expand=expand)
        rels = [1 if is_relevant(c, item) else 0 for c, _ in hits]
        n_rel = sum(1 for c in r.list_chunks(item["expected_document"]) if is_relevant(c, item))
        rank = next((i + 1 for i, x in enumerate(rels) if x), None)
        if not agentic:
            res = answer_question(item["question"], top_k=k, mode=mode, multi_query=multi_query,
                                  expand=expand, retriever=r, use_cache=False)
            answer, grounded = res.answer, res.grounded
            faith = res.faithfulness["score"] if res.faithfulness else 1.0
        missing = [m for m in item.get("must_contain", []) if m.lower() not in answer.lower()]
        sums["h1"] += rank == 1
        sums["hk"] += rank is not None
        sums["p"] += sum(rels) / max(k, len(hits)) if hits else 0.0
        sums["rec"] += sum(rels) / n_rel if n_rel else 0.0
        sums["rr"] += 1 / rank if rank else 0.0
        sums["ndcg"] += _ndcg(rels, n_rel, max(k, len(hits)))
        sums["ok"] += not missing
        sums["faith"] += faith
        sums["grounded"] += grounded
        rows.append({"question": item["question"], "expected": item["expected_document"]
                     + (f" / {item['expected_section']}" if item.get("expected_section") else ""),
                     "rank": rank, "retrieved": [c.chunk_id for c, _ in hits],
                     "top_score": round(hits[0][1], 3) if hits else None,
                     "relevant_in_top_k": sum(rels), "relevant_total": n_rel,
                     "answer_ok": not missing, "missing": missing, "faithfulness": round(faith, 3)})
    n = len(items) or 1
    stats = r.stats()
    return {"questions": len(items), "top_k": k, "embedder": stats["embedder"], "llm_provider": get_llm().provider,
            "chunk_strategy": stats["chunk_strategy"], "vector_store": stats["vector_store"],
            "retrieval_mode": mode or s.retrieval_mode, "multi_query": bool(multi_query), "expand": bool(expand),
            "agentic": agentic,
            "hit_rate_at_1": round(sums["h1"] / n, 3), "hit_rate_at_k": round(sums["hk"] / n, 3),
            "precision_at_k": round(sums["p"] / n, 3), "recall_at_k": round(sums["rec"] / n, 3),
            "mrr": round(sums["rr"] / n, 3), "ndcg_at_k": round(sums["ndcg"] / n, 3),
            "answer_pass_rate": round(sums["ok"] / n, 3), "faithfulness": round(sums["faith"] / n, 3),
            "grounded_rate": round(sums["grounded"] / n, 3), "results": rows}


SUMMARY_KEYS = ("hit_rate_at_1", "hit_rate_at_k", "precision_at_k", "recall_at_k", "mrr", "ndcg_at_k",
                "answer_pass_rate", "faithfulness")


def compare(configs: List[dict], top_k: Optional[int] = None, eval_file: Optional[str] = None) -> List[dict]:
    """Evaluate several configurations side by side. Each config may set index options
    (chunk_strategy, vector_store, embedding_backend) and/or search options (mode, multi_query, expand, agentic).
    Index options build a temporary retriever, so the live index is never changed."""
    out = []
    for cfg in configs:
        index_opts = {k: cfg[k] for k in ("chunk_strategy", "vector_store", "embedding_backend", "faiss_index") if cfg.get(k)}
        r = build_retriever(**index_opts) if index_opts else get_retriever()
        res = evaluate(eval_file=eval_file, top_k=top_k, mode=cfg.get("mode"), multi_query=cfg.get("multi_query"),
                       expand=cfg.get("expand"), retriever=r, agentic=bool(cfg.get("agentic")))
        out.append({"config": cfg, "chunks": r.stats()["chunks"], **{k: res[k] for k in SUMMARY_KEYS}})
    return out

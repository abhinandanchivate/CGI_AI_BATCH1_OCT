"""Lexical retrieval (S036): BM25 keyword scoring and exact-phrase matching."""
import math
import re
from collections import Counter
from typing import List

import numpy as np

from app.rag.text_utils import tokenize


class BM25Index:
    """Okapi BM25: rewards chunks containing the query's words, rare words more,
    and stops rewarding a word after a few repeats (k1) while normalising for length (b)."""

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b
        self.docs: List[Counter] = []
        self.idf: dict = {}
        self.avgdl = 0.0

    def fit(self, texts: List[str]) -> "BM25Index":
        self.docs = [Counter(tokenize(t)) for t in texts]
        n = len(self.docs)
        df = Counter(term for d in self.docs for term in d)
        self.idf = {t: math.log(1 + (n - f + 0.5) / (f + 0.5)) for t, f in df.items()}
        self.avgdl = sum(sum(d.values()) for d in self.docs) / max(n, 1)
        return self

    def scores(self, query: str) -> np.ndarray:
        q_terms = set(tokenize(query))
        out = np.zeros(len(self.docs), dtype="float32")
        for i, d in enumerate(self.docs):
            dl = sum(d.values())
            for t in q_terms:
                tf = d.get(t, 0)
                if tf:
                    out[i] += self.idf[t] * tf * (self.k1 + 1) / (tf + self.k1 * (1 - self.b + self.b * dl / self.avgdl))
        return out


def normalise(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower()).strip()


def exact_matches(texts: List[str], phrase: str) -> List[int]:
    """Indices of texts that contain the phrase literally (case and spacing ignored)."""
    p = normalise(phrase.strip('"\''))
    return [i for i, t in enumerate(texts) if p and p in normalise(t)]

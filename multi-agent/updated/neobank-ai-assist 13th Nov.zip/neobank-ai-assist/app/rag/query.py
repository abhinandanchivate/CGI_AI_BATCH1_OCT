"""Query understanding: domain expansion (S037), multi-query rewrites (S041) and document routing (S043)."""
import json
import re
from functools import lru_cache
from pathlib import Path
from typing import List

from app.config import get_settings
from app.rag.text_utils import STOPWORDS


@lru_cache
def glossary() -> dict:
    path = Path(get_settings().glossary_file)
    if not path.exists():
        return {"acronyms": {}, "synonyms": {}, "document_routes": {}}
    return json.loads(path.read_text(encoding="utf-8"))


def _words(text: str) -> List[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


def expand_query(query: str) -> str:
    """Append banking meanings of acronyms and synonyms: 'forex fee' -> '... foreign currency markup ...'."""
    g, extra = glossary(), []
    for w in _words(query):
        for table in ("acronyms", "synonyms"):
            if w in g[table]:
                extra.append(g[table][w])
    return query if not extra else f"{query} {' '.join(dict.fromkeys(extra))}"


def keyword_query(query: str) -> str:
    """Only the content words: 'What are the ATM withdrawal charges?' -> 'atm withdrawal charges'."""
    return " ".join(w for w in _words(query) if w not in STOPWORDS)


def split_questions(query: str) -> List[str]:
    """Decompose compound questions: 'What is the ATM fee and how do I do video KYC?' -> two parts."""
    parts = re.split(r"\?\s+|;\s*|\s+and\s+(?=(?:what|how|when|where|which|who|can|is|are|do|does)\b)",
                     query.strip(), flags=re.I)
    parts = [p.strip(" ?") for p in parts if len(p.strip(" ?").split()) >= 3]
    return parts if len(parts) > 1 else [query]


def llm_rewrites(query: str, n: int = 3) -> List[str]:
    """Ask the LLM for paraphrases (only when a real model is configured)."""
    from app.llm.client import get_llm
    llm = get_llm()
    if llm.provider == "mock":
        return []
    out = llm.generate("Rewrite the banking customer question in different words. "
                       f"Return exactly {n} rewrites, one per line, no numbering.", query)
    return [l.strip(" -*0123456789.") for l in out.splitlines() if len(l.split()) >= 3][:n]


def generate_queries(query: str, expand: bool = False, max_queries: int = 4) -> List[str]:
    """Multi-query: the original plus rewrites; each is searched and the rankings are fused."""
    base = [query, keyword_query(query), *split_questions(query), *llm_rewrites(query)]
    variants = [expand_query(v) for v in base] if expand else base + [expand_query(query)]
    seen, out = set(), []
    for v in variants:
        key = v.lower().strip()
        if key and key not in seen:
            seen.add(key)
            out.append(v)
    return out[:max_queries]


def route_document(query: str) -> str | None:
    """Pick the single most likely document from domain keywords, or None if unclear."""
    text = " ".join(_words(query))
    scores = {doc: sum(1 for kw in kws if re.search(rf"\b{re.escape(kw)}", text))
              for doc, kws in glossary()["document_routes"].items()}
    ranked = sorted(scores.items(), key=lambda kv: -kv[1])
    if not ranked or ranked[0][1] == 0 or (len(ranked) > 1 and ranked[0][1] == ranked[1][1]):
        return None
    return ranked[0][0]

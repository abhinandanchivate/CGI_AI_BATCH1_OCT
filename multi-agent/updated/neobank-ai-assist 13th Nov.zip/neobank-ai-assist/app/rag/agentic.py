"""Agentic RAG (S043): an agent decides HOW to retrieve before answering.

  1. Plan     - is retrieval needed? split compound questions; per part pick a document (routing),
                a search mode, and whether live data is needed. Gemini plans when available,
                otherwise transparent rules do.
  2. Retrieve - run the chosen search for each part.
  3. Reflect  - is the evidence good enough (score above threshold, key words covered)?
                If not, try the next strategy: drop the document filter, then hybrid + multi-query + expansion.
  4. Answer   - answer each part from its own evidence and combine, with every step recorded in a trace.
"""
import json
import re
import time
from typing import List, Optional

from app.config import get_settings
from app.llm.client import get_llm
from app.rag import live
from app.rag.pipeline import REFUSAL, answer_question
from app.rag.query import expand_query, glossary, keyword_query, route_document, split_questions
from app.rag.text_utils import tokenize

SMALL_TALK = re.compile(r"^\s*(hi|hello|hey|thanks|thank you|good (morning|evening|afternoon))\b[\s!.?]*$", re.I)
FALLBACKS = [  # what to try next when the evidence is weak
    {"document": "keep", "mode": None, "multi_query": False, "expand": "keep", "why": "planned search"},
    {"document": None, "mode": "hybrid", "multi_query": False, "expand": True, "why": "search all documents, hybrid + glossary"},
    {"document": None, "mode": "hybrid", "multi_query": True, "expand": True, "why": "multi-query rewrites"},
]


def choose_mode(question: str) -> str:
    if re.search(r'"[^"]{3,}"', question):
        return "exact"                       # quoted phrase -> literal match
    content = keyword_query(question).split()
    if len(content) <= 2:
        return "keyword"                     # very short queries: exact words matter most
    return "hybrid"


def quoted_phrase(question: str) -> Optional[str]:
    m = re.search(r'"([^"]{3,})"', question)
    return m.group(1) if m else None


def rule_plan(question: str) -> dict:
    if SMALL_TALK.match(question):
        return {"needs_retrieval": False, "steps": [], "planner": "rules"}
    steps = [{"question": q, "search": quoted_phrase(q) or q, "document": route_document(q),
              "mode": choose_mode(q), "expand": expand_query(q) != q and not quoted_phrase(q),
              "live": live.needs_live(q) and bool(live.live_facts(q))} for q in split_questions(question)]
    return {"needs_retrieval": True, "steps": steps, "planner": "rules"}


def llm_plan(question: str) -> Optional[dict]:
    llm = get_llm()
    if llm.provider == "mock":
        return None
    prompt = ("Plan retrieval for a banking assistant. Documents: kyc_policy, loan_policy, card_fees, "
              "fraud_guidelines. Modes: vector, keyword, exact, hybrid. Reply with JSON only: "
              '{"needs_retrieval": bool, "steps": [{"question": str, "document": str|null, "mode": str, "live": bool}]}'
              f"\nQuestion: {question}")
    try:
        raw = llm.generate("You output only valid JSON.", prompt)
        plan = json.loads(re.sub(r"^```(json)?|```$", "", raw.strip(), flags=re.M))
        for st in plan.get("steps", []):
            st["mode"] = st.get("mode") if st.get("mode") in ("vector", "keyword", "exact", "hybrid") else "hybrid"
            st["document"] = st.get("document") if st.get("document") in (
                "kyc_policy", "loan_policy", "card_fees", "fraud_guidelines") else None
            st["live"] = bool(st.get("live"))
            st["search"] = quoted_phrase(st.get("question", "")) or st.get("question", "")
            st["expand"] = st["mode"] != "exact"
        plan["planner"] = "llm"
        return plan if plan.get("steps") or plan.get("needs_retrieval") is False else None
    except Exception:
        return None                          # never trust a broken plan; fall back to rules


def _meanings(word: str) -> set:
    g = glossary()
    return set(tokenize(g["acronyms"].get(word, "") + " " + g["synonyms"].get(word, "")))


def evidence_ok(question: str, result) -> tuple[bool, str]:
    """Enough evidence = something passed the threshold AND it covers at least a third of the key words
    (a word also counts as covered when one of its glossary meanings appears: forex -> foreign currency)."""
    if not result.grounded:
        return False, "no passage above the relevance threshold"
    raw = re.findall(r"[a-z0-9]+", keyword_query(question).lower())
    text = set(tokenize(" ".join(s["snippet"] for s in result.sources) + " " + " ".join(x["label"] for x in result.live)))
    hit = sum(1 for w in raw if set(tokenize(w)) & text or _meanings(w) & text)
    covered = hit / max(len(raw), 1)
    if covered < 0.34:
        return False, f"evidence covers only {covered:.0%} of the key words"
    return True, f"evidence covers {covered:.0%} of the key words"


def agentic_answer(question: str, max_steps: Optional[int] = None) -> dict:
    t0 = time.perf_counter()
    max_steps = max_steps or get_settings().agentic_max_steps
    plan = llm_plan(question) or rule_plan(question)
    trace: List[dict] = [{"step": "plan", "planner": plan["planner"], "plan": plan.get("steps", []),
                          "needs_retrieval": plan.get("needs_retrieval", True)}]
    if not plan.get("needs_retrieval", True):
        return {"question": question, "answer": "Hello! Ask me about KYC, loans, cards, fees or fraud.",
                "grounded": True, "plan": plan, "trace": trace, "sources": [], "parts": [],
                "duration_ms": round((time.perf_counter() - t0) * 1000, 1)}

    parts, sources = [], []
    for step in plan["steps"]:
        best = None
        for attempt, fb in enumerate(FALLBACKS[:max_steps], start=1):
            doc = step["document"] if fb["document"] == "keep" else fb["document"]
            mode = fb["mode"] or step["mode"]
            expand = step.get("expand", False) if fb["expand"] == "keep" else fb["expand"]
            res = answer_question(step["question"], document=doc, mode=mode, multi_query=fb["multi_query"],
                                  expand=expand, include_live=step.get("live", False),
                                  search_query=step.get("search") if mode == "exact" else None)
            ok, why = evidence_ok(step["question"], res)
            trace.append({"step": "retrieve", "question": step["question"], "attempt": attempt,
                          "strategy": fb["why"], "document": doc, "mode": mode, "multi_query": fb["multi_query"],
                          "expand": expand, "top_sources": [s["chunk_id"] for s in res.sources],
                          "live": [x["key"] for x in res.live], "verdict": "accept" if ok else "retry", "reason": why})
            if best is None or (res.grounded and res.confidence > best.confidence):
                best = res
            if ok:
                break
        parts.append({"question": step["question"], "answer": best.answer, "grounded": best.grounded,
                      "confidence": best.confidence, "sources": best.sources, "live": best.live,
                      "faithfulness": (best.faithfulness or {}).get("score", 1.0)})
        sources += [s for s in best.sources if s["chunk_id"] not in {x["chunk_id"] for x in sources}]

    grounded = [p for p in parts if p["grounded"]]
    if not grounded:
        answer = REFUSAL
    elif len(parts) == 1:
        answer = parts[0]["answer"]
    else:
        answer = " ".join(f"({i}) {p['answer']}" for i, p in enumerate(parts, start=1))
    trace.append({"step": "answer", "parts": len(parts), "grounded_parts": len(grounded)})
    return {"question": question, "answer": answer, "grounded": bool(grounded), "plan": plan,
            "parts": parts, "sources": sources, "trace": trace,
            "duration_ms": round((time.perf_counter() - t0) * 1000, 1)}

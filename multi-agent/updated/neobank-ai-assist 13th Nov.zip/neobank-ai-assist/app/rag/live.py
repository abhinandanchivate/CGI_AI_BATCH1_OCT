"""Real-time information (S039): facts that change during the day (rates, service status) are read
from a live feed at question time instead of being indexed, and always shown with their timestamp."""
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import List

from app.config import get_settings


def _path() -> Path:
    return Path(get_settings().live_data_file)


def load_feed() -> dict:
    p = _path()
    if not p.exists():
        return {"source": None, "as_of": None, "items": []}
    return json.loads(p.read_text(encoding="utf-8"))


def save_feed(feed: dict) -> dict:
    """Replace the feed (simulates the treasury system pushing new numbers)."""
    if not feed.get("as_of"):                      # missing or null -> stamp it now
        feed["as_of"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    _path().parent.mkdir(parents=True, exist_ok=True)
    _path().write_text(json.dumps(feed, indent=2, ensure_ascii=False), encoding="utf-8")
    return feed


def age_minutes(as_of: str | None) -> float | None:
    if not as_of:
        return None
    ts = datetime.fromisoformat(as_of)
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return round((datetime.now(timezone.utc) - ts).total_seconds() / 60, 1)


def status() -> dict:
    feed = load_feed()
    age = age_minutes(feed.get("as_of"))
    return {**feed, "age_minutes": age,
            "stale": age is None or age > get_settings().live_max_age_minutes}


GENERIC = {"rate", "interest", "today", "status"}   # common words count for less


def live_facts(question: str, limit: int = 3) -> List[dict]:
    """Feed items matching the question: needs one specific keyword (fd, usd, home...), best match first."""
    words = set(re.findall(r"[a-z0-9]+", question.lower()))
    scored = []
    for item in load_feed().get("items", []):
        kws = set(item.get("keywords", []))
        specific, generic = len((words & kws) - GENERIC), len(words & kws & GENERIC)
        if specific:
            scored.append((specific + 0.25 * generic, item))
    return [i for _, i in sorted(scored, key=lambda x: -x[0])][:limit]


def needs_live(question: str) -> bool:
    return bool(re.search(r"\b(today|now|current|currently|latest|live|this week|right now|rate|rates|status|down)\b",
                          question.lower()))

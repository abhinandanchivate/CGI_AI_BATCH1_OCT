"""Embedding backends behind one interface so they can be swapped by config."""
from typing import List, Protocol
import numpy as np


class Embedder(Protocol):
    def fit(self, texts: List[str]) -> None: ...
    def embed(self, texts: List[str]) -> np.ndarray: ...


class TfidfEmbedder:
    """Offline, dependency-light default. Good enough for a few hundred chunks."""

    def __init__(self):
        from sklearn.feature_extraction.text import TfidfVectorizer
        from app.rag.text_utils import tokenize
        self.vectorizer = TfidfVectorizer(tokenizer=tokenize, token_pattern=None,
                                          ngram_range=(1, 2), sublinear_tf=True)

    def fit(self, texts: List[str]) -> None:
        self.vectorizer.fit(texts)

    def embed(self, texts: List[str]) -> np.ndarray:
        return self.vectorizer.transform(texts).toarray().astype("float32")


class LsaEmbedder:
    """Latent Semantic Analysis (S036): TF-IDF compressed into a few 'topic' dimensions with SVD.
    Words that appear in similar contexts end up close together, giving an offline,
    dependency-light approximation of semantic search."""

    def __init__(self, dims: int = 64):
        from sklearn.decomposition import TruncatedSVD
        self.tfidf = TfidfEmbedder()
        self.dims, self.svd = dims, None
        self._svd_cls = TruncatedSVD

    def fit(self, texts: List[str]) -> None:
        self.tfidf.fit(texts)
        m = self.tfidf.embed(texts)
        n = max(2, min(self.dims, m.shape[0] - 1, m.shape[1] - 1))
        self.svd = self._svd_cls(n_components=n, random_state=42).fit(m)

    def embed(self, texts: List[str]) -> np.ndarray:
        return self.svd.transform(self.tfidf.embed(texts)).astype("float32")


class SentenceTransformerEmbedder:
    """Dense semantic embeddings (needs `pip install sentence-transformers`)."""

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)

    def fit(self, texts: List[str]) -> None:
        pass  # pre-trained, nothing to fit

    def embed(self, texts: List[str]) -> np.ndarray:
        return np.asarray(self.model.encode(texts, normalize_embeddings=True), dtype="float32")


class GeminiEmbedder:
    """Dense embeddings from the Gemini API (needs GEMINI_API_KEY and `pip install google-genai`).
    Documents and queries use different task types, which improves retrieval quality."""

    BATCH = 100  # max texts per embed_content call

    def __init__(self, api_key: str, model: str = "gemini-embedding-001", dims: int = 768):
        from google import genai
        self.client = genai.Client(api_key=api_key)
        self.model, self.dims = model, dims

    def _embed(self, texts: List[str], task_type: str) -> np.ndarray:
        from google.genai import types
        out = []
        for i in range(0, len(texts), self.BATCH):
            r = self.client.models.embed_content(
                model=self.model, contents=texts[i:i + self.BATCH],
                config=types.EmbedContentConfig(task_type=task_type, output_dimensionality=self.dims))
            out += [e.values for e in r.embeddings]
        return np.asarray(out, dtype="float32")

    def fit(self, texts: List[str]) -> None:
        pass  # pre-trained

    def embed(self, texts: List[str]) -> np.ndarray:
        return self._embed(texts, "RETRIEVAL_DOCUMENT")

    def embed_query(self, text: str) -> np.ndarray:
        return self._embed([text], "RETRIEVAL_QUERY")[0]


def get_embedder(backend: str) -> Embedder:
    if backend == "gemini":
        from app.config import get_settings
        s = get_settings()
        if s.gemini_api_key:
            return GeminiEmbedder(s.gemini_api_key, s.gemini_embedding_model)
        import logging
        logging.getLogger(__name__).warning("EMBEDDING_BACKEND=gemini but no GEMINI_API_KEY; using TF-IDF")
    if backend == "sentence-transformers":
        return SentenceTransformerEmbedder()
    if backend == "lsa":
        return LsaEmbedder()
    return TfidfEmbedder()

"""Guidelines and best practices (S045): audit the running configuration against RAG best practice.
Each check returns pass / warn / fail with the reason and what to do about it."""
from pathlib import Path

from app.config import get_settings
from app.llm.client import get_llm
from app.rag import live
from app.rag.retriever import get_retriever

DENSE = ("GeminiEmbedder", "SentenceTransformerEmbedder")


def _check(area, title, ok, warn_msg, fix, fail=False):
    return {"area": area, "check": title, "status": "pass" if ok else ("fail" if fail else "warn"),
            "detail": "OK" if ok else warn_msg, "recommendation": None if ok else fix}


def audit() -> dict:
    s, r = get_settings(), get_retriever()
    st = r.stats()
    dense = st["embedder"] in DENSE
    overlap = s.chunk_overlap / max(s.chunk_size, 1)
    checks = [
        _check("Security", "API key changed from the default", s.api_key != "dev-secret-key",
               "API_KEY is still dev-secret-key", "Set a long random API_KEY in .env before any deployment", fail=True),
        _check("Security", "Admin key changed from the default", s.admin_api_key != "dev-admin-key",
               "ADMIN_API_KEY is still dev-admin-key", "Set a different, secret ADMIN_API_KEY", fail=True),
        _check("Security", "Prompt-injection guard on", s.injection_guard,
               "INJECTION_GUARD is off", "Keep it on: uploaded documents can contain hidden instructions"),
        _check("Chunking", "Chunk size between 200 and 1,500 characters", 200 <= s.chunk_size <= 1500,
               f"CHUNK_SIZE={s.chunk_size}", "Small chunks lose context; large ones dilute relevance and cost tokens"),
        _check("Chunking", "Overlap 10-25% of chunk size", 0.10 <= overlap <= 0.25,
               f"overlap is {overlap:.0%}", "Use about 15% (e.g. 80 for 500)"),
        _check("Retrieval", "top_k between 3 and 8", 3 <= s.top_k <= 8,
               f"TOP_K={s.top_k}", "Too few misses evidence; too many adds noise and cost"),
        _check("Retrieval", "Threshold suits the embedder",
               (0.3 <= s.min_retrieval_score <= 0.8) if dense else (0.03 <= s.min_retrieval_score <= 0.2),
               f"MIN_RETRIEVAL_SCORE={s.min_retrieval_score} with {st['embedder']}",
               "Dense embeddings: start near 0.55; TF-IDF/LSA: near 0.08. Tune with /rag/search"),
        _check("Retrieval", "Semantic embeddings in use", dense,
               f"{st['embedder']} matches words, not meaning",
               "Use EMBEDDING_BACKEND=gemini (or sentence-transformers) in production"),
        _check("Retrieval", "Hybrid search considered", s.retrieval_mode == "hybrid",
               f"RETRIEVAL_MODE={s.retrieval_mode}",
               "Hybrid (BM25 + vector) is the safest default; compare with POST /rag/evaluate/compare"),
        _check("Scale", "Vector store suits the corpus size",
               st["chunks"] < 20000 or st["vector_store"] in ("faiss", "chroma"),
               f"{st['chunks']} chunks in the {st['vector_store']} store", "Use FAISS (hnsw) or Chroma above ~20k chunks"),
        _check("Scale", "Query cache on", s.cache_size > 0, "CACHE_SIZE=0", "Cache repeated questions (CACHE_SIZE=256)"),
        _check("Scale", "Context budget set", 500 <= s.max_context_chars <= 8000,
               f"MAX_CONTEXT_CHARS={s.max_context_chars}", "Cap context to control cost and latency"),
        _check("Freshness", "Knowledge base re-indexes on change", s.auto_reindex_seconds > 0,
               "AUTO_REINDEX_SECONDS=0 (manual re-index only)", "Set e.g. 60, or always add documents through the API"),
        _check("Freshness", "Live data is fresh", not live.status()["stale"],
               f"live feed is {live.status()['age_minutes']} minutes old", "Connect the feed to a real source or update it"),
        _check("Generation", "A real LLM is configured", get_llm().provider != "mock",
               "LLM_PROVIDER is mock (extractive, offline)", "Set LLM_PROVIDER=gemini and GEMINI_API_KEY"),
        _check("Evaluation", "Gold question set present", Path(s.eval_file).exists(),
               f"{s.eval_file} missing", "Keep 50+ real questions with expected sources; run /rag/evaluate on every change"),
    ]
    summary = {k: sum(1 for c in checks if c["status"] == k) for k in ("pass", "warn", "fail")}
    return {"summary": summary, "checks": checks}

"""Ingestion + retrieval: load -> chunk -> embed -> index (vector store + BM25) -> search.

Search modes (S036, S041):
  vector  - nearest neighbours in the vector store (default)
  keyword - BM25 word matching
  exact   - chunks containing the exact phrase
  hybrid  - vector + BM25 rankings fused with Reciprocal Rank Fusion (RRF)
Every hit's score is its cosine similarity to the question (1.0 for exact matches), so the
same relevance threshold works in every mode.
"""
import itertools
import logging
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np

from app.config import get_settings
from app.rag.cache import TTLCache
from app.rag.chunker import Chunk, chunk_document
from app.rag.embeddings import get_embedder
from app.rag.keyword import BM25Index, exact_matches
from app.rag.query import expand_query, generate_queries
from app.rag.vector_store import InMemoryVectorStore, get_vector_store, normalize

log = logging.getLogger(__name__)
MODES = ("vector", "keyword", "exact", "hybrid")
_versions = itertools.count(1)


@dataclass
class IndexState:
    """Everything one search needs, swapped in as a single object after each ingest."""
    chunks: List[Chunk] = field(default_factory=list)
    store: object = field(default_factory=InMemoryVectorStore)
    embedder: object = None
    bm25: BM25Index = field(default_factory=BM25Index)
    matrix: np.ndarray | None = None          # normalised chunk vectors, for relevance scores
    position: dict = field(default_factory=dict)
    indexed_at: Optional[str] = None
    documents: int = 0
    signature: tuple = ()
    config: dict = field(default_factory=dict)
    ingest_ms: float = 0.0
    version: int = 0                          # increases on every ingest (cache keys use it)


def rrf(rankings: List[List[int]], k: int = 60) -> List[int]:
    """Reciprocal Rank Fusion: score = sum of 1 / (k + rank) over every ranking list."""
    scores: dict = {}
    for ranking in rankings:
        for rank, idx in enumerate(ranking, start=1):
            scores[idx] = scores.get(idx, 0.0) + 1.0 / (k + rank)
    return sorted(scores, key=lambda i: -scores[i])


class Retriever:
    def __init__(self):
        self.settings = get_settings()
        self.state = IndexState()
        self.overrides: dict = {}                 # runtime changes via POST /rag/ingest
        self.query_cache = TTLCache(self.settings.cache_size, self.settings.cache_ttl_seconds)
        self._last_check = 0.0
        self._lock = threading.Lock()

    # ---- compatibility properties -------------------------------------------------
    @property
    def store(self):
        return self.state.store

    @property
    def embedder(self):
        return self.state.embedder

    @property
    def indexed_at(self):
        return self.state.indexed_at

    @property
    def version(self):
        return self.state.version

    def _cfg(self, key: str):
        return self.overrides.get(key, getattr(self.settings, key))

    # ---- ingest -------------------------------------------------------------------
    def _files(self, docs_dir: Optional[str] = None) -> List[Path]:
        path = Path(docs_dir or self.settings.docs_dir)
        return sorted(path.glob("*.md")) + sorted(path.glob("*.txt"))

    def _signature(self, files: List[Path]) -> tuple:
        return tuple((f.name, f.stat().st_mtime_ns, f.stat().st_size) for f in files)

    def ingest(self, docs_dir: str | None = None, **overrides) -> dict:
        self.overrides.update({k: v for k, v in overrides.items() if v is not None})
        t0 = time.perf_counter()
        files = self._files(docs_dir)
        strategy = self._cfg("chunk_strategy")
        chunks: List[Chunk] = []
        for f in files:
            chunks.extend(chunk_document(f.stem, f.read_text(encoding="utf-8"),
                                         self.settings.chunk_size, self.settings.chunk_overlap, strategy))
        if not chunks:
            raise ValueError(f"No documents found in {docs_dir or self.settings.docs_dir}")
        texts = [c.text for c in chunks]
        embedder = get_embedder(self._cfg("embedding_backend"))
        try:
            embedder.fit(texts)
            vectors = embedder.embed(texts)
        except Exception as exc:   # e.g. Gemini key invalid or offline
            log.warning("Embedding backend failed (%s); falling back to TF-IDF", exc)
            embedder = get_embedder("tfidf")
            embedder.fit(texts)
            vectors = embedder.embed(texts)
        store = get_vector_store(self._cfg("vector_store"), self._cfg("faiss_index"), self.settings.chroma_path)
        store.add(chunks, vectors)
        state = IndexState(chunks=chunks, store=store, embedder=embedder, bm25=BM25Index().fit(texts),
                           matrix=normalize(vectors), position={c.chunk_id: i for i, c in enumerate(chunks)},
                           indexed_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                           documents=len(files), signature=self._signature(files),
                           config={"chunk_strategy": strategy, "vector_store": store.name,
                                   "embedder": type(embedder).__name__},
                           ingest_ms=round((time.perf_counter() - t0) * 1000, 1), version=next(_versions))
        with self._lock:                 # swap in the finished index in one step
            self.state = state
            self.query_cache.clear()
        log.info("Indexed %d chunks from %d documents (%s, %s, %s)", len(chunks), len(files),
                 strategy, store.name, type(embedder).__name__)
        return {"documents": len(files), "chunks": len(chunks), "embedder": type(embedder).__name__,
                "indexed_at": state.indexed_at, "chunk_strategy": strategy, "vector_store": store.name}

    def refresh_if_changed(self) -> bool:
        """Real-time freshness (S039): re-index when files in data/docs were added, edited or removed."""
        interval = self.settings.auto_reindex_seconds
        if interval <= 0 or time.monotonic() - self._last_check < interval:
            return False
        self._last_check = time.monotonic()
        if self._signature(self._files()) != self.state.signature:
            log.info("Knowledge base changed on disk; re-indexing")
            self.ingest()
            return True
        return False

    # ---- search -------------------------------------------------------------------
    def _query_vector(self, st: IndexState, query: str) -> np.ndarray:
        key = (st.version, query)
        vec = self.query_cache.get(key)
        if vec is None:
            emb = st.embedder
            vec = emb.embed_query(query) if hasattr(emb, "embed_query") else emb.embed([query])[0]
            vec = normalize(np.asarray(vec).reshape(1, -1))[0]
            self.query_cache.set(key, vec)
        return vec

    def _rank(self, st: IndexState, query: str, qv: np.ndarray, mode: str,
              document: Optional[str], pool: int) -> List[int]:
        allowed = [i for i, c in enumerate(st.chunks) if document is None or c.document == document]
        if mode == "exact":
            hits = [allowed[i] for i in exact_matches([st.chunks[j].text for j in allowed], query)]
            cos = st.matrix @ qv
            return sorted(hits, key=lambda i: -cos[i])
        if mode in ("keyword", "hybrid"):
            bm = st.bm25.scores(query)
            kw = [i for i in sorted(allowed, key=lambda i: -bm[i]) if bm[i] > 0][:pool]
            if mode == "keyword":
                return kw
        if not np.any(qv):
            vec = []
        else:
            vec = [st.position[c.chunk_id] for c, _ in st.store.search(qv, pool, document=document)]
        return rrf([vec, kw], self.settings.rrf_k) if mode == "hybrid" else vec

    def search(self, query: str, top_k: int | None = None, document: Optional[str] = None,
               mode: Optional[str] = None, multi_query: Optional[bool] = None,
               expand: Optional[bool] = None) -> List[Tuple[Chunk, float]]:
        self.refresh_if_changed()
        if self.state.embedder is None:
            self.ingest()
        st = self.state                                   # read the whole index once
        k = top_k or self.settings.top_k
        mode = mode or self.settings.retrieval_mode
        if mode not in MODES:
            raise ValueError(f"Unknown retrieval mode '{mode}'. Use one of {', '.join(MODES)}")
        multi = self.settings.multi_query if multi_query is None else multi_query
        expand = self.settings.query_expansion if expand is None else expand
        if mode == "exact":
            queries = [query]                              # never rewrite an exact phrase
        elif multi:
            queries = generate_queries(query, expand)
        else:
            queries = [expand_query(query) if expand else query]
        pool = max(k * 4, 20)
        rankings, cos = [], np.full(len(st.chunks), -1.0, dtype="float32")
        for q in queries:
            qv = self._query_vector(st, q)
            cos = np.maximum(cos, st.matrix @ qv)
            rankings.append(self._rank(st, q, qv, mode, document, pool))
        order = rrf(rankings, self.settings.rrf_k) if len(rankings) > 1 else rankings[0]
        return [(st.chunks[i], 1.0 if mode == "exact" else float(cos[i])) for i in order[:k]]

    def last_queries(self, query: str, mode: Optional[str] = None, multi_query: Optional[bool] = None,
                     expand: Optional[bool] = None) -> List[str]:
        """The query variants search() would use (shown in API responses for teaching)."""
        mode = mode or self.settings.retrieval_mode
        multi = self.settings.multi_query if multi_query is None else multi_query
        expand = self.settings.query_expansion if expand is None else expand
        if mode == "exact":
            return [query]
        if multi:
            return generate_queries(query, expand)
        return [expand_query(query) if expand else query]

    # ---- inspection -----------------------------------------------------------------
    def list_chunks(self, document: Optional[str] = None) -> List[Chunk]:
        return [c for c in self.state.chunks if document is None or c.document == document]

    def get_chunk(self, chunk_id: str) -> Optional[Chunk]:
        i = self.state.position.get(chunk_id)
        return self.state.chunks[i] if i is not None else None

    def stats(self) -> dict:
        st, s = self.state, self.settings
        per_doc: dict = {}
        for c in st.chunks:
            per_doc[c.document] = per_doc.get(c.document, 0) + 1
        return {"embedder": type(st.embedder).__name__ if st.embedder else None,
                "documents": st.documents, "chunks": len(st.chunks),
                "chunks_per_document": per_doc, "indexed_at": st.indexed_at,
                "chunk_size": s.chunk_size, "chunk_overlap": s.chunk_overlap,
                "top_k": s.top_k, "min_retrieval_score": s.min_retrieval_score,
                "chunk_strategy": st.config.get("chunk_strategy"), "vector_store": st.config.get("vector_store"),
                "retrieval_mode": s.retrieval_mode, "multi_query": s.multi_query,
                "query_expansion": s.query_expansion, "ingest_ms": st.ingest_ms,
                "auto_reindex_seconds": s.auto_reindex_seconds, "index_version": st.version,
                "query_cache": self.query_cache.stats()}


def build_retriever(**overrides) -> Retriever:
    """A separate, temporary retriever (used to compare strategies without touching the live one)."""
    r = Retriever()
    r.ingest(**overrides)
    return r


_retriever: Retriever | None = None


def get_retriever() -> Retriever:
    """Singleton so the index is built once per process."""
    global _retriever
    if _retriever is None:
        _retriever = Retriever()
        _retriever.ingest()
    return _retriever

"""Chunking strategies (S035). Every strategy returns Chunk objects that remember which
document sections they cover, so citations and evaluation work whatever the strategy.

  section   - one chunk per '## ' section, long sections split by a sentence-aware window (default)
  fixed     - fixed-size character windows with overlap, ignoring document structure
  sentence  - windows of 3 sentences (1 overlapping) inside each section, heading prefixed
  recursive - split by headings, then paragraphs, then sentences, then words until small enough
  semantic  - start a new chunk where the topic changes (low similarity between neighbouring sentences)
"""
import re
from dataclasses import dataclass, field
from typing import List, Tuple

STRATEGIES = ("section", "fixed", "sentence", "recursive", "semantic")
SENTENCE_RE = re.compile(r"(?<=[.!?])\s+")


@dataclass
class Chunk:
    chunk_id: str
    document: str
    section: str
    text: str
    metadata: dict = field(default_factory=dict)


# ---------------------------------------------------------------- helpers
def split_sections(markdown: str) -> List[tuple]:
    """Return (heading, body) pairs using '## ' headings as boundaries."""
    sections, heading, buf = [], "Introduction", []
    for line in markdown.splitlines():
        if line.startswith("## "):
            if buf:
                sections.append((heading, "\n".join(buf).strip()))
            heading, buf = line[3:].strip(), []
        elif line.startswith("# "):
            continue  # document title, stored as metadata instead
        else:
            buf.append(line)
    if buf:
        sections.append((heading, "\n".join(buf).strip()))
    return [(h, b) for h, b in sections if b]


def sliding_window(text: str, size: int, overlap: int) -> List[str]:
    """Character window that snaps to sentence ends so chunks stay readable."""
    if len(text) <= size:
        return [text]
    sentences = SENTENCE_RE.split(text)
    chunks, current = [], ""
    for sent in sentences:
        if len(current) + len(sent) + 1 > size and current:
            chunks.append(current.strip())
            current = current[-overlap:] + " " + sent  # carry overlap forward
        else:
            current += " " + sent
    if current.strip():
        chunks.append(current.strip())
    return chunks


def _title(markdown: str, fallback: str) -> str:
    m = re.search(r"^# (.+)$", markdown, re.MULTILINE)
    return m.group(1).strip() if m else fallback


def _body_and_headings(markdown: str) -> Tuple[str, List[Tuple[int, str]]]:
    """Document text without the '# ' title, plus (offset, heading) for every '## ' line."""
    body = "\n".join(l for l in markdown.splitlines() if not l.startswith("# ")).strip()
    heads = [(m.start(), m.group(1).strip()) for m in re.finditer(r"^## (.+)$", body, re.MULTILINE)]
    return body, heads


def _sections_in_span(heads, start: int, end: int, length: int) -> List[str]:
    """Headings whose text overlaps the character span [start, end)."""
    if not heads:
        return ["Introduction"]
    found = []
    if start < heads[0][0]:
        found.append("Introduction")
    for i, (pos, name) in enumerate(heads):
        nxt = heads[i + 1][0] if i + 1 < len(heads) else length
        if pos < end and nxt > start:
            found.append(name)
    return found or [heads[-1][1]]


def _units(markdown: str) -> List[Tuple[str, str]]:
    """(section heading, sentence) pairs for the whole document, in reading order."""
    return [(h, s.strip()) for h, body in split_sections(markdown)
            for s in SENTENCE_RE.split(body.replace("\n", " ")) if s.strip()]


def _make(doc, idx, section, text, title, sections, strategy) -> Chunk:
    return Chunk(chunk_id=f"{doc}#{idx}", document=doc, section=section, text=text,
                 metadata={"title": title, "sections": sections, "strategy": strategy})


# ---------------------------------------------------------------- strategies
def _section(doc, md, size, overlap, title):
    out = []
    for s_idx, (heading, body) in enumerate(split_sections(md)):
        for w_idx, piece in enumerate(sliding_window(body, size, overlap)):
            # Prefix the heading so retrieval matches section topics too
            out.append(Chunk(chunk_id=f"{doc}#{s_idx}.{w_idx}", document=doc, section=heading,
                             text=f"{heading}: {piece}",
                             metadata={"title": title, "sections": [heading], "strategy": "section"}))
    return out


def _fixed(doc, md, size, overlap, title):
    body, heads = _body_and_headings(md)
    step, out, start = max(1, size - overlap), [], 0
    while start < len(body):
        end = min(len(body), start + size)
        secs = _sections_in_span(heads, start, end, len(body))
        out.append(_make(doc, len(out), secs[0], body[start:end].strip(), title, secs, "fixed"))
        if end == len(body):
            break
        start += step
    return out


def _sentence(doc, md, size, overlap, title, window=3, stride=2):
    out = []
    for heading, body in split_sections(md):
        sents = [s.strip() for s in SENTENCE_RE.split(body.replace("\n", " ")) if s.strip()]
        for i in range(0, len(sents), stride):
            group = sents[i:i + window]
            out.append(_make(doc, len(out), heading, f"{heading}: {' '.join(group)}", title, [heading], "sentence"))
            if i + window >= len(sents):
                break
    return out


def _recursive(doc, md, size, overlap, title, seps=("\n## ", "\n\n", "\n", ". ", " ")):
    body, heads = _body_and_headings(md)

    def split(start: int, end: int, level: int) -> List[Tuple[int, int]]:
        if end - start <= size or level >= len(seps):
            return [(start, end)]
        sep, spans, cur = seps[level], [], start
        while True:
            j = body.find(sep, cur + 1, end)
            if j == -1:
                spans.append((cur, end))
                break
            spans.append((cur, j))
            cur = j
        out = []
        for s, e in spans:
            out.extend(split(s, e, level + 1) if e - s > size else [(s, e)])
        return out

    merged: List[Tuple[int, int]] = []
    for s, e in split(0, len(body), 0):             # merge small neighbours up to `size`
        if merged and e - merged[-1][0] <= size:
            merged[-1] = (merged[-1][0], e)
        else:
            merged.append((s, e))
    out = []
    for s, e in merged:
        text = body[s:e].strip()
        s += len(body[s:e]) - len(body[s:e].lstrip())   # skip leading blank lines before a heading
        if text:
            secs = _sections_in_span(heads, s, e, len(body))
            out.append(_make(doc, len(out), secs[0], text, title, secs, "recursive"))
    return out


def _semantic(doc, md, size, overlap, title, threshold=0.08):
    from sklearn.feature_extraction.text import TfidfVectorizer
    from app.rag.text_utils import tokenize
    units = _units(md)
    if not units:
        return []
    texts = [s for _, s in units]
    vec = TfidfVectorizer(tokenizer=tokenize, token_pattern=None).fit_transform(texts)
    sims = [float((vec[i] @ vec[i + 1].T).toarray()[0, 0]) for i in range(len(texts) - 1)]
    out, group = [], [0]
    for i in range(1, len(texts)):
        too_long = sum(len(texts[j]) for j in group) + len(texts[i]) > size
        if sims[i - 1] < threshold or too_long:     # topic shift or full: close the chunk
            out.append(group)
            group = []
        group.append(i)
    out.append(group)
    chunks = []
    for g in out:
        secs = list(dict.fromkeys(units[j][0] for j in g))
        chunks.append(_make(doc, len(chunks), secs[0], " ".join(texts[j] for j in g), title, secs, "semantic"))
    return chunks


def chunk_document(doc_name: str, markdown: str, size: int = 500, overlap: int = 80,
                   strategy: str = "section") -> List[Chunk]:
    fn = {"section": _section, "fixed": _fixed, "sentence": _sentence,
          "recursive": _recursive, "semantic": _semantic}.get(strategy)
    if fn is None:
        raise ValueError(f"Unknown chunk strategy '{strategy}'. Use one of {', '.join(STRATEGIES)}")
    return fn(doc_name, markdown, size, overlap, _title(markdown, doc_name))

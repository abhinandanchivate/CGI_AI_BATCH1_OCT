"""RAG endpoints (all under /api/v1/rag). All need X-API-Key; endpoints that change the
knowledge base or the index also need X-Admin-Key.

  Documents (S034 data, S042 multi-modal)  /documents, /documents/{name}, /documents/upload
  Chunks and chunking (S035)               /chunks, /chunks/{chunk_id}, /chunking/preview
  Retrieval (S036, S037, S041)             /search, /search/compare
  Answering (S039, S040, S043)             /ask, /agentic/ask, /live
  Index, scale and quality (S034, S038, S044, S045)
                                           /ingest, /stats, /benchmark, /evaluate, /evaluate/compare, /best-practices
"""
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile, status

from app.config import get_settings
from app.rag import live as live_feed
from app.rag.agentic import agentic_answer
from app.rag.benchmark import benchmark
from app.rag.best_practices import audit
from app.rag.chunker import chunk_document
from app.rag.document_store import DocumentStore
from app.rag.evaluate import QUESTION_SETS, compare, evaluate
from app.rag.multimodal import ALL_EXT, TEXT_EXT, remove_assets, to_markdown
from app.rag.pipeline import answer_question, cache_stats
from app.rag.retriever import build_retriever, get_retriever
from app.schemas import (AgenticRequest, AskRequest, AskResponse, BenchmarkRequest, ChunkInfo,
                         ChunkPreviewRequest, CompareSearchRequest, DocumentChangeResponse, DocumentCreate,
                         DocumentDetail, DocumentInfo, EvalCompareRequest, EvalRequest, IngestRequest,
                         IngestResponse, LiveFeed, RagStats, SearchHit, SearchRequest)
from app.services.security import mask_pii, require_admin_key, require_api_key

router = APIRouter(prefix="/api/v1/rag", tags=["RAG"], dependencies=[Depends(require_api_key)])
ADMIN = [Depends(require_admin_key)]


def _chunk_info(c) -> ChunkInfo:
    return ChunkInfo(chunk_id=c.chunk_id, document=c.document, section=c.section, text=c.text)


def _reindex(name: str, action: str) -> DocumentChangeResponse:
    return DocumentChangeResponse(document=name, action=action, index=IngestResponse(**get_retriever().ingest()))


def _bad_request(exc: Exception):
    raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc))


def _hits(hits) -> List[SearchHit]:
    threshold = get_settings().min_retrieval_score
    return [SearchHit(document=c.document, chunk_id=c.chunk_id, section=c.section,
                      sections=c.metadata.get("sections", [c.section]), score=round(s, 3),
                      passed_threshold=s >= threshold, snippet=c.text[:200]) for c, s in hits]


# ---------- documents ----------
@router.get("/documents", response_model=List[DocumentInfo])
def list_documents():
    """Every document in the knowledge base, with how many chunks it produced."""
    per_doc = get_retriever().stats()["chunks_per_document"]
    return [DocumentInfo(**d, chunks=per_doc.get(d["name"], 0)) for d in DocumentStore().list()]


@router.get("/documents/{name}", response_model=DocumentDetail)
def get_document(name: str):
    """One document's full text and the chunks it was cut into."""
    try:
        doc = DocumentStore().get(name)
    except ValueError as exc:
        _bad_request(exc)
    if not doc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Document '{name}' not found")
    return DocumentDetail(**doc, chunks=[_chunk_info(c) for c in get_retriever().list_chunks(name)])


@router.post("/documents", response_model=DocumentChangeResponse,
             status_code=status.HTTP_201_CREATED, dependencies=ADMIN)
def create_document(req: DocumentCreate):
    """Add (or replace) a Markdown document from JSON, then re-index."""
    try:
        DocumentStore().save(req.name, req.content, overwrite=req.overwrite)
    except FileExistsError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc))
    except ValueError as exc:
        _bad_request(exc)
    return _reindex(req.name, "replaced" if req.overwrite else "created")


@router.post("/documents/upload", response_model=DocumentChangeResponse,
             status_code=status.HTTP_201_CREATED, dependencies=ADMIN)
async def upload_document(file: UploadFile = File(...), name: Optional[str] = Query(None),
                          overwrite: bool = Query(False), caption: Optional[str] = Form(None)):
    """Upload .md/.txt, a .csv table, a .pdf, or an image (.png/.jpg/.webp, with a caption or Gemini vision).
    Tables, PDFs and images are converted to searchable Markdown (S042), then the index is rebuilt."""
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALL_EXT:
        _bad_request(ValueError(f"Unsupported file type '{ext}'. Allowed: {', '.join(ALL_EXT)}"))
    doc_name = (name or Path(file.filename or "").stem).lower().replace(" ", "_")
    s = get_settings()
    limit_kb = s.max_upload_kb if ext in TEXT_EXT else s.max_binary_upload_kb
    raw = await file.read(limit_kb * 1024 + 1)
    if len(raw) > limit_kb * 1024:
        _bad_request(ValueError(f"File is larger than {limit_kb} KB"))
    try:
        DocumentStore.validate_name(doc_name)
        content, save_ext = to_markdown(doc_name, raw, ext, caption)
        DocumentStore().save(doc_name, content, overwrite=overwrite, ext=save_ext)
    except UnicodeDecodeError:
        _bad_request(ValueError("File must be UTF-8 text"))
    except FileExistsError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc))
    except ValueError as exc:
        _bad_request(exc)
    return _reindex(doc_name, "replaced" if overwrite else "uploaded")


@router.delete("/documents/{name}", response_model=DocumentChangeResponse, dependencies=ADMIN)
def delete_document(name: str):
    """Remove a document from the knowledge base, then re-index."""
    try:
        deleted = DocumentStore().delete(name)
    except ValueError as exc:
        _bad_request(exc)
    if not deleted:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Document '{name}' not found")
    remove_assets(name)
    return _reindex(name, "deleted")


# ---------- chunks and chunking ----------
@router.get("/chunks", response_model=List[ChunkInfo])
def list_chunks(document: Optional[str] = Query(None, description="Only chunks of this document")):
    return [_chunk_info(c) for c in get_retriever().list_chunks(document)]


@router.get("/chunks/{chunk_id}", response_model=ChunkInfo)
def get_chunk(chunk_id: str):
    """Chunk IDs contain '#': encode it as %23, e.g. /chunks/card_fees%231.0"""
    chunk = get_retriever().get_chunk(chunk_id)
    if not chunk:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Chunk '{chunk_id}' not found")
    return _chunk_info(chunk)


@router.post("/chunking/preview")
def chunking_preview(req: ChunkPreviewRequest):
    """See how a strategy would cut a document, without changing the index (S035)."""
    if req.chunk_overlap >= req.chunk_size:
        _bad_request(ValueError("chunk_overlap must be smaller than chunk_size"))
    if req.text:
        name, text = "preview", req.text
    else:
        doc = DocumentStore().get(req.document or "card_fees")
        if not doc:
            raise HTTPException(status.HTTP_404_NOT_FOUND, f"Document '{req.document}' not found")
        name, text = doc["name"], doc["content"]
    chunks = chunk_document(name, text, req.chunk_size, req.chunk_overlap, req.strategy)
    sizes = [len(c.text) for c in chunks]
    return {"strategy": req.strategy, "chunk_size": req.chunk_size, "chunk_overlap": req.chunk_overlap,
            "chunks": len(chunks), "min_chars": min(sizes, default=0), "max_chars": max(sizes, default=0),
            "avg_chars": round(sum(sizes) / len(sizes), 1) if sizes else 0,
            "items": [{"chunk_id": c.chunk_id, "sections": c.metadata["sections"], "chars": len(c.text),
                       "text": c.text} for c in chunks]}


# ---------- retrieval ----------
@router.post("/search", response_model=List[SearchHit])
def search(req: SearchRequest):
    """Retrieval only (no LLM): see which chunks match and whether they pass the threshold."""
    try:
        hits = get_retriever().search(mask_pii(req.query), req.top_k, document=req.document, mode=req.mode,
                                      multi_query=req.multi_query, expand=req.expand)
    except ValueError as exc:
        _bad_request(exc)
    if req.min_score is not None:
        hits = [h for h in hits if h[1] >= req.min_score]
    return _hits(hits)


@router.post("/search/compare")
def search_compare(req: CompareSearchRequest):
    """Semantic vs exact matching (S036): the same query through every search method, side by side."""
    q, r = mask_pii(req.query), get_retriever()
    out = {m: _hits(r.search(q, req.top_k, document=req.document, mode=m)) for m in ("exact", "keyword", "vector", "hybrid")}
    out["semantic_lsa"] = _hits(build_retriever(embedding_backend="lsa").search(q, req.top_k, document=req.document))
    return {"query": q, "results": out,
            "notes": {"exact": "literal phrase only", "keyword": "BM25 word matching",
                      "vector": f"{r.stats()['embedder']} vectors", "hybrid": "keyword + vector fused with RRF",
                      "semantic_lsa": "offline latent-semantic vectors (meaning, not exact words)"}}


# ---------- answering ----------
@router.post("/ask", response_model=AskResponse)
def ask(req: AskRequest):
    """Full RAG without agents: retrieve -> guard -> (live data) -> prompt -> LLM -> checks -> cited answer."""
    question = mask_pii(req.question)
    r = answer_question(question, top_k=req.top_k, document=req.document, min_score=req.min_score,
                        mode=req.mode, multi_query=req.multi_query, expand=req.expand,
                        include_live=req.include_live)
    return AskResponse(question=question, answer=r.answer, grounded=r.grounded, confidence=r.confidence,
                       sources=r.sources, prompt=r.prompt if req.include_prompt else None, queries=r.queries,
                       live=r.live, warnings=r.warnings, faithfulness=r.faithfulness, cached=r.cached)


@router.post("/agentic/ask")
def agentic_ask(req: AgenticRequest):
    """Agentic RAG (S043): plan how to retrieve, retrieve, check the evidence, retry, then answer."""
    return agentic_answer(mask_pii(req.question), req.max_steps)


@router.get("/live")
def get_live():
    """Real-time data feed (S039) with its age and a stale flag."""
    return live_feed.status()


@router.put("/live", dependencies=ADMIN)
def put_live(feed: LiveFeed):
    """Push new live values (simulates the treasury system). Takes effect immediately, no re-index."""
    return live_feed.save_feed(feed.model_dump())


# ---------- index, scale and quality ----------
@router.post("/ingest", response_model=IngestResponse, dependencies=ADMIN)
def ingest(req: IngestRequest = IngestRequest()):
    """Rebuild the whole index. Optionally switch chunk strategy, vector store or embedder at run time."""
    return IngestResponse(**get_retriever().ingest(**req.model_dump()))


@router.get("/stats", response_model=RagStats)
def stats():
    return RagStats(**get_retriever().stats(), answer_cache=cache_stats())


@router.post("/benchmark")
def run_benchmark(req: BenchmarkRequest = BenchmarkRequest()):
    """Latency per vector store and search mode, cold vs cached (S038)."""
    return benchmark(req.stores, req.modes, req.repeats)


@router.post("/evaluate")
def run_evaluation(req: EvalRequest = EvalRequest()):
    """Retrieval (hit rate, precision, recall, MRR, nDCG) and answer (correctness, faithfulness) metrics (S044)."""
    return evaluate(eval_file=QUESTION_SETS[req.question_set], top_k=req.top_k, mode=req.mode,
                    multi_query=req.multi_query, expand=req.expand, agentic=req.agentic)


@router.post("/evaluate/compare")
def run_comparison(req: EvalCompareRequest):
    """Evaluate several configurations side by side (modes, chunking, stores, embedders, agentic)."""
    return compare([c.model_dump() for c in req.configs], req.top_k, QUESTION_SETS[req.question_set])


@router.get("/best-practices")
def best_practices():
    """Audit the running configuration against RAG guidelines (S045)."""
    return audit()

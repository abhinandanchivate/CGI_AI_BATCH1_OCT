"""REST endpoints (all under /api/v1, all protected by X-API-Key)."""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, Query

from app.agents.loan_agent import calculate_emi
from app.agents.orchestrator import get_orchestrator
from app.rag.retriever import get_retriever
from app.schemas import ChatRequest, ChatResponse, EMIRequest, EMIResponse, SearchRequest, Source
from app.services import bank_db
from app.services.security import require_api_key

router = APIRouter(prefix="/api/v1", dependencies=[Depends(require_api_key)])


@router.post("/chat", response_model=ChatResponse, tags=["Chat"])
def chat(req: ChatRequest):
    """Main entry point: the orchestrator routes the message to the right agent."""
    return get_orchestrator().handle(req.session_id, req.customer_id, req.message)


@router.get("/agents", tags=["Chat"])
def list_agents():
    return get_orchestrator().list_agents()


@router.get("/accounts/{customer_id}/balance", tags=["Accounts"])
def balance(customer_id: str):
    data = bank_db.get_balance(customer_id)
    if not data:
        raise HTTPException(404, "Customer not found")
    return data


@router.get("/accounts/{customer_id}/transactions", tags=["Accounts"])
def transactions(customer_id: str, limit: int = Query(5, ge=1, le=50)):
    data = bank_db.get_transactions(customer_id, limit)
    if data is None:
        raise HTTPException(404, "Customer not found")
    return data


@router.post("/loans/emi", response_model=EMIResponse, tags=["Loans"])
def emi(req: EMIRequest):
    return calculate_emi(req.principal, req.annual_rate, req.tenure_months)


@router.post("/rag/search", response_model=List[Source], tags=["RAG"])
def rag_search(req: SearchRequest):
    hits = get_retriever().search(req.query, req.top_k)
    return [Source(document=c.document, chunk_id=c.chunk_id, score=round(s, 3), snippet=c.text[:200])
            for c, s in hits]


@router.post("/rag/ingest", tags=["RAG"])
def rag_ingest():
    """Rebuild the index after policy documents change."""
    return {"status": "indexed", **get_retriever().ingest()}

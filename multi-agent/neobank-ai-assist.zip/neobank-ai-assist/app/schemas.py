"""Pydantic models: the contract between the API and its clients."""
from typing import List, Optional
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    session_id: str = Field(..., examples=["sess-001"])
    customer_id: str = Field(..., examples=["CUST1001"])
    message: str = Field(..., min_length=1, max_length=2000,
                         examples=["What documents do I need for KYC?"])


class Source(BaseModel):
    document: str
    chunk_id: str
    score: float
    snippet: str


class TraceStep(BaseModel):
    agent: str
    action: str
    duration_ms: float


class ChatResponse(BaseModel):
    session_id: str
    intent: str
    agent: str
    answer: str
    confidence: float
    sources: List[Source] = []
    trace: List[TraceStep] = []
    escalated: bool = False
    case_id: Optional[str] = None


class SearchRequest(BaseModel):
    query: str = Field(..., min_length=2)
    top_k: int = Field(3, ge=1, le=10)


class EMIRequest(BaseModel):
    principal: float = Field(..., gt=0, examples=[500000])
    annual_rate: float = Field(..., gt=0, lt=50, examples=[10.5])
    tenure_months: int = Field(..., gt=0, le=360, examples=[60])


class EMIResponse(BaseModel):
    emi: float
    total_payment: float
    total_interest: float

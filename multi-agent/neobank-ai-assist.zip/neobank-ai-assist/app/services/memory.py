"""Short-term conversation memory per session (in-memory; use Redis in production)."""
from collections import defaultdict, deque
from app.config import get_settings


class SessionMemory:
    def __init__(self):
        self._store = defaultdict(lambda: deque(maxlen=get_settings().memory_turns * 2))

    def add(self, session_id: str, role: str, text: str) -> None:
        self._store[session_id].append({"role": role, "text": text})

    def history(self, session_id: str) -> list:
        return list(self._store[session_id])

    def last_intent(self, session_id: str) -> str | None:
        for turn in reversed(self._store[session_id]):
            if turn["role"] == "intent":
                return turn["text"]
        return None


memory = SessionMemory()

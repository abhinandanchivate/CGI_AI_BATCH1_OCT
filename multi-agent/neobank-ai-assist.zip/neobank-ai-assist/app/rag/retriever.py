"""Ingestion + retrieval pipeline: load -> chunk -> embed -> index -> search."""
import logging
from pathlib import Path
from typing import List, Tuple

from app.config import get_settings
from app.rag.chunker import Chunk, chunk_document
from app.rag.embeddings import get_embedder
from app.rag.vector_store import InMemoryVectorStore

log = logging.getLogger(__name__)


class Retriever:
    def __init__(self):
        self.settings = get_settings()
        self.store = InMemoryVectorStore()
        self.embedder = None

    def ingest(self, docs_dir: str | None = None) -> dict:
        docs_path = Path(docs_dir or self.settings.docs_dir)
        chunks: List[Chunk] = []
        files = sorted(docs_path.glob("*.md")) + sorted(docs_path.glob("*.txt"))
        for f in files:
            chunks.extend(chunk_document(f.stem, f.read_text(encoding="utf-8"),
                                         self.settings.chunk_size, self.settings.chunk_overlap))
        if not chunks:
            raise ValueError(f"No documents found in {docs_path}")
        texts = [c.text for c in chunks]
        self.embedder = get_embedder(self.settings.embedding_backend)
        try:
            self.embedder.fit(texts)
            vectors = self.embedder.embed(texts)
        except Exception as exc:   # e.g. Gemini key invalid or offline
            log.warning("Embedding backend failed (%s); falling back to TF-IDF", exc)
            self.embedder = get_embedder("tfidf")
            self.embedder.fit(texts)
            vectors = self.embedder.embed(texts)
        self.store.add(chunks, vectors)
        log.info("Indexed %d chunks from %d documents", len(chunks), len(files))
        return {"documents": len(files), "chunks": len(chunks),
                "embedder": type(self.embedder).__name__}

    def search(self, query: str, top_k: int | None = None) -> List[Tuple[Chunk, float]]:
        if self.embedder is None:
            self.ingest()
        k = top_k or self.settings.top_k
        if hasattr(self.embedder, "embed_query"):          # Gemini: query-specific embedding
            q_vec = self.embedder.embed_query(query)
        else:
            q_vec = self.embedder.embed([query])[0]
        return self.store.search(q_vec, k)


_retriever: Retriever | None = None


def get_retriever() -> Retriever:
    """Singleton so the index is built once per process."""
    global _retriever
    if _retriever is None:
        _retriever = Retriever()
        _retriever.ingest()
    return _retriever

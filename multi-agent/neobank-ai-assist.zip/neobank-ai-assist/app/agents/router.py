"""Router Agent: decides which specialist handles the message."""
import re
from app.llm.client import get_llm

INTENT_KEYWORDS = {
    "fraud": ["fraud", "unauthorised", "unauthorized", "don't recognise", "dont recognise",
              "don't recognize", "not done by me", "stolen", "hacked", "scam", "block my card",
              "suspicious", "dispute"],
    "account": ["balance", "transaction", "statement", "spent", "debited", "credited",
                "last 5", "recent", "account number", "how much money"],
    "loan": ["loan", "emi", "eligible", "eligibility", "foreclos", "prepay", "interest rate",
             "home loan", "personal loan", "tenure"],
    "knowledge": ["kyc", "document", "fee", "charges", "atm", "card", "policy", "video kyc",
                  "lounge", "markup", "re-kyc", "otp", "limit"],
    "greeting": ["hello", "hi", "hey", "good morning", "good evening", "thanks", "thank you"],
}
FOLLOW_UP_STARTS = ("and ", "what about", "how about", "also", "for ", "same ")
PRIORITY = ["fraud", "account", "loan", "knowledge", "greeting"]   # tie-break order


class RouterAgent:
    name = "router"

    def classify(self, message: str, last_intent: str | None = None) -> tuple[str, float]:
        text = message.lower()
        scores = {intent: sum(1 for kw in kws if re.search(rf"\b{re.escape(kw)}", text))
                  for intent, kws in INTENT_KEYWORDS.items()}
        best = max(PRIORITY, key=lambda i: (scores[i], -PRIORITY.index(i)))
        if scores[best] == 0:
            # Short follow-ups ("and for 3 years?") inherit the previous intent
            if last_intent and text.startswith(FOLLOW_UP_STARTS) and len(text.split()) <= 8:
                return last_intent, 0.55
            llm_intent = self._llm_classify(message)
            return (llm_intent, 0.6) if llm_intent else ("knowledge", 0.4)
        total = sum(scores.values())
        return best, round(min(0.95, 0.5 + scores[best] / (total + 1)), 2)

    @staticmethod
    def _llm_classify(message: str) -> str | None:
        llm = get_llm()
        if llm.provider == "mock":
            return None
        out = llm.generate(
            "Classify the banking message into exactly one word: account, loan, knowledge, fraud, greeting.",
            message).strip().lower()
        return out if out in INTENT_KEYWORDS else None

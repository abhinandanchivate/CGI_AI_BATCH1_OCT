"""Knowledge Agent: answers policy questions with RAG and cites its sources."""
from typing import List, Optional
from app.agents.base import AgentContext, AgentResult, BaseAgent
from app.config import get_settings
from app.llm.client import get_llm
from app.rag.retriever import get_retriever

SYSTEM_PROMPT = (
    "You are NeoBank's policy assistant. Answer ONLY from the CONTEXT. "
    "If the answer is not in the context, say you don't know and offer a human agent. "
    "Cite sources as [1], [2]. Never ask for OTP, PIN, CVV or full card numbers."
)


def build_prompt(question: str, hits) -> str:
    ctx = "\n".join(f"[{i + 1}] {c.text}" for i, (c, _) in enumerate(hits))
    return f"CONTEXT:\n{ctx}\nQUESTION: {question}"


def to_sources(hits) -> List[dict]:
    return [{"document": c.document, "chunk_id": c.chunk_id, "score": round(s, 3),
             "snippet": c.text[:160]} for c, s in hits]


class KnowledgeAgent(BaseAgent):
    name = "knowledge_agent"
    description = "Grounded answers on KYC, cards, fees and policies using RAG."

    def __init__(self, document_filter: Optional[str] = None):
        self.document_filter = document_filter

    def answer(self, question: str, document_filter: Optional[str] = None) -> AgentResult:
        s = get_settings()
        hits = get_retriever().search(question, top_k=s.top_k * 2)
        doc_filter = document_filter or self.document_filter
        if doc_filter:
            hits = [h for h in hits if h[0].document == doc_filter] or hits
        hits = [h for h in hits if h[1] >= s.min_retrieval_score][: s.top_k]
        if not hits:   # grounding guardrail: no evidence -> no answer
            return AgentResult(
                "I couldn't find that in NeoBank's policy documents. "
                "Would you like me to connect you to a customer-care executive?",
                confidence=0.2)
        answer = get_llm().generate(SYSTEM_PROMPT, build_prompt(question, hits))
        top = hits[0][1]
        return AgentResult(answer, confidence=round(min(0.95, 0.5 + top), 2), sources=to_sources(hits))

    def run(self, ctx: AgentContext) -> AgentResult:
        return self.answer(ctx.message)

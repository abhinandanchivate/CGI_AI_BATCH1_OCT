"""Central configuration. Every value can be overridden with an environment variable."""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "NeoBank AI Assist"
    api_key: str = "dev-secret-key"

    llm_provider: str = "mock"          # mock | gemini | openai | anthropic
    gemini_api_key: str = ""
    gemini_model: str = "gemini-2.5-flash"
    gemini_embedding_model: str = "gemini-embedding-001"
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-6"

    embedding_backend: str = "tfidf"    # tfidf | gemini | sentence-transformers
    docs_dir: str = "data/docs"
    customers_file: str = "data/customers.json"
    chunk_size: int = 500
    chunk_overlap: int = 80
    top_k: int = 3
    min_retrieval_score: float = 0.08
    memory_turns: int = 10


@lru_cache
def get_settings() -> Settings:
    return Settings()

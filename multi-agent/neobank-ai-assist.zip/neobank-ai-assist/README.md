# NeoBank AI Assist — Multi-Agent Banking Assistant with RAG

A teaching case study: a FastAPI service where an orchestrator routes customer messages to
specialist agents (Account, Loan, Knowledge, Fraud). Policy answers are grounded in bank
documents through Retrieval-Augmented Generation (RAG) and returned with citations.

Uses **Google Gemini** as the LLM (and optionally for embeddings). Without a Gemini key it still
runs fully offline: a TF-IDF retriever and an extractive "mock" LLM take over automatically.

## Using Gemini
1. Get a free API key at https://aistudio.google.com/apikey
2. In `.env` set:
```
LLM_PROVIDER=gemini
GEMINI_API_KEY=your-key
GEMINI_MODEL=gemini-2.5-flash          # any model your key can access
EMBEDDING_BACKEND=gemini               # optional: semantic search with gemini-embedding-001
MIN_RETRIEVAL_SCORE=0.55               # dense scores run higher than TF-IDF; tune with /rag/search
```
3. Restart and check `GET /health`: `llm_provider` should read `gemini`.

If a Gemini call fails (bad key, quota, network), the app logs a warning and answers with the
offline extractive model, so the API never breaks. OpenAI and Anthropic remain optional alternatives.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000/docs for Swagger UI. Use header `X-API-Key: dev-secret-key`.

## Try it
```bash
curl -X POST http://127.0.0.1:8000/api/v1/chat \
  -H "X-API-Key: dev-secret-key" -H "Content-Type: application/json" \
  -d '{"session_id":"s1","customer_id":"CUST1001","message":"Which documents do I need for KYC?"}'
```
Or run the terminal client: `python scripts/demo_client.py`

## Tests
```bash
pytest -q
```

## Project layout
```
app/
  main.py              FastAPI app, middleware, startup indexing
  config.py            Settings from environment variables
  schemas.py           Pydantic request/response models
  api/routes.py        REST endpoints (/api/v1/...)
  agents/              router, orchestrator, account, loan, knowledge, fraud
  rag/                 chunker, embeddings, vector store, retriever, text utils
  llm/client.py        gemini | mock | openai | anthropic
  services/            mock bank DB, security (API key + PII masking), session memory
data/docs/             policy documents indexed by RAG
data/customers.json    mock core-banking data
tests/                 pytest suite (18 tests, incl. Gemini with a fake client)
scripts/demo_client.py interactive CLI client
```

## Docker
```bash
docker build -t neobank-ai-assist .
docker run -p 8000:8000 --env-file .env neobank-ai-assist
```

All banks, customers, policies and numbers in this project are fictional and for education only.

"""Lab 1.1 - Tokenization (BPE) & embeddings. Run: uvicorn main:app --reload --port 8001"""
from fastapi import FastAPI
from pydantic import BaseModel, Field

import bpe
import embeddings
import errors_mw
from gemini_client import count_tokens

app = FastAPI(title="Lab 1.1 - Tokenization & Embeddings (S023)")
errors_mw.install(app)

CORPUS = ("low lower lowest newer newest wider widest the lowest price is newer "
          "the newest model is lower in cost and wider in context ") * 3


class TrainRequest(BaseModel):
    corpus: str = CORPUS
    num_merges: int = Field(30, ge=1, le=500)
    sample: str = "the newest and lowest"


@app.post("/day1/bpe/train")
def bpe_train(req: TrainRequest):
    model = bpe.train(req.corpus, req.num_merges)
    tokens = bpe.encode(req.sample, model["merges"])
    return {"merges_learned": len(model["merges"]),
            "first_merges": ["+".join(m) for m in model["merges"][:15]],
            "vocab_size": len(model["vocab"]), "sample_tokens": tokens,
            "round_trip": bpe.decode(tokens)}


class CompareRequest(BaseModel):
    text: str = "Tokenization splits unbelievable words into subword pieces."
    corpus: str = CORPUS
    num_merges: int = 30


@app.post("/day1/bpe/compare")
async def bpe_compare(req: CompareRequest):
    mine = bpe.encode(req.text, bpe.train(req.corpus, req.num_merges)["merges"])
    out = {"characters": len(req.text), "your_bpe": {"count": len(mine), "tokens": mine},
           "gemini_tokens": await count_tokens(req.text)}
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        ids = enc.encode(req.text)
        out["tiktoken_cl100k"] = {"count": len(ids), "tokens": [enc.decode([i]) for i in ids]}
    except Exception as exc:  # needs a one-time vocabulary download
        out["tiktoken_cl100k"] = f"unavailable: {exc.__class__.__name__}"
    return out


class SimilarityRequest(BaseModel):
    sentences: list[str] = Field(default_factory=lambda: [
        "The cat sat on the mat.", "A kitten is resting on a rug.",
        "Interest rates rose this quarter.", "The central bank raised borrowing costs.",
        "I love pizza."], min_length=2, max_length=20)


@app.post("/day1/embed/similarity")
async def embed_similarity(req: SimilarityRequest):
    return await embeddings.similarity(req.sentences)

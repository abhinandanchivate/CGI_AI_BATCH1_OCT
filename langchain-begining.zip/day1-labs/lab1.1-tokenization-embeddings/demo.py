"""Run Lab 1.1 from the terminal, no server needed:  python demo.py"""
import asyncio

import bpe
from gemini_client import count_tokens, has_key
from main import CORPUS

model = bpe.train(CORPUS, 30)
print("First 10 merges:", ["+".join(m) for m in model["merges"][:10]])
tokens = bpe.encode("the newest and lowest", model["merges"])
print("Tokens:", tokens)
print("Round trip:", bpe.decode(tokens))

if has_key():
    import embeddings

    async def online():
        print("\nGemini token count:", await count_tokens("Tokenization splits unbelievable words."))
        r = await embeddings.similarity(["The cat sat on the mat.", "A kitten rests on a rug.",
                                         "Interest rates rose this quarter."])
        print("Embedding dimensions:", r["dimensions"])
        print("Most similar:", r["most_similar"])
        print("Least similar:", r["least_similar"])
    asyncio.run(online())
else:
    print("\n(Set GEMINI_API_KEY in .env to run the embedding part.)")

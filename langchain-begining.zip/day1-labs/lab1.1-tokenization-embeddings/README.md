# Lab 1.1 – Tokenization (BPE) & Embeddings · S023

Build a Byte Pair Encoding tokenizer from scratch, compare it with Gemini's tokenizer, and turn sentences into embedding vectors.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # add GEMINI_API_KEY
pytest                          # offline tests, no key needed
python demo.py                  # terminal demo
uvicorn main:app --reload --port 8001   # API at http://127.0.0.1:8001/docs
```

## Files

| File | What it does |
| --- | --- |
| `bpe.py` | Train, encode and decode a BPE tokenizer (pure Python, offline) |
| `embeddings.py` | Gemini embeddings + cosine similarity matrix |
| `gemini_client.py` | Gemini client with retries and a concurrency limit |
| `main.py` | FastAPI endpoints |
| `demo.py` | Runs the lab in the terminal |

## Endpoints

| Endpoint | Needs key | Returns |
| --- | --- | --- |
| `POST /day1/bpe/train` | No | Learned merges, vocab size, encoded sample, round trip |
| `POST /day1/bpe/compare` | Yes | Your BPE vs Gemini token count (and tiktoken if available) |
| `POST /day1/embed/similarity` | Yes | Cosine matrix, most and least similar pair |

## Flow

```
/bpe/train        -> count pairs -> merge top pair (repeat) -> encode by merge rank -> tokens + round trip
/embed/similarity -> Gemini embed_content (one batch) -> normalise -> matrix multiply -> ranked pairs
```

**Why:** merge order *is* the tokenizer; the round trip proves correctness; one batch embedding call is cheaper; normalising first makes cosine a single matrix multiply.

"""Turn Gemini and validation errors into clean JSON responses."""
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from google.genai import errors


def install(app: FastAPI) -> None:
    @app.exception_handler(errors.APIError)
    async def gemini_error(_: Request, exc: errors.APIError):
        return JSONResponse(status_code=502, content={"error": "Gemini API error", "code": exc.code,
                                                      "message": str(exc)[:500]})

    @app.exception_handler(ValueError)
    async def value_error(_: Request, exc: ValueError):
        return JSONResponse(status_code=400, content={"error": str(exc)})

    @app.exception_handler(RuntimeError)
    async def runtime_error(_: Request, exc: RuntimeError):
        return JSONResponse(status_code=500, content={"error": str(exc)})

"""Minimal Gemini helper for this lab.

Copied into every lab folder on purpose, so each lab runs on its own with no
shared package to install. Reads settings from .env (see .env.example).
"""
from __future__ import annotations

import asyncio
import os
import time
from dataclasses import dataclass, field
from typing import Any

from dotenv import load_dotenv
from google import genai
from google.genai import errors, types

load_dotenv()

MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
MAX_CONCURRENCY = int(os.getenv("MAX_CONCURRENCY", "4"))
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))

_client: genai.Client | None = None
_sem: asyncio.Semaphore | None = None


def client() -> genai.Client:
    """One client per process. Fails with a clear message if the key is missing."""
    global _client
    if _client is None:
        key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        if not key:
            raise RuntimeError("GEMINI_API_KEY is not set. Copy .env.example to .env and add your key.")
        _client = genai.Client(api_key=key)
    return _client


def has_key() -> bool:
    return bool(os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))


@dataclass
class Result:
    text: str
    latency_ms: float
    usage: dict[str, Any]
    thoughts: str | None = None
    response: Any = field(default=None, repr=False)

    def public(self) -> dict[str, Any]:
        out = {"text": self.text, "latency_ms": self.latency_ms, "usage": self.usage}
        if self.thoughts:
            out["thought_summary"] = self.thoughts
        return out


def no_thinking(model: str | None = None) -> dict[str, Any]:
    """Flash models can turn thinking off completely; Pro models cannot."""
    if "flash" in (model or MODEL):
        return {"thinking_config": types.ThinkingConfig(thinking_budget=0)}
    return {}


def _usage(resp) -> dict[str, Any]:
    u = resp.usage_metadata
    if u is None:
        return {}
    return {"prompt_tokens": u.prompt_token_count, "output_tokens": u.candidates_token_count,
            "thinking_tokens": u.thoughts_token_count, "total_tokens": u.total_token_count}


def _split(resp) -> tuple[str, str | None]:
    answer, thoughts = [], []
    for cand in resp.candidates or []:
        for part in (cand.content.parts if cand.content and cand.content.parts else []):
            if part.text:
                (thoughts if part.thought else answer).append(part.text)
    return "".join(answer), ("\n".join(thoughts) or None)


async def generate(contents: Any, *, system: str | None = None, model: str | None = None,
                   **config: Any) -> Result:
    """Async Gemini call with a concurrency limit and retries on 429/500/503.
    Extra keyword arguments go into GenerateContentConfig (temperature, top_p,
    thinking_config, response_schema, ...)."""
    global _sem
    if _sem is None:
        _sem = asyncio.Semaphore(MAX_CONCURRENCY)
    cfg = types.GenerateContentConfig(system_instruction=system, **config)
    async with _sem:
        for attempt in range(MAX_RETRIES + 1):
            try:
                start = time.perf_counter()
                resp = await client().aio.models.generate_content(
                    model=model or MODEL, contents=contents, config=cfg)
                break
            except errors.APIError as exc:
                if exc.code in (429, 500, 503) and attempt < MAX_RETRIES:
                    await asyncio.sleep(2 ** attempt)
                    continue
                raise
    text, thoughts = _split(resp)
    return Result(text=text, latency_ms=round((time.perf_counter() - start) * 1000, 1),
                  usage=_usage(resp), thoughts=thoughts, response=resp)


async def count_tokens(text: str, model: str | None = None) -> int:
    resp = await client().aio.models.count_tokens(model=model or MODEL, contents=text)
    return resp.total_tokens

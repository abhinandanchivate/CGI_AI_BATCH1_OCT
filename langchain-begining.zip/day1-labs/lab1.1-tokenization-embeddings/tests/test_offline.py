import numpy as np

import bpe
from embeddings import cosine_matrix, rank_pairs


def test_first_merge_is_most_frequent_pair():
    assert bpe.train("low lower lowest " * 5, 10)["merges"][0] == ("l", "o")


def test_round_trip_and_compression():
    merges = bpe.train("low lower lowest " * 5, 10)["merges"]
    tokens = bpe.encode("lowest low", merges)
    assert bpe.decode(tokens) == "lowest low"
    assert len(tokens) < len("lowest low")


def test_cosine_matrix_and_ranking():
    v = np.array([[1, 0], [0.9, 0.1], [0, 1]], dtype=float)
    sims = cosine_matrix(v)
    assert np.allclose(np.diag(sims), 1)
    top = rank_pairs(["a", "b", "c"], sims)[0]
    assert {top[1], top[2]} == {"a", "b"}

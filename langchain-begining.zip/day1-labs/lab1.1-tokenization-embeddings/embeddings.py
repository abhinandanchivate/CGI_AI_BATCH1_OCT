"""S023 - Embeddings: text -> vectors, compared with cosine similarity."""
from __future__ import annotations

import os

import numpy as np

from gemini_client import client

EMBEDDING_MODEL = os.getenv("GEMINI_EMBEDDING_MODEL", "gemini-embedding-001")


async def embed(texts: list[str]) -> np.ndarray:
    """One batch call for all texts: faster and cheaper than one call each."""
    resp = await client().aio.models.embed_content(model=EMBEDDING_MODEL, contents=texts)
    return np.array([e.values for e in resp.embeddings], dtype=np.float32)


def cosine_matrix(vectors: np.ndarray) -> np.ndarray:
    """Scale every vector to length 1, then one matrix multiply gives all cosines."""
    unit = vectors / np.linalg.norm(vectors, axis=1, keepdims=True)
    return unit @ unit.T


def rank_pairs(sentences: list[str], sims: np.ndarray) -> list[tuple[float, str, str]]:
    return sorted(((float(sims[i, j]), sentences[i], sentences[j])
                   for i in range(len(sentences)) for j in range(i + 1, len(sentences))),
                  reverse=True)


async def similarity(sentences: list[str]) -> dict:
    vecs = await embed(sentences)
    sims = cosine_matrix(vecs)
    pairs = rank_pairs(sentences, sims)
    return {"model": EMBEDDING_MODEL, "dimensions": int(vecs.shape[1]),
            "matrix": sims.round(3).tolist(),
            "most_similar": {"score": round(pairs[0][0], 3), "a": pairs[0][1], "b": pairs[0][2]},
            "least_similar": {"score": round(pairs[-1][0], 3), "a": pairs[-1][1], "b": pairs[-1][2]}}

"""S023 - Byte Pair Encoding (BPE) from scratch.

Classic word-level BPE (Sennrich et al., 2016): start from characters, repeatedly
merge the most frequent adjacent pair. `</w>` marks the end of a word so the
tokenizer can tell "low" (whole word) from "low" inside "lowest".
"""
from __future__ import annotations

import re
from collections import Counter

EOW = "</w>"


def _words(text: str) -> list[str]:
    return re.findall(r"\w+|[^\w\s]", text.lower())


def _pair_counts(vocab: dict[tuple[str, ...], int]) -> Counter:
    pairs: Counter = Counter()
    for symbols, freq in vocab.items():
        for a, b in zip(symbols, symbols[1:]):
            pairs[(a, b)] += freq
    return pairs


def _merge(pair: tuple[str, str], vocab: dict[tuple[str, ...], int]) -> dict:
    merged = {}
    for symbols, freq in vocab.items():
        out, i = [], 0
        while i < len(symbols):
            if i < len(symbols) - 1 and (symbols[i], symbols[i + 1]) == pair:
                out.append(symbols[i] + symbols[i + 1])
                i += 2
            else:
                out.append(symbols[i])
                i += 1
        merged[tuple(out)] = freq
    return merged


def train(corpus: str, num_merges: int = 50) -> dict:
    vocab = {tuple(w) + (EOW,): f for w, f in Counter(_words(corpus)).items()}
    merges: list[tuple[str, str]] = []
    for _ in range(num_merges):
        pairs = _pair_counts(vocab)
        if not pairs:
            break
        best, freq = pairs.most_common(1)[0]
        if freq < 2:  # merging a pair seen once teaches nothing general
            break
        merges.append(best)
        vocab = _merge(best, vocab)
    tokens = sorted({s for symbols in vocab for s in symbols})
    return {"merges": merges, "vocab": tokens}


def encode(text: str, merges: list[tuple[str, str]]) -> list[str]:
    ranks = {pair: i for i, pair in enumerate(merges)}
    out: list[str] = []
    for word in _words(text):
        symbols = list(word) + [EOW]
        while len(symbols) > 1:
            candidates = [(ranks.get((a, b), 10**9), i)
                          for i, (a, b) in enumerate(zip(symbols, symbols[1:]))]
            rank, i = min(candidates)
            if rank == 10**9:
                break
            symbols[i:i + 2] = [symbols[i] + symbols[i + 1]]
        out.extend(symbols)
    return out


def decode(tokens: list[str]) -> str:
    return "".join(tokens).replace(EOW, " ").strip()

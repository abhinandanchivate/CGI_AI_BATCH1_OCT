# Lab 1.5 – LangChain Essentials & Architecture · S027

Build a `prompt | model | parser` chain on Gemini with LangChain and run it three ways: once, as a batch, and streamed.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # add GEMINI_API_KEY
pytest                          # offline: checks the prompt template
python demo.py
uvicorn main:app --reload --port 8005   # http://127.0.0.1:8005/docs
```

## Endpoints

| Endpoint | Needs key | Returns |
| --- | --- | --- |
| `POST /day1/chain/preview` | No | The messages the template produces |
| `POST /day1/chain/invoke` | Yes | One answer |
| `POST /day1/chain/batch` | Yes | Several answers, run concurrently |
| `POST /day1/chain/stream` | Yes | Text streamed as it is generated |

Stream from a terminal (Swagger waits for the whole response):

```bash
curl -N -X POST http://127.0.0.1:8005/day1/chain/stream -H "Content-Type: application/json" \
  -d '{"topic": "top-p sampling", "audience": "designer"}'
```

## Flow

```
ChatPromptTemplate (system + human) -> ChatGoogleGenerativeAI (Gemini) -> StrOutputParser -> invoke / batch / stream
```

**Why:** templates keep fixed instructions apart from variables; the pipe gives every chain invoke, batch and stream; the Gemini connector is the only provider-specific piece, so switching models changes one import.

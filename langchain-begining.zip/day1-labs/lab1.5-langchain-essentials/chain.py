"""S027 - LangChain essentials: prompt | model | parser (LCEL), using Gemini.

This lab reaches Gemini through LangChain's connector (langchain-google-genai)
instead of the google-genai SDK used in Labs 1.1-1.4, so you can compare both.
"""
from __future__ import annotations

import os
from functools import lru_cache

from dotenv import load_dotenv
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

load_dotenv()

PROMPT = ChatPromptTemplate.from_messages([
    ("system", "You are a concise AI tutor. Answer in exactly 3 bullet points."),
    ("human", "Explain {topic} to a {audience}."),
])


@lru_cache
def build_chain():
    """Built once per process; the pipe gives invoke, batch and stream for free."""
    from langchain_google_genai import ChatGoogleGenerativeAI

    key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not key:
        raise RuntimeError("GEMINI_API_KEY is not set. Copy .env.example to .env and add your key.")
    llm = ChatGoogleGenerativeAI(model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
                                 google_api_key=key, temperature=0.3)
    return PROMPT | llm | StrOutputParser()

"""Run Lab 1.5 from the terminal:  python demo.py"""
import asyncio
import os
import sys
import time

from dotenv import load_dotenv

from chain import PROMPT, build_chain

load_dotenv()
print("Prompt preview:")
for m in PROMPT.invoke({"topic": "tokens", "audience": "student"}).to_messages():
    print(f"  [{m.type}] {m.content}")

if not (os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")):
    sys.exit("\n(Set GEMINI_API_KEY in .env to run the chain.)")


async def main():
    chain = build_chain()
    t = time.perf_counter()
    print("\ninvoke:\n", await chain.ainvoke({"topic": "embeddings", "audience": "10-year-old"}))
    print(f"  ({time.perf_counter() - t:.1f}s)")
    t = time.perf_counter()
    outs = await chain.abatch([{"topic": "tokens", "audience": "designer"},
                               {"topic": "temperature", "audience": "product manager"}])
    print(f"\nbatch of 2 ({time.perf_counter() - t:.1f}s):")
    for o in outs:
        print(o, "\n")
    print("stream:")
    async for chunk in chain.astream({"topic": "top-p sampling", "audience": "chef"}):
        print(chunk, end="", flush=True)
    print()

asyncio.run(main())

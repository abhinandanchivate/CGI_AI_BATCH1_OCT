from fastapi.testclient import TestClient

from chain import PROMPT
from main import app


def test_prompt_has_system_and_variables():
    msgs = PROMPT.invoke({"topic": "tokens", "audience": "student"}).to_messages()
    assert msgs[0].type == "system" and "tokens" in msgs[1].content
    assert set(PROMPT.input_variables) == {"topic", "audience"}


def test_preview_endpoint_needs_no_key():
    r = TestClient(app).post("/day1/chain/preview", json={"topic": "RAG"})
    assert r.status_code == 200 and "RAG" in r.json()["messages"][1]["content"]

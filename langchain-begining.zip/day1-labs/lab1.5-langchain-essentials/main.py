"""Lab 1.5 - LangChain essentials. Run: uvicorn main:app --reload --port 8005"""
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

import errors_mw
from chain import PROMPT, build_chain

app = FastAPI(title="Lab 1.5 - LangChain essentials & architecture (S027)")
errors_mw.install(app)


class ChainRequest(BaseModel):
    topic: str = "embeddings"
    audience: str = "10-year-old"


class BatchRequest(BaseModel):
    items: list[ChainRequest] = [ChainRequest(topic="tokens"),
                                 ChainRequest(topic="temperature", audience="product manager")]


@app.post("/day1/chain/preview")
def preview(req: ChainRequest):
    """Shows the exact messages the template produces (no API call)."""
    return {"messages": [{"role": m.type, "content": m.content}
                         for m in PROMPT.invoke(req.model_dump()).to_messages()]}


@app.post("/day1/chain/invoke")
async def invoke(req: ChainRequest):
    return {"output": await build_chain().ainvoke(req.model_dump())}


@app.post("/day1/chain/batch")
async def batch(req: BatchRequest):
    return {"outputs": await build_chain().abatch([i.model_dump() for i in req.items])}


@app.post("/day1/chain/stream")
async def stream(req: ChainRequest):
    async def tokens():
        async for chunk in build_chain().astream(req.model_dump()):
            yield chunk
    return StreamingResponse(tokens(), media_type="text/plain")

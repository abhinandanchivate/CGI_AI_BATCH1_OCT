"""Run Lab 1.4 from the terminal:  python demo.py   (add --image to call Imagen)"""
import asyncio
import pathlib
import sys

import diffusion
from gemini_client import has_key

out = pathlib.Path("outputs")
out.mkdir(exist_ok=True)
for kind in ("linear", "cosine"):
    print(f"\n{kind} schedule:")
    for r in diffusion.schedule_table(kind)["rows"]:
        print(f"  t={r['t']:>4}  signal={r['signal_coef']:.3f}  noise={r['noise_coef']:.3f}")
    path = out / f"forward_{kind}.png"
    path.write_bytes(diffusion.forward_strip([0, 50, 150, 300, 600, 999], kind))
    print("  saved", path)

if "--image" in sys.argv:
    if not has_key():
        sys.exit("Set GEMINI_API_KEY in .env to generate an image.")
    import imagegen
    data = asyncio.run(imagegen.generate_image("A watercolor robot reading under a banyan tree"))
    (out / "imagen.png").write_bytes(data)
    print("\nsaved outputs/imagen.png")

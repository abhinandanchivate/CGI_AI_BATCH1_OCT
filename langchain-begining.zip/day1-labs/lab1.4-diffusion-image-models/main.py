"""Lab 1.4 - Diffusion & image models. Run: uvicorn main:app --reload --port 8004"""
from typing import Literal

from fastapi import FastAPI, Response
from pydantic import BaseModel

import diffusion
import errors_mw
import imagegen

app = FastAPI(title="Lab 1.4 - LMMs: DALL-E, Imagen, diffusion models (S026)")
errors_mw.install(app)


@app.get("/day1/diffusion/schedule")
def schedule(kind: Literal["linear", "cosine"] = "linear"):
    return diffusion.schedule_table(kind)


class ForwardRequest(BaseModel):
    timesteps: list[int] = [0, 50, 150, 300, 600, 999]
    kind: Literal["linear", "cosine"] = "linear"


@app.post("/day1/diffusion/forward", response_class=Response)
def forward(req: ForwardRequest):
    if any(not 0 <= t < 1000 for t in req.timesteps):
        raise ValueError("timesteps must be between 0 and 999")
    return Response(diffusion.forward_strip(req.timesteps, req.kind), media_type="image/png")


class ImageRequest(BaseModel):
    prompt: str = "A watercolor illustration of a robot reading a book under a banyan tree"
    aspect_ratio: Literal["1:1", "3:4", "4:3", "9:16", "16:9"] = "1:1"


@app.post("/day1/image/generate", response_class=Response)
async def image(req: ImageRequest):
    return Response(await imagegen.generate_image(req.prompt, req.aspect_ratio), media_type="image/png")

# Lab 1.4 – LMMs: DALL·E, Imagen & Diffusion Models · S026

Watch the diffusion forward process destroy an image step by step (offline), then generate an image with Imagen.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # key needed only for Imagen
pytest
python demo.py                  # writes outputs/forward_linear.png and forward_cosine.png
python demo.py --image          # also calls Imagen -> outputs/imagen.png
uvicorn main:app --reload --port 8004   # http://127.0.0.1:8004/docs
```

## Endpoints

| Endpoint | Needs key | Returns |
| --- | --- | --- |
| `GET /day1/diffusion/schedule?kind=linear` | No | Signal and noise coefficients per step |
| `POST /day1/diffusion/forward` | No | PNG strip of the noised image |
| `POST /day1/image/generate` | Yes, billing-enabled | PNG from Imagen |

## Flow

```
forward:  betas -> alpha_bar = cumprod(1 - beta) -> x_t = sqrt(alpha_bar)*x0 + sqrt(1-alpha_bar)*noise -> PNG
image:    prompt -> Imagen (generate_images) -> empty? prompt filtered -> PNG bytes
```

**Why:** the closed form jumps straight to any step; the same noise is reused so frames compare fairly; image models may return nothing when a prompt is filtered.

Imagen requires a Gemini API key with billing enabled. Set `IMAGEN_MODEL` in `.env` if the model name changes.

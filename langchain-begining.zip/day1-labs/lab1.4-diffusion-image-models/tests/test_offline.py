import numpy as np

import diffusion


def test_schedules_decay():
    for ab in (diffusion.linear_schedule(), diffusion.cosine_schedule()):
        assert ab[0] > 0.99 and ab[-1] < 0.01 and np.all(np.diff(ab) <= 0)


def test_cosine_keeps_more_signal_early():
    assert diffusion.cosine_schedule()[250] > diffusion.linear_schedule()[250]


def test_forward_strip_is_png():
    assert diffusion.forward_strip([0, 500, 999])[:4] == b"\x89PNG"

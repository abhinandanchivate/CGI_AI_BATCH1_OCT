"""S026 - Diffusion models: the forward (noising) process, made visible.

A diffusion model is trained to undo this process. Here we only run the forward
direction, which has a closed form:
    x_t = sqrt(alpha_bar_t) * x_0 + sqrt(1 - alpha_bar_t) * noise
"""
from __future__ import annotations

import io

import numpy as np
from PIL import Image


def linear_schedule(steps: int = 1000, beta_start: float = 1e-4,
                    beta_end: float = 0.02) -> np.ndarray:
    betas = np.linspace(beta_start, beta_end, steps)
    return np.cumprod(1.0 - betas)  # alpha_bar_t


def cosine_schedule(steps: int = 1000, s: float = 0.008) -> np.ndarray:
    t = np.arange(steps + 1) / steps
    f = np.cos((t + s) / (1 + s) * np.pi / 2) ** 2
    return np.clip(f[1:] / f[0], 1e-5, 1.0)


def schedule_table(kind: str = "linear", steps: int = 1000) -> dict:
    ab = linear_schedule(steps) if kind == "linear" else cosine_schedule(steps)
    marks = [0, steps // 10, steps // 4, steps // 2, 3 * steps // 4, steps - 1]
    return {"schedule": kind, "steps": steps, "rows": [
        {"t": t, "signal_coef": round(float(np.sqrt(ab[t])), 4),
         "noise_coef": round(float(np.sqrt(1 - ab[t])), 4)} for t in marks]}


def sample_image(size: int = 96) -> np.ndarray:
    """A synthetic picture (sun over hills) so the lab needs no downloads."""
    y, x = np.mgrid[0:size, 0:size] / size
    img = np.stack([0.35 + 0.4 * y, 0.6 + 0.2 * y, 0.95 - 0.3 * y], axis=-1)  # sky
    sun = (x - 0.7) ** 2 + (y - 0.3) ** 2 < 0.02
    img[sun] = [1.0, 0.85, 0.2]
    hills = y > 0.65 + 0.08 * np.sin(x * 9)
    img[hills] = [0.2, 0.55, 0.25]
    return img * 2 - 1  # scale to [-1, 1] like real diffusion models


def forward_strip(timesteps: list[int], kind: str = "linear", seed: int = 0) -> bytes:
    ab = linear_schedule() if kind == "linear" else cosine_schedule()
    x0 = sample_image()
    rng = np.random.default_rng(seed)
    noise = rng.standard_normal(x0.shape)  # same noise for every frame: fair comparison
    frames = []
    for t in timesteps:
        xt = np.sqrt(ab[t]) * x0 + np.sqrt(1 - ab[t]) * noise
        frames.append(((np.clip(xt, -1, 1) + 1) * 127.5).astype(np.uint8))
    strip = np.concatenate(frames, axis=1)
    buf = io.BytesIO()
    Image.fromarray(strip).resize((strip.shape[1] * 2, strip.shape[0] * 2),
                                  Image.NEAREST).save(buf, format="PNG")
    return buf.getvalue()

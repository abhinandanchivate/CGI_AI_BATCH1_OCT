"""S026 - Text-to-image with Imagen through the Gemini API (needs a billing-enabled key)."""
from __future__ import annotations

import os

from google.genai import types

from gemini_client import client

IMAGEN_MODEL = os.getenv("IMAGEN_MODEL", "imagen-4.0-generate-001")


async def generate_image(prompt: str, aspect_ratio: str = "1:1") -> bytes:
    resp = await client().aio.models.generate_images(
        model=IMAGEN_MODEL, prompt=prompt,
        config=types.GenerateImagesConfig(number_of_images=1, aspect_ratio=aspect_ratio))
    if not resp.generated_images:  # safety filters return nothing rather than an error
        raise ValueError("No image returned (the prompt may have been filtered).")
    return resp.generated_images[0].image.image_bytes

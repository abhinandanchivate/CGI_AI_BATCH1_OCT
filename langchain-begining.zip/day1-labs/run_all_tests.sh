#!/usr/bin/env bash
# Runs the offline tests of every lab, each from inside its own folder.
set -e
cd "$(dirname "$0")"
for lab in lab1.*/; do
  echo "== $lab"
  (cd "$lab" && python -m pytest -q)
done

# Day 1 Labs – Models + LangChain (Gemini)

Five independent labs. Each folder has its own `requirements.txt`, `.env.example`, Gemini client, FastAPI app, terminal demo and offline tests, so you can copy any one folder and run it alone.

| Lab | Session | Folder | Port | Key needed |
| --- | --- | --- | --- | --- |
| 1.1 | S023 Tokenization & embeddings | `lab1.1-tokenization-embeddings` | 8001 | For embeddings only |
| 1.2 | S024 Reasoning strategies | `lab1.2-reasoning-strategies` | 8002 | Yes |
| 1.3 | S025 Sampling controls | `lab1.3-sampling-controls` | 8003 | For the Gemini part only |
| 1.4 | S026 Diffusion & image models | `lab1.4-diffusion-image-models` | 8004 | For Imagen only (billing) |
| 1.5 | S027 LangChain essentials | `lab1.5-langchain-essentials` | 8005 | Yes |

## Run any lab

```bash
cd lab1.1-tokenization-embeddings
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env      # add your key from https://aistudio.google.com/apikey
pytest                    # offline tests
python demo.py            # terminal demo
uvicorn main:app --reload --port 8001
```

Each lab uses a different port, so all five can run at the same time.

## Run every lab's tests

```bash
./run_all_tests.sh        # creates nothing; uses your current Python environment
```

Install everything at once with `pip install -r requirements-all.txt`.

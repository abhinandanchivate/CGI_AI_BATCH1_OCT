import asyncio

import strategies
from gemini_client import Result


def test_extract_final():
    assert strategies.extract_final("work...\nFinal answer: **5 cents**.") == "5 cents"
    assert strategies.extract_final("no marker\n42") == "42"


def test_majority_vote():
    assert strategies.majority(["5", "5", "10", "5", "10"]) == ("5", 0.6)


def test_self_consistency_with_fake_model(monkeypatch):
    answers = iter(["Final answer: 5", "Final answer: 10", "Final answer: 5",
                    "Final answer: 5", "Final answer: 10"])

    async def fake_generate(*_, **__):
        return Result(text=next(answers), latency_ms=10, usage={"total_tokens": 20})

    monkeypatch.setattr(strategies, "generate", fake_generate)
    r = asyncio.run(strategies.run("self_consistency", "q"))
    assert r["answer"] == "5" and r["agreement"] == 0.6 and r["total_tokens"] == 100

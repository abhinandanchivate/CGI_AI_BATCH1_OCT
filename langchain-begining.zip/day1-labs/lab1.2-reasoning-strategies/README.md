# Lab 1.2 – Reasoning Tokens & Inference Strategies · S024

Ask Gemini one question five ways and compare answer, latency and token cost.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # add GEMINI_API_KEY (required for this lab)
pytest                          # offline tests use a fake model
python demo.py "What is 17 * 24 - 13 * 19?"
uvicorn main:app --reload --port 8002   # http://127.0.0.1:8002/docs
```

## Strategies (`strategies.py`)

| Strategy | Where the reasoning happens | Cost |
| --- | --- | --- |
| `direct` | Nowhere, thinking off | Lowest |
| `chain_of_thought` | Visible text ("think step by step") | Output tokens |
| `self_consistency` | 5 sampled answers, majority vote | ~5x |
| `thinking_budget` | Hidden thinking, budget 4096 | Thinking tokens |
| `thinking_dynamic` | Hidden thinking, model decides (budget -1) | Varies |

## Endpoints

`GET /day1/reasoning/strategies` · `POST /day1/reasoning/compare`

## Flow

```
/reasoning/compare -> asyncio.gather(5 strategies) -> Gemini (via gemini_client) -> extract "Final answer" -> one row per strategy
```

**Why:** strategies run in parallel, so you wait only for the slowest; every strategy ends with `Final answer:` so they are scored the same way.

Note: this lab makes about 9 Gemini calls per comparison. On a free key, keep `MAX_CONCURRENCY` low if you hit 429 errors.

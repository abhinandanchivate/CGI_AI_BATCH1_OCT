"""Run Lab 1.2 from the terminal:  python demo.py ["your question"]"""
import asyncio
import sys

import strategies
from gemini_client import has_key

if not has_key():
    sys.exit("Set GEMINI_API_KEY in .env first (this lab needs Gemini).")

question = sys.argv[1] if len(sys.argv) > 1 else (
    "A bat and a ball cost $1.10 in total. The bat costs $1.00 more than the ball. "
    "How many cents does the ball cost?")
result = asyncio.run(strategies.compare(question))
print(f"Question: {question}\n")
print(f"{'strategy':<18}{'answer':<14}{'latency ms':>12}{'tokens':>9}")
for r in result["strategies"]:
    tokens = r.get("total_tokens") or (r.get("usage") or {}).get("total_tokens")
    print(f"{r['strategy']:<18}{str(r['answer'])[:13]:<14}{r['latency_ms']:>12}{str(tokens):>9}")

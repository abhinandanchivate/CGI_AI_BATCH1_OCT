"""Lab 1.2 - Reasoning strategies. Run: uvicorn main:app --reload --port 8002"""
from typing import Literal

from fastapi import FastAPI
from pydantic import BaseModel

import errors_mw
import strategies

app = FastAPI(title="Lab 1.2 - Reasoning tokens & inference strategies (S024)")
errors_mw.install(app)

Strategy = Literal["direct", "chain_of_thought", "self_consistency", "thinking_budget", "thinking_dynamic"]


class CompareRequest(BaseModel):
    question: str = ("A bat and a ball cost $1.10 in total. The bat costs $1.00 more than "
                     "the ball. How many cents does the ball cost?")
    strategies: list[Strategy] = list(strategies.STRATEGIES)


@app.get("/day1/reasoning/strategies")
def list_strategies():
    return {"strategies": strategies.STRATEGIES}


@app.post("/day1/reasoning/compare")
async def compare(req: CompareRequest):
    return await strategies.compare(req.question, list(req.strategies))

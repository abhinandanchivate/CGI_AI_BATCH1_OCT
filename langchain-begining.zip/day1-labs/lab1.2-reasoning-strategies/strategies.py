"""S024 - Reasoning tokens & inference strategies.

Five ways to answer the same question, from cheapest to most effort:
  direct            - answer immediately, no thinking
  chain_of_thought  - reasoning written out in the visible answer
  self_consistency  - 5 sampled reasoning paths, majority vote
  thinking_budget   - hidden thinking tokens, fixed budget
  thinking_dynamic  - hidden thinking, the model decides how much
"""
from __future__ import annotations

import asyncio
import re
from collections import Counter

from google.genai import types

from gemini_client import generate, no_thinking

SUFFIX = "\nEnd your response with a line of the form 'Final answer: <answer>'."
FINAL_RE = re.compile(r"final answer\s*[:\-]\s*(.+)", re.IGNORECASE)
STRATEGIES = ["direct", "chain_of_thought", "self_consistency", "thinking_budget", "thinking_dynamic"]


def extract_final(text: str) -> str:
    """Pull the last 'Final answer:' line so every strategy is scored the same way."""
    matches = FINAL_RE.findall(text or "")
    if matches:
        answer = matches[-1]
    else:
        lines = [ln for ln in (text or "").strip().splitlines() if ln.strip()]
        answer = lines[-1] if lines else ""
    return answer.strip().strip("*.$ ").strip()


def majority(answers: list[str]) -> tuple[str, float]:
    winner, votes = Counter(answers).most_common(1)[0]
    return winner, round(votes / len(answers), 2)


async def run(strategy: str, question: str, budget: int = 4096) -> dict:
    if strategy == "direct":
        r = await generate(question + SUFFIX, temperature=0.0, **no_thinking())
    elif strategy == "chain_of_thought":
        r = await generate(question + "\nLet's think step by step." + SUFFIX,
                           temperature=0.0, **no_thinking())
    elif strategy == "self_consistency":
        results = await asyncio.gather(*[
            generate(question + "\nLet's think step by step." + SUFFIX, temperature=0.9, **no_thinking())
            for _ in range(5)])
        answers = [extract_final(x.text) for x in results]
        winner, agreement = majority(answers)
        return {"strategy": strategy, "answer": winner, "votes": dict(Counter(answers)),
                "agreement": agreement, "latency_ms": max(x.latency_ms for x in results),
                "total_tokens": sum(x.usage.get("total_tokens") or 0 for x in results)}
    elif strategy in ("thinking_budget", "thinking_dynamic"):
        cfg = types.ThinkingConfig(thinking_budget=budget if strategy == "thinking_budget" else -1,
                                   include_thoughts=True)
        r = await generate(question + SUFFIX, temperature=0.0, thinking_config=cfg)
    else:
        raise ValueError(f"Unknown strategy {strategy!r}. Choose from {STRATEGIES}")
    return {"strategy": strategy, "answer": extract_final(r.text), "latency_ms": r.latency_ms,
            "usage": r.usage, "thought_summary": (r.thoughts or "")[:500] or None}


async def compare(question: str, strategies: list[str] | None = None) -> dict:
    """All strategies at once: total time = the slowest one, not the sum."""
    chosen = strategies or STRATEGIES
    rows = await asyncio.gather(*[run(s, question) for s in chosen])
    return {"question": question, "strategies": rows}

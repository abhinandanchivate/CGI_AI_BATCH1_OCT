import numpy as np

import sampling


def test_temperature_changes_entropy():
    logits = [5.0, 3.0, 1.0, 0.0]
    assert sampling.entropy_bits(sampling.apply_controls(logits, 0.2)) < \
        sampling.entropy_bits(sampling.apply_controls(logits, 2.0))


def test_greedy_top_k_top_p():
    logits = [5.0, 3.0, 1.0, 0.0]
    assert sampling.apply_controls(logits, 0)[0] == 1.0
    assert (sampling.apply_controls(logits, 1, top_k=2) > 0).sum() == 2
    p = sampling.apply_controls(logits, 1, top_p=0.9)
    assert np.isclose(p.sum(), 1.0) and (p > 0).sum() <= 3


def test_distinct_n():
    assert sampling.distinct_n(["a b c", "a b c"]) == 0.5

"""Run Lab 1.3 from the terminal:  python demo.py"""
import asyncio

import sampling
from gemini_client import has_key

tokens = ["Paris", "London", "Rome", "Berlin", "pizza", "the"]
logits = [5.0, 3.0, 2.5, 2.0, 0.5, 0.1]
print("Offline: effect of temperature, top-k and top-p")
for label, kw in [("T=0.5", dict(temperature=0.5)), ("T=1.0", dict(temperature=1.0)),
                  ("T=2.0", dict(temperature=2.0)), ("T=1, top_k=2", dict(temperature=1.0, top_k=2)),
                  ("T=1, top_p=0.9", dict(temperature=1.0, top_p=0.9))]:
    p = sampling.apply_controls(logits, kw["temperature"], kw.get("top_k"), kw.get("top_p"))
    probs = "  ".join(f"{t}:{v:.2f}" for t, v in zip(tokens, p) if v > 0)
    print(f"  {label:<15} entropy={sampling.entropy_bits(p):.2f} bits  {probs}")

if has_key():
    async def online():
        for t in (0.0, 1.5):
            r = await sampling.gemini_demo("Write a one-line slogan for a coffee shop on Mars.",
                                           4, t, 0.95, 40, 60)
            print(f"\nGemini at temperature {t}: {r['unique_outputs']} unique of 4, distinct-2={r['distinct_2']}")
            for o in r["outputs"]:
                print("  -", o)
        r = await sampling.gemini_demo("Explain photosynthesis.", 1, 0.7, None, None, 8)
        print("\nWith max_output_tokens=8:", r["outputs"][0], "| finish:", r["finish_reasons"][0])
    asyncio.run(online())
else:
    print("\n(Set GEMINI_API_KEY in .env to run the Gemini part.)")

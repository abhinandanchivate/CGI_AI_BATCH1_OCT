# Lab 1.3 – Max New Tokens, Sampling, Temperature, Top-k, Top-p · S025

See what each generation setting does: first with NumPy on fixed scores, then on Gemini.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # key needed only for the Gemini part
pytest
python demo.py
uvicorn main:app --reload --port 8003   # http://127.0.0.1:8003/docs
```

## Endpoints

| Endpoint | Needs key | Returns |
| --- | --- | --- |
| `POST /day1/sampling/local` | No | Probabilities after temperature/top-k/top-p, entropy, samples |
| `POST /day1/sampling/gemini` | Yes | N completions, finish reasons, unique count, distinct-2 |

## Flow

```
local:  logits -> / temperature -> softmax -> top-k -> top-p -> renormalise -> sample
gemini: N parallel calls (temperature, top_p, top_k, max_output_tokens) -> outputs + finish reasons -> diversity
```

**Why:** temperature reshapes the distribution before the filters cut its tail; thinking is off in the Gemini test because hidden thinking also counts against `max_output_tokens`; several samples are needed to see randomness.

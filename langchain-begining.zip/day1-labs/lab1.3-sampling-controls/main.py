"""Lab 1.3 - Sampling & generation controls. Run: uvicorn main:app --reload --port 8003"""
from fastapi import FastAPI
from pydantic import BaseModel, Field

import errors_mw
import sampling

app = FastAPI(title="Lab 1.3 - Max new tokens, sampling, temperature, top-k, top-p (S025)")
errors_mw.install(app)


class LocalRequest(BaseModel):
    tokens: list[str] = ["Paris", "London", "Rome", "Berlin", "pizza", "the"]
    logits: list[float] = [5.0, 3.0, 2.5, 2.0, 0.5, 0.1]
    temperature: float = Field(1.0, ge=0, le=5)
    top_k: int | None = Field(None, ge=1)
    top_p: float | None = Field(None, gt=0, le=1)
    samples: int = Field(20, ge=1, le=1000)


@app.post("/day1/sampling/local")
def sampling_local(req: LocalRequest):
    if len(req.tokens) != len(req.logits):
        raise ValueError("tokens and logits must have the same length")
    return sampling.local_demo(req.tokens, req.logits, req.temperature, req.top_k, req.top_p, req.samples)


class GeminiRequest(BaseModel):
    prompt: str = "Write a one-line slogan for a coffee shop on Mars."
    n: int = Field(5, ge=1, le=10)
    temperature: float = Field(1.0, ge=0, le=2)
    top_p: float | None = Field(0.95, gt=0, le=1)
    top_k: int | None = Field(40, ge=1)
    max_output_tokens: int = Field(60, ge=1, le=2048)


@app.post("/day1/sampling/gemini")
async def sampling_gemini(req: GeminiRequest):
    return await sampling.gemini_demo(req.prompt, req.n, req.temperature, req.top_p,
                                      req.top_k, req.max_output_tokens)

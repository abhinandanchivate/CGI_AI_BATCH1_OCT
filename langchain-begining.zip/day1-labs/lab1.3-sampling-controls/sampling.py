"""S025 - Max new tokens, sampling, temperature, top-k, top-p.

Part 1 is pure NumPy, so you can see exactly what each knob does to a
probability distribution. Part 2 turns the same knobs on a real model.
"""
from __future__ import annotations

import asyncio
from collections import Counter

import numpy as np

from gemini_client import generate, no_thinking


def softmax(logits: np.ndarray) -> np.ndarray:
    z = logits - logits.max()
    e = np.exp(z)
    return e / e.sum()


def apply_controls(logits: list[float], temperature: float = 1.0,
                   top_k: int | None = None, top_p: float | None = None) -> np.ndarray:
    x = np.asarray(logits, dtype=float)
    if temperature <= 0:  # greedy: all mass on the argmax
        p = np.zeros_like(x)
        p[x.argmax()] = 1.0
        return p
    p = softmax(x / temperature)
    if top_k:
        keep = np.argsort(p)[::-1][:top_k]
        mask = np.zeros_like(p, dtype=bool)
        mask[keep] = True
        p = np.where(mask, p, 0.0)
        p /= p.sum()
    if top_p is not None and top_p < 1.0:
        order = np.argsort(p)[::-1]
        cum = np.cumsum(p[order])
        cutoff = int(np.searchsorted(cum, top_p) + 1)  # smallest set reaching top_p
        mask = np.zeros_like(p, dtype=bool)
        mask[order[:cutoff]] = True
        p = np.where(mask, p, 0.0)
        p /= p.sum()
    return p


def entropy_bits(p: np.ndarray) -> float:
    nz = p[p > 0]
    return float(-(nz * np.log2(nz)).sum())


def local_demo(tokens: list[str], logits: list[float], temperature: float,
               top_k: int | None, top_p: float | None, samples: int = 20,
               seed: int = 0) -> dict:
    p = apply_controls(logits, temperature, top_k, top_p)
    rng = np.random.default_rng(seed)
    drawn = rng.choice(len(tokens), size=samples, p=p)
    return {"probabilities": {t: round(float(v), 4) for t, v in zip(tokens, p)},
            "tokens_still_possible": int((p > 0).sum()),
            "entropy_bits": round(entropy_bits(p), 3),
            "samples": [tokens[i] for i in drawn],
            "sample_counts": dict(Counter(tokens[i] for i in drawn))}


def distinct_n(texts: list[str], n: int = 2) -> float:
    grams, total = set(), 0
    for t in texts:
        words = t.split()
        for i in range(len(words) - n + 1):
            grams.add(tuple(words[i:i + n]))
            total += 1
    return round(len(grams) / total, 3) if total else 0.0


async def gemini_demo(prompt: str, n: int, temperature: float, top_p: float | None,
                      top_k: int | None, max_output_tokens: int) -> dict:
    results = await asyncio.gather(*[
        generate(prompt, temperature=temperature, top_p=top_p, top_k=top_k,
                 max_output_tokens=max_output_tokens, **no_thinking())
        for _ in range(n)])
    texts = [r.text.strip() for r in results]
    reasons = [str(r.response.candidates[0].finish_reason) for r in results]
    return {"settings": {"temperature": temperature, "top_p": top_p, "top_k": top_k,
                         "max_output_tokens": max_output_tokens},
            "outputs": texts, "finish_reasons": reasons,
            "unique_outputs": len(set(texts)), "distinct_2": distinct_n(texts)}

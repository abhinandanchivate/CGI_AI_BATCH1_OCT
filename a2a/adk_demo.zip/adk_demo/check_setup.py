"""ADK readiness check.

Run from the adk_demo folder:
    python check_setup.py            # full check, including a live Gemini call
    python check_setup.py --offline  # skip the live call
"""

import asyncio
import os
import sys
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

results = []  # (name, ok, detail)


def report(name, ok, detail=""):
    results.append((name, ok, detail))
    mark = "PASS" if ok else ("SKIP" if ok is None else "FAIL")
    print(f"[{mark}] {name}" + (f" - {detail}" if detail else ""))
    return ok


def check_python():
    v = sys.version_info
    return report("Python 3.10+", v >= (3, 10), f"found {v.major}.{v.minor}.{v.micro}")


def check_adk():
    try:
        import google.adk
        return report("google-adk installed", True, f"version {google.adk.__version__}")
    except ImportError as e:
        return report("google-adk installed", False, f"{e} -> run: pip install google-adk")


def check_credentials():
    env_file = HERE / "hello_agent" / ".env"
    if env_file.exists():
        from dotenv import load_dotenv
        load_dotenv(env_file)
    else:
        print(f"       (no {env_file.relative_to(HERE)} found; using shell environment)")

    if os.getenv("GOOGLE_GENAI_USE_VERTEXAI", "FALSE").upper() in ("TRUE", "1"):
        missing = [k for k in ("GOOGLE_CLOUD_PROJECT", "GOOGLE_CLOUD_LOCATION") if not os.getenv(k)]
        return report("Credentials (Vertex AI)", not missing,
                      "project/location set" if not missing else f"missing {', '.join(missing)}")
    key = os.getenv("GOOGLE_API_KEY", "")
    ok = bool(key) and key != "paste-your-key-here"
    return report("Credentials (Gemini API key)", ok,
                  f"key ending ...{key[-4:]}" if ok else "set GOOGLE_API_KEY in hello_agent/.env")


def check_agent_loads():
    try:
        from hello_agent.agent import root_agent, get_weather, get_current_time
    except Exception as e:
        return report("Agent definition loads", False, repr(e))
    tool_names = [getattr(t, "__name__", type(t).__name__) for t in root_agent.tools]
    report("Agent definition loads", True, f"'{root_agent.name}' on {root_agent.model}, tools={tool_names}")
    w, t = get_weather("Pune"), get_current_time("Pune")
    ok = w["status"] == "success" and t["status"] == "success"
    return report("Tools run locally", ok, f"{w['report']} | {t['report']}")


async def check_live_run():
    from google.adk.runners import InMemoryRunner
    from google.genai import types
    from hello_agent.agent import root_agent

    runner = InMemoryRunner(agent=root_agent, app_name="adk_readiness")
    session = await runner.session_service.create_session(
        app_name="adk_readiness", user_id="tester", session_id=str(uuid.uuid4()))
    question = "What's the weather and the current time in Pune?"
    print(f"       asking: {question}")

    tools_called, final_text = [], ""
    async for event in runner.run_async(
        user_id="tester", session_id=session.id,
        new_message=types.Content(role="user", parts=[types.Part(text=question)]),
    ):
        for call in event.get_function_calls() or []:
            tools_called.append(call.name)
        if event.is_final_response() and event.content and event.content.parts:
            final_text = "".join(p.text or "" for p in event.content.parts)

    report("Model reachable and responded", bool(final_text), final_text.strip().replace("\n", " ")[:160])
    return report("Agent called its tools", bool(tools_called), f"called {tools_called or 'none'}")


def main():
    offline = "--offline" in sys.argv
    print("=== ADK readiness check ===")
    if not (check_python() and check_adk()):
        return finish()
    creds_ok = check_credentials()
    check_agent_loads()
    if offline:
        report("Live Gemini call", None, "skipped (--offline)")
    elif not creds_ok:
        report("Live Gemini call", None, "skipped (fix credentials first)")
    else:
        try:
            asyncio.run(check_live_run())
        except Exception as e:
            msg = str(e)
            hints = {
                "API_KEY_INVALID": "API key rejected - create a new one at aistudio.google.com/apikey",
                "PERMISSION_DENIED": "permission denied - enable the Vertex AI / Gemini API for this project",
                "NOT_FOUND": "model not found - set ADK_MODEL to a model your account can use",
                "RESOURCE_EXHAUSTED": "quota exceeded - wait a minute or check billing",
            }
            hint = next((h for k, h in hints.items() if k in msg), msg[:200])
            report("Live Gemini call", False, f"{type(e).__name__}: {hint}")
    finish()


def finish():
    failed = [r for r in results if r[1] is False]
    skipped = [r for r in results if r[1] is None]
    print("=" * 27)
    if failed:
        print(f"NOT READY: {len(failed)} check(s) failed.")
        sys.exit(1)
    print("READY with skipped checks." if skipped else "ALL GOOD: ADK is set up correctly.")


if __name__ == "__main__":
    main()

# ADK readiness demo

A tiny Google ADK agent (weather + time tools) and a script that checks every layer of the setup.

## 1. Install
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install google-adk
```

## 2. Add credentials
```bash
cp hello_agent/.env.example hello_agent/.env   # Windows: copy hello_agent\.env.example hello_agent\.env
```
Edit `hello_agent/.env`: paste a Gemini API key from https://aistudio.google.com/apikey, or use the Vertex AI option.

## 3. Run the check
```bash
python check_setup.py            # full check incl. a live Gemini call
python check_setup.py --offline  # everything except the live call
```

| Check | Confirms |
|---|---|
| Python 3.10+ | Interpreter is new enough |
| google-adk installed | Package imports; prints version |
| Credentials | API key or Vertex AI project/location is set |
| Agent definition loads | `root_agent` builds with model and tools |
| Tools run locally | Python tools work without the model |
| Model reachable | Live Gemini call returns an answer |
| Agent called its tools | The model actually used function calling |

`ALL GOOD` at the end means you are ready.

## 4. Try the ADK CLI (optional)
Run these from the `adk_demo` folder:
```bash
adk web          # dev UI at http://localhost:8000, pick "hello_agent"
adk run hello_agent   # chat in the terminal
```

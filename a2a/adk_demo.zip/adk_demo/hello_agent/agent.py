"""A minimal ADK agent with two tools, used to confirm the setup works."""

import datetime
import os
from zoneinfo import ZoneInfo

from google.adk.agents import Agent

# Override with ADK_MODEL in .env if your project uses a different Gemini model.
MODEL = os.getenv("ADK_MODEL", "gemini-2.5-flash")

_CITIES = {
    "pune": ("Asia/Kolkata", "sunny, 29 °C"),
    "bengaluru": ("Asia/Kolkata", "partly cloudy, 26 °C"),
    "new york": ("America/New_York", "cloudy, 8 °C"),
    "london": ("Europe/London", "light rain, 10 °C"),
}


def get_weather(city: str) -> dict:
    """Returns a (mock) weather report for a city.

    Args:
        city: Name of the city, e.g. "Pune".
    """
    entry = _CITIES.get(city.strip().lower())
    if not entry:
        return {"status": "error", "error_message": f"No weather data for '{city}'."}
    return {"status": "success", "report": f"The weather in {city.title()} is {entry[1]}."}


def get_current_time(city: str) -> dict:
    """Returns the current local time in a city.

    Args:
        city: Name of the city, e.g. "Pune".
    """
    entry = _CITIES.get(city.strip().lower())
    if not entry:
        return {"status": "error", "error_message": f"No timezone data for '{city}'."}
    now = datetime.datetime.now(ZoneInfo(entry[0]))
    return {"status": "success", "report": f"The time in {city.title()} is {now:%Y-%m-%d %H:%M %Z}."}


root_agent = Agent(
    name="hello_agent",
    model=MODEL,
    description="Answers weather and time questions for a few cities.",
    instruction=(
        "You help users with the weather and local time in a city. "
        "Always use the get_weather and get_current_time tools; never guess. "
        "If a tool returns an error, tell the user politely."
    ),
    tools=[get_weather, get_current_time],
)

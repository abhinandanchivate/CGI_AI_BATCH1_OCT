"""End-to-end tests: REST, MCP, agent runs over SSE, and the A2A loan extension."""

from __future__ import annotations

import asyncio
import json

import pytest
from fastapi.testclient import TestClient
from mcp import Client

from app import agent
from app.main import app
from app.mcp_server import mcp_server
from app.store import store
from partner_agent.server import app as partner_app


@pytest.fixture(scope="session")
def _app_client():
    # The MCP session manager can start only once per process, so share one client.
    with TestClient(app) as c:
        yield c


@pytest.fixture()
def client(_app_client):
    store.reset()
    agent.active_runs.clear()
    return _app_client


def login(c: TestClient, user="asha", password="asha123") -> dict:
    token = c.post("/auth/login", json={"username": user, "password": password}).json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def stream(c: TestClient, h: dict, run_id: str, last: int = 0) -> list[tuple[str, dict]]:
    headers = {**h, "Last-Event-ID": str(last)}
    events, etype = [], None
    with c.stream("GET", f"/agent/runs/{run_id}/stream", headers=headers) as r:
        for line in r.iter_lines():
            if line.startswith("event:"):
                etype = line[6:].strip()
            elif line.startswith("data:"):
                events.append((etype, json.loads(line[5:])))
    return events


def run_chat(c, h, message):
    r = c.post("/agent/runs", json={"message": message}, headers=h)
    assert r.status_code == 201
    run_id = r.json()["run_id"]
    return run_id, stream(c, h, run_id)


def types(events):
    return [t for t, _ in events]


# --------------------------------------------------------------------------- #
# REST
# --------------------------------------------------------------------------- #

def test_auth_and_ownership(client):
    assert client.get("/accounts").status_code == 401
    h = login(client)
    assert {a["id"] for a in client.get("/accounts", headers=h).json()["accounts"]} == {"ACC-1001", "ACC-1003"}
    r = client.get("/accounts/ACC-1002/balance", headers=h)
    assert r.status_code == 403 and r.headers["content-type"].startswith("application/problem+json")


def test_rest_transfer_idempotent_and_fraud_rules(client):
    h = login(client)
    body = {"from_account": "ACC-1001", "to_account": "ACC-1002", "amount": "2500.00"}
    r1 = client.post("/payments/transfer", json=body, headers={**h, "Idempotency-Key": "k-1"})
    r2 = client.post("/payments/transfer", json=body, headers={**h, "Idempotency-Key": "k-1"})
    assert r1.status_code == 200 and r2.json()["idempotent_replay"] is True
    assert client.get("/accounts/ACC-1001/balance", headers=h).json()["balance"] == "47500.00"
    hold = client.post("/payments/transfer", json={**body, "amount": "15000"}, headers={**h, "Idempotency-Key": "k-2"})
    assert hold.status_code == 422 and "HOLD" in hold.json()["title"]
    block = client.post("/payments/transfer", json={**body, "to_account": "ACC-9999"}, headers={**h, "Idempotency-Key": "k-3"})
    assert block.status_code == 422 and "BLOCK" in block.json()["title"]
    broke = client.post("/payments/transfer", json={**body, "amount": "9000", "from_account": "ACC-1001"},
                        headers={**h, "Idempotency-Key": "k-4"})
    assert broke.status_code == 200
    # float amounts are refused
    assert client.post("/payments/transfer", json={**body, "amount": "1.234"},
                       headers={**h, "Idempotency-Key": "k-5"}).status_code == 422


# --------------------------------------------------------------------------- #
# MCP
# --------------------------------------------------------------------------- #

def test_mcp_primitives_and_hold_enforced_in_code():
    store.reset()

    async def go():
        async with Client(mcp_server) as c:
            assert len((await c.list_tools()).tools) == 6
            assert (await c.list_resource_templates()).resource_templates[0].uri_template == \
                "novabank://accounts/{account_id}/statement"
            assert (await c.list_prompts()).prompts[0].name == "review_transfer"
            r = await c.call_tool("transfer_funds", {"user": "asha", "from_account": "ACC-1001",
                                                     "to_account": "ACC-1002", "amount": "20000",
                                                     "idempotency_key": "mcp-1"})
            assert r.is_error and "Confirmation required" in r.content[0].text
            r = await c.call_tool("get_balance", {"user": "asha", "account_id": "ACC-1002"})
            assert r.is_error and "403" in r.content[0].text

    asyncio.run(go())


def test_mcp_streamable_http_endpoint(client):
    r = client.post("/mcp", headers={"Host": "evil.example", "Content-Type": "application/json"}, json={})
    assert r.status_code == 421  # DNS-rebinding protection
    assert len(client.get("/mcp-tools").json()["tools"]) == 6


# --------------------------------------------------------------------------- #
# Agent over SSE
# --------------------------------------------------------------------------- #

def test_agent_transfer_approve(client):
    h = login(client)
    _, ev = run_chat(client, h, "Transfer 2500 to ACC-1002")
    tools = [d["tool"] for t, d in ev if t == "tool.called"]
    assert tools == ["score_fraud", "transfer_funds", "send_notification"]
    assert types(ev)[-1] == "run.completed"


def test_agent_hold_pause_confirm_resume_and_replay(client):
    h = login(client)
    run_id, ev = run_chat(client, h, "Transfer 15000 to ACC-1002")
    assert types(ev)[-1] == "run.paused" and ev[-1][1]["reason"] == "fraud_hold"
    paused_at = len(ev)
    assert client.post(f"/agent/runs/{run_id}/confirm", headers=h).status_code == 200
    ev2 = stream(client, h, run_id, last=paused_at)
    assert types(ev2)[0] == "run.resumed" and types(ev2)[-1] == "run.completed"
    # reconnect with Last-Event-ID replays only what was missed
    assert stream(client, h, run_id, last=paused_at + 2) == ev2[2:]
    assert client.get("/accounts/ACC-1001/balance", headers=h).json()["balance"] == "35000.00"


def test_agent_block_never_transfers(client):
    h = login(client)
    _, ev = run_chat(client, h, "Pay 500 to ACC-9999")
    assert "transfer_funds" not in [d["tool"] for t, d in ev if t == "tool.called"]
    assert types(ev)[-1] == "run.failed"


def test_cancel_paused_run(client):
    h = login(client)
    run_id, _ = run_chat(client, h, "Transfer 15000 to ACC-1002")
    assert client.post(f"/agent/runs/{run_id}/cancel", headers=h).json()["status"] == "CANCELLED"
    assert client.post(f"/agent/runs/{run_id}/confirm", headers=h).status_code == 409


# --------------------------------------------------------------------------- #
# A2A loan extension
# --------------------------------------------------------------------------- #

def test_a2a_loan_flow(client):
    h = login(client)
    run_id, ev = run_chat(client, h, "Can I get a 2 lakh personal loan for 24 months?")
    states = [d["state"] for t, d in ev if t == "a2a.status"]
    assert states == ["submitted", "working", "input-required"]
    assert ev[-1][0] == "run.paused" and ev[-1][1]["reason"] == "partner_input"

    assert client.post(f"/agent/runs/{run_id}/confirm", headers=h, json={}).status_code == 422  # reply needed
    assert client.post(f"/agent/runs/{run_id}/confirm", headers=h, json={"reply": "85000"}).status_code == 200
    ev2 = stream(client, h, run_id, last=len(ev))
    offer = next(d["offer"] for t, d in ev2 if t == "a2a.artifact")
    assert offer["amount"] == "200000.00" and offer["tenure_months"] == 24
    assert types(ev2)[-1] == "run.completed"
    run = client.get(f"/agent/runs/{run_id}", headers=h).json()
    assert run["context"]["a2a"]["state"] == "completed"


def test_a2a_rejected_when_emi_too_high(client):
    h = login(client)
    run_id, ev = run_chat(client, h, "I need a loan of 5 lakh over 12 months")
    client.post(f"/agent/runs/{run_id}/confirm", headers=h, json={"reply": "20000"})
    ev2 = stream(client, h, run_id, last=len(ev))
    assert types(ev2)[-1] == "run.failed" and "rejected" in ev2[-1][1]["error"]


def test_a2a_cancel_sends_cancel_task(client):
    h = login(client)
    run_id, _ = run_chat(client, h, "2 lakh loan please")
    client.post(f"/agent/runs/{run_id}/cancel", headers=h)
    run = client.get(f"/agent/runs/{run_id}", headers=h).json()
    task_id = run["context"]["a2a"]["task_id"]
    with TestClient(partner_app) as p:
        r = p.post("/a2a", headers={"Authorization": "Bearer partner-demo-token"},
                   json={"jsonrpc": "2.0", "id": 1, "method": "GetTask", "params": {"id": task_id}})
    assert r.json()["result"]["status"]["state"] == "TASK_STATE_CANCELED"


def test_partner_requires_auth_and_wire_format_matches_a2a_v1():
    with TestClient(partner_app) as p:
        card = p.get("/.well-known/agent-card.json").json()
        unauth = p.post("/a2a", json={"jsonrpc": "2.0", "id": 1, "method": "GetTask", "params": {"id": "x"}})
        assert unauth.status_code == 401
        r = p.post("/a2a", headers={"Authorization": "Bearer partner-demo-token"}, json={
            "jsonrpc": "2.0", "id": 1, "method": "SendMessage",
            "params": {"message": {"messageId": "m1", "role": "ROLE_USER", "parts": [
                {"text": "offer"}, {"data": {"amount": "100000", "tenure_months": 12, "customer_id": "C1"}}]}}})
        result = r.json()["result"]

    a2a_types = pytest.importorskip("a2a.types", reason="a2a-sdk not installed; skipping proto check")
    from google.protobuf.json_format import ParseDict
    ParseDict(card, a2a_types.AgentCard())               # raises on unknown or mistyped fields
    ParseDict(result, a2a_types.SendMessageResponse())
    assert result["task"]["status"]["state"] == "TASK_STATE_INPUT_REQUIRED"

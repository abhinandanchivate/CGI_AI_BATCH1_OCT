# NovaBank: a neobank built on MCP, with an A2A partner agent

A teaching-grade neobank. Banking capabilities are written once in a service layer and exposed two ways:

- **REST** for mobile and web apps
- **MCP** for AI clients: Claude Desktop, the in-app assistant, any MCP client

The in-app assistant reaches the bank **only through MCP**. When it needs something NovaBank can't do itself (a personal loan), it delegates to a partner's Loans agent over **A2A**.

```
App clients ──REST──┐
                    ├── app/services.py (fraud + ownership rules, once)
AI clients ──MCP────┘          ▲
                               │ MCP (in-process client)
              Assistant agent ─┤
                               │ A2A (Agent Card + JSON-RPC)
                               ▼
                    Partner Loans agent (separate service, own tools)
```

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:app --port 8000          # API, assistant, MCP at /mcp, partner in-process
pytest                                     # 12 tests
```

API docs: http://localhost:8000/docs. Demo users: `asha / asha123` (ACC-1001, ACC-1003) and `ravi / ravi123` (ACC-1002).

### Run the partner agent as a separate service

```bash
uvicorn partner_agent.server:app --port 8100
PARTNER_AGENT_URL=http://localhost:8100 uvicorn app.main:app --port 8000
```

Or with Docker: `docker compose up --build` (API on :8080, partner on :8100).

### Use with Claude Desktop (stdio)

Copy `claude_desktop_config.example.json` into Claude Desktop's config and set `cwd` to this folder. The stdio process has its own in-memory data; use the HTTP endpoint (`http://localhost:8000/mcp`) for shared state.

## Project layout

| File | Role |
| --- | --- |
| `app/store.py` | In-memory data, RunState model and state machine (6 states) |
| `app/services.py` | Business logic shared by REST and MCP: fraud rules, ownership checks, idempotent transfers |
| `app/mcp_server.py` | MCP server (`MCPServer`, SDK 2.x): 6 tools, 1 resource template, 1 prompt |
| `app/agent.py` | Rule-based planner and executor; uses `mcp.Client` and the A2A client |
| `app/a2a_client.py` | Minimal A2A v1 JSON-RPC client; validates partner output |
| `app/main.py` | REST routes, SSE streaming, MCP mounted at `/mcp` |
| `partner_agent/server.py` | Mock partner Loans agent: Agent Card + `SendMessage`, `SendStreamingMessage`, `GetTask`, `CancelTask` |
| `tests/test_novabank.py` | End-to-end tests, including an A2A wire-format check against the official `a2a-sdk` protos |
| `postman/` | Collection (27 requests, 46 assertions) and Local/Docker environments |

## MCP server

| Primitive | Name | Purpose |
| --- | --- | --- |
| Tool | `list_accounts` | Accounts owned by the user |
| Tool | `get_balance` | Balance for one account |
| Tool | `list_transactions` | Recent transactions, newest first |
| Tool | `score_fraud` | APPROVE, HOLD or BLOCK with reasons |
| Tool | `transfer_funds` | Atomic, idempotent transfer; amount as a decimal string |
| Tool | `send_notification` | Mock push, SMS or email |
| Resource | `novabank://accounts/{account_id}/statement` | Mini statement as JSON |
| Prompt | `review_transfer` | Score fraud first; never transfer on BLOCK |

Fraud rules (demo): BLOCK if the payee is `ACC-9999` or the amount is above 100,000; HOLD at 10,000 or more; otherwise APPROVE. `transfer_funds` re-checks fraud itself and refuses a HOLD without a single-use `confirmation_id` that only the human confirm step can create. Server instructions say the same, but instructions alone are not a control.

## Agent runs and streaming

Each chat message becomes a run with a typed `RunState`. Try:

| Message | What happens |
| --- | --- |
| `Transfer 2500 to ACC-1002` | score_fraud → transfer_funds → send_notification, completes |
| `Transfer 15000 to ACC-1002` | HOLD: run pauses; `POST /confirm` then reopen the stream |
| `Pay 500 to ACC-9999` | BLOCK: run fails before any money moves |
| `Can I get a 2 lakh personal loan?` | A2A: partner asks for income; `POST /confirm {"reply": "85000"}`; offer returned |
| `What's my balance?` / `Show transactions` | Read-only MCP calls |

```bash
TOKEN=$(curl -s -X POST localhost:8000/auth/login -H 'content-type: application/json' \
  -d '{"username":"asha","password":"asha123"}' | python -c "import sys,json;print(json.load(sys.stdin)['access_token'])")
RUN=$(curl -s -X POST localhost:8000/agent/runs -H "Authorization: Bearer $TOKEN" \
  -H 'content-type: application/json' -d '{"message":"Can I get a 2 lakh personal loan?"}' \
  | python -c "import sys,json;print(json.load(sys.stdin)['run_id'])")
curl -N localhost:8000/agent/runs/$RUN/stream -H "Authorization: Bearer $TOKEN"     # pauses on partner question
curl -X POST localhost:8000/agent/runs/$RUN/confirm -H "Authorization: Bearer $TOKEN" \
  -H 'content-type: application/json' -d '{"reply":"85000"}'
curl -N localhost:8000/agent/runs/$RUN/stream -H "Authorization: Bearer $TOKEN" -H "Last-Event-ID: 10"
```

SSE events: `plan.created`, `run.started` / `run.resumed`, `tool.called` / `tool.result`, `state.updated`, `run.paused`, `run.completed` / `run.failed` / `run.cancelled`, and for A2A `a2a.discovered`, `a2a.message.sent`, `a2a.status`, `a2a.artifact`. Every event has a sequence id; reconnect with `Last-Event-ID` to get only what you missed.

## A2A extension: loan request to a partner agent

1. **Discover**: fetch `/.well-known/agent-card.json`, check the `personal_loan_offer` skill.
2. **Delegate**: `SendStreamingMessage` with a text part and a data part (customer id, amount, currency, tenure).
3. **Partner works**: `TASK_STATE_WORKING`; the partner uses its own tools (credit bureau, pricing) that NovaBank never sees.
4. **Question back**: `TASK_STATE_INPUT_REQUIRED` → the run pauses on the same path as a fraud HOLD.
5. **Resume**: the human's reply is sent as a new message on the same `taskId`.
6. **Result**: `TASK_STATE_COMPLETED` with a `loan_offer` artifact, validated before it is shown. Cancelling the run sends `CancelTask`. `TASK_STATE_REJECTED` (EMI above 50% of income) fails the run with the partner's reason.

The A2A layer is a hand-written minimal subset of the v1 JSON-RPC binding, so it stays readable for teaching. The tests parse partner messages with the official `a2a-sdk` protobuf types to check field names. For production, use the `a2a-sdk` client and server.

## Demo shortcuts and production fixes

| Area | Demo | Production |
| --- | --- | --- |
| Auth (REST) | Opaque token in memory | OAuth 2.0 / OIDC, short-lived JWTs |
| Auth (MCP) | Tools take a `user` argument | MCP OAuth: identity from the token |
| Auth (A2A) | Static bearer token | OAuth 2.0 client credentials, mTLS |
| Storage | In-memory | Postgres + Redis for runs and idempotency keys |
| Planner | Regex rules | LLM choosing from `tools/list` |
| Audit | Run event log in memory | Append-only event store |

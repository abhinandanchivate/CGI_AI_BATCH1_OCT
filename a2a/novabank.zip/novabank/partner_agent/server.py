"""Mock partner Loans agent: a separate A2A server owned by a lending partner.

NovaBank never sees this code or the partner's internal tools (credit bureau,
pricing). It only sees the Agent Card and the A2A JSON-RPC endpoint.

Implements a minimal subset of the A2A v1 JSON-RPC binding:
  GET  /.well-known/agent-card.json
  POST /a2a   SendMessage | SendStreamingMessage | GetTask | CancelTask

Run standalone:  uvicorn partner_agent.server:app --port 8100
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import uuid
from decimal import ROUND_HALF_UP, Decimal
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

PUBLIC_URL = os.getenv("PARTNER_PUBLIC_URL", "http://localhost:8100")
API_TOKEN = os.getenv("PARTNER_TOKEN", "partner-demo-token")
MAX_AMOUNT = Decimal("1000000")

TERMINAL = {"TASK_STATE_COMPLETED", "TASK_STATE_FAILED", "TASK_STATE_CANCELED", "TASK_STATE_REJECTED"}

app = FastAPI(title="Partner Loans Agent (mock A2A server)")
tasks: dict[str, dict[str, Any]] = {}


# --------------------------------------------------------------------------- #
# Agent Card
# --------------------------------------------------------------------------- #

def agent_card() -> dict[str, Any]:
    return {
        "name": "Partner Loans Agent",
        "description": "Personal-loan eligibility and priced offers for NovaBank customers",
        "version": "1.0.0",
        "supportedInterfaces": [
            {"url": f"{PUBLIC_URL}/a2a", "protocolBinding": "JSONRPC", "protocolVersion": "1.0"}
        ],
        "provider": {"organization": "Partner Lender (demo)", "url": PUBLIC_URL},
        "capabilities": {"streaming": True, "pushNotifications": False},
        "securitySchemes": {
            "bearer": {"httpAuthSecurityScheme": {"scheme": "Bearer",
                                                  "description": "Demo static token; OAuth 2.0 client credentials in production"}}
        },
        "securityRequirements": [{"schemes": {"bearer": {"list": []}}}],
        "defaultInputModes": ["text/plain", "application/json"],
        "defaultOutputModes": ["application/json"],
        "skills": [
            {
                "id": "personal_loan_offer",
                "name": "Personal loan offer",
                "description": "Checks eligibility and returns a priced offer",
                "tags": ["loans", "credit"],
                "examples": ["Personal loan offer of 200000 INR over 24 months"],
            }
        ],
    }


@app.get("/.well-known/agent-card.json")
def get_card() -> dict[str, Any]:
    return agent_card()


# --------------------------------------------------------------------------- #
# The partner's private logic (its "own MCP tools" in the case study)
# --------------------------------------------------------------------------- #

def credit_bureau_score(customer_id: str) -> int:
    """Deterministic fake bureau score between 650 and 849."""
    return 650 + int(hashlib.sha256(customer_id.encode()).hexdigest(), 16) % 200


def annual_rate_for(score: int) -> Decimal:
    if score >= 780:
        return Decimal("11.50")
    if score >= 720:
        return Decimal("13.00")
    return Decimal("16.50")


def emi(principal: Decimal, annual_rate: Decimal, months: int) -> Decimal:
    r = annual_rate / Decimal(1200)
    factor = (1 + r) ** months
    return (principal * r * factor / (factor - 1)).quantize(Decimal("0.01"), ROUND_HALF_UP)


# --------------------------------------------------------------------------- #
# A2A helpers
# --------------------------------------------------------------------------- #

def agent_message(text: str, task: dict[str, Any], data: dict[str, Any] | None = None) -> dict[str, Any]:
    parts: list[dict[str, Any]] = [{"text": text}]
    if data:
        parts.append({"data": data})
    return {"messageId": f"msg_{uuid.uuid4().hex[:10]}", "role": "ROLE_AGENT",
            "taskId": task["id"], "contextId": task["contextId"], "parts": parts}


def set_state(task: dict[str, Any], state: str, text: str | None = None,
              data: dict[str, Any] | None = None) -> dict[str, Any]:
    status: dict[str, Any] = {"state": state}
    if text:
        status["message"] = agent_message(text, task, data)
    task["status"] = status
    return {"statusUpdate": {"taskId": task["id"], "contextId": task["contextId"], "status": status}}


def message_data(message: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    text, data = "", {}
    for part in message.get("parts", []):
        if "text" in part:
            text += part["text"]
        if isinstance(part.get("data"), dict):
            data.update(part["data"])
    return text, data


class RpcError(Exception):
    def __init__(self, code: int, message: str) -> None:
        self.code, self.message = code, message


# --------------------------------------------------------------------------- #
# Task logic: returns the list of StreamResponse events, in order
# --------------------------------------------------------------------------- #

def handle_message(message: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    text, data = message_data(message)
    events: list[dict[str, Any]] = []

    if message.get("taskId"):
        task = tasks.get(message["taskId"])
        if task is None:
            raise RpcError(-32001, "Task not found")
        if task["status"]["state"] != "TASK_STATE_INPUT_REQUIRED":
            raise RpcError(-32602, "Task is not waiting for input")
        task["history"].append(message)
        income_raw = data.get("monthly_income") or (re.findall(r"\d[\d,]*", text) or [""])[0]
        try:
            income = Decimal(str(income_raw).replace(",", ""))
        except Exception:
            income = Decimal(0)
        if income <= 0:
            events.append(set_state(task, "TASK_STATE_INPUT_REQUIRED",
                                    "I could not read an income. Please send net monthly income in INR.",
                                    {"needs": ["monthly_income"]}))
            return task, events
        events.append(set_state(task, "TASK_STATE_WORKING", "Pricing the offer"))
        req = task["metadata"]["request"]
        amount, months = Decimal(req["amount"]), int(req["tenure_months"])
        rate = Decimal(task["metadata"]["annual_rate"])
        monthly = emi(amount, rate, months)
        if monthly > income * Decimal("0.5"):
            events.append(set_state(task, "TASK_STATE_REJECTED",
                                    f"EMI {monthly} would exceed 50% of monthly income {income:.2f}."))
            return task, events
        offer = {"offer_id": f"OFR-{uuid.uuid4().hex[:8].upper()}", "amount": f"{amount:.2f}",
                 "currency": req.get("currency", "INR"), "tenure_months": months,
                 "annual_rate": f"{rate:.2f}", "emi": f"{monthly:.2f}",
                 "valid_until_days": 7, "lender": "Partner Lender (demo)"}
        artifact = {"artifactId": f"art_{uuid.uuid4().hex[:8]}", "name": "loan_offer",
                    "description": "Priced personal-loan offer", "parts": [{"data": offer}]}
        task["artifacts"].append(artifact)
        events.append({"artifactUpdate": {"taskId": task["id"], "contextId": task["contextId"],
                                          "artifact": artifact, "lastChunk": True}})
        events.append(set_state(task, "TASK_STATE_COMPLETED", "Offer ready"))
        return task, events

    # New task
    task = {"id": f"task_{uuid.uuid4().hex[:10]}",
            "contextId": message.get("contextId") or f"ctx_{uuid.uuid4().hex[:8]}",
            "status": {"state": "TASK_STATE_SUBMITTED"}, "artifacts": [], "history": [message],
            "metadata": {}}
    tasks[task["id"]] = task
    events.append({"task": json.loads(json.dumps(task))})

    try:
        amount = Decimal(str(data["amount"]))
        months = int(data["tenure_months"])
    except Exception:
        events.append(set_state(task, "TASK_STATE_REJECTED",
                                "Send a data part with amount (decimal string) and tenure_months."))
        return task, events
    if amount <= 0 or amount > MAX_AMOUNT or not 6 <= months <= 60:
        events.append(set_state(task, "TASK_STATE_REJECTED",
                                f"Amount must be 1 to {MAX_AMOUNT} INR and tenure 6 to 60 months."))
        return task, events

    events.append(set_state(task, "TASK_STATE_WORKING", "Checking credit bureau"))
    score = credit_bureau_score(str(data.get("customer_id", "anonymous")))
    task["metadata"] = {"request": {"amount": f"{amount:.2f}", "tenure_months": months,
                                    "currency": data.get("currency", "INR")},
                        "annual_rate": f"{annual_rate_for(score):.2f}"}
    events.append(set_state(task, "TASK_STATE_INPUT_REQUIRED",
                            "Please confirm the customer's net monthly income in INR.",
                            {"needs": ["monthly_income"]}))
    return task, events


# --------------------------------------------------------------------------- #
# JSON-RPC endpoint
# --------------------------------------------------------------------------- #

def public_task(task: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in task.items() if k != "metadata"}


def rpc_result(req_id: Any, result: Any) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def rpc_error(req_id: Any, code: int, message: str) -> JSONResponse:
    return JSONResponse({"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}})


@app.post("/a2a")
async def a2a_endpoint(request: Request):
    try:
        body = await request.json()
    except Exception:
        return rpc_error(None, -32700, "Parse error")
    req_id, method, params = body.get("id"), body.get("method"), body.get("params") or {}

    if request.headers.get("authorization") != f"Bearer {API_TOKEN}":
        return JSONResponse({"jsonrpc": "2.0", "id": req_id,
                             "error": {"code": -32007, "message": "Unauthenticated"}}, status_code=401)
    try:
        if method in ("SendMessage", "SendStreamingMessage"):
            message = params.get("message")
            if not message or not message.get("parts"):
                raise RpcError(-32602, "params.message with parts is required")
            task, events = handle_message(message)
            if method == "SendMessage":
                return JSONResponse(rpc_result(req_id, {"task": public_task(task)}))

            async def stream():
                for event in events:
                    yield f"data: {json.dumps(rpc_result(req_id, event))}\n\n"

            return StreamingResponse(stream(), media_type="text/event-stream")

        if method == "GetTask":
            task = tasks.get(params.get("id", ""))
            if task is None:
                raise RpcError(-32001, "Task not found")
            return JSONResponse(rpc_result(req_id, public_task(task)))

        if method == "CancelTask":
            task = tasks.get(params.get("id", ""))
            if task is None:
                raise RpcError(-32001, "Task not found")
            if task["status"]["state"] in TERMINAL:
                raise RpcError(-32002, "Task cannot be canceled")
            set_state(task, "TASK_STATE_CANCELED", "Canceled by client")
            return JSONResponse(rpc_result(req_id, public_task(task)))

        raise RpcError(-32601, f"Method not found: {method}")
    except RpcError as e:
        return rpc_error(req_id, e.code, e.message)

"""Generates the Postman collection and environments. Run: python postman/build_collection.py"""

import json
from pathlib import Path

HERE = Path(__file__).parent
AUTH = [{"key": "Authorization", "value": "Bearer {{access_token}}"}]
JSON_H = [{"key": "Content-Type", "value": "application/json"}]
MCP_H = JSON_H + [{"key": "Accept", "value": "application/json, text/event-stream"},
                  {"key": "MCP-Protocol-Version", "value": "2025-11-25"}]


def req(name, method, path, tests, body=None, headers=None, prerequest=None):
    item = {
        "name": name,
        "request": {"method": method, "header": headers or [],
                    "url": {"raw": "{{base_url}}" + path, "host": ["{{base_url}}"],
                            "path": [p for p in path.split("?")[0].strip("/").split("/") if p],
                            **({"query": [{"key": k, "value": v} for k, v in
                                          (q.split("=") for q in path.split("?")[1].split("&"))]}
                               if "?" in path else {})}},
        "event": [{"listen": "test", "script": {"type": "text/javascript", "exec": tests.strip().split("\n")}}],
    }
    if body is not None:
        item["request"]["body"] = {"mode": "raw", "raw": json.dumps(body, indent=2),
                                   "options": {"raw": {"language": "json"}}}
    if prerequest:
        item["event"].append({"listen": "prerequest",
                              "script": {"type": "text/javascript", "exec": prerequest.strip().split("\n")}})
    return item


SSE_PARSE = """
const events = pm.response.text().split('\\n').filter(l => l.startsWith('event:')).map(l => l.slice(6).trim());
"""

folders = [
    ("01 Ops & Auth", [
        req("Reset demo data", "POST", "/demo/reset", "pm.test('200', () => pm.response.to.have.status(200));"),
        req("Health", "GET", "/health", """
pm.test('200', () => pm.response.to.have.status(200));
pm.test('advertises /mcp', () => pm.expect(pm.response.json().mcp_endpoint).to.eql('/mcp'));"""),
        req("Login (bad password) 401", "POST", "/auth/login", """
pm.test('401', () => pm.response.to.have.status(401));
pm.test('problem+json', () => pm.expect(pm.response.headers.get('Content-Type')).to.include('application/problem+json'));""",
            body={"username": "asha", "password": "wrong"}, headers=JSON_H),
        req("Login", "POST", "/auth/login", """
pm.test('200', () => pm.response.to.have.status(200));
const t = pm.response.json().access_token;
pm.test('token returned', () => pm.expect(t).to.be.a('string'));
pm.environment.set('access_token', t);""",
            body={"username": "asha", "password": "asha123"}, headers=JSON_H),
    ]),
    ("02 Accounts", [
        req("My accounts", "GET", "/accounts", """
pm.test('200', () => pm.response.to.have.status(200));
const a = pm.response.json().accounts;
pm.test('two accounts', () => pm.expect(a.length).to.eql(2));
pm.environment.set('account_id', a[0].id);""", headers=AUTH),
        req("Balance", "GET", "/accounts/{{account_id}}/balance", """
pm.test('200', () => pm.response.to.have.status(200));
pm.test('balance is a decimal string', () => pm.expect(pm.response.json().balance).to.match(/^\\d+\\.\\d{2}$/));""",
            headers=AUTH),
        req("Balance of someone else's account 403", "GET", "/accounts/ACC-1002/balance",
            "pm.test('403', () => pm.response.to.have.status(403));", headers=AUTH),
        req("Transactions", "GET", "/transactions?account_id={{account_id}}", """
pm.test('200', () => pm.response.to.have.status(200));
pm.test('has transactions', () => pm.expect(pm.response.json().transactions.length).to.be.above(0));""",
            headers=AUTH),
    ]),
    ("03 Payments", [
        req("Transfer 2500 (APPROVE)", "POST", "/payments/transfer", """
pm.test('200', () => pm.response.to.have.status(200));
const r = pm.response.json();
pm.test('success', () => pm.expect(r.status).to.eql('SUCCESS'));
pm.environment.set('transaction_id', r.transaction_id);""",
            body={"from_account": "{{account_id}}", "to_account": "ACC-1002", "amount": "2500.00"},
            headers=AUTH + JSON_H + [{"key": "Idempotency-Key", "value": "{{idem_key}}"}],
            prerequest="pm.environment.set('idem_key', 'pm-' + Date.now());"),
        req("Same request again (idempotent replay)", "POST", "/payments/transfer", """
pm.test('200', () => pm.response.to.have.status(200));
pm.test('replayed, same transaction', () => {
  pm.expect(pm.response.json().idempotent_replay).to.eql(true);
  pm.expect(pm.response.json().transaction_id).to.eql(pm.environment.get('transaction_id'));
});""",
            body={"from_account": "{{account_id}}", "to_account": "ACC-1002", "amount": "2500.00"},
            headers=AUTH + JSON_H + [{"key": "Idempotency-Key", "value": "{{idem_key}}"}]),
        req("Transfer 15000 (HOLD) 422", "POST", "/payments/transfer", """
pm.test('422', () => pm.response.to.have.status(422));
pm.test('HOLD', () => pm.expect(pm.response.json().title).to.include('HOLD'));""",
            body={"from_account": "{{account_id}}", "to_account": "ACC-1002", "amount": "15000"},
            headers=AUTH + JSON_H + [{"key": "Idempotency-Key", "value": "hold-{{$timestamp}}"}]),
        req("Transfer to blocklisted ACC-9999 (BLOCK) 422", "POST", "/payments/transfer", """
pm.test('422', () => pm.response.to.have.status(422));
pm.test('BLOCK', () => pm.expect(pm.response.json().title).to.include('BLOCK'));""",
            body={"from_account": "{{account_id}}", "to_account": "ACC-9999", "amount": "100"},
            headers=AUTH + JSON_H + [{"key": "Idempotency-Key", "value": "block-{{$timestamp}}"}]),
    ]),
    ("04 Agent (streaming)", [
        req("Create run: transfer 2500", "POST", "/agent/runs", """
pm.test('201', () => pm.response.to.have.status(201));
pm.test('3-step plan', () => pm.expect(pm.response.json().plan.length).to.eql(3));
pm.environment.set('run_id', pm.response.json().run_id);""",
            body={"message": "Transfer 2500 to ACC-1002"}, headers=AUTH + JSON_H),
        req("Stream run (SSE) completes", "GET", "/agent/runs/{{run_id}}/stream", SSE_PARSE + """
pm.test('200', () => pm.response.to.have.status(200));
pm.test('ends with run.completed', () => pm.expect(events[events.length - 1]).to.eql('run.completed'));""",
            headers=AUTH),
        req("Get run state", "GET", "/agent/runs/{{run_id}}", """
pm.test('COMPLETED', () => pm.expect(pm.response.json().status).to.eql('COMPLETED'));""", headers=AUTH),
        req("Create run: transfer 15000 (HOLD)", "POST", "/agent/runs", """
pm.test('201', () => pm.response.to.have.status(201));
pm.environment.set('hold_run_id', pm.response.json().run_id);""",
            body={"message": "Transfer 15000 to ACC-1002"}, headers=AUTH + JSON_H),
        req("Stream pauses on HOLD", "GET", "/agent/runs/{{hold_run_id}}/stream", SSE_PARSE + """
pm.test('ends with run.paused', () => pm.expect(events[events.length - 1]).to.eql('run.paused'));
pm.environment.set('last_event_id', events.length);""", headers=AUTH),
        req("Confirm HOLD", "POST", "/agent/runs/{{hold_run_id}}/confirm",
            "pm.test('200', () => pm.response.to.have.status(200));", headers=AUTH),
        req("Resume stream (Last-Event-ID)", "GET", "/agent/runs/{{hold_run_id}}/stream", SSE_PARSE + """
pm.test('starts with run.resumed', () => pm.expect(events[0]).to.eql('run.resumed'));
pm.test('ends with run.completed', () => pm.expect(events[events.length - 1]).to.eql('run.completed'));""",
            headers=AUTH + [{"key": "Last-Event-ID", "value": "{{last_event_id}}"}]),
    ]),
    ("05 MCP", [
        req("List MCP primitives (via MCP client)", "GET", "/mcp-tools", """
pm.test('6 tools', () => pm.expect(pm.response.json().tools.length).to.eql(6));
pm.test('1 prompt', () => pm.expect(pm.response.json().prompts).to.eql(['review_transfer']));"""),
        req("MCP initialize", "POST", "/mcp", """
pm.test('200', () => pm.response.to.have.status(200));
pm.environment.set('mcp_session_id', pm.response.headers.get('mcp-session-id') || '');
pm.test('serverInfo novabank', () => pm.expect(pm.response.text()).to.include('novabank'));""",
            body={"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
                "protocolVersion": "2025-11-25", "capabilities": {},
                "clientInfo": {"name": "postman", "version": "1.0"}}}, headers=MCP_H),
        req("MCP initialized notification", "POST", "/mcp",
            "pm.test('202', () => pm.response.to.have.status(202));",
            body={"jsonrpc": "2.0", "method": "notifications/initialized"},
            headers=MCP_H + [{"key": "Mcp-Session-Id", "value": "{{mcp_session_id}}"}]),
        req("MCP tools/call score_fraud", "POST", "/mcp", """
pm.test('200', () => pm.response.to.have.status(200));
pm.test('APPROVE', () => pm.expect(pm.response.text()).to.include('APPROVE'));""",
            body={"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": "score_fraud", "arguments": {
                "user": "asha", "from_account": "ACC-1001", "to_account": "ACC-1002", "amount": "500.00"}}},
            headers=MCP_H + [{"key": "Mcp-Session-Id", "value": "{{mcp_session_id}}"}]),
    ]),
    ("06 A2A loan (partner agent)", [
        req("Create run: 2 lakh loan", "POST", "/agent/runs", """
pm.test('201', () => pm.response.to.have.status(201));
pm.test('delegate step', () => pm.expect(pm.response.json().plan[0].kind).to.eql('delegate'));
pm.environment.set('loan_run_id', pm.response.json().run_id);""",
            body={"message": "Can I get a 2 lakh personal loan for 24 months?"}, headers=AUTH + JSON_H),
        req("Stream pauses on partner question", "GET", "/agent/runs/{{loan_run_id}}/stream", SSE_PARSE + """
pm.test('partner discovered', () => pm.expect(events).to.include('a2a.discovered'));
pm.test('ends with run.paused', () => pm.expect(events[events.length - 1]).to.eql('run.paused'));
pm.environment.set('loan_last_event_id', events.length);""", headers=AUTH),
        req("Answer partner (monthly income)", "POST", "/agent/runs/{{loan_run_id}}/confirm",
            "pm.test('200', () => pm.response.to.have.status(200));",
            body={"reply": "85000"}, headers=AUTH + JSON_H),
        req("Resume stream: offer artifact", "GET", "/agent/runs/{{loan_run_id}}/stream", SSE_PARSE + """
pm.test('loan_offer artifact', () => pm.expect(events).to.include('a2a.artifact'));
pm.test('ends with run.completed', () => pm.expect(events[events.length - 1]).to.eql('run.completed'));""",
            headers=AUTH + [{"key": "Last-Event-ID", "value": "{{loan_last_event_id}}"}]),
    ]),
]

collection = {
    "info": {"name": "NovaBank (MCP + A2A)", "schema":
             "https://schema.getpostman.com/json/collection/v2.1.0/collection.json",
             "description": "Runs top to bottom in the Collection Runner. Start the server first."},
    "item": [{"name": n, "item": items} for n, items in folders],
}
(HERE / "NovaBank.postman_collection.json").write_text(json.dumps(collection, indent=2))
for name, url in [("Local", "http://localhost:8000"), ("Docker", "http://localhost:8080")]:
    env = {"name": f"NovaBank {name}", "values": [{"key": "base_url", "value": url, "enabled": True}]}
    (HERE / f"NovaBank.{name}.postman_environment.json").write_text(json.dumps(env, indent=2))

n_req = sum(len(i) for _, i in folders)
n_tests = sum(json.dumps(i).count("pm.test(") for _, i in folders)
print(f"{n_req} requests, {n_tests} assertions")

"""Minimal A2A v1 JSON-RPC client used by the NovaBank assistant to delegate tasks.

The assistant never imports partner code. It discovers the partner through its
Agent Card and talks to it only over A2A.

PARTNER_AGENT_URL=inprocess (default) mounts the mock partner in-process so the
demo runs as one process. Set it to e.g. http://localhost:8100 to call a
separately running partner.
"""

from __future__ import annotations

import json
import os
import uuid
from decimal import Decimal, InvalidOperation
from typing import Any, AsyncIterator

import httpx

AGENT_CARD_PATH = "/.well-known/agent-card.json"

STATE_NAMES = {
    "TASK_STATE_SUBMITTED": "submitted",
    "TASK_STATE_WORKING": "working",
    "TASK_STATE_INPUT_REQUIRED": "input-required",
    "TASK_STATE_AUTH_REQUIRED": "auth-required",
    "TASK_STATE_COMPLETED": "completed",
    "TASK_STATE_FAILED": "failed",
    "TASK_STATE_CANCELED": "canceled",
    "TASK_STATE_REJECTED": "rejected",
}


class A2AError(Exception):
    def __init__(self, code: int, message: str) -> None:
        super().__init__(f"A2A error {code}: {message}")
        self.code, self.message = code, message


def short_state(state: str) -> str:
    return STATE_NAMES.get(state, state.lower())


def user_message(text: str, data: dict[str, Any] | None = None,
                 task_id: str | None = None, context_id: str | None = None,
                 message_id: str | None = None) -> dict[str, Any]:
    parts: list[dict[str, Any]] = [{"text": text}]
    if data:
        parts.append({"data": data})
    msg: dict[str, Any] = {"messageId": message_id or f"msg_{uuid.uuid4().hex[:10]}",
                           "role": "ROLE_USER", "parts": parts}
    if task_id:
        msg["taskId"] = task_id
    if context_id:
        msg["contextId"] = context_id
    return msg


def text_of(message: dict[str, Any] | None) -> str:
    if not message:
        return ""
    return " ".join(p["text"] for p in message.get("parts", []) if "text" in p)


def validate_loan_offer(artifact: dict[str, Any]) -> dict[str, Any]:
    """Partner output is untrusted input: accept only known fields with sane values."""
    data: dict[str, Any] = {}
    for part in artifact.get("parts", []):
        if isinstance(part.get("data"), dict):
            data.update(part["data"])
    try:
        offer = {
            "offer_id": str(data["offer_id"])[:40],
            "amount": f"{Decimal(str(data['amount'])):.2f}",
            "currency": str(data.get("currency", "INR"))[:3],
            "tenure_months": int(data["tenure_months"]),
            "annual_rate": f"{Decimal(str(data['annual_rate'])):.2f}",
            "emi": f"{Decimal(str(data['emi'])):.2f}",
            "lender": str(data.get("lender", "partner"))[:80],
        }
    except (KeyError, ValueError, TypeError, InvalidOperation) as e:
        raise A2AError(-32603, f"Invalid loan_offer artifact: {e}") from None
    if not (0 < Decimal(offer["annual_rate"]) < 50 and 0 < offer["tenure_months"] <= 120):
        raise A2AError(-32603, "loan_offer values out of range")
    return offer


class A2AClient:
    def __init__(self, base_url: str, token: str, transport: httpx.AsyncBaseTransport | None = None,
                 timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.transport = transport
        self.timeout = timeout
        self.card: dict[str, Any] | None = None
        self.endpoint: str | None = None

    def _http(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(transport=self.transport, timeout=self.timeout,
                                 headers={"Authorization": f"Bearer {self.token}"})

    async def discover(self) -> dict[str, Any]:
        async with self._http() as http:
            r = await http.get(self.base_url + AGENT_CARD_PATH)
            r.raise_for_status()
            card = r.json()
        iface = next((i for i in card.get("supportedInterfaces", [])
                      if i.get("protocolBinding") == "JSONRPC"), None)
        if iface is None:
            raise A2AError(-32603, "Partner has no JSON-RPC interface")
        # In-process mode: keep the path from the card, route it through our transport.
        url = iface["url"]
        if self.transport is not None:
            url = self.base_url + httpx.URL(url).path
        self.card, self.endpoint = card, url
        return card

    async def _rpc(self, method: str, params: dict[str, Any]) -> Any:
        if self.endpoint is None:
            await self.discover()
        payload = {"jsonrpc": "2.0", "id": uuid.uuid4().hex[:8], "method": method, "params": params}
        async with self._http() as http:
            r = await http.post(self.endpoint, json=payload)
        body = r.json()
        if "error" in body:
            raise A2AError(body["error"]["code"], body["error"]["message"])
        return body["result"]

    async def send_message(self, message: dict[str, Any]) -> dict[str, Any]:
        return await self._rpc("SendMessage", {"message": message})

    async def stream_message(self, message: dict[str, Any]) -> AsyncIterator[dict[str, Any]]:
        """Yields StreamResponse objects: {task} | {statusUpdate} | {artifactUpdate} | {message}."""
        if self.endpoint is None:
            await self.discover()
        payload = {"jsonrpc": "2.0", "id": uuid.uuid4().hex[:8],
                   "method": "SendStreamingMessage", "params": {"message": message}}
        async with self._http() as http:
            async with http.stream("POST", self.endpoint, json=payload,
                                   headers={"Accept": "text/event-stream"}) as r:
                if r.headers.get("content-type", "").startswith("application/json"):
                    body = json.loads(await r.aread())
                    err = body.get("error", {"code": -32603, "message": "Unexpected response"})
                    raise A2AError(err["code"], err["message"])
                async for line in r.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    body = json.loads(line[5:].strip())
                    if "error" in body:
                        raise A2AError(body["error"]["code"], body["error"]["message"])
                    yield body["result"]

    async def get_task(self, task_id: str) -> dict[str, Any]:
        return await self._rpc("GetTask", {"id": task_id})

    async def cancel_task(self, task_id: str) -> dict[str, Any]:
        return await self._rpc("CancelTask", {"id": task_id})


def partner_client() -> A2AClient:
    url = os.getenv("PARTNER_AGENT_URL", "inprocess")
    token = os.getenv("PARTNER_TOKEN", "partner-demo-token")
    if url == "inprocess":
        from partner_agent.server import app as partner_app
        return A2AClient("http://partner.local", token, transport=httpx.ASGITransport(app=partner_app))
    return A2AClient(url, token)

"""Business logic shared by the REST API and the MCP server.

Fraud and ownership rules live here once. Neither the REST routes nor the MCP
tools re-implement them, so no money-moving path can skip a check.
"""

from __future__ import annotations

import uuid
from decimal import Decimal, InvalidOperation
from typing import Any

from .store import Transaction, now_iso, store

HOLD_THRESHOLD = Decimal("10000.00")   # at or above: human must confirm
BLOCK_THRESHOLD = Decimal("100000.00")  # above: never allowed
BLOCKLIST = {"ACC-9999"}                # known mule account


class ServiceError(Exception):
    """Carries an HTTP status and an RFC 7807 title so REST and MCP report the same error."""

    def __init__(self, status: int, title: str, detail: str = "") -> None:
        super().__init__(f"{status} {title}: {detail}")
        self.status = status
        self.title = title
        self.detail = detail


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def parse_amount(amount: str | int | float | Decimal) -> Decimal:
    if isinstance(amount, float):
        raise ServiceError(422, "Invalid amount", "Pass money as a decimal string, not a float")
    try:
        value = Decimal(str(amount).replace(",", ""))
    except InvalidOperation:
        raise ServiceError(422, "Invalid amount", f"{amount!r} is not a number")
    if value <= 0:
        raise ServiceError(422, "Invalid amount", "Amount must be greater than zero")
    if value.as_tuple().exponent < -2:
        raise ServiceError(422, "Invalid amount", "At most 2 decimal places")
    return value.quantize(Decimal("0.01"))


def money(value: Decimal) -> str:
    return f"{value:.2f}"


def _own_account(user: str, account_id: str):
    account = store.accounts.get(account_id)
    if account is None:
        raise ServiceError(404, "Account not found", account_id)
    if account.owner != user:
        raise ServiceError(403, "Forbidden", f"{account_id} does not belong to {user}")
    return account


# --------------------------------------------------------------------------- #
# Auth (demo: opaque in-memory tokens)
# --------------------------------------------------------------------------- #

def login(username: str, password: str) -> dict[str, Any]:
    user = store.users.get(username)
    if user is None or user["password"] != password:
        raise ServiceError(401, "Invalid credentials")
    token = uuid.uuid4().hex
    store.tokens[token] = username
    return {"access_token": token, "token_type": "bearer", "user": username}


def user_for_token(token: str) -> str:
    user = store.tokens.get(token)
    if user is None:
        raise ServiceError(401, "Unauthorized", "Missing or invalid bearer token")
    return user


# --------------------------------------------------------------------------- #
# Accounts and transactions
# --------------------------------------------------------------------------- #

def list_accounts(user: str) -> list[dict[str, Any]]:
    return [
        {"id": a.id, "name": a.name, "currency": a.currency, "balance": money(a.balance)}
        for a in store.accounts.values()
        if a.owner == user
    ]


def get_balance(user: str, account_id: str) -> dict[str, Any]:
    a = _own_account(user, account_id)
    return {"account_id": a.id, "currency": a.currency, "balance": money(a.balance)}


def list_transactions(user: str, account_id: str, limit: int = 10) -> list[dict[str, Any]]:
    _own_account(user, account_id)
    txns = [t for t in store.transactions if t.account_id == account_id]
    txns.sort(key=lambda t: t.id, reverse=True)
    return [
        {**t.model_dump(exclude={"amount"}), "amount": money(t.amount)}
        for t in txns[: max(1, min(limit, 100))]
    ]


def statement(user: str, account_id: str) -> dict[str, Any]:
    return {
        **get_balance(user, account_id),
        "generated_at": now_iso(),
        "transactions": list_transactions(user, account_id, limit=5),
    }


# --------------------------------------------------------------------------- #
# Fraud and transfers
# --------------------------------------------------------------------------- #

def score_fraud(user: str, from_account: str, to_account: str, amount: str) -> dict[str, Any]:
    """Three demo rules. Returns APPROVE, HOLD or BLOCK with reasons."""
    _own_account(user, from_account)
    value = parse_amount(amount)
    reasons: list[str] = []
    decision = "APPROVE"
    if to_account in BLOCKLIST:
        decision, reasons = "BLOCK", reasons + [f"{to_account} is on the blocklist"]
    if value > BLOCK_THRESHOLD:
        decision, reasons = "BLOCK", reasons + [f"amount above {money(BLOCK_THRESHOLD)} limit"]
    if decision != "BLOCK" and value >= HOLD_THRESHOLD:
        decision, reasons = "HOLD", reasons + [f"amount at or above {money(HOLD_THRESHOLD)} needs confirmation"]
    score = {"APPROVE": 0.1, "HOLD": 0.6, "BLOCK": 0.95}[decision]
    return {"decision": decision, "score": score, "reasons": reasons or ["within normal limits"],
            "amount": money(value), "from_account": from_account, "to_account": to_account}


def confirm_hold(user: str, from_account: str, to_account: str, amount: str) -> str:
    """Record a human confirmation for one HOLD transfer. Returns a single-use id."""
    confirmation_id = f"conf_{uuid.uuid4().hex[:10]}"
    store.hold_confirmations[confirmation_id] = {
        "user": user, "from_account": from_account, "to_account": to_account,
        "amount": money(parse_amount(amount)), "used": False,
    }
    return confirmation_id


def transfer_funds(user: str, from_account: str, to_account: str, amount: str,
                   idempotency_key: str, note: str = "",
                   confirmation_id: str | None = None) -> dict[str, Any]:
    """Atomic, idempotent transfer. Fraud is re-checked here, in code, on every call."""
    if not idempotency_key:
        raise ServiceError(422, "Missing idempotency key")
    with store.lock:
        if idempotency_key in store.idempotency:
            return {**store.idempotency[idempotency_key], "idempotent_replay": True}

        if from_account == to_account:
            raise ServiceError(422, "Invalid transfer", "Source and destination are the same")
        src = _own_account(user, from_account)
        dst = store.accounts.get(to_account)
        if dst is None:
            raise ServiceError(404, "Account not found", to_account)

        fraud = score_fraud(user, from_account, to_account, amount)
        if fraud["decision"] == "BLOCK":
            raise ServiceError(422, "Transfer blocked", "; ".join(fraud["reasons"]))
        if fraud["decision"] == "HOLD":
            conf = store.hold_confirmations.get(confirmation_id or "")
            ok = (conf and not conf["used"] and conf["user"] == user
                  and conf["from_account"] == from_account and conf["to_account"] == to_account
                  and conf["amount"] == fraud["amount"])
            if not ok:
                raise ServiceError(422, "Confirmation required",
                                   "Fraud check returned HOLD; a human must confirm this transfer")
            conf["used"] = True

        value = parse_amount(amount)
        if src.balance < value:
            raise ServiceError(409, "Insufficient funds",
                               f"Balance {money(src.balance)} is less than {money(value)}")

        src.balance -= value
        dst.balance += value
        txn_id = store.next_txn_id()
        store.transactions.append(Transaction(id=txn_id, account_id=from_account, direction="debit",
                                              amount=value, counterparty=to_account, note=note))
        store.transactions.append(Transaction(id=store.next_txn_id(), account_id=to_account,
                                              direction="credit", amount=value,
                                              counterparty=from_account, note=note))
        result = {"transaction_id": txn_id, "status": "SUCCESS", "amount": money(value),
                  "from_account": from_account, "to_account": to_account,
                  "new_balance": money(src.balance), "fraud_decision": fraud["decision"]}
        store.idempotency[idempotency_key] = result
        return result


def send_notification(user: str, channel: str, message: str) -> dict[str, Any]:
    if channel not in {"push", "sms", "email"}:
        raise ServiceError(422, "Invalid channel", "Use push, sms or email")
    note = {"id": f"ntf_{uuid.uuid4().hex[:8]}", "user": user, "channel": channel,
            "message": message, "sent_at": now_iso(), "status": "SENT (mock)"}
    store.notifications.append(note)
    return note

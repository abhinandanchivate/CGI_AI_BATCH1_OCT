"""FastAPI app: REST routers, SSE streaming for agent runs, MCP mounted at /mcp.

Run:  uvicorn app.main:app --port 8000
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import os

from fastapi import Depends, FastAPI, Header, Request
from fastapi.responses import JSONResponse, StreamingResponse
from mcp import Client
from mcp.server.transport_security import TransportSecuritySettings
from pydantic import BaseModel

from . import agent, services
from .mcp_server import mcp_server
from .services import ServiceError
from .store import store

# --------------------------------------------------------------------------- #
# MCP over Streamable HTTP at /mcp, with DNS-rebinding protection for localhost
# --------------------------------------------------------------------------- #

ALLOWED_HOSTS = os.getenv("MCP_ALLOWED_HOSTS", "localhost:*,127.0.0.1:*,localhost,127.0.0.1,testserver").split(",")
mcp_http_app = mcp_server.streamable_http_app(
    streamable_http_path="/mcp",
    transport_security=TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=ALLOWED_HOSTS,
        allowed_origins=["http://localhost:*", "http://127.0.0.1:*"],
    ),
)


@contextlib.asynccontextmanager
async def lifespan(_: FastAPI):
    async with mcp_server.session_manager.run():
        yield


app = FastAPI(title="NovaBank API", version="1.0.0", lifespan=lifespan,
              description="Teaching-grade neobank: REST for apps, MCP for AI clients, A2A for partner agents.")


# --------------------------------------------------------------------------- #
# Errors as RFC 7807 problem+json
# --------------------------------------------------------------------------- #

@app.exception_handler(ServiceError)
async def service_error_handler(request: Request, exc: ServiceError):
    return JSONResponse(
        status_code=exc.status,
        media_type="application/problem+json",
        content={"type": "about:blank", "title": exc.title, "status": exc.status,
                 "detail": exc.detail, "instance": str(request.url.path)},
    )


# --------------------------------------------------------------------------- #
# Auth
# --------------------------------------------------------------------------- #

def current_user(authorization: str = Header(default="")) -> str:
    token = authorization.removeprefix("Bearer ").strip()
    return services.user_for_token(token)


class LoginIn(BaseModel):
    username: str
    password: str


class TransferIn(BaseModel):
    from_account: str
    to_account: str
    amount: str
    note: str = ""


class RunIn(BaseModel):
    message: str


class ConfirmIn(BaseModel):
    reply: str | None = None


# --------------------------------------------------------------------------- #
# 01 Ops & Auth
# --------------------------------------------------------------------------- #

@app.get("/health", tags=["ops"])
def health():
    return {"status": "ok", "mcp_endpoint": "/mcp", "partner_agent": os.getenv("PARTNER_AGENT_URL", "inprocess")}


@app.post("/auth/login", tags=["auth"])
def login(body: LoginIn):
    return services.login(body.username, body.password)


# --------------------------------------------------------------------------- #
# 02 Accounts
# --------------------------------------------------------------------------- #

@app.get("/accounts", tags=["accounts"])
def accounts(user: str = Depends(current_user)):
    return {"accounts": services.list_accounts(user)}


@app.get("/accounts/{account_id}/balance", tags=["accounts"])
def balance(account_id: str, user: str = Depends(current_user)):
    return services.get_balance(user, account_id)


@app.get("/transactions", tags=["accounts"])
def transactions(account_id: str, limit: int = 10, user: str = Depends(current_user)):
    return {"transactions": services.list_transactions(user, account_id, limit)}


# --------------------------------------------------------------------------- #
# 03 Payments
# --------------------------------------------------------------------------- #

@app.post("/payments/transfer", tags=["payments"])
def transfer(body: TransferIn, user: str = Depends(current_user),
             idempotency_key: str = Header(default="", alias="Idempotency-Key")):
    fraud = services.score_fraud(user, body.from_account, body.to_account, body.amount)
    if fraud["decision"] != "APPROVE":
        raise ServiceError(422, f"Fraud check returned {fraud['decision']}", "; ".join(fraud["reasons"]))
    return services.transfer_funds(user, body.from_account, body.to_account, body.amount,
                                   idempotency_key, body.note)


# --------------------------------------------------------------------------- #
# 04 Agent (streaming)
# --------------------------------------------------------------------------- #

def _run_for(run_id: str, user: str):
    run = store.runs.get(run_id)
    if run is None or run.user != user:
        raise ServiceError(404, "Run not found", run_id)
    return run


@app.post("/agent/runs", status_code=201, tags=["agent"])
def create_run(body: RunIn, user: str = Depends(current_user)):
    run = agent.create_run(user, body.message)
    return {"run_id": run.id, "status": run.status.value, "intent": run.intent,
            "plan": [s.model_dump() for s in run.plan], "stream": f"/agent/runs/{run.id}/stream"}


@app.get("/agent/runs/{run_id}/stream", tags=["agent"])
async def stream_run(run_id: str, user: str = Depends(current_user),
                     last_event_id: int = Header(default=0, alias="Last-Event-ID")):
    run = _run_for(run_id, user)
    agent.start(run)

    async def events():
        sent = last_event_id
        while True:
            waiter = agent.signal(run.id)
            for e in [e for e in run.events if e.seq > sent]:
                yield f"id: {e.seq}\nevent: {e.type}\ndata: {json.dumps({**e.data, 'at': e.at})}\n\n"
                sent = e.seq
            if agent.is_settled(run) and not any(e.seq > sent for e in run.events):
                break
            try:
                await asyncio.wait_for(waiter.wait(), timeout=15)
            except asyncio.TimeoutError:
                yield ": keep-alive\n\n"

    return StreamingResponse(events(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.get("/agent/runs/{run_id}", tags=["agent"])
def get_run(run_id: str, user: str = Depends(current_user)):
    return _run_for(run_id, user).model_dump(mode="json")


@app.post("/agent/runs/{run_id}/confirm", tags=["agent"])
def confirm_run(run_id: str, body: ConfirmIn | None = None, user: str = Depends(current_user)):
    return agent.confirm(_run_for(run_id, user), (body.reply if body else None))


@app.post("/agent/runs/{run_id}/cancel", tags=["agent"])
async def cancel_run(run_id: str, user: str = Depends(current_user)):
    return await agent.cancel(_run_for(run_id, user))


# --------------------------------------------------------------------------- #
# 05 MCP
# --------------------------------------------------------------------------- #

@app.get("/mcp-tools", tags=["mcp"])
async def mcp_tools():
    """Lists MCP tools, resources and prompts through a real MCP client."""
    async with Client(mcp_server) as c:
        tools = await c.list_tools()
        templates = await c.list_resource_templates()
        prompts = await c.list_prompts()
    return {
        "tools": [{"name": t.name, "description": t.description} for t in tools.tools],
        "resource_templates": [t.uri_template for t in templates.resource_templates],
        "prompts": [p.name for p in prompts.prompts],
    }


@app.post("/demo/reset", tags=["ops"], include_in_schema=False)
def reset():
    """Test helper: restore seed data."""
    store.reset()
    agent.active_runs.clear()
    return {"status": "reset"}


# The MCP Streamable HTTP route (POST/GET/DELETE /mcp)
app.router.routes.extend(mcp_http_app.routes)

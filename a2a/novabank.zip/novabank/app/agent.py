"""Banking assistant: rule-based planner plus an executor that reaches the bank
only through an MCP client, and reaches partner agents only through A2A.

The agent has no import of app.services for banking actions. It calls MCP
tools exactly as Claude Desktop would (in-process transport here).
"""

from __future__ import annotations

import asyncio
import json
import re
from decimal import Decimal
from typing import Any

from mcp import Client

from . import services
from .a2a_client import A2AError, partner_client, short_state, text_of, user_message, validate_loan_offer
from .mcp_server import mcp_server
from .store import TERMINAL, PlanStep, RunEvent, RunState, RunStatus, store

# --------------------------------------------------------------------------- #
# Events and signalling
# --------------------------------------------------------------------------- #

active_runs: set[str] = set()


def signal(run_id: str) -> asyncio.Event:
    if run_id not in store.run_signals:
        store.run_signals[run_id] = asyncio.Event()
    return store.run_signals[run_id]


def notify(run_id: str) -> None:
    """Wake every stream waiting on this run."""
    old = signal(run_id)
    store.run_signals[run_id] = asyncio.Event()  # fresh event for the next wait
    old.set()


def emit(run: RunState, type_: str, data: dict[str, Any] | None = None) -> RunEvent:
    event = RunEvent(seq=len(run.events) + 1, type=type_, data=data or {})
    run.events.append(event)
    notify(run.id)
    return event


def _state(run: RunState) -> None:
    emit(run, "state.updated", {"status": run.status.value, "current_step": run.current_step,
                                "pause_reason": run.pause_reason})


# --------------------------------------------------------------------------- #
# Planner (rule-based: free, offline, repeatable; swap for an LLM later)
# --------------------------------------------------------------------------- #

AMOUNT = r"(?:rs\.?|inr|₹)?\s*([\d,]+(?:\.\d{1,2})?)\s*(lakh|lac|k)?"
TRANSFER_RE = re.compile(rf"(?:transfer|send|pay)\s+{AMOUNT}\s+to\s+(ACC-\d+)(?:\s+from\s+(ACC-\d+))?", re.I)
LOAN_RE = re.compile(rf"loan.*?{AMOUNT}|{AMOUNT}.*?loan", re.I)
TENURE_RE = re.compile(r"(\d+)\s*(months?|years?)", re.I)
ACCOUNT_RE = re.compile(r"(ACC-\d+)", re.I)


def _amount(number: str, unit: str | None) -> str:
    value = Decimal(number.replace(",", ""))
    unit = (unit or "").lower()
    if unit in ("lakh", "lac"):
        value *= 100000
    elif unit == "k":
        value *= 1000
    return f"{value:.2f}"


def _primary_account(user: str) -> str | None:
    accounts = [a.id for a in store.accounts.values() if a.owner == user]
    return accounts[0] if accounts else None


def plan(user: str, message: str) -> tuple[str, list[PlanStep]]:
    primary = _primary_account(user)

    if m := TRANSFER_RE.search(message):
        amount = _amount(m.group(1), m.group(2))
        to_acc, from_acc = m.group(3).upper(), (m.group(4) or primary or "").upper()
        base = {"user": user, "from_account": from_acc, "to_account": to_acc, "amount": amount}
        return "transfer", [
            PlanStep(tool="score_fraud", args=base),
            PlanStep(tool="transfer_funds", args={**base, "note": "Assistant transfer"}),
            PlanStep(tool="send_notification", args={
                "user": user, "channel": "push",
                "message": "Sent {transfer_funds[amount]} to {transfer_funds[to_account]}. "
                           "Ref {transfer_funds[transaction_id]}"}),
        ]

    if "loan" in message.lower() and (m := LOAN_RE.search(message)):
        number, unit = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
        months = 24
        if t := TENURE_RE.search(message):
            months = int(t.group(1)) * (12 if t.group(2).lower().startswith("year") else 1)
        return "loan", [
            PlanStep(kind="delegate", tool="personal_loan_offer", args={
                "customer_id": store.users[user]["customer_id"],
                "amount": _amount(number, unit), "currency": "INR", "tenure_months": months}),
            PlanStep(tool="send_notification", args={
                "user": user, "channel": "push",
                "message": "Loan offer {loan_offer[offer_id]}: {loan_offer[amount]} at "
                           "{loan_offer[annual_rate]}% for {loan_offer[tenure_months]} months, "
                           "EMI {loan_offer[emi]}"}),
        ]

    if re.search(r"transactions|statement|history", message, re.I):
        acc = (ACCOUNT_RE.search(message).group(1).upper() if ACCOUNT_RE.search(message) else primary)
        return "transactions", [PlanStep(tool="list_transactions", args={"user": user, "account_id": acc, "limit": 5})]

    if re.search(r"balance|accounts?", message, re.I):
        return "balance", [PlanStep(tool="list_accounts", args={"user": user})]

    return "unknown", []


def create_run(user: str, message: str) -> RunState:
    intent, steps = plan(user, message)
    run = RunState(user=user, message=message, intent=intent, plan=steps)
    store.runs[run.id] = run
    emit(run, "plan.created", {"intent": intent, "steps": [s.model_dump() for s in steps]})
    return run


# --------------------------------------------------------------------------- #
# Executor
# --------------------------------------------------------------------------- #

def _pause(run: RunState, reason: str, details: dict[str, Any]) -> None:
    run.transition(RunStatus.PAUSED)
    run.pause_reason = reason
    _state(run)
    emit(run, "run.paused", {"reason": reason, **details})


def _fail(run: RunState, error: str) -> None:
    run.transition(RunStatus.FAILED)
    run.context["error"] = error
    _state(run)
    emit(run, "run.failed", {"error": error})


async def _call_tool(run: RunState, mcp: Client, step: PlanStep) -> dict[str, Any] | None:
    args = dict(step.args)
    if step.tool == "transfer_funds":
        args["idempotency_key"] = f"{run.id}-transfer"  # a retried or resumed run cannot debit twice
        if run.context.get("confirmation_id"):
            args["confirmation_id"] = run.context["confirmation_id"]
    if "message" in args:
        args["message"] = args["message"].format(**run.context)

    emit(run, "tool.called", {"tool": step.tool, "arguments": args})
    result = await mcp.call_tool(step.tool, args)
    text = "".join(getattr(c, "text", "") for c in result.content)
    if result.is_error:
        emit(run, "tool.result", {"tool": step.tool, "is_error": True, "error": text})
        _fail(run, f"{step.tool} failed: {text}")
        return None
    data = json.loads(text) if text else {}
    emit(run, "tool.result", {"tool": step.tool, "is_error": False, "result": data})
    run.context[step.tool] = data
    return data


async def _delegate(run: RunState, step: PlanStep) -> str:
    """Run one A2A step. Returns 'continue', 'paused' or 'failed'."""
    client = partner_client()
    a2a = run.context.setdefault("a2a", {})
    try:
        card = await client.discover()
        if not a2a.get("task_id"):
            skills = [s["id"] for s in card.get("skills", [])]
            emit(run, "a2a.discovered", {"agent": card["name"], "skills": skills})
            if step.tool not in skills:
                _fail(run, f"Partner agent has no skill {step.tool}")
                return "failed"
            message = user_message(f"Personal loan offer for customer {step.args['customer_id']}",
                                   data=step.args, message_id=f"{run.id}-a2a-1")
        else:
            reply = run.context.pop("partner_reply", "")
            message = user_message(reply, data={"monthly_income": re.sub(r"[^\d.]", "", reply) or reply},
                                   task_id=a2a["task_id"], context_id=a2a.get("context_id"))
        emit(run, "a2a.message.sent", {"method": "SendStreamingMessage", "task_id": a2a.get("task_id"),
                                       "parts": message["parts"]})

        state = None
        async for event in client.stream_message(message):
            if "task" in event:
                a2a["task_id"], a2a["context_id"] = event["task"]["id"], event["task"]["contextId"]
                state = short_state(event["task"]["status"]["state"])
                emit(run, "a2a.status", {"task_id": a2a["task_id"], "state": state, "message": ""})
            elif "statusUpdate" in event:
                status = event["statusUpdate"]["status"]
                state = short_state(status["state"])
                a2a["state"] = state
                emit(run, "a2a.status", {"task_id": a2a["task_id"], "state": state,
                                         "message": text_of(status.get("message"))})
                if state == "input-required":
                    a2a["question"] = text_of(status.get("message"))
                    _pause(run, "partner_input", {"question": a2a["question"], "task_id": a2a["task_id"]})
                    return "paused"
                if state in ("failed", "rejected", "canceled"):
                    _fail(run, f"Partner {state} the task: {text_of(status.get('message'))}")
                    return "failed"
            elif "artifactUpdate" in event:
                offer = validate_loan_offer(event["artifactUpdate"]["artifact"])
                run.context["loan_offer"] = offer
                emit(run, "a2a.artifact", {"task_id": a2a["task_id"], "name": "loan_offer", "offer": offer})
        if state != "completed" or "loan_offer" not in run.context:
            _fail(run, f"Partner stream ended in state {state} without an offer")
            return "failed"
        return "continue"
    except A2AError as e:
        _fail(run, str(e))
        return "failed"


async def execute(run: RunState) -> None:
    """Advance a run until it completes, fails or pauses. Safe to call again after confirm."""
    try:
        if run.status == RunStatus.PENDING:
            if not run.plan:
                run.transition(RunStatus.RUNNING)
                _fail(run, "Sorry, I can only check balances and transactions, make transfers "
                           "and get loan offers. Try 'Transfer 2500 to ACC-1002'.")
                return
            run.transition(RunStatus.RUNNING)
            emit(run, "run.started", {"intent": run.intent})
        elif run.status == RunStatus.PAUSED and run.context.pop("resume_ready", False):
            run.transition(RunStatus.RUNNING)
            run.pause_reason = None
            emit(run, "run.resumed", {"current_step": run.current_step})
        else:
            return
        _state(run)

        async with Client(mcp_server) as mcp:
            while run.current_step < len(run.plan):
                if run.status != RunStatus.RUNNING:
                    return
                step = run.plan[run.current_step]

                if step.kind == "delegate":
                    outcome = await _delegate(run, step)
                    if outcome != "continue":
                        return
                    run.current_step += 1
                    _state(run)
                    continue

                data = await _call_tool(run, mcp, step)
                if data is None:
                    return
                run.current_step += 1
                _state(run)

                if step.tool == "score_fraud":
                    if data["decision"] == "BLOCK":
                        _fail(run, "Transfer blocked by fraud check: " + "; ".join(data["reasons"]))
                        return
                    if data["decision"] == "HOLD" and not run.context.get("confirmation_id"):
                        _pause(run, "fraud_hold", {"fraud": data})
                        return

        run.transition(RunStatus.COMPLETED)
        _state(run)
        emit(run, "run.completed", {"summary": summarize(run)})
    except Exception as e:  # never leave a run stuck in RUNNING
        if run.status == RunStatus.RUNNING:
            _fail(run, f"Internal error: {e}")
    finally:
        active_runs.discard(run.id)
        notify(run.id)  # let open streams see the run has settled


def summarize(run: RunState) -> str:
    c = run.context
    if run.intent == "transfer" and "transfer_funds" in c:
        t = c["transfer_funds"]
        return f"Transferred {t['amount']} to {t['to_account']} (ref {t['transaction_id']}). New balance {t['new_balance']}."
    if run.intent == "loan" and "loan_offer" in c:
        o = c["loan_offer"]
        return (f"{o['lender']} offers {o['amount']} {o['currency']} at {o['annual_rate']}% for "
                f"{o['tenure_months']} months, EMI {o['emi']}.")
    if run.intent == "balance" and "list_accounts" in c:
        return "; ".join(f"{a['id']} {a['balance']}" for a in c["list_accounts"]["accounts"])
    if run.intent == "transactions" and "list_transactions" in c:
        return f"{len(c['list_transactions']['transactions'])} recent transactions"
    return "Done"


def start(run: RunState) -> bool:
    """Start execution in the background if the run can move. Returns True if started."""
    can_run = run.status == RunStatus.PENDING or (
        run.status == RunStatus.PAUSED and run.context.get("resume_ready"))
    if not can_run or run.id in active_runs:
        return False
    active_runs.add(run.id)
    asyncio.get_running_loop().create_task(execute(run))
    return True


# --------------------------------------------------------------------------- #
# Human-in-the-loop
# --------------------------------------------------------------------------- #

def confirm(run: RunState, reply: str | None = None) -> dict[str, Any]:
    if run.status != RunStatus.PAUSED:
        raise services.ServiceError(409, "Run is not paused", f"Status is {run.status.value}")
    if run.pause_reason == "fraud_hold":
        f = run.context["score_fraud"]
        run.context["confirmation_id"] = services.confirm_hold(
            run.user, f["from_account"], f["to_account"], f["amount"])
    elif run.pause_reason == "partner_input":
        if not reply:
            raise services.ServiceError(422, "Reply required",
                                        run.context.get("a2a", {}).get("question", "Answer the partner's question"))
        run.context["partner_reply"] = reply
    run.context["resume_ready"] = True
    return {"run_id": run.id, "status": run.status.value, "resume": f"/agent/runs/{run.id}/stream"}


async def cancel(run: RunState) -> dict[str, Any]:
    if run.status not in (RunStatus.PENDING, RunStatus.PAUSED):
        raise services.ServiceError(409, "Run cannot be cancelled", f"Status is {run.status.value}")
    a2a = run.context.get("a2a", {})
    if a2a.get("task_id") and a2a.get("state") not in ("completed", "failed", "rejected", "canceled"):
        try:
            await partner_client().cancel_task(a2a["task_id"])
            a2a["state"] = "canceled"
            emit(run, "a2a.status", {"task_id": a2a["task_id"], "state": "canceled", "message": "CancelTask sent"})
        except A2AError as e:
            emit(run, "a2a.status", {"task_id": a2a["task_id"], "state": "unknown", "message": str(e)})
    run.transition(RunStatus.CANCELLED)
    _state(run)
    emit(run, "run.cancelled", {})
    return {"run_id": run.id, "status": run.status.value}


def is_settled(run: RunState) -> bool:
    """True when the stream can close: terminal, or paused and waiting on a human."""
    if run.status in TERMINAL:
        return True
    return (run.status == RunStatus.PAUSED and run.id not in active_runs
            and not run.context.get("resume_ready"))

"""In-memory data store, RunState model and the run state machine.

Everything lives in process memory so the demo runs offline with no database.
Swap Store for Postgres/Redis in production; RunState is a Pydantic model, so
persisting it is a serialization change, not a redesign.
"""

from __future__ import annotations

import asyncio
import threading
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# --------------------------------------------------------------------------- #
# Banking data
# --------------------------------------------------------------------------- #

class Account(BaseModel):
    id: str
    owner: str
    name: str
    currency: str = "INR"
    balance: Decimal


class Transaction(BaseModel):
    id: str
    account_id: str
    direction: str  # "debit" | "credit"
    amount: Decimal
    counterparty: str
    note: str = ""
    created_at: str = Field(default_factory=now_iso)


# --------------------------------------------------------------------------- #
# Agent runs
# --------------------------------------------------------------------------- #

class RunStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


TERMINAL = {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED}

# The only legal status changes. Anything else raises IllegalTransition.
TRANSITIONS: dict[RunStatus, set[RunStatus]] = {
    RunStatus.PENDING: {RunStatus.RUNNING, RunStatus.CANCELLED},
    RunStatus.RUNNING: {RunStatus.PAUSED, RunStatus.COMPLETED, RunStatus.FAILED},
    RunStatus.PAUSED: {RunStatus.RUNNING, RunStatus.CANCELLED},
    RunStatus.COMPLETED: set(),
    RunStatus.FAILED: set(),
    RunStatus.CANCELLED: set(),
}


class IllegalTransition(Exception):
    pass


class PlanStep(BaseModel):
    kind: str = "tool"  # "tool" (MCP tools/call) | "delegate" (A2A task)
    tool: str | None = None  # MCP tool name, or the A2A skill id for delegate
    args: dict[str, Any] = Field(default_factory=dict)


class RunEvent(BaseModel):
    seq: int
    type: str
    data: dict[str, Any]
    at: str = Field(default_factory=now_iso)


class RunState(BaseModel):
    id: str = Field(default_factory=lambda: f"run_{uuid.uuid4().hex[:10]}")
    user: str
    message: str
    intent: str = "unknown"
    plan: list[PlanStep] = Field(default_factory=list)
    current_step: int = 0
    status: RunStatus = RunStatus.PENDING
    pause_reason: str | None = None  # "fraud_hold" | "partner_input"
    context: dict[str, Any] = Field(default_factory=dict)
    events: list[RunEvent] = Field(default_factory=list)
    created_at: str = Field(default_factory=now_iso)

    def transition(self, new: RunStatus) -> None:
        if new not in TRANSITIONS[self.status]:
            raise IllegalTransition(f"{self.status.value} -> {new.value} is not allowed")
        self.status = new


# --------------------------------------------------------------------------- #
# Store
# --------------------------------------------------------------------------- #

class Store:
    def __init__(self) -> None:
        self.lock = threading.RLock()  # guards balances and idempotency keys
        self.reset()

    def reset(self) -> None:
        self.users: dict[str, dict[str, str]] = {
            "asha": {"password": "asha123", "name": "Asha Rao", "customer_id": "CUST-001"},
            "ravi": {"password": "ravi123", "name": "Ravi Kumar", "customer_id": "CUST-002"},
        }
        self.accounts: dict[str, Account] = {
            "ACC-1001": Account(id="ACC-1001", owner="asha", name="Asha Savings", balance=Decimal("50000.00")),
            "ACC-1003": Account(id="ACC-1003", owner="asha", name="Asha Salary", balance=Decimal("120000.00")),
            "ACC-1002": Account(id="ACC-1002", owner="ravi", name="Ravi Savings", balance=Decimal("15000.00")),
        }
        self.transactions: list[Transaction] = [
            Transaction(id="TXN-0001", account_id="ACC-1001", direction="credit",
                        amount=Decimal("50000.00"), counterparty="Opening deposit"),
            Transaction(id="TXN-0002", account_id="ACC-1003", direction="credit",
                        amount=Decimal("120000.00"), counterparty="Salary"),
            Transaction(id="TXN-0003", account_id="ACC-1002", direction="credit",
                        amount=Decimal("15000.00"), counterparty="Opening deposit"),
        ]
        self.tokens: dict[str, str] = {}  # bearer token -> username
        self.idempotency: dict[str, dict[str, Any]] = {}  # key -> transfer result
        self.hold_confirmations: dict[str, dict[str, Any]] = {}  # id -> approved transfer
        self.notifications: list[dict[str, Any]] = []
        self.runs: dict[str, RunState] = {}
        self.run_signals: dict[str, asyncio.Event] = {}
        self._txn_counter = len(self.transactions)

    def next_txn_id(self) -> str:
        self._txn_counter += 1
        return f"TXN-{self._txn_counter:04d}"


store = Store()

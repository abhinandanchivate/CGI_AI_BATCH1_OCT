"""
NovaTrust Bank policy snippets used as retrieved context (a tiny RAG store).
Values are illustrative sample policies for the lab, not real bank terms.
"""
import re

KB = [
    {"id": "KB-CARD-01", "title": "Blocking a lost or stolen debit/credit card",
     "text": "Customers can block a card instantly in the NovaTrust app (Cards > Block), by SMS 'BLOCK <last 4 digits>' "
             "to 56767, or by calling 1800-000-1234 (24x7). A replacement card is dispatched within 7 working days. "
             "Unauthorised transactions reported within 3 working days carry zero customer liability."},
    {"id": "KB-ATM-01", "title": "ATM cash not dispensed but account debited",
     "text": "If cash is not dispensed but the account is debited, the amount is auto-reversed within 5 calendar days "
             "(T+5). If not reversed by then, the bank pays compensation of Rs 100 per day of delay. Customers should "
             "raise a complaint with the ATM ID, date, time and amount."},
    {"id": "KB-UPI-01", "title": "Failed UPI transaction",
     "text": "For a UPI payment debited from the customer but not credited to the beneficiary, auto-reversal happens "
             "within T+1 working day. If not reversed, the customer can raise a dispute in the app under UPI > Help."},
    {"id": "KB-LOAN-01", "title": "Personal loan eligibility",
     "text": "Personal loan eligibility: age 21-60 at loan maturity, minimum net monthly income Rs 25,000, credit score "
             "700 or above, and FOIR (all EMIs including the new one divided by net monthly income) of 50% or less. "
             "Tenure 12-60 months. Interest rate 10.5% to 16% per annum based on profile."},
    {"id": "KB-LOAN-02", "title": "EMI calculation",
     "text": "EMI = P x r x (1+r)^n / ((1+r)^n - 1), where P is principal, r is the monthly interest rate "
             "(annual rate / 12 / 100) and n is tenure in months."},
    {"id": "KB-FD-01", "title": "Fixed deposit rates",
     "text": "Fixed deposit rates: 1 year 6.8%, 2 years 7.0%, 3-5 years 7.1% per annum. Senior citizens get an "
             "additional 0.5%. Premature withdrawal carries a 1% penalty on the applicable rate."},
    {"id": "KB-KYC-01", "title": "KYC update",
     "text": "KYC can be updated through Video KYC in the app or at any branch with an officially valid document. "
             "The bank never asks for OTP, PIN, CVV or passwords over phone, SMS or email."},
    {"id": "KB-GRV-01", "title": "Grievance escalation",
     "text": "Complaints are acknowledged within 24 hours and resolved within 30 days. Unresolved complaints can be "
             "escalated to the Principal Nodal Officer and then to the RBI Integrated Ombudsman Scheme."},
]


def _tokens(s: str) -> set[str]:
    stop = {"the", "a", "an", "is", "to", "of", "and", "or", "in", "my", "i", "for", "on", "it", "was", "but", "not", "be", "can", "how", "what", "do"}
    return {w for w in re.findall(r"[a-z0-9]+", s.lower()) if w not in stop and len(w) > 1}


def retrieve(query: str, k: int = 2) -> list[dict]:
    """Keyword-overlap retrieval. Swap for embeddings + a vector DB in production."""
    q = _tokens(query)
    scored = []
    for d in KB:
        overlap = len(q & _tokens(d["title"] + " " + d["text"]))
        if overlap:
            scored.append((overlap, d))
    scored.sort(key=lambda x: -x[0])
    return [dict(d, score=s) for s, d in scored[:k]]

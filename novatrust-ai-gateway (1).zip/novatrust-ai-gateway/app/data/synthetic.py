"""
Synthetic NovaTrust Bank data. Every record is generated; no real customer data.

1. loan_applications()  -> S011 bias lab
   * 'repaid'        = the TRUE outcome, driven only by financial features
   * 'approved_hist' = what past human underwriters decided. It carries bias:
       women and rural applicants were approved less often for the same profile.
   * Women are also under-represented (about 30% of applications).
   * Two proxy columns (career_break_years, pincode_tier) correlate with gender and
     area, so simply deleting the protected columns does not remove the bias.

2. customer_accounts()  -> S012 differential-privacy lab
"""
from __future__ import annotations

from functools import lru_cache

import numpy as np
import pandas as pd

SEED = 42
BRANCHES = ["Mumbai", "Delhi", "Bengaluru", "Chennai", "Kolkata", "Hyderabad"]


@lru_cache(maxsize=1)
def loan_applications(n: int = 6000) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    gender = rng.choice(["male", "female"], size=n, p=[0.70, 0.30])
    area = rng.choice(["urban", "rural"], size=n, p=[0.65, 0.35])

    # Structural gap: slightly lower average recorded income for women and rural applicants
    base_income = rng.lognormal(mean=np.log(9.0), sigma=0.45, size=n)  # lakh per annum
    income = base_income * np.where(gender == "female", 0.92, 1.0) * np.where(area == "rural", 0.90, 1.0)
    credit_score = np.clip(rng.normal(720, 60, n), 300, 900).round()
    employment_years = np.clip(rng.gamma(2.5, 2.4, n), 0, 35).round(1)
    loan_amount = np.clip(rng.lognormal(np.log(6.0), 0.5, n), 1, 40).round(2)  # lakh
    existing_emi_ratio = np.clip(rng.beta(2, 6, n), 0, 0.8).round(3)

    # PROXY features: look neutral, but correlate with a protected attribute.
    # Neither one affects true repayment.
    career_break_years = np.clip(
        rng.exponential(np.where(gender == "female", 1.6, 0.25)), 0, 10).round(1)
    pincode_tier = np.where(area == "rural",
                            rng.choice([2, 3], size=n, p=[0.15, 0.85]),
                            rng.choice([1, 2, 3], size=n, p=[0.6, 0.35, 0.05]))

    # TRUE creditworthiness: no protected attribute involved
    z = (
        0.018 * (credit_score - 700)
        + 0.10 * (income - 9)
        - 3.2 * (existing_emi_ratio - 0.25)
        + 0.06 * (employment_years - 6)
        - 0.06 * (loan_amount - 6)
        + 0.6
    )
    p_repay = 1 / (1 + np.exp(-z))
    repaid = (rng.random(n) < p_repay).astype(int)

    # HISTORICAL decision: true signal + human bias against women and rural applicants
    bias = -1.1 * (gender == "female") - 0.8 * (area == "rural")
    z_hist = z + bias + rng.normal(0, 0.4, n)
    approved_hist = (z_hist > 0.35).astype(int)

    return pd.DataFrame({
        "applicant_id": [f"APP{100000 + i}" for i in range(n)],
        "gender": gender,
        "area": area,
        "annual_income_lakh": income.round(2),
        "credit_score": credit_score.astype(int),
        "employment_years": employment_years,
        "loan_amount_lakh": loan_amount,
        "existing_emi_ratio": existing_emi_ratio,
        "career_break_years": career_break_years,
        "pincode_tier": pincode_tier,
        "approved_hist": approved_hist,
        "repaid": repaid,
    })


@lru_cache(maxsize=1)
def customer_accounts(n: int = 2000) -> pd.DataFrame:
    rng = np.random.default_rng(SEED + 1)
    balance = np.clip(rng.lognormal(np.log(85000), 1.0, n), 0, 1_000_000).round(0)
    return pd.DataFrame({
        "customer_id": [f"CUST{50000 + i}" for i in range(n)],
        "branch": rng.choice(BRANCHES, size=n),
        "age": rng.integers(21, 75, n),
        "balance_inr": balance,
        "has_personal_loan": (rng.random(n) < 0.22).astype(int),
        "missed_emi_last_12m": (rng.random(n) < 0.07).astype(int),
    })

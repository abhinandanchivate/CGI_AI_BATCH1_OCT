"""
S012 - Security Approaches
  A. Prompt-injection defense  : POST /s012/chat  (direct + indirect injection, 3 defense levels)
  B. Data anonymization        : POST /s012/anonymize, POST /s012/reidentify
  C. Differential privacy      : POST /s012/dp/query, POST /s012/dp/differencing-attack, GET/POST budget
"""
from __future__ import annotations

from typing import Literal, Optional

import numpy as np
import pandas as pd
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.core import assistant, audit, config, pii
from app.data.synthetic import BRANCHES, customer_accounts

router = APIRouter(prefix="/s012", tags=["S012 Security Approaches"])

DefenseLevel = Literal["none", "basic", "full"]


# ============================================================ A. Prompt injection
class ChatRequest(BaseModel):
    message: str = Field(..., examples=["My ATM did not dispense cash but my account was debited. What should I do?"])
    defense_level: DefenseLevel = "full"
    document: Optional[str] = Field(None, description="Optional untrusted document (email, statement) for indirect injection tests")
    show_prompt: bool = Field(False, description="Return the exact prompt sent to the model (teaching aid)")


@router.post("/chat")
def chat(req: ChatRequest):
    out = assistant.answer(req.message, req.defense_level, req.document)
    if not req.show_prompt:
        out.pop("prompt_sent", None)
    return out


# ============================================================ B. Anonymization
class AnonymizeRequest(BaseModel):
    text: str = Field(..., examples=["Hi, my name is Priya Sharma. My PAN is ABCPS1234K and card 4111 1111 1111 1111 "
                                     "was charged twice. Call me on +91 9876543210 or priya.s@gmail.com."])
    mode: Literal["redact", "mask", "pseudonymize", "hash"] = "pseudonymize"


class ReidentifyRequest(BaseModel):
    text: str
    vault: dict


@router.post("/anonymize")
def anonymize(req: AnonymizeRequest):
    res = pii.transform(req.text, req.mode)
    audit.record("s012", "anonymize", {"mode": req.mode, "entities": len(res["entities"])})
    res["reversible"] = req.mode == "pseudonymize"
    res["use_case"] = {
        "redact": "Logs and analytics where identity is never needed again.",
        "mask": "Agent screens: enough to confirm the customer, not enough to misuse.",
        "pseudonymize": "Sending text to an external LLM, then restoring identities in the reply (vault stays in the bank).",
        "hash": "Joining records across datasets without exposing the raw identifier.",
    }[req.mode]
    return res


@router.post("/reidentify")
def reidentify(req: ReidentifyRequest):
    """Restore pseudonymised tokens using the vault (only inside the bank's trust boundary)."""
    return {"text": pii.reidentify(req.text, req.vault)}


# ============================================================ C. Differential privacy
_BUDGET = {"spent": 0.0}
CLIP_UPPER = 1_000_000.0  # balances are clipped to [0, 10 lakh] so one customer can move a sum by at most this


class DPQuery(BaseModel):
    statistic: Literal["count", "sum", "mean"] = "mean"
    column: Literal["balance_inr", "missed_emi_last_12m", "has_personal_loan"] = "balance_inr"
    branch: Optional[str] = Field("Mumbai", description=f"One of {BRANCHES} or null for all")
    min_age: int = 18
    epsilon: float = Field(1.0, gt=0, le=10, description="Privacy loss for this query. Smaller = more private, noisier")
    runs: int = Field(1, ge=1, le=50, description="Repeat the query to see the noise. Each run spends epsilon.")


def _laplace(scale: float, rng) -> float:
    return float(rng.laplace(0, scale))


def _subset(branch: Optional[str], min_age: int) -> pd.DataFrame:
    df = customer_accounts()
    if branch:
        if branch not in BRANCHES:
            raise HTTPException(400, f"branch must be one of {BRANCHES}")
        df = df[df["branch"] == branch]
    return df[df["age"] >= min_age]


def dp_answer(df: pd.DataFrame, statistic: str, column: str, eps: float, rng) -> float:
    upper = CLIP_UPPER if column == "balance_inr" else 1.0
    vals = df[column].clip(0, upper)
    if statistic == "count":
        return float(df[column].astype(bool).sum() if column != "balance_inr" else len(df)) + _laplace(1 / eps, rng)
    if statistic == "sum":
        return float(vals.sum()) + _laplace(upper / eps, rng)
    noisy_sum = float(vals.sum()) + _laplace(upper / (eps / 2), rng)      # half the budget on the sum
    noisy_cnt = max(1.0, len(df) + _laplace(1 / (eps / 2), rng))         # half on the count
    return noisy_sum / noisy_cnt


def true_answer(df: pd.DataFrame, statistic: str, column: str) -> float:
    if statistic == "count":
        return float(df[column].astype(bool).sum() if column != "balance_inr" else len(df))
    vals = df[column].clip(0, CLIP_UPPER if column == "balance_inr" else 1.0)
    return float(vals.sum() if statistic == "sum" else vals.mean())


@router.post("/dp/query")
def dp_query(q: DPQuery):
    cost = q.epsilon * q.runs
    if _BUDGET["spent"] + cost > config.DP_TOTAL_BUDGET:
        audit.record("s012", "dp_budget_refused", {"requested": cost, "spent": _BUDGET["spent"]})
        raise HTTPException(429, f"Privacy budget exceeded: spent {_BUDGET['spent']:.2f} of "
                                 f"{config.DP_TOTAL_BUDGET}, this request needs {cost:.2f}. POST /s012/dp/budget/reset")
    _BUDGET["spent"] += cost
    df = _subset(q.branch, q.min_age)
    rng = np.random.default_rng()
    truth = true_answer(df, q.statistic, q.column)
    answers = [dp_answer(df, q.statistic, q.column, q.epsilon, rng) for _ in range(q.runs)]
    err = [abs(a - truth) / truth * 100 if truth else 0 for a in answers]
    audit.record("s012", "dp_query", {"statistic": q.statistic, "epsilon": q.epsilon, "runs": q.runs})
    return {
        "query": q.model_dump(), "rows_matched": len(df),
        "true_answer_for_teaching_only": round(truth, 2),
        "dp_answers": [round(a, 2) for a in answers],
        "mean_abs_error_pct": round(float(np.mean(err)), 3),
        "noise_mechanism": "Laplace", "budget": budget_status(),
        "note": "In production the true answer is never returned; it is shown here to visualise the noise.",
    }


@router.get("/dp/budget")
def budget_status():
    return {"total_epsilon": config.DP_TOTAL_BUDGET, "spent": round(_BUDGET["spent"], 3),
            "remaining": round(config.DP_TOTAL_BUDGET - _BUDGET["spent"], 3)}


@router.post("/dp/budget/reset")
def budget_reset():
    _BUDGET["spent"] = 0.0
    return budget_status()


class AttackRequest(BaseModel):
    target_customer_id: str = Field("CUST50186", description="The customer the attacker wants to learn about")
    epsilon: float = Field(0.5, gt=0, le=10)
    trials: int = Field(200, ge=10, le=2000)


@router.post("/dp/differencing-attack")
def differencing_attack(req: AttackRequest):
    """
    Attacker knows the target's branch, age and that they hold a personal loan. They ask:
      Q1 = how many personal-loan customers in <branch> missed an EMI?
      Q2 = same, but excluding customers of the target's age
    Q1 - Q2 reveals whether the target missed an EMI. DP noise breaks this.
    (Does not spend the session budget - it is a simulation.)
    """
    df = customer_accounts()
    tgt = df[df["customer_id"] == req.target_customer_id]
    if tgt.empty:
        raise HTTPException(404, "customer not found")
    t = tgt.iloc[0]
    q1 = df[(df["branch"] == t["branch"]) & (df["has_personal_loan"] == t["has_personal_loan"])]
    q2 = q1[q1["age"] != t["age"]]
    exact_diff = int(q1["missed_emi_last_12m"].sum() - q2["missed_emi_last_12m"].sum())
    truth = int(exact_diff > 0)

    rng = np.random.default_rng(11)
    correct = 0
    for _ in range(req.trials):
        a1 = q1["missed_emi_last_12m"].sum() + rng.laplace(0, 1 / req.epsilon)
        a2 = q2["missed_emi_last_12m"].sum() + rng.laplace(0, 1 / req.epsilon)
        guess = int((a1 - a2) >= 0.5)
        correct += guess == truth
    same_age = int(len(q1) - len(q2))
    return {
        "target": {"customer_id": t["customer_id"], "branch": t["branch"], "age": int(t["age"])},
        "customers_matching_target_profile": same_age,
        "without_dp": {"q1_minus_q2": exact_diff,
                       "attacker_learns": (f"{t['customer_id']} missed an EMI" if same_age == 1 and exact_diff
                                           else f"{exact_diff} of {same_age} matching customer(s) missed an EMI"),
                       "attack_success_rate": 1.0},
        "with_dp": {"epsilon_per_query": req.epsilon, "trials": req.trials,
                    "attack_success_rate": round(correct / req.trials, 3),
                    "interpretation": "Close to 0.5 means the attacker is guessing; higher epsilon leaks more."},
    }

"""
S015 - Zero-shot, One-shot, Few-shot prompting
Task: triage NovaTrust customer complaints into CATEGORY + PRIORITY, returned as JSON.
The priority convention (money at risk = HIGH, access problems = MEDIUM, information = LOW) is never
stated in words - only the examples show it. That is what one-/few-shot add.
"""
from __future__ import annotations

import json
import re
from typing import Literal

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.core import llm

router = APIRouter(prefix="/s015", tags=["S015 Zero/One/Few-shot"])

LABELS = ["CARD_FRAUD", "ATM_CASH_ISSUE", "UPI_FAILURE", "LOAN_EMI", "KYC_UPDATE", "NETBANKING_ACCESS"]

EXAMPLES = [  # the few-shot pool - never part of the test set
    {"text": "There are two transactions on my credit card from a website I have never used.",
     "label": {"category": "CARD_FRAUD", "priority": "HIGH"}},
    {"text": "I can't log in to net banking, it says my user ID is locked.",
     "label": {"category": "NETBANKING_ACCESS", "priority": "MEDIUM"}},
    {"text": "What documents do I need to update my address for KYC?",
     "label": {"category": "KYC_UPDATE", "priority": "LOW"}},
    {"text": "Paid my electricity bill on UPI, money gone from my account but the biller shows unpaid.",
     "label": {"category": "UPI_FAILURE", "priority": "HIGH"}},
]

TEST_SET = [
    ("Someone used my debit card in another city while the card is with me.", "CARD_FRAUD", "HIGH"),
    ("I got an SMS for a Rs 25,000 purchase I didn't make.", "CARD_FRAUD", "HIGH"),
    ("ATM at the mall gave me only Rs 2000 out of Rs 5000 but deducted the full amount.", "ATM_CASH_ISSUE", "HIGH"),
    ("Cash withdrawal failed but my account was debited.", "ATM_CASH_ISSUE", "HIGH"),
    ("Where is the nearest ATM that accepts deposits?", "ATM_CASH_ISSUE", "LOW"),
    ("Sent money to my friend via UPI, it shows pending since yesterday and amount is debited.", "UPI_FAILURE", "HIGH"),
    ("My UPI PIN reset is not working.", "UPI_FAILURE", "MEDIUM"),
    ("Why is my EMI higher this month than last month?", "LOAN_EMI", "LOW"),
    ("My loan EMI was debited twice this month.", "LOAN_EMI", "HIGH"),
    ("Can I prepay my personal loan, and is there a charge?", "LOAN_EMI", "LOW"),
    ("My account is frozen saying KYC expired.", "KYC_UPDATE", "MEDIUM"),
    ("How do I do video KYC?", "KYC_UPDATE", "LOW"),
    ("Net banking OTP is not coming to my new phone number.", "NETBANKING_ACCESS", "MEDIUM"),
    ("I forgot my net banking password.", "NETBANKING_ACCESS", "MEDIUM"),
    ("Mobile app keeps logging me out before I can see my statement.", "NETBANKING_ACCESS", "MEDIUM"),
    ("Got a call from 'bank staff' asking for my card CVV, I gave it and now see a charge.", "CARD_FRAUD", "HIGH"),
]

INSTRUCTION = (f"Classify the NovaTrust customer complaint.\nCategories: {', '.join(LABELS)}.\n"
               "Priorities: HIGH, MEDIUM, LOW.\n"
               'Respond with ONLY JSON: {"category": "...", "priority": "..."}')


def build_prompt(complaint: str, mode: str) -> str:
    shots = {"zero": [], "one": EXAMPLES[:1], "few": EXAMPLES}[mode]
    parts = [INSTRUCTION]
    for ex in shots:
        parts.append(f"Complaint: {ex['text']}\nAnswer: {json.dumps(ex['label'])}")
    parts.append(f"Complaint: {complaint}\nAnswer:")
    return "\n\n".join(parts)


KEYWORDS = [  # used only by the mock model
    ("CARD_FRAUD", ["didn't make", "never used", "cvv", "card in another city", "purchase i"]),
    ("ATM_CASH_ISSUE", ["atm", "cash withdrawal", "withdrawal failed"]),
    ("UPI_FAILURE", ["upi"]),
    ("LOAN_EMI", ["emi", "loan"]),
    ("KYC_UPDATE", ["kyc"]),
    ("NETBANKING_ACCESS", ["net banking", "password", "log", "otp", "app"]),
]


def _mock(_s: str, prompt: str) -> str:
    text = prompt.rsplit("Complaint:", 1)[-1].lower()
    cat = next((c for c, kws in KEYWORDS if any(k in text for k in kws)), "NETBANKING_ACCESS")
    money = any(w in text for w in ["debited", "deducted", "charge", "purchase", "twice", "didn't make", "rs "])
    prio = "HIGH" if money else ("LOW" if text.strip().startswith(("how", "where", "can", "why", "what")) else "MEDIUM")
    return json.dumps({"category": cat, "priority": prio})


def parse(raw: str) -> dict:
    m = re.search(r"\{.*?\}", raw, re.S)
    try:
        d = json.loads(m.group(0)) if m else {}
    except json.JSONDecodeError:
        d = {}
    cat = str(d.get("category", "")).upper()
    pr = str(d.get("priority", "")).upper()
    return {"category": cat if cat in LABELS else None, "priority": pr if pr in {"HIGH", "MEDIUM", "LOW"} else None,
            "valid_json": bool(d), "exact_format": raw.strip().startswith("{") and raw.strip().endswith("}")}


class ClassifyRequest(BaseModel):
    complaint: str = Field(..., examples=["Rs 3,000 was debited twice for one UPI payment to a shop."])
    mode: Literal["zero", "one", "few"] = "few"


@router.get("/dataset")
def dataset():
    return {"labels": LABELS, "few_shot_examples": EXAMPLES,
            "test_set": [{"text": t, "category": c, "priority": p} for t, c, p in TEST_SET]}


@router.post("/classify")
def classify(req: ClassifyRequest):
    prompt = build_prompt(req.complaint, req.mode)
    res = llm.complete("You are a precise complaint-triage classifier.", prompt, mock=_mock, max_tokens=60)
    return {"mode": req.mode, "prompt": prompt, "raw_output": res["text"], "parsed": parse(res["text"]),
            "provider": res["provider"]}


class EvalRequest(BaseModel):
    modes: list[Literal["zero", "one", "few"]] = ["zero", "one", "few"]


@router.post("/evaluate")
def evaluate(req: EvalRequest):
    results = {}
    for mode in req.modes:
        cat_ok = pri_ok = fmt_ok = 0
        errors = []
        for text, cat, pri in TEST_SET:
            res = llm.complete("You are a precise complaint-triage classifier.", build_prompt(text, mode),
                               mock=_mock, max_tokens=60)
            p = parse(res["text"])
            cat_ok += p["category"] == cat
            pri_ok += p["priority"] == pri
            fmt_ok += p["exact_format"]
            if p["category"] != cat or p["priority"] != pri:
                errors.append({"complaint": text, "expected": [cat, pri], "got": [p["category"], p["priority"]]})
        n = len(TEST_SET)
        results[mode] = {"category_accuracy": round(cat_ok / n, 3), "priority_accuracy": round(pri_ok / n, 3),
                         "format_compliance": round(fmt_ok / n, 3), "errors": errors,
                         "prompt_examples_used": {"zero": 0, "one": 1, "few": len(EXAMPLES)}[mode]}
    return {"test_cases": len(TEST_SET), "results": results}

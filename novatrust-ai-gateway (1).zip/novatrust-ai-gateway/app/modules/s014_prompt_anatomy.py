"""
S014 - Prompt Anatomy & Context Types

Anatomy (six parts):  ROLE | INSTRUCTION | CONTEXT | INPUT DATA | OUTPUT FORMAT | CONSTRAINTS  (+ optional EXAMPLES)
Context types (five): system context, conversation history, retrieved knowledge (RAG),
                      customer profile (personalisation), environment (channel, date, locale)
"""
from __future__ import annotations

from datetime import date
from typing import Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.core import llm, pii
from app.data.knowledge_base import KB, retrieve

router = APIRouter(prefix="/s014", tags=["S014 Prompt Anatomy & Context"])


class Turn(BaseModel):
    role: str = Field(..., pattern="^(user|assistant)$")
    content: str


class ContextBlock(BaseModel):
    conversation_history: list[Turn] = Field(default_factory=lambda: [
        Turn(role="user", content="Hi, I withdrew cash yesterday at an ATM in Andheri."),
        Turn(role="assistant", content="Sure, how can I help with that withdrawal?")])
    customer_profile: dict = Field(default_factory=lambda: {
        "customer_id": "CUST50186", "segment": "Salaried", "preferred_language": "English",
        "products": ["Savings", "Debit card"], "vulnerable_customer_flag": False})
    use_retrieval: bool = True
    environment: dict = Field(default_factory=lambda: {"channel": "mobile_app_chat", "locale": "en-IN"})


class BuildRequest(BaseModel):
    role: str = "You are Nova, a polite and precise customer-service assistant for NovaTrust Bank, India."
    instruction: str = "Resolve the customer's issue using only the policy context. Tell them exactly what happens next."
    context: ContextBlock = ContextBlock()
    input_data: str = "Rs 10,000 was debited but the ATM gave no cash. What happens now?"
    output_format: str = ("Reply in 3 parts: (1) one-line empathy, (2) numbered next steps with timelines, "
                          "(3) one line on compensation if any. Max 90 words.")
    constraints: list[str] = Field(default_factory=lambda: [
        "Never ask for OTP, PIN, CVV or full card number.",
        "Do not invent timelines or amounts that are not in the policy context.",
        "If the policy context does not answer the question, offer to connect to an agent."])
    examples: Optional[list[dict]] = None
    run: bool = True


def assemble(req: BuildRequest) -> dict:
    ctx = req.context
    docs = retrieve(req.input_data + " " + " ".join(t.content for t in ctx.conversation_history), k=2) \
        if ctx.use_retrieval else []
    profile = pii.transform(str(ctx.customer_profile), "pseudonymize")["text"]  # minimise PII sent to the model
    env = dict(ctx.environment, today=date.today().isoformat())

    sections = {
        "ROLE": req.role,
        "INSTRUCTION": req.instruction,
        "CONTEXT.retrieved_knowledge": "\n".join(f"[{d['id']}] {d['text']}" for d in docs) or "(none)",
        "CONTEXT.customer_profile": profile,
        "CONTEXT.environment": str(env),
        "CONSTRAINTS": "\n".join(f"- {c}" for c in req.constraints),
        "OUTPUT_FORMAT": req.output_format,
    }
    if req.examples:
        sections["EXAMPLES"] = "\n\n".join(f"Input: {e['input']}\nOutput: {e['output']}" for e in req.examples)

    system = "\n\n".join(f"### {k}\n{v}" for k, v in sections.items() if k != "INSTRUCTION")
    user = f"### INSTRUCTION\n{req.instruction}\n\n### INPUT DATA\n{req.input_data}"
    history = [t.model_dump() for t in ctx.conversation_history]
    return {"sections": sections, "system_prompt": system, "history": history, "user_prompt": user,
            "retrieved_doc_ids": [d["id"] for d in docs],
            "approx_tokens": (len(system) + len(user) + sum(len(t["content"]) for t in history)) // 4}


def _mock(system: str, user: str) -> str:
    if "KB-ATM-01" in system:
        return ("[MOCK] I'm sorry for the trouble with your withdrawal.\n1. The Rs 10,000 will be auto-reversed to "
                "your account within 5 calendar days.\n2. If it isn't, raise a complaint in the app with the ATM ID, "
                "date, time and amount.\nIf the reversal is late, NovaTrust pays Rs 100 for each day of delay.")
    return "[MOCK] Generic answer: please contact NovaTrust customer care."


@router.get("/knowledge-base")
def knowledge_base():
    return {"documents": KB}


@router.post("/build")
def build(req: BuildRequest):
    """Assemble a prompt from its named parts, show it, and (optionally) run it."""
    p = assemble(req)
    if req.run:
        res = llm.complete(p["system_prompt"], p["user_prompt"], history=p["history"], mock=_mock)
        p["response"], p["provider"] = res["text"], res["provider"]
    return p


class CompareRequest(BaseModel):
    question: str = Field("Rs 10,000 was debited but the ATM gave no cash. What happens now?")


@router.post("/compare")
def compare(req: CompareRequest):
    """Same question: a bare prompt vs a fully structured prompt."""
    bare = llm.complete("You are a helpful assistant.", req.question,
                        mock=lambda s, u: "[MOCK] Contact your bank; they will usually refund it in a few days.")
    structured_req = BuildRequest(input_data=req.question)
    p = assemble(structured_req)
    full = llm.complete(p["system_prompt"], p["user_prompt"], history=p["history"], mock=_mock)
    return {"bare_prompt": {"system": "You are a helpful assistant.", "user": req.question, "response": bare["text"]},
            "structured_prompt": {"sections": p["sections"], "response": full["text"]},
            "what_to_look_for": ["Specific timelines from policy (T+5) vs vague 'a few days'",
                                 "Compensation rule mentioned only when retrieved context is present",
                                 "Format and length obey OUTPUT_FORMAT",
                                 "Conversation history lets the model know which transaction is meant"]}

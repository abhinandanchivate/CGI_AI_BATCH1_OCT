"""
S011 - Bias Mitigation: balanced datasets, fairness metrics, post-processing.

Use case: NovaTrust's personal-loan pre-approval model was trained on 10 years of
historical underwriter decisions ('approved_hist') that under-approved women and
rural applicants. We measure the bias and fix it three ways:

  pre-processing  : balanced_resample, reweighing, drop_protected ("fairness through unawareness")
  in-processing   : (out of scope for the lab; see doc)
  post-processing : threshold_optimizer (a separate decision threshold per group, applied on top of
                    a model trained without the protected columns)

Fairness is evaluated against 'repaid' (the true outcome), which a synthetic dataset
lets us know for every applicant.
"""
from __future__ import annotations

from typing import Literal, Optional

import numpy as np
import pandas as pd
from fastapi import APIRouter
from pydantic import BaseModel, Field
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from app.core import audit
from app.data.synthetic import loan_applications

router = APIRouter(prefix="/s011", tags=["S011 Bias Mitigation"])

NUMERIC = ["annual_income_lakh", "credit_score", "employment_years", "loan_amount_lakh", "existing_emi_ratio",
           "career_break_years", "pincode_tier"]
REFERENCE_GROUP = {"gender": "male", "area": "urban"}     # privileged group
PROTECTED_GROUP = {"gender": "female", "area": "rural"}   # unprivileged group
GO_LIVE = {"disparate_impact_min": 0.80, "demographic_parity_diff_max": 0.10, "max_accuracy_drop_pp": 3.0}

Attribute = Literal["gender", "area"]
Method = Literal["none", "drop_protected", "balanced_resample", "reweighing", "threshold_optimizer"]


# ---------------------------------------------------------------- helpers
def _split():
    df = loan_applications()
    train, test = train_test_split(df, test_size=0.3, random_state=7, stratify=df["gender"])
    train, valid = train_test_split(train, test_size=0.25, random_state=7, stratify=train["gender"])
    return train.copy(), valid.copy(), test.copy()


def _features(df: pd.DataFrame, include_protected: bool) -> pd.DataFrame:
    X = df[NUMERIC].copy()
    if include_protected:
        X["is_female"] = (df["gender"] == "female").astype(int)
        X["is_rural"] = (df["area"] == "rural").astype(int)
    return X


def _model():
    return make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))


def fairness_report(df: pd.DataFrame, pred: np.ndarray, attribute: str) -> dict:
    """All metrics a Risk Committee asks for, per group and as gaps."""
    ref, prot = REFERENCE_GROUP[attribute], PROTECTED_GROUP[attribute]
    y = df["repaid"].to_numpy()
    out = {"groups": {}}
    for g in [ref, prot]:
        m = (df[attribute] == g).to_numpy()
        yg, pg = y[m], pred[m]
        out["groups"][g] = {
            "n": int(m.sum()),
            "approval_rate": round(float(pg.mean()), 3),
            "true_positive_rate": round(float(pg[yg == 1].mean()), 3),   # good borrowers approved
            "false_positive_rate": round(float(pg[yg == 0].mean()), 3),  # bad borrowers approved
            "accuracy": round(float((pg == yg).mean()), 3),
        }
    r, p = out["groups"][ref], out["groups"][prot]
    di = p["approval_rate"] / r["approval_rate"] if r["approval_rate"] else 0.0
    out["metrics"] = {
        "accuracy_overall": round(float((pred == y).mean()), 3),
        "approval_rate_overall": round(float(pred.mean()), 3),
        "demographic_parity_diff": round(r["approval_rate"] - p["approval_rate"], 3),
        "disparate_impact_ratio": round(di, 3),
        "equal_opportunity_diff": round(r["true_positive_rate"] - p["true_positive_rate"], 3),
        "equalized_odds_diff": round(max(abs(r["true_positive_rate"] - p["true_positive_rate"]),
                                         abs(r["false_positive_rate"] - p["false_positive_rate"])), 3),
    }
    return out


def _pass_fail(metrics: dict, baseline_acc: Optional[float] = None) -> dict:
    checks = {
        "disparate_impact >= 0.80": metrics["disparate_impact_ratio"] >= GO_LIVE["disparate_impact_min"],
        "demographic_parity_diff <= 0.10": abs(metrics["demographic_parity_diff"]) <= GO_LIVE["demographic_parity_diff_max"],
    }
    if baseline_acc is not None:
        drop = (baseline_acc - metrics["accuracy_overall"]) * 100
        checks["accuracy_drop <= 3pp"] = drop <= GO_LIVE["max_accuracy_drop_pp"]
    checks["ready_for_go_live"] = all(checks.values())
    return checks


def _reweigh(df: pd.DataFrame, attribute: str) -> np.ndarray:
    """Kamiran & Calders reweighing: w(g, y) = P(g) * P(y) / P(g, y)."""
    y = df["approved_hist"]
    w = np.ones(len(df))
    for g in df[attribute].unique():
        for lab in [0, 1]:
            m = ((df[attribute] == g) & (y == lab)).to_numpy()
            if m.sum():
                w[m] = (df[attribute] == g).mean() * (y == lab).mean() / m.mean()
    return w


def _balanced_resample(df: pd.DataFrame, attribute: str) -> pd.DataFrame:
    """Every group gets the same size AND the same approval rate (the overall rate)."""
    rng = np.random.default_rng(0)
    target_n = df[attribute].value_counts().max()
    pos_rate = df["approved_hist"].mean()
    parts = []
    for g in df[attribute].unique():
        for lab, share in [(1, pos_rate), (0, 1 - pos_rate)]:
            cell = df[(df[attribute] == g) & (df["approved_hist"] == lab)]
            k = int(round(target_n * share))
            idx = rng.choice(len(cell), size=k, replace=len(cell) < k)
            parts.append(cell.iloc[idx])
    return pd.concat(parts)


def _group_thresholds(df, proba, attribute, target: str) -> dict:
    """Post-processing: pick a threshold per group on the validation set."""
    overall = (proba >= 0.5)
    y = df["repaid"].to_numpy()
    goal = overall.mean() if target == "demographic_parity" else overall[y == 1].mean()
    thresholds = {}
    for g in df[attribute].unique():
        m = (df[attribute] == g).to_numpy()
        best, best_gap = 0.5, 9.0
        for t in np.arange(0.05, 0.95, 0.005):
            pg = proba[m] >= t
            val = pg.mean() if target == "demographic_parity" else pg[y[m] == 1].mean()
            if abs(val - goal) < best_gap:
                best, best_gap = float(t), abs(val - goal)
        thresholds[g] = round(best, 3)
    return thresholds


def run_method(attribute: str, method: str, fairness_target: str = "demographic_parity") -> dict:
    train, valid, test = _split()
    # threshold_optimizer post-processes a model trained WITHOUT the protected columns
    include = method not in {"drop_protected", "threshold_optimizer"}
    model, weights, thresholds = _model(), None, None

    if method == "balanced_resample":
        train = _balanced_resample(train, attribute)
    if method == "reweighing":
        weights = _reweigh(train, attribute)

    fit_kw = {"logisticregression__sample_weight": weights} if weights is not None else {}
    model.fit(_features(train, include), train["approved_hist"], **fit_kw)

    proba_test = model.predict_proba(_features(test, include))[:, 1]
    if method == "threshold_optimizer":
        proba_valid = model.predict_proba(_features(valid, include))[:, 1]
        thresholds = _group_thresholds(valid, proba_valid, attribute, fairness_target)
        cut = test[attribute].map(thresholds).to_numpy()
        pred = (proba_test >= cut).astype(int)
    else:
        pred = (proba_test >= 0.5).astype(int)

    report = fairness_report(test, pred, attribute)
    report.update({"method": method, "attribute": attribute, "train_rows": int(len(train)),
                   "test_rows": int(len(test)), "thresholds": thresholds or {"all_groups": 0.5}})
    return report


# ---------------------------------------------------------------- schemas
class TrainRequest(BaseModel):
    protected_attribute: Attribute = Field("gender", description="Which attribute to audit")


class MitigateRequest(BaseModel):
    protected_attribute: Attribute = "gender"
    method: Method = "reweighing"
    fairness_target: Literal["demographic_parity", "equal_opportunity"] = Field(
        "demographic_parity", description="Only used by threshold_optimizer")


class Applicant(BaseModel):
    gender: Literal["male", "female"] = "female"
    area: Literal["urban", "rural"] = "rural"
    annual_income_lakh: float = 8.5
    credit_score: int = 745
    employment_years: float = 6
    loan_amount_lakh: float = 5
    existing_emi_ratio: float = 0.2
    career_break_years: float = 1.5
    pincode_tier: int = 3


class ScoreRequest(BaseModel):
    applicant: Applicant = Applicant()
    method: Method = "none"
    protected_attribute: Attribute = "gender"


# ---------------------------------------------------------------- endpoints
@router.get("/dataset/summary")
def dataset_summary():
    """Step 1: inspect the historical data for imbalance and label bias."""
    df = loan_applications()
    def by(col):
        g = df.groupby(col).agg(applications=("applicant_id", "count"),
                                historical_approval_rate=("approved_hist", "mean"),
                                true_repayment_rate=("repaid", "mean")).round(3)
        g["share_of_data"] = (g["applications"] / len(df)).round(3)
        return g.reset_index().to_dict(orient="records")
    return {"rows": len(df), "columns": list(df.columns), "by_gender": by("gender"), "by_area": by("area"),
            "observation": "Repayment is almost identical across groups, yet historical approval rates differ "
                           "sharply: the labels carry human bias. Women are also only ~30% of the data."}


@router.post("/train")
def train_baseline(req: TrainRequest):
    """Step 2: train the pilot model exactly as it was built and audit it."""
    rep = run_method(req.protected_attribute, "none")
    rep["go_live_checks"] = _pass_fail(rep["metrics"])
    audit.record("s011", "baseline_audit", {"attribute": req.protected_attribute, **rep["metrics"]})
    return rep


@router.post("/mitigate")
def mitigate(req: MitigateRequest):
    """Step 3: apply one mitigation and compare with the baseline."""
    base = run_method(req.protected_attribute, "none")
    after = run_method(req.protected_attribute, req.method, req.fairness_target)
    delta = {k: round(after["metrics"][k] - base["metrics"][k], 3) for k in base["metrics"]}
    checks = _pass_fail(after["metrics"], base["metrics"]["accuracy_overall"])
    audit.record("s011", "mitigation", {"method": req.method, "ready": checks["ready_for_go_live"]})
    return {"method": req.method, "attribute": req.protected_attribute, "before": base["metrics"],
            "after": after["metrics"], "delta": delta, "groups_after": after["groups"],
            "thresholds": after["thresholds"], "go_live_checks": checks}


@router.post("/compare")
def compare_all(req: TrainRequest):
    """Step 4: leaderboard of every method for the chosen attribute."""
    base_acc = None
    rows = []
    for m in ["none", "drop_protected", "balanced_resample", "reweighing", "threshold_optimizer"]:
        r = run_method(req.protected_attribute, m)
        if m == "none":
            base_acc = r["metrics"]["accuracy_overall"]
        rows.append({"method": m, **r["metrics"],
                     "ready_for_go_live": _pass_fail(r["metrics"], base_acc)["ready_for_go_live"]})
    return {"attribute": req.protected_attribute, "results": rows}


@router.post("/score-applicant")
def score_applicant(req: ScoreRequest):
    """Step 5: score one applicant, then flip only the protected attribute (counterfactual test)."""
    train, valid, _ = _split()
    include = req.method not in {"drop_protected", "threshold_optimizer"}
    model, kw = _model(), {}
    if req.method == "balanced_resample":
        train = _balanced_resample(train, req.protected_attribute)
    if req.method == "reweighing":
        kw = {"logisticregression__sample_weight": _reweigh(train, req.protected_attribute)}
    model.fit(_features(train, include), train["approved_hist"], **kw)
    thresholds = None
    if req.method == "threshold_optimizer":
        pv = model.predict_proba(_features(valid, include))[:, 1]
        thresholds = _group_thresholds(valid, pv, req.protected_attribute, "demographic_parity")

    def decide(app: dict):
        p = float(model.predict_proba(_features(pd.DataFrame([app]), include))[:, 1][0])
        t = thresholds[app[req.protected_attribute]] if thresholds else 0.5
        return {"approval_probability": round(p, 3), "threshold": t,
                "decision": "APPROVE" if p >= t else "REFER_TO_UNDERWRITER"}

    a = req.applicant.model_dump()
    flipped = dict(a)
    attr = req.protected_attribute
    flipped[attr] = REFERENCE_GROUP[attr] if a[attr] == PROTECTED_GROUP[attr] else PROTECTED_GROUP[attr]
    d1, d2 = decide(a), decide(flipped)
    return {"method": req.method, "applicant": a, "result": d1,
            "counterfactual": {"changed": {attr: flipped[attr]}, "result": d2},
            "counterfactual_consistent": d1["decision"] == d2["decision"]}

"""In-memory audit log of every guardrail decision (would be a SIEM / DB in production)."""
from datetime import datetime, timezone

_LOG: list[dict] = []


def record(module: str, event: str, detail: dict | None = None) -> None:
    _LOG.append({
        "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "module": module,
        "event": event,
        "detail": detail or {},
    })
    del _LOG[:-500]  # keep the last 500 events


def entries(limit: int = 50) -> list[dict]:
    return _LOG[-limit:][::-1]


def clear() -> None:
    _LOG.clear()

"""
Rule-based PII detector for Indian banking identifiers.

Production note: pair these regexes with an NER model (e.g. Microsoft Presidio +
spaCy) for names and addresses. Regex alone is shown here so the logic is visible.
"""
from __future__ import annotations

import hashlib
import re

# Order matters: more specific patterns first so they win overlaps.
PATTERNS: list[tuple[str, re.Pattern]] = [
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b")),
    ("PAN", re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b")),
    ("IFSC", re.compile(r"\b[A-Z]{4}0[A-Z0-9]{6}\b")),
    ("CARD", re.compile(r"\b(?:\d{4}[ -]?){3}\d{4}\b")),
    ("AADHAAR", re.compile(r"\b[2-9]\d{3}[ -]?\d{4}[ -]?\d{4}\b")),
    ("PHONE", re.compile(r"(?:\+91[ -]?)?\b[6-9]\d{9}\b")),
    ("UPI_ID", re.compile(r"\b[\w.-]+@(?:ok\w+|ybl|paytm|upi|ibl|axl)\b")),
    ("ACCOUNT_NO", re.compile(r"\b\d{9,18}\b")),
    ("PERSON", re.compile(r"\b(?:Mr|Mrs|Ms|Dr|Shri|Smt)\.?\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?")),
    ("PERSON", re.compile(r"(?i:my name is|name:)\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)")),
]


def detect(text: str) -> list[dict]:
    """Return non-overlapping PII spans, earliest pattern wins on overlap."""
    taken: list[tuple[int, int]] = []
    found = []
    for label, pat in PATTERNS:
        for m in pat.finditer(text):
            # for "my name is X" capture only the name group
            s, e = (m.start(1), m.end(1)) if m.lastindex else (m.start(), m.end())
            if any(s < te and e > ts for ts, te in taken):
                continue
            taken.append((s, e))
            found.append({"type": label, "start": s, "end": e, "value": text[s:e]})
    return sorted(found, key=lambda d: d["start"])


def _mask_value(kind: str, v: str) -> str:
    digits = re.sub(r"\D", "", v)
    if kind in {"CARD", "ACCOUNT_NO", "AADHAAR", "PHONE"} and len(digits) >= 4:
        return "X" * (len(digits) - 4) + digits[-4:]
    if kind == "PAN":
        return "XXXXX" + v[5:9] + "X"
    if kind == "EMAIL":
        user, _, dom = v.partition("@")
        return user[0] + "***@" + dom
    return f"<{kind}>"


def transform(text: str, mode: str = "pseudonymize", salt: str = "novatrust-demo") -> dict:
    """
    mode = redact       -> [PAN]            irreversible, no utility
           mask         -> XXXXX1234X        partial view for agents
           pseudonymize -> <PAN_1>           consistent token + vault for re-identification
           hash         -> PAN_3f9a1c        deterministic one-way token (joins across datasets)
    """
    spans = detect(text)
    vault, counters, out, cursor = {}, {}, [], 0
    reverse = {}
    for sp in spans:
        out.append(text[cursor:sp["start"]])
        v, k = sp["value"], sp["type"]
        if mode == "redact":
            rep = f"[{k}]"
        elif mode == "mask":
            rep = _mask_value(k, v)
        elif mode == "hash":
            rep = f"{k}_" + hashlib.sha256((salt + v).encode()).hexdigest()[:6]
        else:
            if v in reverse:
                rep = reverse[v]
            else:
                counters[k] = counters.get(k, 0) + 1
                rep = f"<{k}_{counters[k]}>"
                reverse[v] = rep
                vault[rep] = v
        out.append(rep)
        cursor = sp["end"]
    out.append(text[cursor:])
    return {"text": "".join(out), "entities": [{"type": s["type"], "value": s["value"]} for s in spans],
            "vault": vault if mode == "pseudonymize" else None}


def reidentify(text: str, vault: dict) -> str:
    for token, value in vault.items():
        text = text.replace(token, value)
    return text

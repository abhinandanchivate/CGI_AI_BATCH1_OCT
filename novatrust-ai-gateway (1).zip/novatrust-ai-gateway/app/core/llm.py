"""
One function, `complete()`, hides which LLM provider is used.

Providers
---------
anthropic : Claude via the Anthropic SDK (ANTHROPIC_API_KEY)
openai    : OpenAI chat completions (OPENAI_API_KEY)
mock      : no network call. Each caller passes a `mock` function that returns a
            canned, clearly labelled answer so the lab runs without any API key.
"""
from __future__ import annotations

from typing import Callable, Optional

from app.core import config


class LLMResult(dict):
    """dict with keys: text, provider, model"""


def complete(
    system: str,
    user: str,
    *,
    history: Optional[list[dict]] = None,
    temperature: float = 0.0,
    max_tokens: int = 800,
    mock: Optional[Callable[[str, str], str]] = None,
) -> LLMResult:
    messages = list(history or []) + [{"role": "user", "content": user}]
    provider = config.LLM_PROVIDER

    if provider == "anthropic":
        import anthropic

        client = anthropic.Anthropic()
        resp = client.messages.create(
            model=config.ANTHROPIC_MODEL,
            system=system,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
        return LLMResult(text=text, provider="anthropic", model=config.ANTHROPIC_MODEL)

    if provider == "openai":
        from openai import OpenAI

        client = OpenAI()
        resp = client.chat.completions.create(
            model=config.OPENAI_MODEL,
            messages=[{"role": "system", "content": system}] + messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return LLMResult(text=resp.choices[0].message.content or "", provider="openai",
                         model=config.OPENAI_MODEL)

    # ---- mock ----
    text = mock(system, user) if mock else "[MOCK] No mock response defined for this call."
    return LLMResult(text=text, provider="mock", model="mock-v1")

# NovaTrust Responsible AI Gateway

One banking demo for sessions **S011–S016**: bias mitigation, security, guardrails and prompt engineering.
All data is synthetic. Every LLM call also works in **mock mode** (no API key).

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                     # add ANTHROPIC_API_KEY or OPENAI_API_KEY, or leave blank for mock
uvicorn app.main:app --reload --port 8000
```

Open http://127.0.0.1:8000/docs and follow the lab guide, or run the scripted walkthrough:

```bash
python scripts/demo_runner.py                 # all sessions
python scripts/demo_runner.py --session S013 --pause
pytest -q                                     # smoke tests (mock mode)
```

## Layout

```
app/
  main.py                     FastAPI app, platform endpoints (/health, /audit/log)
  core/
    config.py                 env settings, provider auto-detect, canary secret
    llm.py                    one complete() for anthropic | openai | mock
    assistant.py              "Nova" chatbot pipeline with defense levels none|basic|full
    injection.py              L1 input screen, L2 spotlighting, L3 output check
    moderation.py             rules / LLM judge / OpenAI moderation
    pii.py                    Indian banking PII detection + redact/mask/pseudonymize/hash
    audit.py                  in-memory audit log
  data/
    synthetic.py              loan applications (biased labels + proxies), customer accounts
    knowledge_base.py         policy snippets + keyword retrieval (mini RAG)
  modules/
    s011_bias.py              fairness metrics, reweighing, resampling, threshold optimizer
    s012_security.py          chat with injection defense, anonymization, differential privacy
    s013_guardrails.py        moderation, Constitutional AI loop, red-team suite, RLHF preference capture
    s014_prompt_anatomy.py    prompt builder from named parts + context types
    s015_shots.py             zero / one / few-shot complaint triage + evaluation
    s016_cot.py               loan eligibility: direct vs CoT vs self-consistency, rule-engine ground truth
scripts/demo_runner.py        guided walkthrough against a running server
tests/test_endpoints.py       smoke tests
```

## Provider settings (.env)

| Variable | Meaning |
|---|---|
| `LLM_PROVIDER` | `anthropic`, `openai` or `mock`; blank = auto-detect from keys |
| `ANTHROPIC_MODEL` / `OPENAI_MODEL` | Any current model id your key can use |
| `DP_TOTAL_BUDGET` | Total epsilon an analyst session may spend (default 5.0) |

Mock mode is for running the lab offline. It returns clearly labelled `[MOCK]` answers; the S012/S013
mock deliberately behaves like a *naive* model so attacks are visible. Use a real provider for the
S014–S016 quality comparisons.

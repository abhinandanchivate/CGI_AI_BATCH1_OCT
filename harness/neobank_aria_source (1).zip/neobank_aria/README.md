# NeoBank Aria — Agent Harness Teaching Demo (S059–S066)

Aria is an in-app AI assistant for **Kosh Bank**, a fictional Indian neobank. The project is a small,
readable agent harness that shows how sessions S059–S066 work on one banking agent.

| Session | Concept | Where in code | Demo |
|---|---|---|---|
| S059 | Context compaction & summarisation | `aria/harness/memory.py` | `--scenario compaction` |
| S060 | What an agent harness is | `aria/harness/harness.py` (+ tools, guardrails, tracing) | `--scenario harness` |
| S061 | Custom harness vs framework | `langgraph_version/graph_agent.py` | `python langgraph_version/graph_agent.py` |
| S062 | Sandboxing & permission boundaries | `aria/harness/sandbox.py`, `guardrails.py` | `--scenario sandbox` |
| S063 | Agent loop: Perceive → Plan → Act → Observe | `aria/agent/react_loop.py` | `--scenario react` |
| S064 | ReAct vs Plan-and-Execute | `aria/agent/plan_execute.py` | `--scenario compare` |
| S065 | Termination & infinite-loop prevention | `aria/agent/termination.py` | `--scenario loops` |
| S066 | Human-in-the-loop checkpoints | `aria/harness/hitl.py` | `--scenario hitl [--interactive]` |

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt                          # google-genai, python-dotenv, langgraph, pytest
cp .env.example .env                                     # then paste your GEMINI_API_KEY into .env
python main.py --scenario all                            # uses Gemini because the key is set
pytest -q                                                # 29 tests, no network needed
```

### Choosing the model

| Flag | Model | When to use |
|---|---|---|
| *(none)* | Gemini if `GEMINI_API_KEY` is set, otherwise the offline mock | Default |
| `--llm gemini` | Google Gemini via `google-genai` (model from `GEMINI_MODEL`, default `gemini-3.6-flash`) | Live class, realistic behaviour |
| `--llm mock` | Deterministic rule-based stand-in | Reproducing the exact output in the manuals; no internet |

Gemini is called with native function calling and **automatic function calling disabled**, so Gemini only
proposes a tool call and `Harness.execute()` decides whether it runs. Scripted misbehaviour (loop traps,
attacks) stays scripted with either model so the safety layers always fire.

## Layout

```
aria/
  bank/core_banking.py     mock core banking (accounts, cards, UPI, disputes)
  banking_tools.py         the 13 tools Aria can call
  harness/                 tools · sandbox · guardrails · memory · hitl · tracing · harness
  agent/                   llm · react_loop · plan_execute · termination
langgraph_version/         same agent on LangGraph
tests/test_aria.py         one test group per session + a Gemini adapter test
main.py                    scenario runner
runs/                      audit logs + HITL checkpoints (created at runtime)
```

All people, accounts and figures are fictional.

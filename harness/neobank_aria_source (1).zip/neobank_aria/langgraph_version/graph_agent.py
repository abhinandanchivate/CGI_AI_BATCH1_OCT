"""
S061 - The same Aria agent built on a framework (LangGraph) instead of our custom loop.

What the framework gives you for free:
  * the loop itself as an explicit graph (agent -> human_review? -> tools -> agent)
  * durable state via a checkpointer (InMemorySaver here; Postgres/Redis in prod)
  * `interrupt()` to pause for a human and `Command(resume=...)` to continue,
    even from a different process hours later
  * recursion_limit as a built-in hard stop

What you STILL write yourself: tools, permission boundaries, guardrails,
approval policy, compaction, domain logic. We reuse ours from `aria/`.

Run:  pip install -r requirements.txt   then   python langgraph_version/graph_agent.py\n(uses Gemini when GEMINI_API_KEY is set, otherwise the offline mock)
"""
from __future__ import annotations

import operator
import sys
from pathlib import Path
from typing import Annotated, TypedDict

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os  # noqa: E402

try:
    from dotenv import load_dotenv  # noqa: E402
    load_dotenv()
except ImportError:
    pass

from langgraph.checkpoint.memory import InMemorySaver  # noqa: E402
from langgraph.graph import END, START, StateGraph  # noqa: E402
from langgraph.types import Command, interrupt  # noqa: E402

from aria.agent import FinalAnswer, GeminiLLM, MockBankingLLM  # noqa: E402
from aria.bank import CoreBanking  # noqa: E402
from aria.banking_tools import build_registry  # noqa: E402
from aria.harness import ApprovalPolicy, ConversationMemory, Harness, Observation, SessionContext  # noqa: E402
from aria.harness.memory import Message  # noqa: E402
from aria.harness.sandbox import ROLE_ALLOWLIST  # noqa: E402

SYSTEM = "You are Aria, Kosh Bank's in-app assistant."
MAX_STEPS = 8


class NullApprovalPolicy:
    """HITL moves out of the harness and into the graph (interrupt node)."""
    def evaluate(self, *a, **k):
        return None

    def note_success(self, *a, **k):
        pass


class AgentState(TypedDict):
    messages: Annotated[list[dict], operator.add]   # reducer: append
    proposed: dict | None
    steps: int
    final: str


def build_graph():
    bank = CoreBanking()
    ctx = SessionContext("CUST-1001", "ACC-55501", "CARD-4411")
    tools = build_registry()
    harness = Harness(bank=bank, ctx=ctx, tools=tools, memory=ConversationMemory(SYSTEM),
                      approval_policy=NullApprovalPolicy())
    harness.tracer.verbose = False
    policy = ApprovalPolicy()
    use_gemini = bool(os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))
    llm = GeminiLLM() if use_gemini else MockBankingLLM()
    print(f"LLM: {'Google Gemini' if use_gemini else 'offline mock'}")
    visible = [t for t in tools.all() if t.name in ROLE_ALLOWLIST[ctx.role]]

    def agent(state: AgentState):
        context = [Message("system", SYSTEM)] + [Message(**m) for m in state["messages"]]
        d = llm.decide(context, visible)
        if isinstance(d, FinalAnswer):
            print(f"  [agent  ] FINAL: {d.text}")
            return {"final": d.text, "proposed": None, "messages": [{"role": "assistant", "content": d.text}]}
        print(f"  [agent  ] propose {d.name}({d.args})")
        return {"proposed": {"name": d.name, "args": d.args}, "steps": state["steps"] + 1,
                "messages": [{"role": "assistant", "content": f"Action: {d.name}({d.args})"}]}

    def route_after_agent(state: AgentState):
        if state["final"]:
            return END
        if state["steps"] > MAX_STEPS:                       # termination condition
            return "give_up"
        p = state["proposed"]
        tool = tools.get(p["name"])
        if tool and policy.evaluate(tool, p["args"], bank, ctx):
            return "human_review"
        return "tools"

    def human_review(state: AgentState):
        p = state["proposed"]
        req = policy.evaluate(tools.get(p["name"]), p["args"], bank, ctx)
        decision = interrupt({"tool": p["name"], "args": p["args"], "reasons": req.reasons,
                              "approver": req.approver_role})          # <-- graph pauses here
        if decision["decision"] == "approve":
            return {}
        if decision["decision"] == "edit":
            return {"proposed": {"name": p["name"], "args": decision["args"], "edited": True}}
        obs = Observation("rejected", error=f"Human reviewer rejected the action: {decision.get('note', '')}")
        return {"proposed": None, "messages": [{"role": "tool", "name": p["name"], "content": obs.to_json()}]}

    def route_after_review(state: AgentState):
        return "tools" if state["proposed"] else "agent"

    def run_tools(state: AgentState):
        p = state["proposed"]
        obs = harness.execute(p["name"], p["args"])        # permissions + sanitiser still apply
        if obs.ok and p.get("edited"):
            obs.edited_args = p["args"]                     # tell the model a human changed the args
        if obs.ok:
            policy.note_success(p["name"], p["args"])
        print(f"  [tools  ] {p['name']} -> {obs.status}")
        return {"proposed": None, "messages": [{"role": "tool", "name": p["name"], "content": obs.to_json()}]}

    def give_up(state: AgentState):
        msg = "I couldn't finish this automatically; a specialist will follow up."
        return {"final": msg, "messages": [{"role": "assistant", "content": msg}]}

    g = StateGraph(AgentState)
    g.add_node("agent", agent)
    g.add_node("human_review", human_review)
    g.add_node("tools", run_tools)
    g.add_node("give_up", give_up)
    g.add_edge(START, "agent")
    g.add_conditional_edges("agent", route_after_agent, ["human_review", "tools", "give_up", END])
    g.add_conditional_edges("human_review", route_after_review, ["tools", "agent"])
    g.add_edge("tools", "agent")
    g.add_edge("give_up", END)
    return g.compile(checkpointer=InMemorySaver()), bank


def main():
    graph, bank = build_graph()
    config = {"configurable": {"thread_id": "priya-session-1"}, "recursion_limit": 25}
    ask = "Please send 75,000 to Rahul rahul.verma@okaxis for the bike."
    print(f"customer: {ask}")
    result = graph.invoke({"messages": [{"role": "user", "content": ask}], "proposed": None, "steps": 0, "final": ""},
                          config)
    scripted = [{"decision": "approve", "note": "OTP ok"},
                {"decision": "edit", "args": {"vpa": "rahul.verma@okaxis", "amount": 50000.0, "note": "Transfer to Rahul"}}]
    while "__interrupt__" in result:
        payload = result["__interrupt__"][0].value
        answer = scripted.pop(0) if scripted else {"decision": "reject", "note": "no more scripted answers"}
        print(f"  [HITL   ] paused for {payload['approver']}: {payload['tool']} {payload['reasons']} -> {answer['decision']}")
        result = graph.invoke(Command(resume=answer), config)     # resume from checkpoint
    print(f"\nbalance now Rs {bank.db['accounts']['ACC-55501']['balance']:,.2f}")
    print(f"checkpoints stored for thread: {len(list(graph.get_state_history(config)))}")


if __name__ == "__main__":
    main()

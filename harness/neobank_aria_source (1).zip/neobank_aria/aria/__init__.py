"""NeoBank Aria - a teaching harness for LLM agents in retail banking (S059-S066)."""

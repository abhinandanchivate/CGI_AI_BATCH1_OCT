"""
S060 - What is an Agent Harness?

The harness is everything around the model that turns "a model that writes
text" into "an agent that can safely act":

    +--------------------------- HARNESS ----------------------------+
    |  Tools (registry + schemas)      Memory (context + compaction)  |
    |  Guardrails (in / tool-out / out) Sandbox (permissions, limits) |
    |  HITL (approval policy + approver + checkpoints)                |
    |  Execution environment (bank APIs, session identity)            |
    |  Tracing / audit                                                |
    +-----------------------------------------------------------------+
                         ^ proposes action      | observation
                         |                      v
                              LLM  (inside the loop)

`Harness.execute()` is the single choke point every proposed action goes
through: validate -> permission check -> human checkpoint -> run ->
sanitise output -> record. The model can PROPOSE anything; only the harness
can make it happen.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Callable

from .guardrails import sanitize_tool_output
from .hitl import ApprovalPolicy, Approver, AutoApprover, CheckpointStore, Decision
from .memory import ConversationMemory
from .sandbox import ROLE_ALLOWLIST, PermissionDenied, PermissionPolicy, SandboxViolation, SessionContext
from .tools import ToolRegistry
from .tracing import Tracer


@dataclass
class Observation:
    status: str                 # ok | error | denied | rejected | invalid
    data: object = None
    error: str = ""
    flags: list[str] = field(default_factory=list)
    edited_args: dict | None = None

    @property
    def ok(self) -> bool:
        return self.status == "ok"

    def to_json(self) -> str:
        d = {"status": self.status}
        if self.data is not None:
            d["data"] = self.data
        if self.error:
            d["error"] = self.error
        if self.edited_args:
            d["human_edited_args"] = self.edited_args
        return json.dumps(d, default=str)


@dataclass
class Harness:
    bank: object
    ctx: SessionContext
    tools: ToolRegistry
    memory: ConversationMemory
    permissions: PermissionPolicy = field(default_factory=PermissionPolicy)
    approval_policy: ApprovalPolicy = field(default_factory=ApprovalPolicy)
    approver: Approver = field(default_factory=AutoApprover)
    checkpoints: CheckpointStore | None = None
    tracer: Tracer = field(default_factory=Tracer)
    state_provider: Callable[[], dict] | None = None   # loop gives us its state for checkpoints
    sanitize_outputs: bool = True                      # set False only to demo defence-in-depth

    def execute(self, name: str, args: dict) -> Observation:
        tool = self.tools.get(name)
        if tool is None:
            self.tracer.log("DENY", f"unknown tool '{name}' (hallucinated?)")
            visible = [n for n in self.tools.names() if n in ROLE_ALLOWLIST.get(self.ctx.role, set())]
            return Observation("invalid", error=f"Unknown tool '{name}'. Available: {visible}")

        # 1. schema validation
        errs = tool.validate(args)
        if errs:
            self.tracer.log("DENY", f"invalid args for {name}: {errs}")
            return Observation("invalid", error="; ".join(errs))

        # 2. permission boundary (sandbox layers 1-3)
        try:
            self.permissions.check(tool, args, self.ctx, self.bank)
        except PermissionDenied as e:
            self.tracer.log("DENY", f"{name} blocked by permission boundary: {e}")
            return Observation("denied", error=str(e))

        # 3. human-in-the-loop checkpoint
        req = self.approval_policy.evaluate(tool, args, self.bank, self.ctx)
        edited = None
        if req:
            self.tracer.log("HITL", f"PAUSE {req.id} -> {req.approver_role}: {name}({args}) because {req.reasons}")
            if self.checkpoints is not None:
                state = self.state_provider() if self.state_provider else {}
                path = self.checkpoints.save(req, state)
                self.tracer.log("HITL", f"state checkpointed to {path}")
            resp = self.approver.review(req)
            if self.checkpoints is not None:
                self.checkpoints.resolve(req.id, resp)
            self.tracer.log("HITL", f"RESUME {req.id}: {resp.decision.value.upper()} ({resp.note})")
            if resp.decision == Decision.REJECT:
                return Observation("rejected", error=f"Human reviewer rejected the action: {resp.note}")
            if resp.decision == Decision.EDIT and resp.args:
                edited = resp.args
                args = resp.args
                errs = tool.validate(args)
                if errs:
                    return Observation("invalid", error="; ".join(errs))
                try:  # edited args must pass the boundary too
                    self.permissions.check(tool, args, self.ctx, self.bank)
                except PermissionDenied as e:
                    return Observation("denied", error=str(e))

        # 4. execute inside the environment
        try:
            raw = tool.fn(self.bank, self.ctx, **args)
        except SandboxViolation as e:
            self.tracer.log("DENY", f"code sandbox blocked {name}: {e}")
            return Observation("denied", error=f"Sandbox: {e}")
        except (KeyError, ValueError) as e:
            self.tracer.log("OBSERVE", f"{name} failed: {e}")
            return Observation("error", error=str(e))

        # 5. treat tool output as untrusted
        clean, flags = sanitize_tool_output(raw) if self.sanitize_outputs else (raw, [])
        if flags:
            self.tracer.log("GUARD", f"tool output sanitised: {sorted(set(flags))}")

        # 6. bookkeeping
        self.permissions.record_success(tool, args)
        self.approval_policy.note_success(name, args)
        return Observation("ok", data=clean, flags=flags, edited_args=edited)

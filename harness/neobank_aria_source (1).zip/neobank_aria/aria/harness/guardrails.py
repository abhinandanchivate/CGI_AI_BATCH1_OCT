"""
S060 - Guardrails: checks on what goes INTO and comes OUT OF the model.

* Input guardrail  - masks PII the customer types (card numbers, Aadhaar, PAN)
                     and flags direct prompt-injection attempts.
* Tool-output guardrail - treats data returned by tools as UNTRUSTED. Text
                     inside a transaction memo can contain an indirect prompt
                     injection; we neutralise it before the model reads it.
* Output guardrail - blocks replies that leak full card numbers or give
                     prohibited financial advice.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

INJECTION_PATTERNS = [
    r"ignore (all )?(previous|prior|above) instructions",
    r"you are now (in )?(admin|developer|dan) mode",
    r"system prompt",
    r"disregard (your|the) (rules|guardrails|policy)",
    r"transfer .* (immediately|now) to",
]
_inj = re.compile("|".join(INJECTION_PATTERNS), re.IGNORECASE)

PII_PATTERNS = {
    "CARD": re.compile(r"\b(?:\d[ -]?){15}\d\b"),
    "AADHAAR": re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b"),
    "PAN": re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b"),
}

ADVICE_PATTERNS = re.compile(r"guaranteed returns|you should (buy|invest in)|sure-shot|risk[- ]free profit", re.I)


@dataclass
class GuardrailResult:
    text: str
    flags: list[str]
    blocked: bool = False


def mask_pii(text: str) -> tuple[str, list[str]]:
    flags = []
    for label, pat in PII_PATTERNS.items():
        if pat.search(text):
            flags.append(f"pii:{label}")
            text = pat.sub(f"[{label}_REDACTED]", text)
    return text, flags


def check_input(text: str) -> GuardrailResult:
    text, flags = mask_pii(text)
    if _inj.search(text):
        flags.append("prompt_injection:direct")
        return GuardrailResult(text, flags, blocked=True)
    return GuardrailResult(text, flags)


def sanitize_tool_output(obj):
    """Recursively neutralise injected instructions in tool results.

    Returns (clean_obj, flags). Strings that look like instructions are
    replaced, so the model sees that something was removed but never sees
    the instruction itself.
    """
    flags: list[str] = []

    def _walk(o):
        if isinstance(o, str):
            if _inj.search(o):
                flags.append("prompt_injection:indirect")
                return "[REMOVED: untrusted instruction-like text in data]"
            masked, f = mask_pii(o)
            flags.extend(f)
            return masked
        if isinstance(o, dict):
            return {k: _walk(v) for k, v in o.items()}
        if isinstance(o, list):
            return [_walk(v) for v in o]
        return o

    return _walk(obj), flags


def check_output(text: str) -> GuardrailResult:
    flags = []
    masked, f = mask_pii(text)
    if f:
        flags.extend(f)
    if ADVICE_PATTERNS.search(masked):
        flags.append("prohibited_financial_advice")
        return GuardrailResult(
            "I can help with your Kosh account, but I can't give investment advice. "
            "Please speak to a SEBI-registered advisor.", flags, blocked=True)
    return GuardrailResult(masked, flags)

"""Audit trail + pretty console tracing. Every loop event is recorded (regulators ask for this)."""
from __future__ import annotations

import json
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

COLORS = {"PERCEIVE": "36", "PLAN": "35", "ACT": "33", "OBSERVE": "32", "GUARD": "31", "HITL": "34",
          "COMPACT": "90", "STOP": "31", "FINAL": "1;32", "PLANNER": "35", "INFO": "37", "DENY": "31"}


def _use_color() -> bool:
    return sys.stdout.isatty()


@dataclass
class Tracer:
    scenario: str = "run"
    verbose: bool = True
    events: list[dict] = field(default_factory=list)
    llm_calls: int = 0
    t0: float = field(default_factory=time.time)

    def log(self, kind: str, msg: str, **data) -> None:
        ev = {"t": round(time.time() - self.t0, 3), "kind": kind, "msg": msg, **data}
        self.events.append(ev)
        if self.verbose:
            tag = f"[{kind:<8}]"
            if _use_color():
                tag = f"\033[{COLORS.get(kind, '37')}m{tag}\033[0m"
            print(f"  {tag} {msg}")

    def save(self, folder: str = "runs") -> Path:
        Path(folder).mkdir(exist_ok=True)
        p = Path(folder) / f"audit_{self.scenario}.jsonl"
        with p.open("w") as f:
            for e in self.events:
                f.write(json.dumps(e, default=str) + "\n")
        return p

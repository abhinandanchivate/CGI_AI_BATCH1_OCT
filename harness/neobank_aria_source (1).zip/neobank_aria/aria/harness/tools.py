"""
S060 - Tools: the harness's hands.

A Tool bundles four things the harness needs to call it safely:
  * a JSON-schema-like parameter spec (so arguments can be validated
    BEFORE anything runs),
  * a risk level (drives sandbox + human-in-the-loop decisions),
  * a scope (which resources it may touch),
  * the implementation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Callable


class Risk(IntEnum):
    READ = 0          # balance, transactions - no side effects
    WRITE_LOW = 1     # budget alert, freeze card (protective, reversible)
    WRITE_HIGH = 2    # move money, add payee, unfreeze card, disputes


_PY_TYPES = {"string": str, "number": (int, float), "integer": int, "boolean": bool}


@dataclass
class Tool:
    name: str
    description: str
    params: dict[str, dict]            # {"amount": {"type": "number", "required": True}}
    risk: Risk
    fn: Callable[..., Any]
    tags: set[str] = field(default_factory=set)

    def validate(self, args: dict) -> list[str]:
        """Return a list of validation errors (empty == valid)."""
        errors = []
        for pname, spec in self.params.items():
            if spec.get("required") and pname not in args:
                errors.append(f"missing required parameter '{pname}'")
        for k, v in args.items():
            if k not in self.params:
                errors.append(f"unknown parameter '{k}'")
                continue
            expected = _PY_TYPES[self.params[k]["type"]]
            if isinstance(v, bool) and self.params[k]["type"] != "boolean":
                errors.append(f"'{k}' must be {self.params[k]['type']}")
            elif not isinstance(v, expected):
                errors.append(f"'{k}' must be {self.params[k]['type']}, got {type(v).__name__}")
            if "enum" in self.params[k] and v not in self.params[k]["enum"]:
                errors.append(f"'{k}' must be one of {self.params[k]['enum']}")
        return errors

    def to_llm_schema(self) -> dict:
        """Schema in the shape most LLM tool-use APIs expect."""
        props, required = {}, []
        for pname, spec in self.params.items():
            p = {"type": spec["type"], "description": spec.get("description", "")}
            if "enum" in spec:
                p["enum"] = spec["enum"]
            props[pname] = p
            if spec.get("required"):
                required.append(pname)
        return {"name": self.name, "description": self.description,
                "input_schema": {"type": "object", "properties": props, "required": required}}


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def all(self) -> list[Tool]:
        return list(self._tools.values())

    def names(self) -> list[str]:
        return list(self._tools)

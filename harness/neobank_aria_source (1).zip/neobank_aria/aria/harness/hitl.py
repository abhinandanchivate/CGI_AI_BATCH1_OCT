"""
S066 - Human-in-the-Loop Checkpoints inside the loop.

The loop pauses BEFORE a risky action executes, persists its state as a
checkpoint, and asks a human (the customer for step-up confirmation, or an
ops analyst for high-value / suspicious actions). The human can:

    APPROVE  - run the action as proposed
    EDIT     - run it with changed arguments (e.g. lower the amount)
    REJECT   - do not run; the rejection reason is fed back to the agent as
               an observation so it can respond sensibly

No answer within the timeout counts as REJECT ("fail closed").
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Callable, Protocol

from .tools import Risk, Tool


class Decision(str, Enum):
    APPROVE = "approve"
    EDIT = "edit"
    REJECT = "reject"


@dataclass
class ApprovalRequest:
    tool: str
    args: dict
    reasons: list[str]
    approver_role: str               # "customer" (step-up) or "ops_analyst"
    id: str = field(default_factory=lambda: f"CHK-{uuid.uuid4().hex[:6].upper()}")
    created_at: float = field(default_factory=time.time)


@dataclass
class ApprovalResponse:
    decision: Decision
    args: dict | None = None
    note: str = ""


# ---------------------------------------------------------------------------
# Policy: WHEN to interrupt
# ---------------------------------------------------------------------------
@dataclass
class ApprovalPolicy:
    high_value_threshold: float = 50_000.0
    dispute_threshold: float = 10_000.0
    payees_added_this_session: set[str] = field(default_factory=set)

    def evaluate(self, tool: Tool, args: dict, bank, ctx) -> ApprovalRequest | None:
        reasons, role = [], "customer"
        if tool.name == "transfer_money":
            amt = float(args.get("amount", 0))
            if amt > self.high_value_threshold:
                reasons.append(f"high-value transfer Rs {amt:,.0f} > Rs {self.high_value_threshold:,.0f}")
                role = "ops_analyst"
            if args.get("vpa") in self.payees_added_this_session:
                reasons.append("payee added in this session (cooling-period rule)")
        if tool.name == "add_payee":
            reasons.append("new beneficiary requires customer step-up confirmation")
        if tool.name == "unfreeze_card":
            reasons.append("unfreezing a card re-enables spending")
        if tool.name == "raise_dispute":
            txn = next((t for t in bank.db["transactions"][ctx.account] if t["id"] == args.get("txn_id")), None)
            if txn and abs(txn["amount"]) >= self.dispute_threshold:
                reasons.append(f"dispute on Rs {abs(txn['amount']):,.0f} needs analyst review")
                role = "ops_analyst"
        if tool.risk == Risk.WRITE_HIGH and not reasons:
            reasons.append("high-risk action")
        return ApprovalRequest(tool.name, args, reasons, role) if reasons else None

    def note_success(self, tool_name: str, args: dict) -> None:
        if tool_name == "add_payee":
            self.payees_added_this_session.add(args["vpa"])


# ---------------------------------------------------------------------------
# Approvers: WHO answers
# ---------------------------------------------------------------------------
class Approver(Protocol):
    def review(self, req: ApprovalRequest) -> ApprovalResponse: ...


class ConsoleApprover:
    """Interactive approver for live demos."""

    def __init__(self, timeout_s: float = 120.0):
        self.timeout_s = timeout_s

    def review(self, req: ApprovalRequest) -> ApprovalResponse:
        print(f"\n  +--- HUMAN CHECKPOINT {req.id} ({req.approver_role}) ---")
        print(f"  | action : {req.tool}({json.dumps(req.args)})")
        for r in req.reasons:
            print(f"  | reason : {r}")
        ans = input("  | [a]pprove / [e]dit / [r]eject ? ").strip().lower()
        if ans.startswith("a"):
            return ApprovalResponse(Decision.APPROVE, note="approved at console")
        if ans.startswith("e"):
            new = dict(req.args)
            for k, v in req.args.items():
                nv = input(f"  |   {k} [{v}]: ").strip()
                if nv:
                    new[k] = type(v)(nv) if not isinstance(v, bool) else nv.lower() == "true"
            return ApprovalResponse(Decision.EDIT, new, "edited at console")
        note = input("  | reason for rejection: ").strip() or "rejected at console"
        return ApprovalResponse(Decision.REJECT, note=note)


class ScriptedApprover:
    """Deterministic approver for tests/classroom runs: answers from a queue."""

    def __init__(self, responses: list[ApprovalResponse]):
        self.responses = list(responses)
        self.seen: list[ApprovalRequest] = []

    def review(self, req: ApprovalRequest) -> ApprovalResponse:
        self.seen.append(req)
        if not self.responses:
            return ApprovalResponse(Decision.REJECT, note="no response before timeout (fail closed)")
        return self.responses.pop(0)


class AutoApprover:
    def __init__(self, decision: Decision = Decision.APPROVE):
        self.decision = decision
        self.seen: list[ApprovalRequest] = []

    def review(self, req: ApprovalRequest) -> ApprovalResponse:
        self.seen.append(req)
        return ApprovalResponse(self.decision, note=f"auto-{self.decision.value}")


# ---------------------------------------------------------------------------
# Durable checkpoints: pause the loop, survive a restart, resume later
# ---------------------------------------------------------------------------
class CheckpointStore:
    def __init__(self, folder: str | Path = "runs/checkpoints"):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)

    def save(self, req: ApprovalRequest, agent_state: dict) -> Path:
        path = self.folder / f"{req.id}.json"
        path.write_text(json.dumps({"request": req.__dict__, "state": agent_state}, indent=2, default=str))
        return path

    def load(self, chk_id: str) -> dict:
        return json.loads((self.folder / f"{chk_id}.json").read_text())

    def resolve(self, chk_id: str, response: ApprovalResponse) -> None:
        path = self.folder / f"{chk_id}.json"
        data = json.loads(path.read_text())
        data["response"] = {"decision": response.decision.value, "args": response.args, "note": response.note}
        path.write_text(json.dumps(data, indent=2, default=str))

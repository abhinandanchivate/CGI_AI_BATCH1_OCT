"""
S062 - Sandboxing & Permission Boundaries.

Four layers, each independent (defence in depth):

1. Tool allowlist per role      - a chat agent simply cannot see admin tools.
2. Resource scoping             - every account/card argument must belong to
                                  the authenticated customer (stops the
                                  "confused deputy" problem).
3. Limits                       - per-transaction cap, daily cap, write-rate cap.
4. Code execution sandbox       - LLM-written analytics code runs in a separate
                                  process, after an AST allowlist check, with a
                                  timeout and no imports / file / network access.

The LLM never decides whether it is allowed to do something. The harness does.
"""
from __future__ import annotations

import ast
import json
import subprocess
import sys
from dataclasses import dataclass, field

from .tools import Risk, Tool


class PermissionDenied(Exception):
    pass


@dataclass
class SessionContext:
    """Identity of the authenticated user. Set by the app's auth layer, NOT by the LLM."""
    customer_id: str
    account: str
    card: str
    role: str = "customer_chat"
    channel: str = "mobile_app"


ROLE_ALLOWLIST: dict[str, set[str]] = {
    # Customer-facing chat agent: no admin / bulk / cross-customer tools.
    "customer_chat": {
        "get_balance", "list_transactions", "get_transaction_status", "list_payees",
        "get_card", "add_payee", "transfer_money", "freeze_card", "unfreeze_card",
        "raise_dispute", "set_budget_alert", "run_analytics",
    },
    # Read-only role used e.g. for a "spend insights" widget.
    "insights_readonly": {"get_balance", "list_transactions", "run_analytics"},
}


@dataclass
class PermissionPolicy:
    per_txn_cap: float = 100_000.0          # hard ceiling even WITH human approval
    max_writes_per_session: int = 5
    writes_done: int = 0
    transferred_today: float = 0.0
    daily_cap: float = 200_000.0
    audit: list[dict] = field(default_factory=list)

    def check(self, tool: Tool, args: dict, ctx: SessionContext, bank) -> None:
        # Layer 1: allowlist
        allowed = ROLE_ALLOWLIST.get(ctx.role, set())
        if tool.name not in allowed:
            raise PermissionDenied(f"Tool '{tool.name}' is not permitted for role '{ctx.role}'")

        # Layer 2: resource scoping (confused-deputy protection)
        if "account" in args and args["account"] != ctx.account:
            owner = bank.db["accounts"].get(args["account"], {}).get("owner", "unknown")
            raise PermissionDenied(
                f"Account {args['account']} belongs to {owner}, not the session customer {ctx.customer_id}")
        if "card" in args and args["card"] != ctx.card:
            raise PermissionDenied(f"Card {args['card']} does not belong to session customer")

        # Layer 3: limits
        if tool.risk >= Risk.WRITE_LOW:
            if self.writes_done >= self.max_writes_per_session:
                raise PermissionDenied("Write-rate limit reached for this session")
        if tool.name == "transfer_money":
            amt = float(args.get("amount", 0))
            if amt > self.per_txn_cap:
                raise PermissionDenied(f"Amount Rs {amt:,.0f} exceeds hard per-transaction cap Rs {self.per_txn_cap:,.0f}")
            if self.transferred_today + amt > self.daily_cap:
                raise PermissionDenied("Daily transfer cap would be exceeded")

    def record_success(self, tool: Tool, args: dict) -> None:
        if tool.risk >= Risk.WRITE_LOW:
            self.writes_done += 1
        if tool.name == "transfer_money":
            self.transferred_today += float(args["amount"])


# ---------------------------------------------------------------------------
# Layer 4: code execution sandbox
# ---------------------------------------------------------------------------
SAFE_BUILTINS = ["sum", "len", "min", "max", "round", "sorted", "abs", "dict", "list",
                 "set", "str", "float", "int", "enumerate", "range", "any", "all", "zip"]

_BANNED_NODES = (ast.Import, ast.ImportFrom, ast.Global, ast.Nonlocal, ast.With,
                 ast.AsyncWith, ast.AsyncFunctionDef, ast.ClassDef, ast.Try, ast.Lambda, ast.While)
_BANNED_NAMES = {"open", "exec", "eval", "compile", "__import__", "globals", "locals",
                 "getattr", "setattr", "delattr", "vars", "input", "breakpoint", "help", "exit", "quit"}


class SandboxViolation(Exception):
    pass


def static_check(code: str) -> None:
    """AST allowlist: reject anything that is not plain data-crunching."""
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        raise SandboxViolation(f"syntax error: {e}") from e
    for node in ast.walk(tree):
        if isinstance(node, _BANNED_NODES):
            raise SandboxViolation(f"'{type(node).__name__}' is not allowed in analytics code")
        if isinstance(node, ast.Name) and node.id in _BANNED_NAMES:
            raise SandboxViolation(f"use of '{node.id}' is not allowed")
        if isinstance(node, ast.Attribute) and node.attr.startswith("_"):
            raise SandboxViolation("access to private/dunder attributes is not allowed")
    if "result" not in code:
        raise SandboxViolation("code must assign its answer to a variable named 'result'")


_RUNNER = r"""
import json, sys
data = json.loads(sys.stdin.read())
safe = {k: __builtins__[k] if isinstance(__builtins__, dict) else getattr(__builtins__, k) for k in data["builtins"]}
env = {"__builtins__": safe, "txns": data["txns"]}
exec(data["code"], env)
print(json.dumps({"result": env.get("result")}, default=str))
"""


def run_sandboxed(code: str, txns: list[dict], timeout_s: float = 3.0) -> object:
    """Execute LLM-written analytics code in an isolated child process."""
    static_check(code)
    payload = json.dumps({"code": code, "txns": txns, "builtins": SAFE_BUILTINS})
    try:
        proc = subprocess.run([sys.executable, "-I", "-c", _RUNNER], input=payload,
                              capture_output=True, text=True, timeout=timeout_s)
    except subprocess.TimeoutExpired as e:
        raise SandboxViolation(f"analytics code exceeded {timeout_s}s timeout") from e
    if proc.returncode != 0:
        last = proc.stderr.strip().splitlines()[-1] if proc.stderr.strip() else "unknown error"
        raise SandboxViolation(f"analytics code failed: {last}")
    return json.loads(proc.stdout)["result"]

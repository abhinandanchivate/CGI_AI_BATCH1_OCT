"""
S059 - Context Compaction & Summarization Strategies   (+ S060 memory)

The model only sees a fixed-size context window. A banking conversation
grows quickly: every `list_transactions` call can dump hundreds of rows.
The harness, not the model, decides what stays in context.

Strategies implemented (each is a pluggable class):

  TruncationStrategy      keep system prompt + last N messages. Cheap, lossy.
  ToolOutputCompaction    replace bulky OLD tool results with a one-line digest.
  SummarizationStrategy   fold the oldest turns into a running summary
                          (by LLM if one is supplied, else an extractive
                          summariser that keeps amounts, IDs and decisions).
  HybridStrategy          tool-output compaction -> summarisation -> truncation,
                          stopping as soon as the context fits the budget.

"Pinned facts" (customer id, open disputes, pending approvals) survive every
strategy - they live outside the message list and are re-injected each turn.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Callable, Protocol


def estimate_tokens(text: str) -> int:
    """~4 characters per token - good enough for budgeting in a demo."""
    return max(1, len(text) // 4)


@dataclass
class Message:
    role: str            # system | user | assistant | tool | summary
    content: str
    name: str = ""       # tool name for role == tool
    compacted: bool = False

    @property
    def tokens(self) -> int:
        return estimate_tokens(self.content)

    def to_dict(self) -> dict:
        return self.__dict__.copy()


@dataclass
class ConversationMemory:
    system_prompt: str
    token_budget: int = 2_000
    messages: list[Message] = field(default_factory=list)
    pinned_facts: dict[str, str] = field(default_factory=dict)   # long-lived, never compacted
    compaction_log: list[dict] = field(default_factory=list)

    # ---- basic ops ----
    def add(self, role: str, content: str, name: str = "") -> None:
        self.messages.append(Message(role, content, name))

    def pin(self, key: str, value: str) -> None:
        self.pinned_facts[key] = value

    def render_system(self) -> str:
        if not self.pinned_facts:
            return self.system_prompt
        facts = "\n".join(f"- {k}: {v}" for k, v in self.pinned_facts.items())
        return f"{self.system_prompt}\n\nPINNED FACTS (always true for this session):\n{facts}"

    def total_tokens(self) -> int:
        return estimate_tokens(self.render_system()) + sum(m.tokens for m in self.messages)

    def over_budget(self) -> bool:
        return self.total_tokens() > self.token_budget

    def context(self) -> list[Message]:
        return [Message("system", self.render_system())] + self.messages

    def maybe_compact(self, strategy: "CompactionStrategy") -> bool:
        if not self.over_budget():
            return False
        before = self.total_tokens()
        strategy.compact(self)
        after = self.total_tokens()
        if after >= before:          # strategy had nothing it could remove
            return False
        self.compaction_log.append({"strategy": type(strategy).__name__, "before": before, "after": after})
        return True

    # ---- persistence (used by HITL checkpoints) ----
    def to_dict(self) -> dict:
        return {"system_prompt": self.system_prompt, "token_budget": self.token_budget,
                "messages": [m.to_dict() for m in self.messages], "pinned_facts": self.pinned_facts}

    @classmethod
    def from_dict(cls, d: dict) -> "ConversationMemory":
        m = cls(d["system_prompt"], d["token_budget"], pinned_facts=d["pinned_facts"])
        m.messages = [Message(**x) for x in d["messages"]]
        return m


class CompactionStrategy(Protocol):
    def compact(self, mem: ConversationMemory) -> None: ...


# ---------------------------------------------------------------------------
class TruncationStrategy:
    """Sliding window: drop the oldest messages, keep the last `keep_last`."""

    def __init__(self, keep_last: int = 6):
        self.keep_last = keep_last

    def compact(self, mem: ConversationMemory) -> None:
        dropped = len(mem.messages) - self.keep_last
        if dropped > 0:
            mem.messages = mem.messages[-self.keep_last:]


# ---------------------------------------------------------------------------
def digest_tool_output(name: str, content: str) -> str:
    """One-line digest of a tool result, keeping the facts a banker needs."""
    try:
        data = json.loads(content)
    except (json.JSONDecodeError, TypeError):
        return f"[compacted {name} output: {content[:80]}...]"
    if isinstance(data, dict) and "status" in data:          # harness Observation envelope
        if data["status"] != "ok":
            return f"[compacted {name}: {data['status']} - {str(data.get('error', ''))[:80]}]"
        data = data.get("data")
    if isinstance(data, list) and data and isinstance(data[0], dict) and "amount" in data[0]:
        total = sum(t["amount"] for t in data)
        ids = [t["id"] for t in data]
        pending = [t["id"] for t in data if t.get("status") == "PENDING"]
        return (f"[compacted {name}: {len(data)} txns, net Rs {total:,.2f}, "
                f"ids {ids[0]}..{ids[-1]}, pending={pending or 'none'}]")
    s = json.dumps(data)
    return f"[compacted {name}: {s[:120]}{'...' if len(s) > 120 else ''}]"


class ToolOutputCompaction:
    """Replace tool outputs older than the last `keep_recent` tool messages with digests."""

    def __init__(self, keep_recent: int = 1, min_tokens: int = 60):
        self.keep_recent = keep_recent
        self.min_tokens = min_tokens

    def compact(self, mem: ConversationMemory) -> None:
        tool_idx = [i for i, m in enumerate(mem.messages) if m.role == "tool"]
        for i in tool_idx[:-self.keep_recent] if self.keep_recent else tool_idx:
            m = mem.messages[i]
            if not m.compacted and m.tokens >= self.min_tokens:
                mem.messages[i] = Message("tool", digest_tool_output(m.name, m.content), m.name, compacted=True)


# ---------------------------------------------------------------------------
_FACT_RE = re.compile(r"(Rs ?[\d,]+(?:\.\d+)?|TXN-\d+|DSP-\d+|PAY-\d+|CARD-\d+|approved|rejected|blocked|frozen|refund)",
                      re.IGNORECASE)


def extractive_summary(msgs: list[Message]) -> str:
    """No-LLM summariser: keep user asks + any sentence carrying a 'fact'."""
    lines = []
    for m in msgs:
        if m.role == "user":
            lines.append(f"Customer asked: {m.content[:100]}")
        elif m.role in ("assistant", "summary"):
            facts = sorted(set(_FACT_RE.findall(m.content)))
            if facts:
                lines.append(f"Aria noted: {', '.join(facts[:8])}")
        elif m.role == "tool":
            lines.append(digest_tool_output(m.name, m.content) if not m.compacted else m.content)
    return " | ".join(lines)


class SummarizationStrategy:
    """Fold everything except the last `keep_last` messages into one summary message."""

    def __init__(self, keep_last: int = 4, summarizer: Callable[[list[Message]], str] | None = None):
        self.keep_last = keep_last
        self.summarizer = summarizer or extractive_summary

    def compact(self, mem: ConversationMemory) -> None:
        if len(mem.messages) <= self.keep_last:
            return
        old, recent = mem.messages[:-self.keep_last], mem.messages[-self.keep_last:]
        summary = self.summarizer(old)
        mem.messages = [Message("summary", f"SUMMARY OF EARLIER CONVERSATION: {summary}", compacted=True)] + recent


# ---------------------------------------------------------------------------
class HybridStrategy:
    """Cheapest-first: digest tool outputs, then summarise, then truncate as last resort."""

    def __init__(self, summarizer=None):
        self.steps = [ToolOutputCompaction(keep_recent=1), SummarizationStrategy(keep_last=4, summarizer=summarizer),
                      TruncationStrategy(keep_last=3)]

    def compact(self, mem: ConversationMemory) -> None:
        for step in self.steps:
            if not mem.over_budget():
                return
            step.compact(mem)


STRATEGIES = {
    "truncate": TruncationStrategy,
    "tool_digest": ToolOutputCompaction,
    "summarize": SummarizationStrategy,
    "hybrid": HybridStrategy,
}

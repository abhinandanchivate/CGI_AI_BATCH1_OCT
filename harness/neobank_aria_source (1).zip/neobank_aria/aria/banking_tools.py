"""The Kosh Bank tool belt exposed to Aria. Each fn receives (bank, ctx, **args)."""
from __future__ import annotations

from .harness.sandbox import run_sandboxed
from .harness.tools import Risk, Tool, ToolRegistry


def _acct(ctx, account=None):
    return account or ctx.account


def _get_balance(bank, ctx, account=None):
    return bank.get_balance(_acct(ctx, account))


def _list_txns(bank, ctx, days=30, merchant=None, account=None):
    return bank.list_transactions(_acct(ctx, account), days, merchant)


def _txn_status(bank, ctx, txn_id, account=None):
    return bank.get_transaction_status(_acct(ctx, account), txn_id)


def _list_payees(bank, ctx):
    return bank.list_payees(ctx.customer_id)


def _get_card(bank, ctx, card=None):
    return bank.get_card(card or ctx.card)


def _add_payee(bank, ctx, name, vpa):
    return bank.add_payee(ctx.customer_id, name, vpa)


def _transfer(bank, ctx, vpa, amount, note=""):
    if vpa not in {p["vpa"] for p in bank.list_payees(ctx.customer_id)}:
        raise ValueError(f"{vpa} is not a saved payee. Add the payee first.")
    return bank.transfer(ctx.account, vpa, float(amount), note)


def _freeze(bank, ctx, card=None):
    return bank.set_card_status(card or ctx.card, "FROZEN")


def _unfreeze(bank, ctx, card=None):
    return bank.set_card_status(card or ctx.card, "ACTIVE")


def _dispute(bank, ctx, txn_id, reason):
    return bank.raise_dispute(ctx.account, txn_id, reason)


def _budget(bank, ctx, category, monthly_limit):
    return bank.set_budget_alert(ctx.customer_id, category, float(monthly_limit))


def _analytics(bank, ctx, code, days=30):
    txns = bank.list_transactions(ctx.account, days)
    slim = [{k: t[k] for k in ("id", "date", "merchant", "amount", "category", "status")} for t in txns]
    return {"result": run_sandboxed(code, slim)}


def _admin_export(bank, ctx):
    return bank.db["customers"]


def build_registry() -> ToolRegistry:
    S, N, I, B = "string", "number", "integer", "boolean"
    reg = ToolRegistry()
    add = reg.register
    add(Tool("get_balance", "Get current balance of the customer's account.",
             {"account": {"type": S, "description": "Account id (defaults to the customer's own)"}}, Risk.READ, _get_balance))
    add(Tool("list_transactions", "List recent transactions, optionally filtered by merchant.",
             {"days": {"type": I, "description": "Look-back window in days"},
              "merchant": {"type": S, "description": "Merchant name filter"},
              "account": {"type": S}}, Risk.READ, _list_txns))
    add(Tool("get_transaction_status", "Get the settlement status of one transaction.",
             {"txn_id": {"type": S, "required": True}, "account": {"type": S}}, Risk.READ, _txn_status))
    add(Tool("list_payees", "List the customer's saved UPI payees.", {}, Risk.READ, _list_payees))
    add(Tool("get_card", "Get debit card status (masked).", {"card": {"type": S}}, Risk.READ, _get_card))
    add(Tool("add_payee", "Save a new UPI payee.",
             {"name": {"type": S, "required": True}, "vpa": {"type": S, "required": True, "description": "UPI id"}},
             Risk.WRITE_HIGH, _add_payee))
    add(Tool("transfer_money", "Send money via UPI to a SAVED payee.",
             {"vpa": {"type": S, "required": True}, "amount": {"type": N, "required": True},
              "note": {"type": S}}, Risk.WRITE_HIGH, _transfer))
    add(Tool("freeze_card", "Temporarily freeze the debit card (protective).", {"card": {"type": S}}, Risk.WRITE_LOW, _freeze))
    add(Tool("unfreeze_card", "Unfreeze the debit card.", {"card": {"type": S}}, Risk.WRITE_HIGH, _unfreeze))
    add(Tool("raise_dispute", "Raise a chargeback dispute for a transaction.",
             {"txn_id": {"type": S, "required": True}, "reason": {"type": S, "required": True}},
             Risk.WRITE_HIGH, _dispute))
    add(Tool("set_budget_alert", "Set a monthly spend alert for a category.",
             {"category": {"type": S, "required": True, "enum": ["Food", "Shopping", "Travel", "Bills", "Entertainment"]},
              "monthly_limit": {"type": N, "required": True}}, Risk.WRITE_LOW, _budget))
    add(Tool("run_analytics", "Run a short Python snippet over the variable `txns` (list of dicts with id, date, "
                              "merchant, amount, category, status). Assign the answer to `result`. No imports.",
             {"code": {"type": S, "required": True}, "days": {"type": I}}, Risk.READ, _analytics))
    # Registered, but NOT on the customer_chat allowlist -> demonstrates sandbox layer 1
    add(Tool("admin_export_all_customers", "Export every customer record (back-office only).", {}, Risk.WRITE_HIGH, _admin_export))
    return reg

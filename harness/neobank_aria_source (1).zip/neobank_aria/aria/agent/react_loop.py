"""
S063 - The Agent Loop: Perceive -> Plan -> Act -> Observe     (ReAct style)

    PERCEIVE  take the customer's message, run input guardrails, add to memory,
              compact memory if it no longer fits the budget
    PLAN      ask the model for the next step given the WHOLE context
              (thought + one tool call, or a final answer)
    ACT       hand the proposed tool call to the harness (validation,
              permissions, human checkpoint, execution)
    OBSERVE   write the observation back into memory, update loop monitor
    ...repeat until a termination condition fires (S065)

ReAct re-plans after EVERY observation: adaptive, but one model call per step.
"""
from __future__ import annotations

import json
import uuid
from dataclasses import dataclass

from ..harness.guardrails import check_input, check_output
from ..harness.harness import Harness
from ..harness.memory import HybridStrategy
from ..harness.sandbox import ROLE_ALLOWLIST
from .llm import FinalAnswer, ToolCall
from .termination import LoopMonitor, StopReason, TerminationPolicy


@dataclass
class AgentResult:
    answer: str
    stop_reason: StopReason
    steps: int
    llm_calls: int
    tokens_used: int


def _short(obs) -> str:
    s = obs.to_json()
    return s if len(s) < 160 else s[:157] + "..."


class ReActAgent:
    def __init__(self, harness: Harness, llm, policy: TerminationPolicy | None = None, compaction=None):
        self.h = harness
        self.llm = llm
        self.policy = policy or TerminationPolicy()
        self.compaction = compaction or HybridStrategy(summarizer=getattr(llm, "summarize", None))
        self.monitor: LoopMonitor | None = None

    def visible_tools(self):
        """The model only ever SEES tools its role allows (least privilege starts at the prompt)."""
        allowed = ROLE_ALLOWLIST.get(self.h.ctx.role, set())
        return [t for t in self.h.tools.all() if t.name in allowed]

    def state(self) -> dict:
        m = self.monitor
        return {"loop": "react", "steps": m.steps if m else 0, "tokens_used": m.tokens_used if m else 0,
                "memory": self.h.memory.to_dict()}

    def run(self, user_text: str) -> AgentResult:
        tr, mem = self.h.tracer, self.h.memory
        llm_calls = 0

        # ---------------- PERCEIVE ----------------
        g = check_input(user_text)
        tr.log("PERCEIVE", f'customer says: "{g.text}"')
        if g.flags:
            tr.log("GUARD", f"input guardrail flags: {g.flags}")
        if g.blocked:
            ans = "I can't help with that request. If you need help with your account, just ask!"
            tr.log("STOP", "input blocked by guardrail")
            return AgentResult(ans, StopReason.INPUT_BLOCKED, 0, 0, 0)
        mem.add("user", g.text)

        self.monitor = LoopMonitor(self.policy)
        self.h.state_provider = self.state

        while True:
            if mem.maybe_compact(self.compaction):
                c = mem.compaction_log[-1]
                tr.log("COMPACT", f"{c['strategy']}: {c['before']} -> {c['after']} tokens")

            stop = self.monitor.before_step(mem.total_tokens())
            if stop:
                return self._graceful_stop(stop, llm_calls)

            # ---------------- PLAN ----------------
            decision = self.llm.decide(mem.context(), self.visible_tools())
            llm_calls += 1
            tr.llm_calls += 1

            if isinstance(decision, FinalAnswer):
                out = check_output(decision.text)
                if out.flags:
                    tr.log("GUARD", f"output guardrail flags: {out.flags}")
                mem.add("assistant", out.text)
                tr.log("FINAL", out.text)
                return AgentResult(out.text, StopReason.FINAL_ANSWER, self.monitor.steps, llm_calls,
                                   self.monitor.tokens_used)

            assert isinstance(decision, ToolCall)
            tr.log("PLAN", f"step {self.monitor.steps}: {decision.thought}")
            mem.add("assistant", f"Thought: {decision.thought}\nAction: {decision.name}({json.dumps(decision.args)})")

            # ---------------- ACT ----------------
            tr.log("ACT", f"{decision.name}({json.dumps(decision.args)})")
            obs = self.h.execute(decision.name, decision.args)

            # ---------------- OBSERVE ----------------
            mem.add("tool", obs.to_json(), name=decision.name)
            tr.log("OBSERVE", _short(obs))

            stop, nudge = self.monitor.after_action(decision.name, decision.args, obs.to_json(), obs.ok)
            if nudge:
                tr.log("STOP", "soft intervention: loop warning injected into context")
                mem.add("harness", nudge)
            if stop:
                return self._graceful_stop(stop, llm_calls)

    def _graceful_stop(self, reason: StopReason, llm_calls: int) -> AgentResult:
        """Never hang, never go silent: tell the customer what we know and hand off."""
        tr, mem = self.h.tracer, self.h.memory
        last_tool = next((m for m in reversed(mem.messages) if m.role == "tool"), None)
        found = ""
        if last_tool:
            try:
                d = json.loads(last_tool.content).get("data")
                if isinstance(d, dict):
                    found = " Latest information I have: " + ", ".join(f"{k}={v}" for k, v in d.items() if v) + "."
            except (json.JSONDecodeError, AttributeError):
                pass
        ticket = f"ESC-{uuid.uuid4().hex[:5].upper()}"
        ans = (f"I wasn't able to finish this automatically.{found} I've passed your request to a Kosh "
               f"support specialist (ticket {ticket}), who will get back to you within 2 hours.")
        tr.log("STOP", f"terminated: {reason.value} after {self.monitor.steps} steps, "
                       f"{self.monitor.tokens_used} tokens -> escalated {ticket}")
        mem.add("assistant", ans)
        tr.log("FINAL", ans)
        return AgentResult(ans, reason, self.monitor.steps, llm_calls, self.monitor.tokens_used)

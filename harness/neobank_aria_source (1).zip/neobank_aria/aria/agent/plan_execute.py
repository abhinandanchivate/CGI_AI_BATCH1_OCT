"""
S064 - Plan-and-Execute loop (contrast with ReAct in react_loop.py).

    PLANNER   one model call turns the goal into an ordered list of steps
    EXECUTOR  runs the steps one by one through the SAME harness
              (validation, permissions, HITL all still apply)
    REPLANNER called only when the plan is exhausted or a step fails;
              may append new steps (e.g. "freeze card" after spotting a
              foreign transaction) or return [] when the goal is met
    SYNTH     one final model call writes the customer reply

Fewer model calls and a reviewable plan up-front; less adaptive per step.
"""
from __future__ import annotations

import json

from ..harness.guardrails import check_input, check_output
from ..harness.harness import Harness
from ..harness.sandbox import ROLE_ALLOWLIST
from .react_loop import AgentResult, _short
from .termination import LoopMonitor, StopReason, TerminationPolicy


class PlanExecuteAgent:
    def __init__(self, harness: Harness, llm, policy: TerminationPolicy | None = None, max_replans: int = 3):
        self.h, self.llm = harness, llm
        self.policy = policy or TerminationPolicy()
        self.max_replans = max_replans

    def visible_tools(self):
        allowed = ROLE_ALLOWLIST.get(self.h.ctx.role, set())
        return [t for t in self.h.tools.all() if t.name in allowed]

    def run(self, goal: str) -> AgentResult:
        tr, mem = self.h.tracer, self.h.memory
        g = check_input(goal)
        tr.log("PERCEIVE", f'customer goal: "{g.text}"')
        if g.blocked:
            return AgentResult("I can't help with that request.", StopReason.INPUT_BLOCKED, 0, 0, 0)
        mem.add("user", g.text)
        monitor = LoopMonitor(self.policy)
        llm_calls = 0

        plan = self.llm.plan(g.text, self.visible_tools())
        monitor.tokens_used += mem.total_tokens()      # cost of the planner call
        llm_calls += 1
        tr.llm_calls += 1
        tr.log("PLANNER", f"plan with {len(plan)} steps:")
        for i, s in enumerate(plan, 1):
            tr.log("PLANNER", f"  {i}. {s.tool}({json.dumps(s.args)[:70]})  # {s.why}")

        results, replans = [], 0
        while plan:
            stop = monitor.before_step(0)        # executor makes no model call
            if stop:
                tr.log("STOP", f"terminated: {stop.value}")
                break
            step = plan.pop(0)
            tr.log("ACT", f"executor step {monitor.steps}: {step.tool}")
            obs = self.h.execute(step.tool, step.args)
            mem.add("tool", obs.to_json(), name=step.tool)
            tr.log("OBSERVE", _short(obs))
            results.append((step, obs))
            stop, _ = monitor.after_action(step.tool, step.args, obs.to_json(), obs.ok)
            if stop:
                tr.log("STOP", f"terminated: {stop.value}")
                break

            if (not plan or not obs.ok) and replans < self.max_replans:
                new = self.llm.replan(g.text, results, self.visible_tools())
                monitor.tokens_used += mem.total_tokens()
                llm_calls += 1
                tr.llm_calls += 1
                replans += 1
                if new:
                    tr.log("PLANNER", f"replan #{replans}: +{[s.tool for s in new]} ({new[0].why})")
                    plan = new + ([] if not obs.ok else plan)
                else:
                    tr.log("PLANNER", f"replan #{replans}: goal satisfied, no more steps")

        text = self.llm.synthesize(g.text, results)
        monitor.tokens_used += mem.total_tokens()
        llm_calls += 1
        tr.llm_calls += 1
        out = check_output(text)
        mem.add("assistant", out.text)
        tr.log("FINAL", out.text.replace("\n", "\n             "))
        return AgentResult(out.text, StopReason.FINAL_ANSWER, monitor.steps, llm_calls, monitor.tokens_used)

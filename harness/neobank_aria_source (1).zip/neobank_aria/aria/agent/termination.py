"""
S065 - Loop Termination Conditions & Infinite-Loop Prevention.

A loop with an LLM in it has no natural end. The harness must enforce one.
`LoopMonitor` checks, at every iteration:

  FINAL_ANSWER     the happy path - model says it is done
  MAX_STEPS        hard iteration cap
  TOKEN_BUDGET     cumulative tokens sent to the model (cost ceiling)
  TIMEOUT          wall-clock ceiling (customer is waiting in the app)
  REPEATED_ACTION  same tool + same args N times  (classic infinite loop)
  NO_PROGRESS      N identical observations in a row, even with different args
  ERROR_BUDGET     N consecutive failures/denials

Before a hard stop on repetition, the monitor first injects a NUDGE
("you already called X with these args; the result won't change") - a soft
intervention that often lets a real model recover on its own.
On any non-final stop the agent exits gracefully: tells the customer what it
found and hands off to a human (escalation ticket) instead of hanging.
"""
from __future__ import annotations

import hashlib
import json
import time
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum


class StopReason(str, Enum):
    FINAL_ANSWER = "final_answer"
    MAX_STEPS = "max_steps"
    TOKEN_BUDGET = "token_budget"
    TIMEOUT = "timeout"
    REPEATED_ACTION = "repeated_action"
    NO_PROGRESS = "no_progress"
    ERROR_BUDGET = "error_budget"
    INPUT_BLOCKED = "input_blocked"


@dataclass
class TerminationPolicy:
    max_steps: int = 8
    token_budget: int = 30_000
    max_seconds: float = 60.0
    repeat_threshold: int = 3
    no_progress_threshold: int = 3
    max_consecutive_errors: int = 3


def _h(obj) -> str:
    return hashlib.sha1(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:10]


@dataclass
class LoopMonitor:
    policy: TerminationPolicy
    steps: int = 0
    tokens_used: int = 0
    started: float = field(default_factory=time.time)
    action_counts: Counter = field(default_factory=Counter)
    recent_obs: list[str] = field(default_factory=list)
    consecutive_errors: int = 0

    def before_step(self, context_tokens: int) -> StopReason | None:
        if self.steps >= self.policy.max_steps:
            return StopReason.MAX_STEPS
        if self.tokens_used + context_tokens > self.policy.token_budget:
            return StopReason.TOKEN_BUDGET
        if time.time() - self.started > self.policy.max_seconds:
            return StopReason.TIMEOUT
        self.steps += 1
        self.tokens_used += context_tokens
        return None

    def after_action(self, name: str, args: dict, obs_json: str, ok: bool) -> tuple[StopReason | None, str | None]:
        """Returns (stop_reason, nudge_message)."""
        sig = _h([name, args])
        self.action_counts[sig] += 1
        n = self.action_counts[sig]

        self.recent_obs.append(_h(obs_json))
        self.consecutive_errors = 0 if ok else self.consecutive_errors + 1

        if n >= self.policy.repeat_threshold:
            return StopReason.REPEATED_ACTION, None
        tail = self.recent_obs[-self.policy.no_progress_threshold:]
        if len(tail) == self.policy.no_progress_threshold and len(set(tail)) == 1:
            return StopReason.NO_PROGRESS, None
        if self.consecutive_errors >= self.policy.max_consecutive_errors:
            return StopReason.ERROR_BUDGET, None
        if n == self.policy.repeat_threshold - 1:
            return None, (f"LOOP WARNING: you have called {name} with identical arguments {n} times and got the "
                          f"same kind of result. Calling it again will not change the outcome. Use a different "
                          f"approach or give the customer your final answer now.")
        return None, None


from typing import Literal

from pydantic import BaseModel, Field, EmailStr, field_validator , ConfigDict
class CustomerCreate(BaseModel):
    # Input rules: full_name 2–100 valid letters/separators, email format, phone 10 digits starting 6–9.  ==> pydantic spec i.e. CustomerCreate

    full_name: str = Field(min_length=2, max_length=100, description="Full name must be 2-100 characters long and contain only letters and spaces.")
    email: EmailStr
    phone: str = Field(pattern=r'^[6-9]\d{9}$', description="Phone number must be 10 digits long and start with a digit between 6 and 9.")

    @field_validator('full_name')
    def validate_full_name(cls, value:str):
        value = " ".join(value.split())  # Remove extra spaces
        if len(value)< 2 or not all (c.isalpha() or c.isspace() for c in value):
            raise ValueError("Full name must be 2-100 characters long and contain only letters and spaces.")
        return value

class CustomerUpdate(CustomerCreate):
    pass
class CustomerOut(CustomerCreate):
    # Output rules: full_name, email, phone.  ==> pydantic spec i.e. CustomerOut
    id: int
    model_config = ConfigDict(from_attributes=True)
    # model_config : used to configure the model's behavior.
    # ConfigDict: configuration helper ==> from_attributes= true ==> it will tell pydentic to read the values from object attreibutes not onlly from dicts.
    # from_attributes: 
    
class AccountCreate(BaseModel):
    customer_id: int = Field(gt=0, description="Customer ID must be a positive integer.")
    account_number: str = Field(pattern=r'^[0-9]{12}$')
    account_type: str = Literal["SAVINGS", "CURRENT"]
    balance: Decimal = Field(default=Decimal("0.00"), ge=Decimal("0.00"), max_digits=14, decimal_places=2, description="Balance must be a non-negative decimal number.")
class AccountUpdate(BaseModel):
    account_type: str = Literal["SAVINGS", "CURRENT"]
class AccountOut(AccountCreate):
    #response work
    id: int
    model_config = ConfigDict(from_attributes=True)



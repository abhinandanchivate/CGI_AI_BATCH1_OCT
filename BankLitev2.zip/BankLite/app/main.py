from fastapi import FastAPI
from app.config import settings
from app.database import Base, engine
from app.models import Customer

def create_app(create_tables: bool = True) -> FastAPI:
    app = FastAPI(title=settings.app_name)
    if create_tables:
       
        Base.metadata.create_all(bind=engine) # only in training ==> production 
    app.include_router(Customer.router,prefix="/api/v1")

    @app.get("/health", status_code=200, tags=["health"])
    def health_check():
        return {"status": "ok"}
    return app

app = create_app()